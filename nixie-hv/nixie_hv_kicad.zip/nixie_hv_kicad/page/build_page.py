#!/usr/bin/env python3
"""Build the decision page: page_tpl.html + ../generator/{kit,footprints,pcbkit}.json + the two generator scripts -> index.html.
    python3 build_page.py [out.html]
ZIPV in the environment becomes the ?v= tag on the zip link, so a CDN cannot serve an older zip (publish.sh sets it).
"""
import json, os, sys
here = os.path.dirname(os.path.abspath(__file__)); gen = os.path.join(here, "..", "generator")
rd = lambda f: open(os.path.join(gen, f), encoding="utf-8").read()
emb = lambda f: json.dumps(json.loads(rd(f)), ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
js = lambda f: rd(f).split("if (typeof module")[0]
page = open(os.path.join(here, "page_tpl.html"), encoding="utf-8").read()
for k, v in (("__KIT__", emb("kit.json")), ("__FPDATA__", emb("footprints.json")), ("__PCBKIT__", emb("pcbkit.json")),
             ("__ASSEMBLE_JS__", js("assemble.js")), ("__PCBGEN_JS__", js("pcbgen.js")), ("__ZIPV__", os.environ.get("ZIPV", "0"))):
    assert page.count(k) == 1, k
    page = page.replace(k, v)
out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "index.html")
open(out, "w", encoding="utf-8").write(page)
print("%s: %.0f kB" % (out, len(page.encode()) / 1e3))
