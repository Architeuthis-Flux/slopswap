// Minimal GLB reader: every mesh primitive with its node path, colour, world-space positions and indices.
import fs from "node:fs";
const CT = { 5120: Int8Array, 5121: Uint8Array, 5122: Int16Array, 5123: Uint16Array, 5125: Uint32Array, 5126: Float32Array }, NC = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 };
const mul = (a, b) => { const o = new Array(16).fill(0); for (let r = 0; r < 4; r++) for (let c = 0; c < 4; c++) for (let k = 0; k < 4; k++) o[r * 4 + c] += a[r * 4 + k] * b[k * 4 + c]; return o; };   // row-major
const I4 = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
function nodeMat(nd) {
  if (nd.matrix) { const m = nd.matrix; return [m[0], m[4], m[8], m[12], m[1], m[5], m[9], m[13], m[2], m[6], m[10], m[14], m[3], m[7], m[11], m[15]]; }
  let M = I4.slice();
  if (nd.scale) M = mul([nd.scale[0], 0, 0, 0, 0, nd.scale[1], 0, 0, 0, 0, nd.scale[2], 0, 0, 0, 0, 1], M);
  if (nd.rotation) { const [x, y, z, w] = nd.rotation; M = mul([1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w), 0, 2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w), 0, 2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y), 0, 0, 0, 0, 1], M); }
  if (nd.translation) M = mul([1, 0, 0, nd.translation[0], 0, 1, 0, nd.translation[1], 0, 0, 1, nd.translation[2], 0, 0, 0, 1], M);
  return M;
}
export function loadGlb(path) {
  const b = fs.readFileSync(path); if (b.toString("latin1", 0, 4) !== "glTF") throw new Error("not a GLB: " + path);
  const n = b.readUInt32LE(12), j = JSON.parse(b.toString("utf8", 20, 20 + n)), o = 20 + n, bin = b.subarray(o + 8, o + 8 + b.readUInt32LE(o));
  const acc = i => { const a = j.accessors[i], v = j.bufferViews[a.bufferView], Ty = CT[a.componentType], k = NC[a.type], off = (v.byteOffset || 0) + (a.byteOffset || 0), st = v.byteStride || Ty.BYTES_PER_ELEMENT * k, out = new Float64Array(a.count * k);
    const dv = new DataView(bin.buffer, bin.byteOffset + off), rd = { 5120: "getInt8", 5121: "getUint8", 5122: "getInt16", 5123: "getUint16", 5125: "getUint32", 5126: "getFloat32" }[a.componentType];
    for (let r = 0; r < a.count; r++) for (let c = 0; c < k; c++) out[r * k + c] = dv[rd](r * st + c * Ty.BYTES_PER_ELEMENT, true);
    return out; };
  const prims = [];
  const walk = (i, M, path) => { const nd = j.nodes[i], M2 = mul(M, nodeMat(nd)), p2 = path.concat(nd.name || "");
    if (nd.mesh !== undefined) for (const pr of j.meshes[nd.mesh].primitives) {
      const p = acc(pr.attributes.POSITION), pos = new Float64Array(p.length);
      for (let q = 0; q < p.length; q += 3) for (let r = 0; r < 3; r++) pos[q + r] = M2[r * 4] * p[q] + M2[r * 4 + 1] * p[q + 1] + M2[r * 4 + 2] * p[q + 2] + M2[r * 4 + 3];
      const idx = pr.indices !== undefined ? Array.from(acc(pr.indices)) : Array.from({ length: p.length / 3 }, (_, q) => q), mt = pr.material !== undefined ? j.materials[pr.material] : {};
      const col = ((mt.pbrMetallicRoughness || {}).baseColorFactor || [0.6, 0.6, 0.6, 1]).slice(0, 3);
      prims.push({ path: p2.join("/"), color: col, pos, idx, mat: mt.name || "" });
    }
    for (const c of nd.children || []) walk(c, M2, p2); };
  for (const r of j.scenes[j.scene || 0].nodes) walk(r, I4, []);
  return prims;
}
if (process.argv[1].endsWith("glb.mjs")) for (const f of process.argv.slice(2)) {
  const prims = loadGlb(f), seen = new Map(); let lo = [1e9, 1e9, 1e9], hi = [-1e9, -1e9, -1e9];
  for (const p of prims) { const k = p.path.slice(0, 60) + " | " + p.color.map(c => c.toFixed(2)) + " | " + p.mat.slice(0, 16), s = seen.get(k) || seen.set(k, { t: 0, lo: [1e9, 1e9, 1e9], hi: [-1e9, -1e9, -1e9] }).get(k); s.t += p.idx.length / 3;
    for (let q = 0; q < p.pos.length; q += 3) for (let r = 0; r < 3; r++) { s.lo[r] = Math.min(s.lo[r], p.pos[q + r]); s.hi[r] = Math.max(s.hi[r], p.pos[q + r]); lo[r] = Math.min(lo[r], p.pos[q + r]); hi[r] = Math.max(hi[r], p.pos[q + r]); } }
  console.log(f, "prims", prims.length, "bbox", lo.map(v => +v.toFixed(5)), hi.map(v => +v.toFixed(5)));
  [...seen].slice(0, 12).forEach(([k, s]) => console.log("   ", k, "tris", s.t, s.lo.map(v => +v.toFixed(5)), s.hi.map(v => +v.toFixed(5))));
}
