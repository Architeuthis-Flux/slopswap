#!/usr/bin/env node
// Part meshes for the 3D preview, in the mesh format of the Jumperless V6 outline viewer (v6mech src/partmodels.js):
//   { s, groups: [{ color, q: 1, i32, pos: base64 int16 xyz (times s = mm), idx: base64 uint16/32, pad?: 1 }] }
// Each footprint in ../generator/pcbkit.json is put alone on a board and exported by KiCad itself
// (kicad-cli pcb export glb), so the model's offset, rotation and scale are KiCad's, not re-derived here.
// Frame: the footprint's own, x right, y down (KiCad), z up from the board's top face, mm.
// Triangles are wound for the viewer's frame (x, z, y).
//   node prep_models.mjs            needs KiCad 9 or 10; writes nixie-models.js next to this file
import fs from "node:fs"; import path from "node:path"; import os from "node:os"; import { execFileSync } from "node:child_process"; import { fileURLToPath } from "node:url";
import { loadGlb } from "./glb.mjs";
const here = path.dirname(fileURLToPath(import.meta.url)), root = path.join(here, "..");
const CLI = process.env.KICAD_CLI || "/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli";
const LIB = process.env.KICAD_3DMODELS || "/Applications/KiCad/KiCad.app/Contents/SharedSupport/3dmodels";
const pk = JSON.parse(fs.readFileSync(path.join(root, "generator/pcbkit.json"), "utf8")), fpTable = JSON.parse(fs.readFileSync(path.join(root, "generator/footprints.json"), "utf8"));
const T = 0.8, tmp = fs.mkdtempSync(path.join(os.tmpdir(), "nixie3d-"));
for (const d of ["NixieHV.pretty", "NixieHV.3dshapes", "fp-lib-table"]) fs.cpSync(path.join(root, "nixie_hv", d), path.join(tmp, d), { recursive: true });
const b64 = ta => Buffer.from(ta.buffer, ta.byteOffset, ta.byteLength).toString("base64");
// T1's STEP came out of Omnixie's model without colours: these three are painted by hand, after the vendor's photo
const PAINT = { "NixieHV:TTRN-060S": { "/1": [0.16, 0.16, 0.17], "/2": [0.78, 0.5, 0.12], "/3": [0.07, 0.07, 0.08] } };

function exportOne(key) {
  let t = pk.fps[key].F0.t.split("@@REF@@").join("X1").split("@@VAL@@").join("v").replace(/\(net \d+ "@@[^@]*@@"\)/g, "");
  // kicad-cli does not resolve the old ${KICADn_3DMODEL_DIR} names: point each model at the STEP file in this KiCad's own library
  t = t.replace(/\(model "\$\{KICAD[0-9]+_3DMODEL_DIR\}\/([^"]+?)\.(?:wrl|step|stp)"/g, (m, rel) => '(model "' + path.join(LIB, rel + ".step") + '"');
  const rect = pk.rect.replace("11.111", "-30").replace("22.222", "-30").replace("33.333", "30").replace("44.444", "30");
  const pcb = path.join(tmp, "one.kicad_pcb"), glb = path.join(tmp, "one.glb");
  fs.writeFileSync(pcb, pk.head + t + "\n" + rect + "\n)\n"); fs.rmSync(glb, { force: true });
  execFileSync(CLI, ["pcb", "export", "glb", "--no-board-body", "--include-pads", "--user-origin", "0x0mm", "-f", "-o", glb, pcb], { stdio: "pipe" });
  return loadGlb(glb);
}
// which way KiCad's y runs in the export: the transformer has three pads on its +y end, one of them on the centre line
const ySign = (() => { const z = []; for (const p of exportOne("NixieHV:TTRN-060S")) if (!p.path.includes("/X1/")) for (let q = 0; q < p.pos.length; q += 3) if (Math.abs(p.pos[q]) < 0.0004) z.push(p.pos[q + 2]);
  if (!z.length || !(z.every(v => v > 0) || z.every(v => v < 0))) throw new Error("cannot tell which way y runs in the export"); return z[0] > 0 ? 1 : -1; })();

const models = {}, report = [];
for (const key of Object.keys(pk.fps)) {
  const prims = exportOne(key), groups = new Map(); let nb = 0, np = 0;
  for (const p of prims) {
    const body = p.path.includes("/X1/"), paint = body && PAINT[key] && Object.entries(PAINT[key]).find(([suf]) => p.path.endsWith(suf));
    const col = body ? (paint ? paint[1] : p.color) : [0.85, 0.71, 0.25], gk = (body ? "b" : "p") + col.map(v => Math.round(v * 255)).join(",");
    const g = groups.get(gk) || groups.set(gk, { color: col.map(v => +(+v).toFixed(3)), pad: !body, xyz: [], idx: [], map: new Map() }).get(gk);
    const vmap = new Map();
    for (let t3 = 0; t3 < p.idx.length; t3 += 3) {
      const tri = [0, 1, 2].map(k => { const vi = p.idx[t3 + k]; let ni = vmap.get(vi);
        if (ni === undefined) {
          const x = p.pos[vi * 3] * 1000, y = ySign * p.pos[vi * 3 + 2] * 1000; let z = p.pos[vi * 3 + 1] * 1000 - T;
          if (!body) z += z > -T / 2 ? 0.1 : -0.1;          // KiCad sinks the copper into the board body: stand it just proud of each face
          const k3 = Math.round(x * 2000) + "," + Math.round(y * 2000) + "," + Math.round(z * 2000);
          ni = g.map.get(k3); if (ni === undefined) { ni = g.xyz.length / 3; g.xyz.push(x, y, z); g.map.set(k3, ni); } vmap.set(vi, ni);
        } return ni; });
      if (tri[0] === tri[1] || tri[1] === tri[2] || tri[0] === tri[2]) continue;
      if (ySign < 0) tri.reverse();                         // keep the outside of each face outside in the viewer's frame
      g.idx.push(...tri); body ? nb++ : np++;
    }
  }
  const all = [...groups.values()].filter(g => g.idx.length), maxAbs = Math.max(1e-6, ...all.flatMap(g => g.xyz.map(Math.abs))), s = +(maxAbs / 32760).toPrecision(6);
  const lo = [1e9, 1e9, 1e9], hi = [-1e9, -1e9, -1e9];
  for (const g of all) if (!g.pad) for (let q = 0; q < g.xyz.length; q++) { lo[q % 3] = Math.min(lo[q % 3], g.xyz[q]); hi[q % 3] = Math.max(hi[q % 3], g.xyz[q]); }
  models[key] = { s, bbox: nb ? [lo.map(v => +v.toFixed(3)), hi.map(v => +v.toFixed(3))] : null,
    groups: all.map(g => ({ color: g.color, q: 1, i32: g.xyz.length / 3 > 65535, pos: b64(Int16Array.from(g.xyz, v => Math.round(v / s))), idx: b64(g.xyz.length / 3 > 65535 ? Uint32Array.from(g.idx) : Uint16Array.from(g.idx)), ...(g.pad ? { pad: 1 } : {}) })) };
  const f = fpTable[key], want = !!(f && f.model && f.ok3d !== false);
  report.push([key.split(":")[1].slice(0, 46).padEnd(46), "body " + String(nb).padStart(6), "pads " + String(np).padStart(5), nb ? "z " + lo[2].toFixed(2) + ".." + hi[2].toFixed(2) + (f ? "  table " + f.z : "") : (want ? "MISSING BODY" : "no model")].join("  "));
  if (want && !nb) { console.log(report.join("\n")); throw new Error("no body came out for " + key + ", whose model the table says is in KiCad's library"); }
  if (!np) throw new Error("no pads came out for " + key);
}
// how each placed variant turns the footprint, read off the pad positions the board kit already holds: [a, b, c, d] with x' = a x + b y, y' = c x + d y
const variants = {};
for (const [key, vs] of Object.entries(pk.fps)) { const p0 = vs.F0.pads, ids = Object.keys(p0).filter(k => Math.hypot(p0[k][0], p0[k][1]) > 0.3);
  for (const [vk, v] of Object.entries(vs)) for (const a of ids) for (const b of ids) { const [x1, y1] = p0[a], [x2, y2] = p0[b], det = x1 * y2 - x2 * y1; if (Math.abs(det) < 0.5) continue;
    const [u1, v1] = v.pads[a], [u2, v2] = v.pads[b], M = [(u1 * y2 - u2 * y1) / det, (x1 * u2 - x2 * u1) / det, (v1 * y2 - v2 * y1) / det, (x1 * v2 - x2 * v1) / det].map(n => Math.round(n));
    if (!variants[vk]) variants[vk] = M; else if (variants[vk].join() !== M.join()) throw new Error("variant " + vk + " turns " + key + " differently: " + M + " vs " + variants[vk]); } }
console.log(report.join("\n")); console.log("y runs", ySign > 0 ? "with" : "against", "the export's z; variants", JSON.stringify(variants));
const out = path.join(here, "nixie-models.js");
fs.writeFileSync(out, "// Built by prep_models.mjs from KiCad's 3D models (kicad-cli pcb export glb, one footprint at a time). Do not edit.\n// Frame: the footprint's own, x right, y down, z up from the board's top face, int16 times s = mm. pad: 1 marks copper.\n" +
  "window.NIXIE_MODELS = " + JSON.stringify({ T, variants, models }) + ";\n");
console.log("wrote", out, (fs.statSync(out).size / 1e3).toFixed(0), "kB"); fs.rmSync(tmp, { recursive: true, force: true });
