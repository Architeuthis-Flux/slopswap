#!/usr/bin/env node
// Check the 3D preview's placement against KiCad itself, and measure the closed stack with the real part models.
//   node check3d.mjs          needs KiCad 9 or 10 (kicad-cli)
// 1. For a one-board layout and a stacked one, the generated .kicad_pcb is exported by kicad-cli (GLB, parts only) and
//    every part's box there is compared with the box the preview's own maths (view3d.js) gives it. Fails over 0.05 mm in
//    plan or 0.1 mm in height. (KiCad seats underside parts 0.09 mm lower than a plain 0.8 mm board would: its export
//    makes the board 0.71 mm of laminate with copper and mask on each face, so 0.89 mm between the two seating planes.)
// 2. For stacked layouts, the boards are closed with the same maths and the smallest gaps are reported: part to facing
//    board, part to facing part, and how far the tails of outside-mounted through-hole parts reach into the gap.
import fs from "node:fs"; import path from "node:path"; import os from "node:os"; import { execFileSync } from "node:child_process"; import { fileURLToPath } from "node:url"; import { createRequire } from "node:module";
import { loadGlb } from "./glb.mjs";
const here = path.dirname(fileURLToPath(import.meta.url)), root = path.join(here, ".."), require = createRequire(import.meta.url);
const A = require("../generator/assemble.js"); Object.assign(globalThis, A);
const Gen = require("../generator/pcbgen.js"), M = require("./view3d.js");
const rd = f => JSON.parse(fs.readFileSync(path.join(root, "generator", f), "utf8")), KIT = rd("kit.json"), PK = rd("pcbkit.json"), FP = rd("footprints.json");
const win = {}; new Function("window", fs.readFileSync(path.join(here, "nixie-models.js"), "utf8"))(win); const D = win.NIXIE_MODELS, T = D.T;
const CLI = process.env.KICAD_CLI || "/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli", LIB = process.env.KICAD_3DMODELS || "/Applications/KiCad/KiCad.app/Contents/SharedSupport/3dmodels";
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "nixie3dchk-"));
for (const d of ["NixieHV.pretty", "NixieHV.3dshapes", "fp-lib-table"]) fs.cpSync(path.join(root, "nixie_hv", d), path.join(tmp, d), { recursive: true });
const SMALL = { cout: "c0805", cin: "1x0805", rsense: "0603", auxpkg: "yff", led: "0", cell: "cast", io: "cast", trimpads: "none", pass: "0201", jp: "link" };
const dec = {}; const verts = key => dec[key] || (dec[key] = D.models[key] ? M.decode(D.models[key]).filter(g => !g.pad) : []);
const boxOf = (key, Am) => { const lo = [1e9, 1e9, 1e9], hi = [-1e9, -1e9, -1e9]; let n = 0;
  for (const g of verts(key)) for (let i = 0; i < g.xyz.length; i += 3) { const q = M.at(Am, g.xyz[i], g.xyz[i + 1], g.xyz[i + 2]); for (let a = 0; a < 3; a++) { lo[a] = Math.min(lo[a], q[a]); hi[a] = Math.max(hi[a], q[a]); } n++; }
  return n ? { lo, hi } : null; };
function layout(o) {
  const P = A.partsOfKit(KIT, o).map(m => { const key = m.fpk || m.fp; return { ref: m.ref, name: m.val, fpn: key, f: FP[key], pid: m.pid || null, g: m.g, fit: m.dnp === "no", u: m.u }; });
  const on = A.normaliseOpts(KIT, o);
  return Gen.layoutBoard(P, PK.fps, { mode: "env", W: 11, gap: 0, low: true, stack: on.stack === "two" ? { t1: on.stackt1, nets: Gen.netlistKit(KIT, o), t: T } : null });
}
let bad = 0;
function againstKicad(name, o) {
  const lay = layout(o); let pcb = Gen.assemblePcb(PK, KIT, o, lay).text;
  pcb = pcb.replace(/\(model "\$\{KICAD[0-9]+_3DMODEL_DIR\}\/([^"]+?)\.(?:wrl|step|stp)"/g, (m, rel) => '(model "' + path.join(LIB, rel + ".step") + '"');
  const f = path.join(tmp, "nixie_hv.kicad_pcb"), glb = path.join(tmp, "b.glb"); fs.writeFileSync(f, pcb); fs.rmSync(glb, { force: true });
  execFileSync(CLI, ["pcb", "export", "glb", "--no-board-body", "--user-origin", "100x60mm", "-f", "-o", glb, f], { stdio: "pipe" });
  const kc = new Map();
  for (const p of loadGlb(glb)) { const ref = p.path.split("/")[1]; const b = kc.get(ref) || kc.set(ref, { lo: [1e9, 1e9, 1e9], hi: [-1e9, -1e9, -1e9] }).get(ref);
    for (let i = 0; i < p.pos.length; i += 3) { const q = [p.pos[i] * 1000, p.pos[i + 2] * 1000, p.pos[i + 1] * 1000 - T]; for (let a = 0; a < 3; a++) { b.lo[a] = Math.min(b.lo[a], q[a]); b.hi[a] = Math.max(b.hi[a], q[a]); } } }
  let n = 0, worst = 0, worstZ = 0, worstRef = "", under = 0;
  for (const r of lay.placed) {
    const p = r.it.p, q = M.pose(r, D, T, false); if (!q || !q.body || r.both) continue;       // KiCad's file has every part on its board's parts side
    const mine = boxOf(p.fpn, q.body); if (!mine) continue;
    if (q.brd) { mine.lo[1] += lay.W + 6; mine.hi[1] += lay.W + 6; }                           // board 2 is drawn 6 mm below board 1
    const k = kc.get(p.ref); if (!k) { console.log("  " + name + ": KiCad exported no body for " + p.ref + " (" + p.fpn + ")"); bad++; continue; }
    const d = Math.max(...[0, 1].flatMap(a => [Math.abs(mine.lo[a] - k.lo[a]), Math.abs(mine.hi[a] - k.hi[a])])), dz = Math.max(Math.abs(mine.lo[2] - k.lo[2]), Math.abs(mine.hi[2] - k.hi[2]));
    if (d > worst) { worst = d; worstRef = p.ref; } worstZ = Math.max(worstZ, dz); n++; if (q.body[10] < 0) under++;
    if (d > 0.05 || dz > 0.1) { bad++; console.log("  " + name + ": " + p.ref + " is off by " + d.toFixed(3) + " mm in plan, " + dz.toFixed(3) + " in height  mine " + mine.lo.map(v => v.toFixed(2)) + " .. " + mine.hi.map(v => v.toFixed(2)) + "  KiCad " + k.lo.map(v => v.toFixed(2)) + " .. " + k.hi.map(v => v.toFixed(2))); }
  }
  console.log(name + ": " + n + " part bodies compared with KiCad's export (" + under + " on the underside" + (lay.stack ? ", " + lay.placed.filter(r => r.brd === 1).length + " on board 2" : "") + "), worst difference " + worst.toFixed(3) + " mm in plan" + (worstRef ? " (" + worstRef + ")" : "") + ", " + worstZ.toFixed(3) + " mm in height");
}
function closed(name, o, quiet) {
  const lay = layout(o), st = lay.stack, W = lay.W, Gp = st.G, parts = [];
  for (const r of lay.placed) {
    const p = r.it.p, q = M.pose(r, D, T, true); if (!q || !q.body || r.both) continue;
    const b = boxOf(p.fpn, M.mul(M.inStack(q.brd, W, Gp, 0), q.body)); if (b) parts.push({ ref: p.ref, brd: q.brd, outside: q.outside, ...b });
  }
  const inside = parts.filter(p => !p.outside), rows = []; let through = "";
  for (const p of inside) {
    const gap = p.brd ? p.lo[2] : Gp - p.hi[2];
    if (st.slot && p.ref === "T1") {              // it passes through the cut-out: it must stop inside the board's thickness
      through = " T1 stands " + (-gap).toFixed(2) + " mm into the cut-out of the " + T + " mm board."; if (-gap > T + 1e-6) { bad++; console.log("  " + name + ": T1 comes out past the facing board's outside face"); }
    } else rows.push([gap, p.ref + " to the facing board"]);
  }
  for (const a of inside.filter(p => !p.brd)) for (const b of inside.filter(p => p.brd))
    if (a.lo[0] < b.hi[0] && b.lo[0] < a.hi[0] && a.lo[1] < b.hi[1] && b.lo[1] < a.hi[1]) rows.push([b.lo[2] - a.hi[2], a.ref + " to " + b.ref]);
  rows.sort((x, y) => x[0] - y[0]);
  if (quiet) return rows[0] || [9, ""];
  const tails = parts.filter(p => p.outside).map(p => p.ref + " " + (p.brd ? Gp - p.lo[2] : p.hi[2]).toFixed(1) + " mm");
  console.log(name + ": gap " + Gp + " mm. Smallest clearances with the real models: " + rows.slice(0, 3).map(r => r[0].toFixed(2) + " mm " + r[1]).join("; ") + "." + through +
    (tails.length ? " Untrimmed tails of outside-mounted parts reach into the gap: " + tails.join(", ") + " (the placement allows 2 mm)." : ""));
  if (rows.length && rows[0][0] < 0) { bad++; console.log("  " + name + ": parts collide when the stack is closed"); }
}
againstKicad("one board, as drawn", {});
againstKicad("one board, smallest with USB", SMALL);
againstKicad("stacked preset", { ...SMALL, stack: "two" });
againstKicad("stacked, as drawn", { stack: "two" });
closed("stacked preset", { ...SMALL, stack: "two" });
closed("stacked preset, slot", { ...SMALL, stack: "two", stackt1: "slot" });
closed("stacked, as drawn", { stack: "two" });
closed("stacked, as drawn, slot", { stack: "two", stackt1: "slot" });
closed("stacked, 1812 output capacitor and SMD trimmer", { stack: "two", cout: "c1812", trimpads: "smd", trimfit: "smd", io: "cast", cell: "cast" });
// 3. the same closing, over random option sets (the ones check_stack.js draws), both transformer choices
{ let seed = 7; const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648, N = Number(process.argv[2]) || 300, hits = new Map(); let min = [9, "", ""], neg = 0;
  for (let i = 0; i < N; i++) {
    const o = {}; for (const [k, v] of KIT.options) o[k] = i < KIT.options.length ? (KIT.options[i][0] === k ? v[v.length - 1] : v[0]) : v[Math.floor(rnd() * v.length)];
    o.stack = "two"; o.usbtype = "h"; o.stackt1 = i % 2 ? "slot" : "in";
    const r = closed("", o, true); if (r[0] < min[0]) min = [r[0], r[1], KIT.options.map(([k, v]) => o[k] === v[0] ? "" : k + "=" + o[k]).filter(Boolean).join(" ")];
    if (r[0] < 0) { neg++; const k = r[1].replace(/\d+/g, "n"); hits.set(r[1], (hits.get(r[1]) || 0) + 1); }
  }
  console.log(N + " random stacked option sets closed with the real models: smallest gap " + min[0].toFixed(2) + " mm (" + min[1] + "; " + min[2] + "); " + neg + " sets collide" + (neg ? ": " + [...hits].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, n]) => k + " x" + n).join(", ") : ""));
  if (neg) bad++; }
fs.rmSync(tmp, { recursive: true, force: true });
if (bad) { console.log(bad + " problem(s)"); process.exit(1); }
console.log("placement agrees with KiCad; no collisions in the closed stacks checked");
