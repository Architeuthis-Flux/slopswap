Nixie HV supply - KiCad files
=============================

The decision page these come from: https://slopswap.org/nixie-hv/

nixie_hv/                 the board as drawn (the default switches on the decision page): 50 x 11 mm
    nixie_hv.kicad_pro / .kicad_sch / .kicad_pcb     written for KiCad 9; KiCad 10 opens them
    nixie_hv.pdf                        plot of the sheet
    nixie_hv_bom.csv                    parts list
    NixieHV.kicad_sym, sym-lib-table    project symbols (MAX668, BQ25171, TPS61099 in both
                                        packages, TLV61220, CSD17318Q2, CSD85302L, transformer)
    NixieHV.pretty, fp-lib-table        project footprints:
        TTRN-060S                         transformer land pattern from Tokyo Coil's sheet
        Castellated_1x02_P2.54mm          cell or HV: two plated half-holes on the board edge
        Castellated_1x10_P1.27mm          I/O: ten plated half-holes on the board edge
        Pads_1x02_P2.54mm, Pads_1x10_P1.27mm
        StackPin_P1.27mm                  one plated hole for a header pin joining two stacked boards
    NixieHV.3dshapes/TTRN-060S.step     the transformer, cut out of Omnixie's STEP model of the
                                        NCH8200HV (where it is labelled TTRN-060S)

nixie_hv_smallest_usb/    the "Smallest with USB charging" preset: 29.8 x 11 mm, which fits behind
                          an IN-16 and under an IN-12 (11 x 31 mm)

nixie_hv_stacked/         the same preset as two stacked boards with the parts on the facing sides:
                          two boards of 32.2 x 11 mm, 5.0 mm apart, 6.6 mm over all

Every project folder holds a placed board, nixie_hv.kicad_pcb
    - every footprint placed, on the side it belongs, with its nets assigned and the outline drawn
    - grouped by function from one end to the other: USB-C and charger, cell and protection,
      aux boost, flyback, then the 170 V parts and the HV connection at the far end
    - NOT routed: no tracks, vias or copper pours. Reference designators are hidden on silkscreen
    - design rules in nixie_hv.kicad_pro: 0.15 mm clearance (needed by 0201 and the 0.4 mm-pitch
      boost converter) and a net class "HV" at 0.45 mm for the 170 V nets. Treat 0.45 mm as a
      starting value and set it to your own standard

Stacked boards (stack=two)
    - one .kicad_pcb with two outlines, 6 mm apart, each drawn from its parts side like an open
      book. Fold the lower outline up over the long edge between them: a point (x, y) on the
      upper outline (board 1) ends up under (x, width - y) of the lower one (board 2)
    - board 1 carries the USB-C socket and every outside connection; board 2 the flyback and the
      170 V parts. The charger, the cell protection or the aux boost move to board 2 when that
      makes the two boards more even in length
    - every net with pads on both boards gets a pin post: footprints SPnA (board 1) and SPnB
      (board 2) are one 0.4 mm square header pin through both. The low-voltage ones stand in a
      row beside the transformer; ground posts stand at each end, and 170 V crosses at the far end.
      They are marked "not in schematic". KiCad lists each as an unconnected item, because it
      cannot know the two pads are joined off the board
    - the gap is the tallest inside part plus 0.2 mm. stackt1=slot lets the transformer pass
      through a cut-out in board 1, which brings the gap down to its height less one 0.8 mm board
    - through-hole headers and a through-hole pot are meant to be mounted on the outside faces;
      solder pads (io=pads, cell=pads) are placed on the outside face of board 1. The placement
      allows 2 mm inside the gap for the through-hole parts' solder tails: trim them to that.
      The board file still draws those through-hole parts on the parts side (their footprints
      were only written out for that side): flip them to the back before judging the stack in 3D
    - nothing is placed facing the transformer. Facing parts are kept 0.2 mm apart, 0.5 mm from
      the 170 V parts. KiCad cannot check clearance between two boards: look at it in 3D
    - a stack is usually longer than one board with the same options, not shorter: the area facing
      the transformer is lost and the posts take room. It buys closed-in 170 V parts, two flat
      outside faces and one-sided assembly

generator/                the same generators the decision page uses
    node nixie_hv_gen.js --list                    every option and its values
    node nixie_hv_gen.js -o ../nixie_hv --width 11 io=cast cell=cast pass=0201
    node nixie_hv_gen.js -o ../nixie_hv_stacked --width 11 io=cast cell=cast stack=two stackt1=slot
        writes the schematic AND the board (needs Node.js, nothing else)
    python3 nixie_hv_gen.py -o ../nixie_hv/nixie_hv.kicad_sch io=cast cell=cast pass=0201
        writes the schematic only (needs Python 3)
    node check_stack.js 400                        self-check of the stacked placement
    The option string is the one the page shows. The page's two Build buttons give the same files.
    kit.json and pcbkit.json are the source for both: the schematic, and every footprint already
    written out for each side and rotation.

page/                     the decision page's source
    python3 build_page.py     page_tpl.html + the generator's files -> index.html, with the 3D view's
                              files copied beside it

view3d/                   the 3D preview on the page
    three.min.js, OrbitControls.js, render.js
                              taken unchanged from the Jumperless V6 outline viewer (v6mech): three.js r128
                              and its orbit controls (MIT, three-LICENSE.txt), and v6mech's lighting and materials
    view3d.js                 the view itself, after v6mech's viewer.js. Its placement maths is plain
                              numbers, so check3d.mjs runs the same code
    nixie-models.js           every footprint's body and pads as meshes, in v6mech's mesh format
    node prep_models.mjs      rebuilds nixie-models.js: each footprint is put alone on a board and
                              exported by kicad-cli, so the model's offset and rotation are KiCad's own
                              (needs KiCad 9 or 10; glb.mjs reads the export)
    node check3d.mjs          compares the preview's placement with KiCad's export of whole generated
                              boards, and measures closed stacks with the real models (needs KiCad)
    The page works without these files: the 3D panel then says it could not load.

nch8200hv_as_built/       the Omnixie NCH8200HV as it is built, reverse-engineered from the
                          vendor's photos and datasheet. NOT in the published zip

Checked
    - the schematic's connectivity against an independently written netlist for 1686 option sets,
      and KiCad 9.0.9 ERC (0 errors, 0 warnings) on 110 of them. That was before the two stack
      options were added; they change nothing in the schematic but the option string printed on it
    - one-board boards through KiCad 9.0.9 DRC with schematic parity on 70 option sets. The
      generator still writes those two saved one-board .kicad_pcb files byte for byte; their
      schematics differ from the earlier ones only in the option string printed on the sheet
    - with KiCad 10.0.6: ERC and DRC on the three project folders here: no errors (KiCad 10 warns
      that symbols and footprints differ from its newer libraries)
    - stacked boards through KiCad 10.0.6 DRC with schematic parity on 20 option sets (11 chosen,
      9 random): no errors; seven of them have silkscreen warnings between close neighbours.
      fet=q60 was run as well and fails only inside its own footprint from KiCad's library
    - check_stack.js on 400 random option sets at 11, 13 and 18 mm wide: nothing overlaps on a
      face, leaves the outline or sits in the cut-out, and facing parts fit the gap
    - the page's stacked build against the script's: identical board files for the stacked preset
      and for the as-drawn options stacked
    - the 3D preview's placement against KiCad 10.0.6's own export of four generated boards (166
      part bodies, on both sides and on both boards): the same in plan to 0.001 mm. Underside
      parts sit 0.09 mm higher than KiCad puts them, because KiCad's export has 0.89 mm between
      the two seating planes of a 0.8 mm board
    - 400 random stacked option sets closed with the real part models (check3d.mjs): none
      collide, and the smallest gap is 0.20 mm (USB socket to the charger). The placement works
      from a table of part heights (generator/footprints.json), and KiCad's models are up to
      0.25 mm taller than it for a few parts (0805 inductor, SOT-23), so a real gap can be
      smaller than the rule's figure; in these sets none was. The transformer has 0.40 mm above
      it when it is inside. The untrimmed tails of the 2.54 mm header reach 2.2 mm into the
      gap, against the 2 mm the placement allows: trim them
    - the 1812 output capacitor's height in that table was 2.0 mm; it is 2.5 mm (TDK's sheet and
      KiCad's model) and is corrected. No saved board uses that part, and the three project
      folders regenerate unchanged

Not checked
    - nothing has been built or simulated
    - the stacked build: clearance between the boards in 3D, the length of pin that spans them,
      how the gap is held while soldering, and whether the slotted board is stiff enough
    - T1 is the NCH8200HV's transformer, Tokyo Coil TTRN-060S-054. Tokyo Coil publishes figures
      only for the -055 (10.8 uH, 1:18, 2.7 A); the -054's are not published
    - the TTRN-060S land pattern is read as a top view of the board. Check which end is pin 1
      against a real part before ordering boards
    - Q2's pin numbers are KiCad's for the CSD17313Q2 (same 2 x 2 mm package family): check them
      against the CSD17318Q2 datasheet
    - Q1 (CSD85302L, 1.35 mm LGA) has no footprint or 3D model yet, so the boards leave it off;
      the vertical USB-C socket (usbtype=v) likewise
    - the boards are placements, not finished layouts: nothing is routed, and the USB-C socket
      sits flush with the board edge rather than at the overhang its drawing shows
    - RV1's footprint is KiCad's Bourns 3314G, a stand-in for the TOCOS G43BT land pattern
    - KiCad's footprint for the DSBGA boost converter points at a 3D model that is not in
      KiCad's 3D library, so the 3D preview shows a plain block for it
    - in the 3D preview the transformer's colours are painted by hand (its STEP carries none),
      and the boards are plain: no tracks, silkscreen or drilled holes
