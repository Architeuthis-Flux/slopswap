// Board generator: netlist from the schematic kit, placement by function, and the .kicad_pcb text.
// Used by the decision page and, under node, by the checks that run KiCad's DRC on the result.

class Bin {            // free space on one side of the board, kept as maximal free rectangles
  constructor(L, W) { this.free = [{ x: 0, y: 0, w: L, h: W }]; }
  find(w, h) {         // best short side fit, either orientation (tightest packing)
    let best = null;
    for (const f of this.free) {
      for (const [a, b, rot] of [[w, h, false], [h, w, true]]) {
        if (a <= f.w + 1e-6 && b <= f.h + 1e-6) {
          const s = Math.min(f.w - a, f.h - b), l = Math.max(f.w - a, f.h - b), sc = s * 1000 + l;
          if (!best || sc < best.sc) best = { x: f.x, y: f.y, w: a, h: b, sc, rot };
        }
      }
    }
    return best;
  }
  findBL(w, h, minX, ok) { // leftmost, then topmost, position at or right of minX; ok(r) can veto a position
    let best = null;
    for (const f of this.free) {
      const x = Math.max(f.x, minX);
      if (x + w <= f.x + f.w + 1e-6 && h <= f.h + 1e-6) {
        for (const y of ok ? [f.y, f.y + f.h - h] : [f.y]) {
          if (ok && !ok({ x, y, w, h })) continue;
          if (!best || x < best.x - 1e-6 || (Math.abs(x - best.x) < 1e-6 && y < best.y)) best = { x, y, w, h };
        }
      }
    }
    return best;
  }
  isFree(r) {
    return this.free.some(f => r.x >= f.x - 1e-6 && r.y >= f.y - 1e-6 && r.x + r.w <= f.x + f.w + 1e-6 && r.y + r.h <= f.y + f.h + 1e-6);
  }
  occupy(r) {
    const out = [];
    for (const f of this.free) {
      if (r.x >= f.x + f.w - 1e-6 || r.x + r.w <= f.x + 1e-6 || r.y >= f.y + f.h - 1e-6 || r.y + r.h <= f.y + 1e-6) { out.push(f); continue; }
      if (r.x > f.x + 1e-6) out.push({ x: f.x, y: f.y, w: r.x - f.x, h: f.h });
      if (r.x + r.w < f.x + f.w - 1e-6) out.push({ x: r.x + r.w, y: f.y, w: f.x + f.w - r.x - r.w, h: f.h });
      if (r.y > f.y + 1e-6) out.push({ x: f.x, y: f.y, w: f.w, h: r.y - f.y });
      if (r.y + r.h < f.y + f.h - 1e-6) out.push({ x: f.x, y: r.y + r.h, w: f.w, h: f.y + f.h - r.y - r.h });
    }
    const keep = out.filter(a => a.w > .3 && a.h > .3);
    this.free = keep.filter((a, i) => !keep.some((b, j) => j !== i && a.x >= b.x - 1e-6 && a.y >= b.y - 1e-6 && a.x + a.w <= b.x + b.w + 1e-6 && a.y + a.h <= b.y + b.h + 1e-6 && (j < i || !(Math.abs(a.x - b.x) < 1e-6 && Math.abs(a.y - b.y) < 1e-6 && Math.abs(a.w - b.w) < 1e-6 && Math.abs(a.h - b.h) < 1e-6))));
  }
}

// ---------------------------------------------------------------- netlist
function netlistKit(kit, opts) {      // Map "REF.PIN" -> net name, named the way KiCad names them
  const o = normaliseOpts(kit, opts), sel = kit.els.filter(e => e.c.every(a => atomOk(a, o)));
  const par = new Map();
  const find = k => { if (!par.has(k)) par.set(k, k); let r = k; while (par.get(r) !== r) r = par.get(r); while (par.get(k) !== r) { const n = par.get(k); par.set(k, r); k = n; } return r; };
  const uni = (a, b) => { const ra = find(a), rb = find(b); if (ra !== rb) par.set(ra, rb); };
  const pins = [];
  for (const e of sel) {
    if (e.w) uni("p" + e.w[0] + "," + e.w[1], "p" + e.w[2] + "," + e.w[3]);
    if (e.lb) uni("p" + e.lb[2] + "," + e.lb[3], "n" + (e.lb[0] === "local" ? "/" : "") + e.lb[1]);
    if (e.p) e.p.forEach((pt, i) => {
      const k = "p" + pt[0] + "," + pt[1];
      if (e.pw) uni(k, "n" + e.pw);
      else if (e.r[0] !== "#") { const id = e.r + "." + e.pn[i]; uni("i" + id, k); pins.push([id, e.r, e.pn[i], e.pm[i]]); }
      else find(k);
    });
  }
  const rank = n => (n[0] === "/" ? "1" : "0") + n, names = new Map(), count = new Map();
  for (const k of [...par.keys()]) if (k[0] === "n") { const r = find(k), n = k.slice(1), c = names.get(r); if (!c || rank(n) < rank(c)) names.set(r, n); }
  for (const [id] of pins) { const r = find("i" + id); count.set(r, (count.get(r) || 0) + 1); }
  const out = new Map();
  for (const [id, ref, num, nm] of pins) {
    const r = find("i" + id); let n = names.get(r);
    if (!n) n = count.get(r) === 1 ? "unconnected-(" + ref + "-" + nm + "-Pad" + num + ")" : "Net-(" + ref + "-Pad" + num + ")";
    out.set(id, n);
  }
  return out;
}

// ---------------------------------------------------------------- placement by function
const HV_REFS = ["D2", "C11", "C12", "R14", "R15", "J3"];
const ZONES = ["chg", "cell", "aux", "fly", "hv"];
function zoneOf(p) {
  if (HV_REFS.includes(p.ref)) return "hv";
  if (p.ref === "J1") return p.f.end ? "usb" : "chg";
  if (p.ref === "J4") return "io";
  if (p.ref === "J2" || p.g === "prot") return "cell";
  if (p.g === "chg") return "chg";
  if (p.g === "aux") return "aux";
  return "fly";
}
function placeByFunction(P, V, W, gap, low) {
  const LMAX = 400, EM = 0.4, A = new Bin(LMAX, W), B = new Bin(LMAX, W), bins = [A, B], out = [], ext = [0, 0];
  for (const b of bins) { b.occupy({ x: 0, y: 0, w: LMAX, h: EM }); b.occupy({ x: 0, y: W - EM, w: LMAX, h: EM }); b.occupy({ x: 0, y: 0, w: EM, h: W }); }   // keep copper off the board edge
  const dim = (p, vk) => { const v = V[p.fpn] && V[p.fpn][vk]; return v ? { w: v.bb[2] - v.bb[0] + gap, h: v.bb[3] - v.bb[1] + gap, bb: v.bb } : null; };
  const put = (side, r, p, vk, at) => {       // side 0 top, 1 bottom, 2 through the board
    const rc = { x: r.x, y: Math.max(0, r.y), w: r.w, h: Math.min(W, r.y + r.h) - Math.max(0, r.y) };
    if (side !== 1) A.occupy(rc); if (side !== 0) B.occupy(rc);
    const v = vk && V[p.fpn] ? V[p.fpn][vk] : null, deg = vk ? Number(vk.slice(1)) : (r.rot ? 90 : 0);
    out.push({ x: r.x, y: r.y, w: r.w, h: r.h, side, it: { p }, vkey: vk || null, deg, rot: deg % 180 === 90, at: at || null,
               ox: v ? r.x + gap / 2 - v.bb[0] : null, oy: v ? r.y + gap / 2 - v.bb[1] : null });
    if (side !== 1) ext[0] = Math.max(ext[0], r.x + r.w); if (side !== 0) ext[1] = Math.max(ext[1], r.x + r.w);
    return out[out.length - 1];
  };
  const edgeScan = (w, h, y, minX, both, sideOnly) => {     // slide along an edge until the strip is free
    for (let x = minX; x < LMAX - w; x += 0.25) {
      const ya = Math.max(EM, y), yb = Math.min(W - EM, y + h), r = { x, y: ya, w, h: yb - ya }, free = b => r.h <= 1e-6 || b.isFree(r);
      const okA = sideOnly === 1 || free(A), okB = (sideOnly === 0 && !both) || free(B);
      if (okA && okB) return { x, y, w, h };
    }
    return null;
  };
  const by = z => P.filter(p => zoneOf(p) === z);
  const x0 = EM;
  // USB-C at the left end, mouth outward
  const usb = by("usb")[0];
  if (usb) {
    if (usb.f.end) {
      const vk = "F270", d = dim(usb, vk);
      if (d.h > W + 1e-6) return { fail: "usb" };
      A.occupy({ x: 0, y: 0, w: d.w, h: W });
      const rr = put(0, { x: 0, y: (W - d.h) / 2, w: d.w, h: d.h }, usb, vk);
      for (const t of V[usb.fpn][vk].th) B.occupy({ x: Math.max(0, rr.ox + t[0] - 0.5), y: Math.max(0, rr.oy + t[1] - 0.5), w: t[2] - t[0] + 1, h: t[3] - t[1] + 1 });   // its stakes come through
    }
  }
  // I/O along the bottom edge, starting beside the socket
  const io = by("io")[0];
  if (io) {
    if (io.f.edge) { const d = dim(io, "F0"); put(2, edgeScan(d.w, d.h, W - d.h + 0.045, x0, true), io, "F0", "b"); out[out.length - 1].oy = W; }
    else if (io.f.th) { const d = dim(io, "F90"); put(2, edgeScan(d.w, d.h, W - EM - d.h, x0, true), io, "F90", "b"); }
    else { const d = dim(io, "B0"); put(1, edgeScan(d.w, d.h, W - EM - d.h, x0, false, 1), io, "B0", "b"); }
  }
  const starts = [EM];
  const placeItem = (p, minX, force) => {
    const tall = p.fit && p.f.z > 2, conn = /^J/.test(p.ref);
    const topOnly = p.f.th || (low && tall) || conn || (typeof force === "string" && force !== "B");
    const sides = topOnly ? [0] : (force === "B" && V[p.fpn] && V[p.fpn].B0 ? [1] : [0, 1]);
    let best = null;
    for (const s of sides) {
      const vks = force && force !== "B" ? [force] : (V[p.fpn] ? [(s ? "B" : "F") + "0", (s ? "B" : "F") + "90"].filter(k => V[p.fpn][k]) : [null, "rot"]);
      for (const vk of vks) {
        let d = vk && vk !== "rot" ? dim(p, vk) : { w: (vk === "rot" ? p.f.ch : p.f.cw) + gap, h: (vk === "rot" ? p.f.cw : p.f.ch) + gap };
        if (!d || d.h > W + 1e-6) continue;
        let mx = minX, r = null;
        for (let n = 0; n < 400; n++) {
          r = bins[s].findBL(d.w, d.h, mx);
          if (!r) break;
          if (!p.f.th || B.isFree(r)) break;
          mx = r.x + 0.25; r = null;
        }
        if (!r) continue;
        const pref = (s === 1 ? 0 : 0.3) + (p.f.z <= 1 ? 0 : (s === 0 ? -0.6 : 0));    // small parts lean to the bottom, taller ones to the top
        const score = r.x + pref + r.y * 1e-3;
        if (!best || score < best.score) best = { r, s, vk: vk === "rot" ? null : vk, score, rot: vk === "rot" };
      }
    }
    if (!best) return null;
    best.r.rot = best.rot;
    return put(p.f.th ? 2 : best.s, best.r, p, best.vk);
  };
  const size = p => p.f.cw * p.f.ch;
  for (const z of ZONES) {
    let items = by(z), minX = starts[starts.length - 1], zs = Infinity;
    if (z === "hv") {
      const t1 = out.find(r => r.it.p.ref === "T1"), t1r = t1 ? t1.x + t1.w : 0;
      const lead = ext[0] <= t1r + 1e-6 ? 0.2 : 1.0;
      minX = Math.max(ext[0] + lead, ext[1] + 1.0, t1r);
      items = HV_REFS.map(r => items.find(p => p.ref === r)).filter(Boolean);
    } else if (z === "fly") {
      // anything that must be on top goes first, then the input capacitors, then the transformer hard against them;
      // the controller, switch and their passives go underneath, so nothing low-voltage ends up beyond the transformer
      const core = ["C8", "C9", "T1"].map(r => items.find(p => p.ref === r)).filter(Boolean);
      const mustTop = items.filter(p => !core.includes(p) && (p.f.th || (low && p.fit && p.f.z > 2) || !(V[p.fpn] && V[p.fpn].B0)));
      const under = items.filter(p => !core.includes(p) && !mustTop.includes(p)).sort((a, b) => size(b) - size(a));
      under.forEach(p => { p._under = true; });
      items = mustTop.concat(core, under);
    } else items = items.slice().sort((a, b) => (/^[UQJL]/.test(b.ref) - /^[UQJL]/.test(a.ref)) || size(b) - size(a));
    for (const p of items) {
      let r;
      if (p.ref === "J2") {            // the cell connection sits on the top edge
        const vk = "F180", d = dim(p, vk);
        const e = edgeScan(d.w, d.h, p.f.edge ? -0.045 : (/JST/.test(p.fpn) ? 0 : EM), minX, p.f.edge, p.f.edge ? undefined : 0);
        r = put(p.f.edge ? 2 : 0, e, p, vk, "t"); if (p.f.edge) r.oy = 0;
      } else if (p.ref === "J3" && p.f.edge) continue;
      else r = placeItem(p, minX, p.ref === "T1" ? "F90" : (p._under ? "B" : null));
      if (!r) return { fail: "wide" };
      zs = Math.min(zs, r.x);
    }
    starts.push(isFinite(zs) ? zs : minX);
  }
  let L = Math.max(ext[0], ext[1]);
  const j3 = P.find(p => p.ref === "J3" && p.f.edge);
  if (j3) {                            // HV out on the far end
    const d = dim(j3, "F90"), r = put(2, { x: L + 0.2, y: (W - d.h) / 2, w: d.w, h: d.h }, j3, "F90", "r");
    r.ox = Math.ceil((L + 0.2 + d.w - 0.045) * 10) / 10; r.x = r.ox - (d.w - 0.045); L = r.ox;
  } else L = Math.ceil((L + EM) * 10) / 10;
  return { W, L, placed: out };
}
// ---------------------------------------------------------------- two stacked boards, parts on the facing sides
// Board 0 carries the USB socket and every outside connection; board 1 the flyback and the 170 V parts.
// Each is laid out in its own component-side view, the pair opened like a book along a long edge, so a
// point (x, y) on board 0 lies under (x, W - y) on board 1. Facing parts must clear each other in the gap,
// and nothing may face the transformer. Every net with pads on both boards gets one pin post.
const PIN_FP = "NixieHV:StackPin_P1.27mm", PIN_P = 1.27, PIN_W = 1.5, HV_NETS = ["/HV", "/SEC", "/FBT"];
function placeStack(P, V, W, gap, st, onB1, t1Top) {   // st: {t1:"in"|"slot", nets:Map, t:board thickness}
  const LMAX = 400, EM = 0.4, T = st.t || 0.8, slot = st.t1 === "slot";
  const brd = p => { const z = zoneOf(p); return /^J[1-4]$/.test(p.ref) ? 0 : (z === "fly" || z === "hv" || onB1.includes(z)) ? 1 : 0; };
  const through = p => !!p.f.th && !p.f.edge, outer = p => /:Pads_/.test(p.fpn);   // these sit on, or solder to, the outside face
  const zin = p => (!p.fit || through(p) || outer(p)) ? 0 : p.f.z, hvRef = p => p.ref === "T1" || HV_REFS.includes(p.ref);
  const t1 = P.find(p => p.ref === "T1");
  const need = Math.max(0.2 + Math.max(0, ...P.filter(p => !(slot && p === t1)).map(zin)), slot && t1 ? t1.f.z - T : 0);
  const G = Math.ceil(Math.round(need * 100) / 10) / 10;          // the air gap between the boards
  const I = [new Bin(LMAX, W), new Bin(LMAX, W)], O = new Bin(LMAX, W), out = [], ext = [0, 0], solid = [[], []];   // inner faces; outer face of board 0
  for (const b of [I[0], I[1], O]) { b.occupy({ x: 0, y: 0, w: LMAX, h: EM }); b.occupy({ x: 0, y: W - EM, w: LMAX, h: EM }); b.occupy({ x: 0, y: 0, w: EM, h: W }); }
  const mir = r => ({ x: r.x, y: W - r.y - r.h, w: r.w, h: r.h });
  const clip = r => { const y = Math.max(0, r.y); return { x: r.x, y, w: r.w, h: Math.min(W, r.y + r.h) - y }; };
  const dim = (p, vk) => { const v = V[p.fpn] && V[p.fpn][vk]; return v ? { w: v.bb[2] - v.bb[0] + gap, h: v.bb[3] - v.bb[1] + gap, bb: v.bb } : null; };
  const clash = (b, r, p) => { const s = b ? mir(r) : r, z = zin(p), hv = hvRef(p);
    return solid[1 - b].some(o => o.x < s.x + s.w - 1e-6 && s.x < o.x + o.w - 1e-6 && o.y < s.y + s.h - 1e-6 && s.y < o.y + o.h - 1e-6 && o.z + z + (hv || o.hv ? 0.5 : 0.2) > G + 1e-6); };
  const put = (b, side, r, p, vk, at) => {       // side 0 inner face, 1 outer face, 2 through this board
    const rc = clip(r);
    if (side !== 1) I[b].occupy(rc); if (b === 0 && side !== 0) O.occupy(rc);
    const v = vk && V[p.fpn] ? V[p.fpn][vk] : null, deg = vk ? Number(vk.slice(1)) : (r.rot ? 90 : 0);
    out.push({ x: r.x, y: r.y, w: r.w, h: r.h, side, brd: b, it: { p }, vkey: vk || null, deg, rot: deg % 180 === 90, at: at || null,
               ox: v ? r.x + gap / 2 - v.bb[0] : null, oy: v ? r.y + gap / 2 - v.bb[1] : null });
    ext[b] = Math.max(ext[b], r.x + r.w);
    if (zin(p) > 0) solid[b].push({ ...(b ? mir(rc) : rc), z: zin(p), hv: hvRef(p) });
    return out[out.length - 1];
  };
  const scan = (w, h, y, minX, p, needI, needO) => {   // board 0: slide along an edge until the strip is free and clears board 1
    for (let x = minX; x < LMAX - w; x += 0.25) {
      const ya = Math.max(EM, y), yb = Math.min(W - EM, y + h), r = { x, y: ya, w, h: yb - ya };
      if ((!needI || r.h <= 1e-6 || I[0].isFree(r)) && (!needO || r.h <= 1e-6 || O.isFree(r)) && !(needI && clash(0, { x, y, w, h }, p))) return { x, y, w, h };
    }
    return null;
  };
  const placeItem = (b, p, minX, force, keep) => {
    const th = through(p), ou = outer(p) && b === 0, bin = ou ? O : I[b];
    const vks = force ? [force] : (V[p.fpn] ? (ou ? ["B0", "B90"] : ["F0", "F90"]).filter(k => V[p.fpn][k]) : [null, "rot"]);
    const near = r => out.some(q => (q.brd === b || q.both) && (th || (ou ? q.side !== 0 : q.side !== 1)) && q.x < r.x + r.w + keep && r.x < q.x + q.w + keep && q.y < r.y + r.h + keep && r.y < q.y + q.h + keep);
    const ok = r => !(th && b === 0 && !O.isFree(r)) && (ou || !clash(b, r, p)) && !(keep && near(r));
    let best = null;
    for (const vk of vks) {
      const d = vk && vk !== "rot" ? dim(p, vk) : { w: (vk === "rot" ? p.f.ch : p.f.cw) + gap, h: (vk === "rot" ? p.f.cw : p.f.ch) + gap };
      if (!d || d.h > W + 1e-6) continue;
      let r = null;
      for (let mx = minX, n = 0; n < 1200 && !r; n++, mx += 0.25) r = bin.findBL(d.w, d.h, mx, ok);
      if (!r) continue;
      const score = r.x + r.y * 1e-3;
      if (!best || score < best.score) best = { r, vk: vk === "rot" ? null : vk, score, rot: vk === "rot" };
    }
    if (!best) return null;
    best.r.rot = best.rot;
    return put(b, th ? 2 : ou ? 1 : 0, best.r, p, best.vk);
  };
  const by = (b, z) => P.filter(p => brd(p) === b && zoneOf(p) === z && !/^J[1-4]$/.test(p.ref));
  // USB-C at the left end of board 0, mouth outward
  const usb = P.find(p => p.ref === "J1");
  let x0 = EM;
  if (usb) {
    if (usb.f.end) {
      const vk = "F270", d = dim(usb, vk);
      if (d.h > W + 1e-6) return { fail: "usb" };
      I[0].occupy({ x: 0, y: 0, w: d.w, h: W });
      const rr = put(0, 0, { x: 0, y: (W - d.h) / 2, w: d.w, h: d.h }, usb, vk);
      for (const t of V[usb.fpn][vk].th) O.occupy({ x: Math.max(0, rr.ox + t[0] - 0.5), y: Math.max(0, rr.oy + t[1] - 0.5), w: t[2] - t[0] + 1, h: t[3] - t[1] + 1 });
      x0 = d.w;
    } else if (!placeItem(0, usb, EM)) return { fail: "wide" };
  }
  // one pin post for every net that has pads on both boards
  const bo = new Map(P.map(p => [p.ref, brd(p)])), on = new Map();
  for (const [id, net] of st.nets) { const b = bo.get(id.slice(0, id.lastIndexOf("."))); if (b === undefined || /^unconnected-/.test(net)) continue; on.set(net, (on.get(net) || 0) | (1 << b)); }
  const cross = [...on].filter(([, m]) => m === 3).map(([n]) => n).sort((a, b) => (b === "GND") - (a === "GND") || (a < b ? -1 : 1));
  const lvPins = cross.filter(n => !HV_NETS.includes(n)), hvPins = cross.filter(n => HV_NETS.includes(n));
  let pc = 0;
  const post = (net, x, yc, row) => {            // x: left edge; yc: centre, both in board 0 coordinates; a row runs along the board
    const r = { x, y: yc - PIN_P / 2, w: row ? PIN_P : PIN_W, h: PIN_P };
    if (row) while (!(I[0].isFree(r) && O.isFree(r) && I[1].isFree(mir(r)))) { r.x += PIN_P; if (r.x > LMAX - 2) return; }
    I[0].occupy(r); O.occupy(r); I[1].occupy(mir(r)); x = r.x;
    const p = { ref: "SP" + (++pc), name: net.replace(/^\//, ""), fpn: PIN_FP, pid: "post", g: "stk", fit: true, net,
                f: { cw: PIN_W, ch: PIN_P, bw: 1, bh: 1, th: true, z: 0, pkg: "pin post, 1.27 mm pitch", model: null } };
    out.push({ ...r, side: 2, brd: 0, both: true, it: { p }, vkey: "F0", deg: 0, rot: false, at: null, ox: x + r.w / 2, oy: yc - (row && !t1Top ? 0.1 : 0) });
    ext[0] = Math.max(ext[0], x + r.w); ext[1] = Math.max(ext[1], x + r.w);
  };
  const corners = x => { if (cross.includes("GND")) { post("GND", x, EM + PIN_P / 2); post("GND", x, W - EM - PIN_P / 2); } };
  corners(x0);                                    // two ground posts hold the socket end together
  // board 1 first: the transformer has to stand clear of the socket, and board 0 then works round the transformer
  let slotRect = null;
  const zones = b => b ? ZONES.filter(z => onB1.includes(z)).concat("fly", "hv") : ZONES.filter(z => !onB1.includes(z) && z !== "fly" && z !== "hv");
  const size = p => p.f.cw * p.f.ch;
  for (const b of [1, 0]) {
    const starts = [b ? EM : x0];
    if (b === 0) {                                // the outside connections: I/O along the bottom edge, the cell on the top edge
      const io = P.find(p => p.ref === "J4"), cell = P.find(p => p.ref === "J2");
      if (io) {
        let r;
        if (io.f.edge) { const d = dim(io, "F0"); r = scan(d.w, d.h, W - d.h + 0.045, x0, io, true, true); if (r) put(0, 2, r, io, "F0", "b").oy = W; }
        else if (io.f.th) { const d = dim(io, "F90"); r = scan(d.w, d.h, W - EM - d.h, x0, io, true, true); if (r) put(0, 2, r, io, "F90", "b"); }
        else { const d = dim(io, "B0"); r = scan(d.w, d.h, W - EM - d.h, x0, io, false, true); if (r) put(0, 1, r, io, "B0", "b"); }
        if (!r) return { fail: "wide" };
      }
      if (cell) {
        let r;
        if (cell.f.edge) { const d = dim(cell, "F180"); r = scan(d.w, d.h, -0.045, x0, cell, true, true); if (r) put(0, 2, r, cell, "F180", "t").oy = 0; }
        else if (outer(cell)) { const d = dim(cell, "B0"); r = scan(d.w, d.h, EM, x0, cell, false, true); if (r) put(0, 1, r, cell, "B0", "t"); }
        else { const d = dim(cell, "F180"); r = scan(d.w, d.h, /JST/.test(cell.fpn) ? 0 : EM, x0, cell, true, false); if (r) put(0, 0, r, cell, "F180", "t"); }
        if (!r) return { fail: "wide" };
      }
    }
    for (const z of zones(b)) {
      let items = by(b, z), minX = starts[starts.length - 1], zs = Infinity;
      if (z === "hv") {
        const tr = out.find(r => r.it.p.ref === "T1"), t1r = tr ? tr.x + tr.w : 0;
        minX = Math.max(ext[1] + (ext[1] <= t1r + 1e-6 ? 0.2 : 1.0), t1r);
        items = HV_REFS.map(r => items.find(p => p.ref === r)).filter(Boolean);
      } else if (z === "fly") {                   // controller and switch, input capacitors, the transformer against them, then the small parts in what is left
        const core = ["C8", "C9", "T1"].map(r => items.find(p => p.ref === r)).filter(Boolean);
        const rest = items.filter(p => !core.includes(p)).sort((a, b) => size(b) - size(a));
        items = rest.filter(p => size(p) > 2).concat(core, rest.filter(p => size(p) <= 2));
      } else items = items.slice().sort((a, b) => (/^[UQL]/.test(b.ref) - /^[UQL]/.test(a.ref)) || size(b) - size(a));
      for (const p of items) {
        let r;
        if (p === t1) {                           // centred, which leaves a rail either side of it; or hard against one edge, which leaves one wider strip
          const d = dim(p, "F90"), y = t1Top ? W - EM - d.h : (W - d.h) / 2;
          for (let x = minX; x < LMAX - d.w && !r; x += 0.25) { const c = { x, y, w: d.w, h: d.h }; if (I[1].isFree(c) && !clash(1, c, p)) r = put(1, 0, c, p, "F90"); }
          if (r) { const yc = (t1Top ? EM + d.h + 0.1 : EM) + PIN_P / 2; lvPins.forEach(n => post(n, r.x, yc, true)); }   // the low-voltage posts stand beside it, from its primary end
        } else r = placeItem(b, p, minX);
        if (!r) return { fail: "wide" };
        if (p === t1 && slot) {                   // the cut-out it passes through, on board 0
          const v = V[p.fpn][r.vkey], c = mir({ x: r.ox + v.bb[0], y: r.oy + v.bb[1], w: v.bb[2] - v.bb[0], h: v.bb[3] - v.bb[1] });
          if (!I[0].isFree(c) || !O.isFree(c)) return { fail: "wide" };
          I[0].occupy(c); O.occupy(c); slotRect = c;
        }
        zs = Math.min(zs, r.x);
      }
      starts.push(isFinite(zs) ? zs : minX);
    }
  }
  // the far end: the HV connection on board 0, then the posts that carry 170 V across and hold this end together
  const lv0 = ext[0], j3 = P.find(p => p.ref === "J3");
  if (j3 && !j3.f.edge && !placeItem(0, j3, Math.max(x0, ext[1] - 6), null, 1.0)) return { fail: "wide" };   // under the 170 V parts, 1 mm from everything else
  const xr = Math.max(ext[0] + 0.2, ext[1] + 0.2, hvPins.length ? lv0 + 1.0 : 0);
  corners(xr);
  hvPins.forEach((n, i) => post(n, xr, W / 2 + (i - (hvPins.length - 1) / 2) * 2 * PIN_P));
  let L = Math.max(ext[0], ext[1]);
  if (j3 && j3.f.edge) {
    const d = dim(j3, "F90"), r = put(0, 2, { x: L + 0.2, y: (W - d.h) / 2, w: d.w, h: d.h }, j3, "F90", "r");
    r.ox = Math.ceil((L + 0.2 + d.w - 0.045) * 10) / 10; r.x = r.ox - (d.w - 0.045); L = r.ox;
  } else L = Math.ceil((L + EM) * 10) / 10;
  const zo = b => Math.max(0, ...P.filter(p => p.fit && through(p) && brd(p) === b).map(p => p.f.z));   // parts standing on an outside face
  return { W, L, placed: out, stack: { G, T, slot: slotRect, pins: pc, cross, onB1, len: ext.map(v => Math.round(v * 10) / 10), outside: [zo(0), zo(1)], thick: zo(0) + T + G + T + zo(1) } };
}
function layoutStack(P, V, W, gap, st) {       // try each way of sharing the low-voltage blocks between the boards; keep the shortest
  let best = null, fail = null;
  for (let m = 0; m < 8; m++) {
    const onB1 = ["chg", "cell", "aux"].filter((z, i) => m >> i & 1);
    for (const top of st.t1 === "slot" ? [false] : [false, true]) {
      const r = placeStack(P, V, W, gap, st, onB1, top);
      if (r.fail) { fail = fail || r; continue; }
      if (!best || r.L < best.L - 1e-6 || (Math.abs(r.L - best.L) < 1e-6 && r.stack.pins < best.stack.pins)) best = r;
    }
  }
  return best || fail;
}
function layoutBoard(P, V, cfg) {      // cfg: {mode:"env"|"ratio", W, gap, low, stack:{t1, nets, t}|null}
  const area = P.reduce((a, p) => a + (p.f.cw + cfg.gap) * (p.f.ch + cfg.gap) * (p.f.th ? 2 : 1), 0);
  const bodyArea = P.reduce((a, p) => a + Math.min(p.f.bw, p.f.cw) * Math.min(p.f.bh, p.f.ch) * (p.f.th ? 2 : 1), 0);
  const fin = r => r.fail ? { W: cfg.W, L: 0, placed: [], area, bodyArea, fill: 0, fail: r.fail } : { ...r, area, bodyArea, fill: area / (2 * r.W * r.L) };
  const place = W => cfg.stack ? layoutStack(P, V, W, cfg.gap, cfg.stack) : placeByFunction(P, V, W, cfg.gap, cfg.low);
  if (cfg.mode !== "ratio") return fin(place(cfg.W));
  for (let W = 7.4; W < 40; W = Math.round((W + 0.2) * 10) / 10) {
    const r = place(W);
    if (!r.fail && r.L <= 4 * W) return fin({ ...r, L: Math.max(r.L, 0) });
  }
  return null;
}

// ---------------------------------------------------------------- .kicad_pcb
function assemblePcb(pcbkit, kit, opts, layout, origin) {
  const o = normaliseOpts(kit, opts), nl = netlistKit(kit, o);
  const names = [...new Set(nl.values())].sort(), code = new Map(names.map((n, i) => [n, i + 1]));
  const OX = origin ? origin[0] : 100, OY = origin ? origin[1] : 60, f = v => String(Math.round(v * 1000) / 1000);
  let uc = 0; const uuid = () => "70636230-0000-4000-8000-" + (++uc).toString(16).padStart(12, "0");
  const out = [pcbkit.head], skipped = [];
  names.forEach((n, i) => out.push('\t(net ' + (i + 1) + ' "' + n + '")\n'));
  const st = layout.stack, off = b => b ? layout.W + 6 : 0;      // a stack's second board is drawn 6 mm below the first
  for (const r of layout.placed) {
    const p = r.it.p;
    if (!r.vkey) { skipped.push(p.ref); continue; }
    for (const b of r.both ? [0, 1] : [r.brd || 0]) {            // a pin post is on both boards, mirrored across the fold
      let t = pcbkit.fps[p.fpn][r.vkey].t;
      t = t.replace("(at 0 0", "(at " + f(OX + r.ox) + " " + f(OY + off(b) + (r.both && b ? layout.W - r.oy : r.oy)));
      t = t.split("@@REF@@").join(r.both ? p.ref + "AB"[b] : p.ref).split("@@VAL@@").join(String(p.name).replace(/["\\]/g, ""));
      t = t.replace(/\(net \d+ "@@([^@]*)@@"\)/g, (m, num) => { const n = p.net || nl.get(p.ref + "." + num); return n ? '(net ' + code.get(n) + ' "' + n + '")' : ""; });
      t = t.replace(/\(path "[^"]*"\)/, '(path "/' + p.u + '")');
      if (!p.fit) t = t.replace(/\(attr ([^)]*)\)/, (m, s) => "(attr " + s + " dnp)");
      t = t.replace(/\(uuid "[^"]*"\)/g, () => '(uuid "' + uuid() + '")');
      out.push(t + "\n");
    }
  }
  const rect = (x, y, w, h) => out.push(pcbkit.rect.replace("11.111", f(OX + x)).replace("22.222", f(OY + y)).replace("33.333", f(OX + x + w)).replace("44.444", f(OY + y + h)).replace(/\(uuid "[^"]*"\)/, '(uuid "' + uuid() + '")') + "\n");
  rect(0, 0, layout.L, layout.W);
  if (st) { rect(0, off(1), layout.L, layout.W); if (st.slot) rect(st.slot.x, st.slot.y, st.slot.w, st.slot.h); }
  const note = (st ? "Nixie HV supply, two stacked boards of " + f(layout.L) + " x " + f(layout.W) + " mm, parts on the facing sides, " + f(st.G) + " mm apart. Each is drawn from its parts side: " +
      "fold the lower outline up over the long edge between them. Posts SPnA and SPnB are one pin through both boards." + (st.slot ? " The transformer passes through the cut-out in the upper outline." : "") + " Placed by function, not routed."
    : "Nixie HV supply " + f(layout.L) + " x " + f(layout.W) + " mm. Parts placed by function, not routed.") +
    (skipped.length ? " Not on the board (no footprint yet): " + skipped.join(", ") + "." : "");
  out.push(pcbkit.text.replace("@@NOTE@@", note).replace("55.555", f(OX)).replace("66.666", f(OY + (st ? 2 * layout.W + 6 : layout.W) + 3)).replace(/\(uuid "[^"]*"\)/, '(uuid "' + uuid() + '")') + "\n");
  out.push(")\n");
  return { text: out.join(""), skipped, nets: names.length, count: layout.placed.reduce((a, r) => a + (r.vkey ? (r.both ? 2 : 1) : 0), 0) };
}
if (typeof module !== "undefined") module.exports = { Bin, netlistKit, placeByFunction, layoutBoard, assemblePcb, zoneOf };
