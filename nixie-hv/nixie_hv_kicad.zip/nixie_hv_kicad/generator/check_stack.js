#!/usr/bin/env node
// Self-check for the stacked placement: random option sets, both transformer choices, several widths.
//   node check_stack.js [how many sets, default 300]
// Fails if anything overlaps on a face, leaves the outline, sits in the transformer cut-out, or if two
// facing parts need more than the gap (0.2 mm between them, 0.5 mm to the 170 V parts).
const fs = require("fs"), path = require("path"), assert = require("assert");
const A = require("./assemble.js"); Object.assign(global, A);
const G = require("./pcbgen.js");
const rd = f => JSON.parse(fs.readFileSync(path.join(__dirname, f), "utf8"));
const KIT = rd("kit.json"), PK = rd("pcbkit.json"), FP = rd("footprints.json");
let seed = 7; const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
const HV = ["T1", "D2", "C11", "C12", "R14", "R15", "J3"], N = Number(process.argv[2]) || 300;
let done = 0, noFit = 0, longer = 0;
for (let i = 0; i < N; i++) {
  const o = {}; for (const [k, v] of KIT.options) o[k] = i < KIT.options.length ? (KIT.options[i][0] === k ? v[v.length - 1] : v[0]) : v[Math.floor(rnd() * v.length)];
  o.stack = "two"; o.usbtype = "h"; o.stackt1 = i % 2 ? "slot" : "in";
  const W = [11, 11, 13, 18][i % 4];
  const P = A.partsOfKit(KIT, o).map(m => { const key = m.fpk || m.fp; return { ref: m.ref, name: m.val, fpn: key, f: FP[key], pid: m.pid || null, g: m.g, fit: m.dnp === "no", u: m.u }; });
  const cfg = { mode: "env", W, gap: 0, low: true }, flat = G.layoutBoard(P, PK.fps, cfg);
  const r = G.layoutBoard(P, PK.fps, { ...cfg, stack: { t1: o.stackt1, nets: G.netlistKit(KIT, o), t: 0.8 } }), tag = JSON.stringify(o) + " W=" + W;
  if (r.fail) { noFit++; continue; }
  const st = r.stack, mir = q => ({ x: q.x, y: W - q.y - q.h, w: q.w, h: q.h }), hit = (a, b) => a.x < b.x + b.w - 1e-6 && b.x < a.x + a.w - 1e-6 && a.y < b.y + b.h - 1e-6 && b.y < a.y + a.h - 1e-6;
  const zin = q => { const p = q.it.p; return (!p.fit || (p.f.th && !p.f.edge) || /:Pads_/.test(p.fpn)) ? 0 : p.f.z; };
  for (const b of [0, 1]) {
    const on = r.placed.filter(q => q.brd === b || q.both).map(q => ({ q, r: q.both && b ? mir(q) : q }));
    for (const { q, r: a } of on) {
      assert(a.x >= -1e-6 && a.x + a.w <= r.L + 0.05 && a.y >= -0.05 && a.y + a.h <= W + 0.05, "off the board: " + q.it.p.ref + " " + tag);
      if (b === 0 && st.slot) assert(!hit(a, st.slot), "in the cut-out: " + q.it.p.ref + " " + tag);
    }
    for (const face of [0, 1]) {            // 0: inner face, 1: outer face; a through part is on both
      const f = on.filter(({ q }) => q.side === 2 || q.side === face);
      for (let m = 0; m < f.length; m++) for (let n = m + 1; n < f.length; n++) assert(!hit(f[m].r, f[n].r), "overlap on board " + (b + 1) + ": " + f[m].q.it.p.ref + " / " + f[n].q.it.p.ref + " " + tag);
    }
  }
  const b0 = r.placed.filter(q => q.brd === 0 && !q.both && q.side !== 1), b1 = r.placed.filter(q => q.brd === 1);
  for (const a of b0) for (const c of b1) if (hit(a, mir(c))) {
    const need = zin(a) + zin(c) + (HV.includes(a.it.p.ref) || HV.includes(c.it.p.ref) ? 0.5 : 0.2);
    assert(zin(a) === 0 && zin(c) === 0 || need <= st.G + 1e-6, "facing parts too tall: " + a.it.p.ref + " / " + c.it.p.ref + " need " + need.toFixed(2) + " of " + st.G + " " + tag);
  }
  A.assembleKit(KIT, o); assert(G.assemblePcb(PK, KIT, o, r).text.length > 1000);
  done++; if (!flat.fail && r.L > flat.L) longer++;
}
console.log(done + " stacked layouts checked, " + noFit + " option sets did not fit their width; " + longer + " of them are longer than the same options on one board");
