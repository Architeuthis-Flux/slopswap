#!/usr/bin/env python3
"""Nixie HV supply: write the KiCad schematic for one set of options.

    python3 nixie_hv_gen.py                       the board as drawn
    python3 nixie_hv_gen.py io=cast cell=cast     change some options
    python3 nixie_hv_gen.py --list                show every option and its values
    python3 nixie_hv_gen.py -o ../nixie_hv/nixie_hv.kicad_sch fet=q30 ...

The option string is the one the decision page shows.  Needs only Python 3 and kit.json next to this file.
"""
import json, os, re, sys

def atom_ok(atom, o):
    if "!=" in atom:
        k, v = atom.split("!=")
        return o[k] not in v.split("|")
    k, v = atom.split("=")
    return o[k] in v.split("|")


# ----------------------------------------------------------------------------- assembling a kit
_PH = re.compile(r"\{\{([A-Z0-9_]+)\}\}")


def normalise(kit, o):
    """Fill in defaults and reject unknown values."""
    out = {}
    for key, vals in kit["options"]:
        v = str(o.get(key, vals[0]))
        if v not in vals:
            raise ValueError("option %s: %r is not one of %s" % (key, v, vals))
        out[key] = v
    return out


def subst(kit, o, text):
    def rep(m):
        name = m.group(1)
        if name == "CFG":
            return " ".join("%s=%s" % (k, o[k]) for k, _v in kit["options"])
        s = kit["subs"][name]
        return s["map"][o[s["opt"]]]
    return _PH.sub(rep, text)


def assemble(kit, o):
    o = normalise(kit, o)
    sel = [e for e in kit["els"] if all(atom_ok(a, o) for a in e["c"])]
    ends, pins = {}, {}
    for e in sel:
        if "w" in e:
            w = e["w"]
            for k in (w[0] + "," + w[1], w[2] + "," + w[3]):
                ends[k] = ends.get(k, 0) + 1
        for p in e.get("p", ()):
            k = p[0] + "," + p[1]
            pins[k] = pins.get(k, 0) + 1
    junc = []
    for k, n in ends.items():
        if n >= 2 and n + pins.get(k, 0) >= 3:
            x, y = k.split(",")
            junc.append((int(round(float(x) * 100)), int(round(float(y) * 100)), x, y))
    junc.sort()
    used = {e["l"] for e in sel if "l" in e}
    out = [kit["head"], "(lib_symbols\n"]
    out += [txt + "\n" for lib_id, txt in kit["libs"] if lib_id in used]
    out.append(")\n")
    for xi, yi, x, y in junc:
        out.append("(junction (at %s %s) (diameter 0) (color 0 0 0 0) (uuid 6a756e63-0000-4000-8000-%08x%04x))\n" % (x, y, xi, yi))
    out += [e["t"] + "\n" for e in sel]
    out.append(kit["tail"])
    return subst(kit, o, "".join(out))


def parts_of(kit, o):
    """Fitted and unfitted parts for one option set: the BOM the page shows."""
    o = normalise(kit, o)
    rows = []
    for e in kit["els"]:
        if "m" in e and all(atom_ok(a, o) for a in e["c"]):
            row = {k: (subst(kit, o, v) if isinstance(v, str) else v) for k, v in e["m"].items()}
            row["u"] = e["u"]
            rows.append(row)
    return rows


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    kit = json.load(open(os.path.join(here, "kit.json"), encoding="utf-8"))
    args = sys.argv[1:]
    if "--list" in args:
        for key, vals in kit["options"]:
            print("%-9s %s   (first is as drawn)" % (key, " | ".join(vals)))
        sys.exit(0)
    out = "nixie_hv.kicad_sch"
    if "-o" in args:
        i = args.index("-o"); out = args[i + 1]; del args[i:i + 2]
    opts = {}
    for a in args:
        if "=" not in a:
            sys.exit("expected key=value, got %r (try --list)" % a)
        k, v = a.split("=", 1)
        if k not in dict(kit["options"]):
            sys.exit("unknown option %r (try --list)" % k)
        opts[k] = v
    try:
        text = assemble(kit, opts)
    except ValueError as e:
        sys.exit(str(e))
    open(out, "w", encoding="utf-8").write(text)
    rows = parts_of(kit, opts)
    print("wrote %s: %d parts, %d of them not fitted" % (out, len(rows), sum(r["dnp"] == "yes" for r in rows)))
