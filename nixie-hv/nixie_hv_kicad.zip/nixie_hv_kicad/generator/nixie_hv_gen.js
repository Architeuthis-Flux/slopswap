#!/usr/bin/env node
// Nixie HV supply: write the KiCad schematic AND the placed board for one set of options.
//   node nixie_hv_gen.js --list
//   node nixie_hv_gen.js -o ../nixie_hv --width 11 io=cast cell=cast pass=0201
// The option string is the one the decision page shows. --width is the board width in mm (default 11).
const fs = require("fs"), path = require("path");
const A = require("./assemble.js"); Object.assign(global, A);
const G = require("./pcbgen.js");
const rd = f => JSON.parse(fs.readFileSync(path.join(__dirname, f), "utf8"));
const KIT = rd("kit.json"), PK = rd("pcbkit.json"), FP = rd("footprints.json");
let out = ".", W = 11; const o = {}, a = process.argv.slice(2);
for (let i = 0; i < a.length; i++) {
  if (a[i] === "-o") out = a[++i];
  else if (a[i] === "--width") W = Number(a[++i]);
  else if (a[i] === "--list") { KIT.options.forEach(([k, v]) => console.log(k.padEnd(9), v.join(" | "), "  (first is as drawn)")); process.exit(0); }
  else { const j = a[i].indexOf("="); if (j < 0) { console.error("expected key=value, got " + a[i] + " (try --list)"); process.exit(1); } o[a[i].slice(0, j)] = a[i].slice(j + 1); }
}
let sch;
try { sch = A.assembleKit(KIT, o); } catch (e) { console.error(e.message); process.exit(1); }
const P = A.partsOfKit(KIT, o).map(m => { const key = m.fpk || m.fp; return { ref: m.ref, name: m.val, fpn: key, f: FP[key], pid: m.pid || null, g: m.g, fit: m.dnp === "no", u: m.u }; });
fs.writeFileSync(path.join(out, "nixie_hv.kicad_sch"), sch);
const on = A.normaliseOpts(KIT, o);
const lay = G.layoutBoard(P, PK.fps, { mode: "env", W, gap: 0, low: true, stack: on.stack === "two" ? { t1: on.stackt1, nets: G.netlistKit(KIT, o), t: 0.8 } : null });
if (!lay || lay.fail) { console.log("schematic written; no board: the parts do not fit a " + W + " mm wide outline"); process.exit(0); }
const pcb = G.assemblePcb(PK, KIT, o, lay);
fs.writeFileSync(path.join(out, "nixie_hv.kicad_pcb"), pcb.text);
console.log("wrote nixie_hv.kicad_sch and nixie_hv.kicad_pcb: " + (lay.stack ? "two boards of " : "") + lay.L + " x " + lay.W + " mm, " +
  (lay.stack ? lay.stack.G + " mm apart on " + lay.stack.pins + " pin posts, " + lay.stack.thick.toFixed(1) + " mm thick over all, " : "") +
  pcb.count + " footprints, " + pcb.nets + " nets, not routed" +
  (pcb.skipped.length ? "; left off (no footprint yet): " + pcb.skipped.join(", ") : ""));
