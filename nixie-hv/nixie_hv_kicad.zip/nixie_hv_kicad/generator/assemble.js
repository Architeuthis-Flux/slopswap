// Turns the schematic kit into a .kicad_sch for one option set. Mirrors optsch.assemble() exactly.
function atomOk(a, o) {
  const ne = a.indexOf("!=");
  if (ne >= 0) return !a.slice(ne + 2).split("|").includes(o[a.slice(0, ne)]);
  const i = a.indexOf("=");
  return a.slice(i + 1).split("|").includes(o[a.slice(0, i)]);
}
function normaliseOpts(kit, o) {
  const out = {};
  for (const [k, vals] of kit.options) {
    const v = String(o[k] === undefined ? vals[0] : o[k]);
    if (!vals.includes(v)) throw new Error("option " + k + ": " + v + " is not one of " + vals.join(", "));
    out[k] = v;
  }
  return out;
}
function substKit(kit, o, text) {
  return text.replace(/\{\{([A-Z0-9_]+)\}\}/g, (m, name) => {
    if (name === "CFG") return kit.options.map(([k]) => k + "=" + o[k]).join(" ");
    const s = kit.subs[name];
    return s.map[o[s.opt]];
  });
}
function assembleKit(kit, opts) {
  const o = normaliseOpts(kit, opts);
  const sel = kit.els.filter(e => e.c.every(a => atomOk(a, o)));
  const ends = new Map(), pins = new Map();
  const bump = (m, k) => m.set(k, (m.get(k) || 0) + 1);
  for (const e of sel) {
    if (e.w) { bump(ends, e.w[0] + "," + e.w[1]); bump(ends, e.w[2] + "," + e.w[3]); }
    if (e.p) for (const p of e.p) bump(pins, p[0] + "," + p[1]);
  }
  const junc = [];
  for (const [k, n] of ends) {
    if (n >= 2 && n + (pins.get(k) || 0) >= 3) {
      const [x, y] = k.split(",");
      junc.push([Math.round(parseFloat(x) * 100), Math.round(parseFloat(y) * 100), x, y]);
    }
  }
  junc.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const used = new Set(sel.filter(e => e.l).map(e => e.l));
  const out = [kit.head, "(lib_symbols\n"];
  for (const [id, txt] of kit.libs) if (used.has(id)) out.push(txt + "\n");
  out.push(")\n");
  for (const [xi, yi, x, y] of junc)
    out.push("(junction (at " + x + " " + y + ") (diameter 0) (color 0 0 0 0) (uuid 6a756e63-0000-4000-8000-" +
      xi.toString(16).padStart(8, "0") + yi.toString(16).padStart(4, "0") + "))\n");
  for (const e of sel) out.push(e.t + "\n");
  out.push(kit.tail);
  return substKit(kit, o, out.join(""));
}
function partsOfKit(kit, opts) {
  const o = normaliseOpts(kit, opts), rows = [];
  for (const e of kit.els) {
    if (!e.m || !e.c.every(a => atomOk(a, o))) continue;
    const r = {};
    for (const k in e.m) r[k] = typeof e.m[k] === "string" ? substKit(kit, o, e.m[k]) : e.m[k];
    r.u = e.u;
    rows.push(r);
  }
  return rows;
}
if (typeof module !== "undefined") module.exports = { atomOk, normaliseOpts, substKit, assembleKit, partsOfKit };
