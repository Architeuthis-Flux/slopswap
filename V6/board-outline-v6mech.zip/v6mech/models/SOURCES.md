# Where the part models came from

| File | Source | Used for |
|---|---|---|
| `SIQ-02FVS3-1.step` | embedded in `JumperlessV6/MainBoard/MainBoard.kicad_pcb` (the V5 board), decompressed | rotary encoder |
| `ClickwheelcapColor.step` | embedded in the same board file | encoder cap |
| `TFT_1.47in_172x320_Touch_16P_folded.step` | `JumperlessV6/Displays/Jumperless_Displays.3dshapes/` | 1.47" TFT |
| `PinHeader_2x35_P1.27mm_Horizontal.step` | KiCad packages3D (GitHub mirror), `Connector_PinHeader_1.27mm.3dshapes` | wig header, removable variant |
| `PinSocket_2x35_P1.27mm_Horizontal.step` | KiCad packages3D, `Connector_PinSocket_1.27mm.3dshapes` | main-board socket, removable variant |
| `M.2-E.step` | SparkFun KiCad libraries, `3dmodels/Connector.3dshapes` | M.2 socket (Key E body standing in for Key M) |
| `Navigation_SMD_9.9x9.9mm.step` | SparkFun KiCad libraries, `3dmodels/Switch.3dshapes` (its footprint cites the K1-1210UN-01 datasheet) | flat nav pad, Hroparts K1-1210UN-01 |
| `SW_SPST_TL3342.step` | KiCad packages3D, `Button_Switch_SMD.3dshapes` | 5.1 × 5.1 tact switch (stands in for TS-1187A-C-C-B, which is 1.7 high, not 1.54) |
| `5628_Mini_Joycon_Thumbstick.step` | Adafruit CAD Parts, `5628 Mini Joycon Thumbstick` (MIT) | Joy-Con type thumbstick |

The viewer's meshes (`src/models.js`) were tessellated from these with `tools/step2json.mjs` and
`tools/prep_models.mjs`. The 1.47" AMOLED mesh comes from
`Displays/Jumperless_Displays.3dshapes/AMOLED_1.47in_194x368_QSPI_B2B.step` with its FPC tail left out;
the STEP export draws that display as its two envelope boxes for the same reason.

KiCad library models are CC-BY-SA 4.0 with the KiCad library exception; SparkFun's are CC-BY 4.0; Adafruit's CAD
parts are MIT.

Part bodies in `src/catalog.js` that come from a model were read off it with `tools/silhouette.py` (the plan
outline of the model per height band).

Parts with no model here are drawn as envelopes: USB-C, PCIe x1 right-angle, SFP cage, the probe, the
breadboard shell, the ALPS RKJXM nav stick and the ALPS SKRHADE010 nav switch. `src/catalog.js` says where each envelope's numbers came from.

## Fonts (src/fonts/, used by the viewer page only)

| File | Family | Licence |
|---|---|---|
| `ArchivoNarrow-var.woff2` | Archivo Narrow | SIL Open Font License 1.1 |
| `Michroma-400.woff2` | Michroma | SIL Open Font License 1.1 |
| `IBMPlexMono-400/500/600.woff2` | IBM Plex Mono | SIL Open Font License 1.1 |

Copied from slopswap's `styles/fonts/`.

## Parts library (rev A6)

`src/partlib.js` (footprints, sizes) and `src/partmodels.js` (meshes) are written by `tools/prep_parts.py`,
which fetches each part's footprint and 3D model from EasyEDA by LCSC number with `easyeda2kicad`
(https://github.com/uPesy/easyeda2kicad.py) and keeps the downloads in `ref/ez/<key>/` (not shipped). The
footprints and models are EasyEDA / LCSC library content; they were not checked against the makers'
drawings. The table of parts, LCSC numbers and the quantities Kevin holds is at the top of the script.
Model points are stored as int16 times a scale per model (about 0.001 mm steps).
