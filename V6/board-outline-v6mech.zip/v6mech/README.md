# v6mech: Jumperless V6 board outline and stack

One parameter file describes the whole mechanical stack. A browser page shows it in 3D and lets you
change it; the same code writes a KiCad board and a DXF per board, and a script turns it into a STEP
assembly. Made 2026-11-23; rev A2 the same day (outline traced from the notebook page, boards spaced
with parts between them); rev A3 the same day (input parts to choose from, and a per-board switch for what
each part opens); rev A4 the same day (a 7.62 mm strip, the Wiiig face board on the shell, the page remembers
everything between reloads, the parts and options from the other V6 design notes, a painted and lit 3D view,
and the routing lab's console look); rev A5 on 2026-11-24 (panels that resize, fold and dock; scrolling
moves the view and pinching zooms it; the inside corner follows the breadboard's chamfer; the top-left block
slopes in with no flat under it; the wig's top board has no card edge; straightening the left side can be put back);
rev A6 the same day (a Magnetometers tab: the probe tracker's sensors as a list of their own, each on a board and a
face, dragged about on a plan with every hole coloured by how well the layout places the probe there);
rev A7 the same day (the 2.2 inch bar display, a parts library with footprints and models from the parts
inventory, a parts browser, cantilevered buttons, hiding what is plugged into a socket, and a KiCad export
with the outline as lines and arcs and the parts as footprints);
rev A8 the same day (a display can sit behind a window: under the top board, the board cut to the active area
with chamfered corners, glass let into the cut; and each bar display says what drives it, what it costs and
where to get it); rev A8b and A8c the same day (a cantilever's tongue belongs to the top board; sixteen
long-travel push switches, drawn pressed); rev A9 on 2026-11-25 (a Top band control, and the default outline
made square: 83.82 x 83.82); rev A10 the same day (view controls in the 3D view itself, board opacity, lighting
rigs, surfaces, more backdrops and benches).

## Use it

1. Open `V6_outline_viewer.html` (double-click; it needs no server and no network).
2. Drag parts in the 3D view. Tick **Edit the outline** to drag the outline's vertices, and
   **Lay the notebook sketch over it** to see the pencil drawing under the outline. Checks are on the right.
   **Export files** gives every file as text to copy or download.
3. Under **Parts**, pick a click wheel, directional switch, joystick or buttons. Select any part to move it,
   change the board it sits on, and tick which boards are opened for it.
4. To make your changes the defaults: export "Parameters", save it over `v6_outline.json`, then
   `node build.mjs`. That rewrites `out/` and the viewer.
5. For Fusion: `pip install cadquery`, then `python3 step_export.py` writes
   `out/<variant>/V6_stack_<variant>.step`.

`v6_outline.json` can also be edited by hand; every dimension has a name, and keys starting with `_`
are comments.

## What the page remembers

The design, every view setting, which sections are folded and where the camera stands are written to the
browser's own storage a quarter of a second after anything changes, and again when the page is left. A reload
brings all of it back. Nothing is sent anywhere, so a different browser or machine starts from the built-in design.

- **Undo / Redo** (the buttons, or Ctrl/Cmd + Z and Shift + Ctrl/Cmd + Z): 80 steps, since the page was opened.
- **Saved designs → Save a copy** keeps a named copy in the same storage; Open and Delete are beside each.
- **Copy code** gives the design as a short text (only what differs from the built-in design); **Copy link**
  puts that code after `#p=` in the page's address where the page is on a web server. Paste either, or the
  JSON of a `v6_outline.json`, into the box and press Open. Opening a link keeps the design you had as
  "before the link".
- A design saved by an older page is brought up to the current one: your outline, stack and parts are kept,
  new settings start at their defaults, and a line at the top of the panel says so.
- **Reset** goes back to the built-in design; Undo brings yours back.

If the browser refuses storage (some private windows, some embedded frames), the page says so at the top of
the Design panel, and Copy code or Export is the way to keep a design.

## Layout, and moving the view

- **Resize:** drag the line between a panel and the view. Double-click it for the usual size; with the line
  focused, the arrow keys move it (Shift for bigger steps).
- **Fold:** the mark at the end of a panel's bar, or a click on its name. A folded panel is only its bar.
- **Dock:** the three small pictures in a panel's bar put it on the left, under the view, or on the right.
  Two panels in one dock share it, with a line between them to drag.
- **Layout** (top right) has five arrangements, View only (also the `\` key), text size, fold or unfold all
  the Design sections, and Usual layout to go back. All of it is remembered.
- **By the window's width:** until a panel has been docked by hand, a window narrower than 1180 px gets
  Design on the left and Checks under the view, and a wider one gets them either side. Narrower than 700 px
  there are no docks: the view, then the panels one under the other at their own height.
- **In the view:** drag turns it, scrolling moves it, a pinch (or Ctrl/Cmd + scroll) zooms about the pointer,
  right-drag moves it too. With a mouse, **View → Scrolling → Zooms** gives the wheel its old job.

## The wig's two boards

The wig is a sandwich: a **top board** with the countersunk holes, the shell with its clips, and a **bottom
board** with the card edge (the tongue with the 2 × 35 holes of the 1.27 mm header) along its top.

- **Top board** (`wig.face`): the 484 countersunk holes read from `V6pile/Wig/Wiig/wiigtop.3mf` by
  `tools/prep_face.py` (2.032 at the top face, 1.2 through: a 90° countersink 0.416 deep; 480 on the 16 × 30
  grid and four at the ends of the row beside each rail pair), on the breadboard body's own outline, 78.74 ×
  54.99, 0.71 thick. `wiigtop.3mf` itself also has the 3.43 mm card-edge strip with the 70 holes along its
  top; rev A4 drew that on the top board, which was wrong. It is trimmed; `header_strip: true` puts it back.
- **Bottom board:** with a removable wig it is the wig's own PCB (WigLEDmag outline, tongue included, with
  the header on it), under the shell and under the frame's upper boards. With an integrated wig it is the
  main board itself, and there is no card edge.
- **It sits → On the shell** adds the top board's thickness: the top of the breadboard is 7.46 and the unit
  is 9.06 thick. **Let into it** shortens the shell instead and the top stays at the shell height.
- **Level with the shell / with the face** set the gaps so the frame's top board is flush with either.
- The STEP export cuts the real countersunk holes; the KiCad and DXF files are still the frame boards only.

## How it is drawn

**View → Drawn as** picks one of four: **Real** (soldermask, bare FR4 edges, plated holes, gold, a lit room
to reflect, shadows, tone mapping), **Flat** (one colour per board, as before), **X-ray** and **Lines**.
Backdrop, bench (shadow, a 0.1 inch grid that lines up with the holes, or nothing), lens, exposure, where the
light comes from, and a slow turn are beside it; **Save the picture** writes a PNG, with a clear background
when the backdrop is None. **Look** sets the soldermask of the boards and of the face board, silkscreen,
copper finish, the shell's colour, LEDs under the holes and whether the display is lit. None of that changes
the geometry or any exported file.

## From the other V6 notes

- **Left strip 7.62** (3 pitches; unit pitch 86.36, 4 dead rows). **Outline → Make the left side straight**
  pulls the top-left block in to the strip edge and keeps the outline as drawn under `frame.outline_drawn`;
  **Put it back as drawn** restores it (Undo does too).
- **Edge coupler between units** (edge-coupler notes, v1 and v2): the WingTAT HEE70LP03BK used today needs
  about 6.4 mm between the two boards, the kiss slot V2 9.2 and V3 7.8. The check compares that with the
  strip width, and the housing is drawn in the gap when the next unit is shown. 7.62 is the first strip
  that takes the WingTAT part; the kiss slot V2 needs 10.16.
- **Display**: the fifteen candidates from the display library that are shorter than the unit, each with the
  module size and thickness from its drawing, beside the two modelled 1.47 inch ones.
- **Expansion port**: M.2, PCIe x1, two SFP cages, and from the port survey a mini PCIe socket and a DDR4
  SO-DIMM socket.
- **Add part → Chips and tall parts**: CH446Q, CH32H417, RP2350B, TSSOP-16, the 6.3 mm inductor, the FPC
  connector. **Mechanical**: an M2 screw with a spacer in every gap, as one answer to what holds the boards apart.
- **Magnetometers**: since rev A6 a list of their own with a tab to edit them (next section). The 3D view and
  the docked-probe check use that list.
- **Shell height** 6.75 or 7.1 at a click.

## The Magnetometers tab

The second tab in the top rail (the page's address ends in `#magnetometers` while it is open). The view becomes a
plan of the unit: the frame, the breadboard's outline, the parts and the dock as thin outlines, the sensors as
dots, and every breadboard hole coloured by the error of the probe's fix there. The Design panel becomes the
sensor list and the probe's settings, the Checks panel the numbers. It is the same design: undo, the saved
state, codes, the 3D view, the docked-probe check and the exported files all follow.

- **Move them.** Drag a sensor (Shift keeps it on a 1.27 mm grid). Double-click the plan to add one, Delete
  removes the selected one, the arrow keys nudge it 0.5 mm (Shift 2.54). Dragged under the breadboard it rides the
  board under the breadboard (`on: "wig"`: the wig's PCB when removable, the main board when integrated); dragged
  off it, the bottom board. Board, face (a dot is the top face, a ring the underside) and part (MMC5603 or
  TMAG5273) are set per sensor in the panel. A sensor that is off its board there, or under a part standing on
  the same face, is drawn red and listed.
- **Arrangements.** Eight to load: 6 under the breadboard + 6 on the frame (the built-in default), 6 + 3, 4 + 8,
  3 + 9, the frame only, 12 under (3 × 4), 18 under (3 × 6, the earlier plan) and the WigLEDmag as built. The
  Accuracy panel shows all eight under the current probe settings; click one to put it on the plan. **Hold for
  comparison** keeps one layout's numbers beside the next one's.
- **Improve** nudges every sensor a little at a time, each kept on its own side of the breadboard's edge, on
  its board and off the parts, and keeps a move only if the error over the holes drops. It finds the nearest
  better layout, not the best one.
- **Probe**: the magnet (the bench probe as measured, 1900 mT·mm³, by default; the cylinder drawn in the dock;
  3 × 6 mm N42; the clip magnet; or any strength), how far its centre is above the breadboard's top, and how far
  the probe leans. **Readings**: noise, how well each zero is known, gain error, whether the fit solves for the
  ambient field too, and whether it holds the magnet's strength.
- **Colour by**: the error; how far the fix moves when the ambient field changes by 10 µT and the zero is not
  taken again; or how many sensors are past full scale at that hole.

What the number is: the error bound (Cramér–Rao) of a dipole fit to the sensors' readings, in the plane of the
board, 1 sigma, per frame, rms over the probe upright and leaning four ways. The model is Testolomew's
(`MagFit.h`: positions in mm, fields in mT, moment in mT·mm³, strength held). Each reading's error is its noise,
the doubt in its zero and its gain error (0.4 µT, 1 µT and 1 % for the MMC5603, from the 2026-11-01 bench);
a sensor past 95 % of full scale is left out. `src/magmodel.js` is the whole of it and runs in Node too:
`node tools/magcheck.mjs --check` prints the arrangements' numbers and checks the model against reference values
from the Python study in `V6pile/maglayout`. The bound is a floor: Testolomew's own fit, run on these
arrangements, comes out 1.3 to 1.5 times it at the median hole and two to three times at the worst with the
bench magnet, and about twice it everywhere with the 2 × 1 mm one (the figures are under What rev A6 shows).

## Frame of reference

- x right, y **down** (KiCad). x = 0 is the wig's left edge, y = 0 the wig body's top edge.
  Breadboard column k is at x = 2.54 × k (k = 1..30).
- z = 0 is the top face of the main board, which is also the wig PCB's top face. z is up.

## The outline

`frame.outline` is a list of vertices, clockwise from the top-left corner, traced from the notebook page
(photo a384f12f, warped so the drawn breadboard's corners land on the WigLEDmag's; read to about ±0.5 mm).
Each vertex can carry a corner:

| In the JSON | Corner |
|---|---|
| nothing | sharp |
| `"r": 2` | round |
| `"c": [cx, cy], "r": 2` | rounded chamfer: a chamfer with both ends blended. `cx` is the leg along the more horizontal edge, `cy` along the more vertical one |
| `"c": "wig"` | the WigLEDmag corner itself (2.51 × 2.11), copied point for point from its Edge.Cuts |

The WigLEDmag corner is a 2.21 × 1.58 chamfer with 1.0 mm blends; the bigger corners use the same
construction with bigger numbers.

Where the drawing and a hard reference disagree by less than the pencil's width, the reference wins: the
strip's edge is on x = −5.08 (drawn −4.8 to −5.0), the band's right edge on x = 78.74 (drawn 79.0 to 79.3),
the strip's end on the breadboard's bottom edge (drawn 0.5 lower). Everything else is as drawn, including
the 1.7 mm step in the top edge at x ≈ 45 and the 0.5 mm bump on the strip's outer edge.

In `integrated` mode the bottom board is this outline plus the breadboard's own outline as one piece; the
seam along the strip is filled, and `frame.fill_notches` closes the notch at the top-right if wanted.

## The 0.1 inch rule

- Unit pitch = (31 + n) × 2.54, n = `grid.dead_rows_left` (0, 1 or 2): the strip's width in rows.
  Two units side by side then have n + 1 dead rows between column 30 of one and column 1 of the next.
- The check places a neighbour one unit pitch away on each side and looks for overlap in plan:
  a bare breadboard (the WigLEDmag outline), and a second whole unit. Edges that just touch are fine.
- A 1×40 header from column 1 puts pins 31 to 31 + n on dead rows and the rest in the next unit's holes.
  Turn on "Show the next unit" and "Show a 1x40 header" to see it.

## How the stack is built

- `stack` lists the boards bottom to top, each with its thickness and the **gap** under it. Parts live in
  the gaps. The default is three 1.6 mm boards with 1.775 mm between them, which puts the top board flush
  with the breadboard at 6.75. "Level with the breadboard" shares the space out again after a change.
- The bottom board is the main board. In `removable` mode it is the frame alone and the wig is its own PCB
  (the real WigLEDmag outline) on a 2×35 1.27 mm right-angle header and socket, both on the top faces, so
  the mated pair is inside the sandwich.
- **Openings are automatic, and only where needed.** Each part has bodies with a plan shape and a height
  range. A board is cut only where a body passes through it. The probe lies between the bottom and top
  boards, so only a board in between is opened for it. A part that has to be reached from outside (a button,
  a flat nav pad) also opens the boards above it, with a hole the size of its actuator.
- **Every part can overrule that, board by board.** `"open": { "L2": true }` on a part opens that board for
  it even though it stops short; `false` keeps the board whole even though the part runs into it, and the
  check then says so. In the viewer these are the tick boxes under a selected part.
- Kind `ring` turns a board into a hollow spacer with `frame.ring_wall` of wall. None in the default stack.
- `features` in the JSON adds manual cuts or tabs.

## Controls

The input parts in the catalogue, with where each lands in the default stack (main board top at 0, mid
board 1.775 to 3.375, top board 5.15 to 6.75). "Top" is the part's highest point against the top face.

| Part | Size | Put on | Top | Boards opened |
|---|---|---|---|---|
| Click wheel SIQ-02FVS3, no cap (default) | base 10.3 × 11.1 × 2.0, wheel Ø14.5 from 2.0 to 4.0 | main | 2.75 below | mid; **the top board covers it** |
| same, top board opened by hand | | main | 2.75 below | mid, top (Ø15 well) |
| same, on the mid board | | mid | 0.63 above | top |
| Click wheel with the V5 cap | cap top at 5.75 | main | 1.0 below | mid, top |
| Nav stick ALPS RKJXM1015004 (through-hole, the bench part) | 11 × 11 × 6.6, lever Ø2.2 to 15 | main | lever 8.25 above; body 0.15 below | mid, top (11 × 11) |
| Nav switch ALPS SKRHADE010 (SMD) | 7.45 × 7.5 × 1.85, stem to 5.0 | mid | stem 1.63 above | top (the body reaches 0.075 into it) |
| same, on the main board | | main | 1.75 below | mid; top for access (Ø6.3) |
| Nav pad Hroparts K1-1210UN-01 (SMD, flat) | 9.9 × 9.9 × 1.7 | mid | 1.68 below | top for access (Ø8.4) |
| same, on the top board | | top | 1.7 above | none |
| Tact 5.1 × 5.1, 1.7 high (TS-1187A-C-C-B) | | mid | 1.68 below | top for access (Ø4.0) |
| same, on the top board | | top | 1.7 above | none |
| Thumbstick, Joy-Con type (Adafruit 5628) | can 17.9 × 19.9 × 5.25, cap Ø15 to 13.7 | main | cap 6.93 above | mid, top |
| Custom control | body w × d × h, actuator Ø and top height, typed in | main | as typed | as it falls |

Sources are in `src/catalog.js` beside each part. The SKRHADE010 and K1-1210UN footprints are already in
JumperlessFootprints; the RKJXM has no footprint yet (B25 says so too).

## Checks

| Check | What it tells you |
|---|---|
| 0.1 inch stacking | pitch on grid; a bare breadboard on either side; a second whole unit on either side; the pitch at which two units clear |
| Stack height | top board against breadboard top; which boards are opened, for what, and whether that leaves them in pieces |
| Clashes | parts that share space (plan overlap × height overlap); a part that runs into a board it was told not to open; parts that reach past the edge of their board |
| Standing out | how far each part stands above the top face |
| Component room | per board face, the area with nothing standing in front of it, against the 9,134 mm² of main-board courtyard from `docs/V6_area.json` |
| Probe dock | that it stays between the outer boards; wall left in a cut board; the docked magnet's field at the nearest magnetometer; whether a dead-row pin line runs down the channel |

`node build.mjs --check` exits 1 if two parts clash, a part runs into a board kept whole, or a bare
breadboard no longer fits beside the unit.

## Rev A10: view controls in the 3D view, and more ways to draw it

- **A strip of view controls sits in the 3D view**, along the bottom to start with: Explode, Board opacity, Hide
  shell and Drawn as. Its four small squares dock it along the bottom or top or down the left or right of the view;
  **–** folds it to a tab and **×** sends everything back to the View section. **+** lists every view control with a
  tick for whether it is in the strip, and each row of the View section has a **pin** that does the same. A control
  is in one place or the other, never both. All of it is remembered.
- **Board opacity** fades the frame's boards (and what is printed on them) so the parts between them show, without
  going to X-ray.
- **Lighting**: six rigs (Studio, Bench lamp, Overcast, Three lights, Pink and cyan, Dusk). Picking one sets a main
  light, a second light, a back light and the sky, each of which then has its own colour and level. Light from still
  turns the main light, and the back light stays opposite it.
- **Board surface**: Smooth, Soldermask grain, Glass weave, or Tracks under the mask (made-up routing, there to
  make a board look like a board; it is not the design's copper). **Shell surface**: Moulded or Printed layers.
- **Backdrop** adds Slate, Blueprint, Dusk, Rainbow line and a colour of your own. **Bench** adds a cutting mat
  (10 mm squares), a wooden bench and brushed steel, each taking the shadow.
- The lighting colours, surfaces and benches apply to the Real drawing. None of this changes a check or an export.

## Rev A9: a square outline, and a top band that moves

Kevin: the overall (simplified) outline should be square, and the strip along the left means the top can come up
to match, which gives more room.

- **Top band** (0.1 inch grid section, under Left strip) is how far the frame stands above the breadboard's top
  edge. Type a height, or press **Make it square** (as high as the unit pitch is wide), **Square to the widest
  point** (as high as the outline is wide where the top-left block sticks out) or **As drawn** (24.7, the
  notebook page). The whole top edge moves as one, so the 1.7 mm step in it stays; the parts in the upper half of
  the band move with it (the click wheel, the USB-C and the port by default), the rest stay where they are.
  Undo takes it back.
- The line under it gives the simplified outline (left strip plane to right plane, top edge to bottom edge), how
  far it is from square, and its height in rows. `checks.txt` has the same on the line under GRID, and
  `resolved.json` under `checks.grid.overall`.
- **The default design is now square: 83.82 x 83.82**, top band 28.83 (it was 24.7, so 79.69 high). The top edge
  is at y = -27.13 left of the step and -28.83 right of it; the click wheel, USB-C and M.2 socket went up 4.13
  with it; the display and the two keys did not move. Where the sections below say 23.0 and 24.7, that is the
  drawing, and `frame.band_drawn` keeps it.
- **Square on the unit pitch is also 33 rows high.** A unit stood above another then keeps its hole rows on the
  0.1 inch grid, the same way units side by side do. At 24.7 the height was 31.37 rows. With a 7.62 strip the
  square is 86.36 (34 rows, top band 31.37).
- What it buys: 359 mm² more on each of the three boards (main 6955, mid 2038, top 1509 mm² integrated), and
  component room used drops from 82 % to 72 %. There are about 9 mm of top board free above the display now.
- A design saved in the browser keeps its own outline: open it and press Make it square.
- Not looked at: the tongues could be about 4 mm longer in the taller band (softer keys), and nothing has been
  moved to use the new room. The widest point is still 87.04 because of the top-left block, so the outline with
  the block is 3.2 mm wider than it is high.

## Rev A8c: the long-travel push switches, and buttons drawn pressed

Sixteen push switches with a real travel (0.7 to 1.7 mm, a spring and a click, not a dome under a film) are in
the parts list under Buttons. They are the candidates for the keys, from the '93 Grand Cherokee head unit's
buttons onward:

| Key | Part | Over all, mm | Travel | Force | Footprint | LCSC |
|---|---|---|---|---|---|---|
| `btn_spej` | ALPS SPEJ push switch | 8.4 x 7 x 8 | 1.7 | 3.5 N | SW_Push_Alps_SPEJ110100 | C97447 |
| `btn_speh` | ALPS SPEH push switch | 6.54 x 6 x 5 | 1.6 | 1.96 to 3 N | SW_Push_Alps_SPEH | C97448 |
| `btn_evpasac` | Panasonic EVP-AS | 7 x 6.11 x 5 | 1.3 | 1.6 to 3.5 N | SW_Push_Panasonic_EVPAS | C4365033, C2915187, C2915191, C5119011 |
| `btn_evpas_10` | Panasonic EVP-AS | 7 x 6.11 x 5 | 1 | 2.2 to 4.0 N | SW_Push_Panasonic_EVPAS | none found |
| `btn_evqpv_13` | Panasonic EVQ-PV through-hole | 6 x 6.1 x 5 | 1.3 | 1.6 to 3.5 N | SW_Push_Panasonic_EVQPV | C5736850 |
| `btn_evqpv_10` | Panasonic EVQ-PV through-hole | 6 x 6.1 x 5 | 1 | 2.2 N | SW_Push_Panasonic_EVQPV | none found |
| `btn_evpbd` | Panasonic EVP-BD / 0B | 7 x 6 x 4 | 0.75 | 3.5 to 7.0 N | SW_Push_Panasonic_EVPBD | C4364307 |
| `btn_evpcd` | Panasonic EVP-CD | 7 x 6 x 4 | 1 | 4.0 to 5.0 N | SW_Push_Panasonic_EVPCD | none found |
| `btn_sksu_bb` | ALPS SKSUBBE010 | 5.4 x 5.4 x 4.34 | 1.04 | 5 N | SW_Push_Alps_SKSU_H4.34 | C726003 |
| `btn_sksu_bc` | ALPS SKSUBCE010 | 5.4 x 5.4 x 4.34 | 0.9 | 3 N | SW_Push_Alps_SKSU_H4.34 | C470481 |
| `btn_sksu_aa` | ALPS SKSUAAE010 | 5.4 x 5.4 x 3.85 | 0.7 | 3.5 N | SW_Push_Alps_SKSU_H3.85 | C262410 |
| `btn_skps` | ALPS SKPS | 6.6 x 6 x 5.01 | 1.05 | 3.0 to 3.6 N | SW_Push_Alps_SKPS | C358623, C2925580, C278358 |
| `btn_b3al` | Omron B3AL | 6.6 x 6.9 x 5.01 | 1.3 | 1.96 to 5.00 N | SW_Push_Omron_B3AL | C4364511, C5950094 |
| `btn_b3al_ms` | Omron B3AL -MS | 6.6 x 6.9 x 5.01 | 1 | 3.00 to 3.50 N | SW_Push_Omron_B3AL | none found |
| `btn_kscslt_j` | C&K KSC SLT J-bend | 6.8 x 6.2 x 5 | 1.35 | 2.4 to 3.5 N | SW_Push_CK_KSC-SLT_J | C2801879 |
| `btn_kscslt_g` | C&K KSC SLT gullwing | 10 x 6.2 x 5 | 1.35 | 2.4 to 3.5 N | SW_Push_CK_KSC-SLT_G | C2801904, C2801527 |

- Each has the maker's land pattern as its footprint, a model in three bodies (housing, terminals, actuator)
  and a travel. Select one and tick **Pressed** (or press P): the actuator is drawn down by the travel.
  **Show the buttons pressed**, under the expansion port, does it for all of them at once. Both are kept with
  the design. Neither changes a check or an export: heights, clashes and Standing out always use the released
  part.
- Pressed is drawn from the released mesh: every point of the actuator goes down by the travel and stops at
  the housing's top, so a plunger's wall shortens and a cap that travels further than it stands proud ends
  flush. The STEP models in the KiCad library are cut properly instead (the SPEH's cap ends 0.1 below its
  frame there, flush here).
- `btn_spej` and `btn_evpasac` were in the parts library already, with EasyEDA's footprint and a one-body
  model. The new entries take their place under the same keys, so a saved design keeps its parts. The EVP-AS
  footprint changes with that: pads 2.0 x 2.0 at +-3.0, which is Panasonic's land pattern; EasyEDA's has them
  at +-2.8.
- The travel in the table is the one the model is pressed by. Where a family has two travels there are two
  entries (EVP-AS, EVQ-PV, B3AL, SKSU); where the force grades differ by 0.1 mm (EVP-BD 0.7 to 0.8) there is
  one, at 0.75. The part numbers and forces of a family are listed under the selected part.
- `src/switchlib.js` and `src/switchmodels.js` are written by `V6pile/switches/src/build_viewer.py` from the
  same table that writes the KiCad library, so the footprint here is the one in
  `JumperlessV6footprints.pretty` (KiCad 8.0 folder), and the mesh is the tessellated STEP in
  `3dmodels/JumperlessV6.3dshapes/`. Edit `V6pile/switches/src/switches_data.py`, not these two files.

## Rev A8b: the tongue belongs to the top board

In A7 and A8 a cantilevered button's slot was cut by the same rule as any button's opening: in every board on
the free side of the switch. So a switch on the underside of a board put the slot in the boards below it (a key
hanging under the mid board cut the main board, with the tongue running the other way because the part was
mirrored), a switch on the main board put it in the mid board as well as the top one, and a fourth board put it
in two boards. Now:

- The slot is cut in the top board and in no other, whatever the stack and whichever board or face the switch is
  on, and it stays where it is when the switch is turned over (Other side).
- A board between the switch and the top board gets the switch's plain opening. A board ticked open by hand
  gets the plain opening too, never the slot.
- The switch can be on the board under the top board (pressed from above, the default) or on the underside of
  the top board, riding the tongue and pressing on the board below. Anywhere else the checks say the tongue
  cannot work it; they also say when the switch stops more than 1 mm short of the tongue.
- `node tools/tonguecheck.mjs` tries seven arrangements in both wig variants and fails if a slot is in any
  board but the top one.

## What rev A8 adds

- **A display behind a window.** Select the display in the Parts list and tick **Behind a window**. The module then
  hangs under the top board instead of coming up through it, and the top board is cut to the active area only:
  **Cut inside the active area by** (0.3 mm all round by default, so the dead border is covered) and **Corner
  chamfer** (2.0 mm) set the cut. **Glass let into the cut** adds a pane as thick as the top board, the cut less
  the **Gap round the glass** (0.1 mm), ending flush with the top face; the lit picture is drawn under it.
  In the JSON it is `"window": { "crop": 0.3, "chamfer": 2.0, "glass": 1, "gap": 0.1 }` on the display part
  (an empty `{}` takes those defaults). A routed cut has a 0.4 to 0.5 mm radius in each of its eight corners,
  which is not drawn; the pane needs the same radius.
- **Checks → Display window** gives the cut, the share of the active area that shows, the pane's size, and the
  room left under the module. `checks.txt` has the same under DISPLAY WINDOW, and `resolved.json` under
  `checks.windows`. The pane is a body of the display part (`glass: true`), so the STEP export has it.
- **What it shows for the default design** (the window is off by default, so nothing built-in has moved):
  - 2.2 inch bar, 1.6 mm top board: the cut is 14.36 x 53.76 and 93.9 % of the active area shows. The module
    runs from z 3.53 to 5.15, 0.155 mm above the mid board, and runs into the click wheel (0.47 mm) and the
    4.2 mm M.2 socket (0.57 mm). The top board keeps 325 mm² more than with the module through it.
  - The same with a 1.0 mm top board (gap under it 2.375): no clashes, 0.755 mm under the module. With 0.8 mm
    (gap 2.575): no clashes, 0.955 mm under it, which is room for a metal dome but not for a 1.7 mm tact.
  - The 2.79 inch bar does not fit where the 2.2 sits, window or not: 24.4 mm wide, it overlaps the
    breadboard shell by 134 mm².
- **Display → the line under the selector**: pixels, controller, the bus the stock FPC brings out, prices on
  2026-11-24, whole-screen frame rate on 50 MHz SPI, and links to the listings and the controller datasheet
  (`DISPLAY_INFO` in `src/catalog.js`; the survey is `V6pile/notes/README_v6BarDisplay.md`).
- Two numbers in the display library disagree with the vendors and were left as they are: the 2.2 inch bar's
  active area is 54.36 long in `displays_data.py` and 54.18 at EastRising (420 x 0.129), and its module is
  60.11 long here against 59.11 on Shineworld's and EastRising's sheets. The window is cut from the library's
  numbers, so with the vendors' figure the cut is 0.21 mm inside the active area at each end, not 0.3.
- Not run here: `tools/verify.py` (needs ezdxf) and `step_export.py` (needs cadquery).

## What rev A7 adds

Rev A6 (the Magnetometers tab, next section down) was made in another session the same morning while this
one was under way; A7 is the two merged, with nothing of A6 taken out.

- **The 2.2 inch bar display is the default** (LTN220TF-PF09, 17.6 × 60.11 × 1.62, lying along the band at
  x 30, y −9.9, flush with the top board). It overlaps the M.2 socket and one corner of the click wheel in
  plan but is 1 mm above both.
- **Parts library.** `src/partlib.js` holds 34 parts from Kevin's parts inventory (`~/Documents/Parts/
  INVENTORY.md`) and a few near them: 16 buttons, 6 directional switches, 3 joysticks, the click wheel and
  an encoder, 7 connectors. Each was fetched from EasyEDA by its LCSC number (`tools/prep_parts.py`, which
  runs `easyeda2kicad`): the footprint as pads and drawings, and the 3D model, which is shown in the view
  (`src/partmodels.js`) and measured for the part's size and height. The part's frame is the footprint's
  frame. Two 5 mm and 7 mm metal domes are entered by hand (no footprint, height assumed).
- **Add a part** (Parts section): a list of all 77 catalogue parts with a search box, a row of kinds and
  "only what is in my parts inventory". Add drops the part in the middle of the view, selected, to be
  dragged. A selected part has Turn 90, Turn 45, Other side, Duplicate and Remove (keys R, Shift+R, F, D,
  Delete).
- **Cantilevered buttons.** Any button can be given a tongue: a U-shaped slot cut in the top board over it, so
  the board is the key top. The default design has two beside the display (TS-1187A on the mid board, tongue
  16.5 × 3 mm in the top board). The checks give the force to click each one, and say when a slot breaks
  out at an edge or comes within 0.8 mm of another opening. **In the 1.6 mm top board those two take about
  8.7 N** (a tact alone is 1.6 N): stiff. The same tongue in a 0.8 mm board is about 2.5 N; a 0.2 mm bump
  under the tongue brings 1.6 mm down to about 5.7 N. A third key does not fit beside the display: its slot
  runs out through the corner chamfer above the USB-C.
- **Hide what is plugged into the sockets** (Parts section): the blue M.2 card, mini PCIe card or SO-DIMM.
- **KiCad export.** Each board's `.kicad_pcb` now has its outline and openings on Edge.Cuts as `gr_line`,
  `gr_arc` and `gr_circle` (no polygons): fillets and offset corners are found again in the polygon and
  written as one arc each, every primitive starting on the exact point where the last one ended. Parts
  mounted on the board are placed as footprints at their position, rotation and side: the EasyEDA footprint
  where the library has one, otherwise the part's outline on the courtyard layer as a footprint with no
  pads. `out/<variant>/v6mech.pretty/` holds the library footprints used, and `WT_wig_top_board.kicad_pcb`
  is the wig's top board: outline plus its 484 holes as plated pads (the countersink is a fab note, the
  0.26 mm ring is a guess).
## What rev A6 shows

With the bench probe's magnet (1900 mT·mm³) 2 mm above the surface, error bound in mm as median / 90th
percentile / worst hole, and how far a 10 µT ambient change moves the fix (median / worst):

| Arrangement | Error | Holes within half a pitch | 10 µT shift |
|---|---|---|---|
| 6 under + 6 on the frame | 0.10 / 0.14 / 0.21 | 480 | 0.47 / 1.6 |
| 6 under + 3 on the frame | 0.11 / 0.15 / 0.21 | 480 | 0.52 / 1.6 |
| 4 under + 8 on the frame | 0.11 / 0.15 / 0.29 | 480 | 0.71 / 2.3 |
| 3 under + 9 on the frame | 0.14 / 0.18 / 0.25 | 480 | 0.94 / 3.2 |
| Frame only, 8 top + 4 left | 0.29 / 1.34 / 4.07 | 427 | 3.5 / 61 |
| 12 under, 3 × 4 | 0.08 / 0.13 / 0.21 | 480 | 0.59 / 1.6 |
| 18 under, 3 × 6 | 0.07 / 0.10 / 0.16 | 480 | 0.52 / 1.4 |

- Nine to twelve sensors with three to six of them under the breadboard are within a few hundredths of a
  millimetre of twelve under it. The sensors under the breadboard carry the far corner; the frame's carry the
  top rows and the left columns, and steady the fix against the ambient field.
- With the 2 × 1 mm magnet drawn in the dock (363) the same layouts give 0.23 / 0.34 / 0.76 (6 + 6) to
  0.42 / 0.69 / 0.95 (3 + 9), every hole still within half a pitch by the bound, against 0.15 / 0.29 / 0.64 for
  twelve under.
- Testolomew's own fit on the same layouts (`V6pile/maglayout`'s harness, cold on every frame, 12 boards × 4
  frames a hole): with the bench magnet 0.13 / 0.23 / 0.43 (6 + 6), 0.14 / 0.25 / 0.45 (6 + 3), 0.16 / 0.28 / 0.87
  (4 + 8) and 0.20 / 0.31 / 0.73 (3 + 9), every hole within half a pitch, against 0.08 / 0.17 / 0.43 for twelve
  under. With the 2 × 1 mm magnet it is about twice the bound: 0.50 / 0.71 / 1.38 and 456 of 480 holes (6 + 6),
  0.71 / 1.02 / 2.18 and 367 holes (3 + 9), 0.34 / 0.65 / 1.19 and 475 for twelve under.
- 20 mm above the surface with the bench magnet: 0.46 / 0.60 / 0.83 (6 + 6), 0.56 / 0.68 / 0.95 (3 + 9).
- The default frame sensors sit on the main board's underside: a row at y = −6 (clear of the wig's card edge,
  which is cut out of the main board when the wig is removable) and two in the left strip under the dock.

## What rev A5 shows

- **Inside corner.** The frame's inside corner copies the breadboard's own corner (2.51 × 2.11, the same
  points), so the mid and top boards close up to the shell there, less the fit gap.
- **Along the breadboard.** Wherever the frame runs along the breadboard, the spaces the breadboard's own
  outline leaves against it (the corner chamfers and the 0.635 mm waist between y = 13.45 and 41.92) are
  frame. Each board is then cut by whatever part of the wig is at its height, less the fit gap, so the
  strip's inner edge follows the breadboard's contour: 0.1 mm off the shell on the mid and top boards, 0.2 mm
  off the wig's own PCB on a removable wig's main board. The far side and the two short link notches beside
  the tongue are left alone; the shell is drawn without those notches.
- **Top-left block.** It now slopes in to the strip along the corner chamfer of a breadboard standing on the
  left (2.211 × 1.583, r 1.0), carried on in a straight line to the block's left edge at x = −8.3, with no
  flat under the block. On the sketch the drawn slope is steeper by about 5° and within 0.5 mm of this line.
- With the wig's top board on the shell the unit is 9.06 mm thick and the breadboard's top is 0.71 above the
  frame's top board.
- At a 7.62 strip (pitch 86.36) a bare breadboard still fits on either side. With the left side made straight,
  two whole units overlap by 37 mm², all of it the click wheel, which hangs 4.6 mm past the corner; they clear
  at pitch 91.44.
- Today's WingTAT coupler fits a 7.62 strip with 1.22 mm to spare and does not fit 5.08. The check takes the
  strip as empty space: on this outline the strip is board, and the coupler's tongue is not drawn.

Everything under rev A3 still holds:


- The outline lies on the pencil lines to about half a millimetre (turn the sketch on to see it).
- A bare breadboard fits against either side at pitch 83.82 = 33 × 2.54, 3 dead rows. The step under the
  top-left block is the WigLEDmag corner, so the neighbour's corner nests in it exactly.
- **A second whole unit does not fit at that pitch.** The top-left block reaches x = −8.3, 3.2 mm past the
  strip, and meets the other unit's band (51 mm² of board, plus the encoder wheel). Two units clear at
  5 dead rows (pitch 88.9). Either of these brings it back to 3: pull the block in to −5.08 and move the
  encoder 1.6 mm right; or keep the block and end the band 4.8 mm short on the right (which takes the USB-C corner with it).
- The click wheel has no cap and the top board covers it; it is reached from the corner. At its V5 offsets
  from the new corner (5.83 mm from the left and top edges) its wheel, which tops out at 4.0, still meets
  the underside of the display (3.7) by 0.3 mm where the two overlap in plan. A 7.1 shell clears it by 0.05.
  The glass's square top-left corner also reaches about 1.2 mm past the top-left chamfer.
- The top edge left of the step is 0.2 mm above the display glass, so the top board has no rim there.
- USB-C at the V5 corner and a 21.9 mm M.2 socket use all of the top edge right of the step.
- Component room: about 11,600 mm² integrated (4,600 of it on the breadboard's part of the main board) and 5,800 mm² removable,
  for 9,134 mm² of parts. Gaps of 1.775 mm take parts up to about 1.5 mm.
- A Ø3.6 probe between the outer boards opens the mid board along the strip and leaves 0.46 and 0.54 mm
  walls. The strip's centreline is also a dead-row pin line. At 70 mm long with its tip at y = 1 it sticks
  out 16 mm at the bottom.

## Files

- `src/partlib.js`, `src/partmodels.js`: the parts library (footprints, sizes) and its 3D models, written by
  `tools/prep_parts.py`; edit the table in that script, not these.
- `src/switchlib.js`, `src/switchmodels.js`: the long-travel push switches (rev A8c), in the same shape as the
  two files above plus a travel and an actuator group in each model; written by
  `python3 V6pile/switches/src/build_viewer.py <this folder>`. Loaded after the parts library, so an entry with
  the same key replaces the library's.
- `out/<variant>/v6mech.pretty/`, `out/<variant>/WT_wig_top_board.kicad_pcb`: the library footprints used and
  the wig's top board.

| Path | What |
|---|---|
| `v6_outline.json` | the parameters; the source of truth |
| `V6_outline_viewer.html` | the viewer, one file, built by `build.mjs` |
| `build.mjs` | writes `out/` and the viewer; plain Node, no packages |
| `step_export.py` | STEP assembly from `out/<variant>/resolved.json` (CadQuery) |
| `src/geometry.js` | parameters → outline, boards, openings, parts, checks (browser and Node) |
| `src/magmodel.js` | the magnetometers: where each sits, the field model, the error bound at every hole, the arrangements, Improve (browser and Node) |
| `src/magtab.js` | the Magnetometers tab: the plan, dragging, its two panels |
| `tools/magcheck.mjs` | prints the arrangements' numbers for `v6_outline.json` and checks the model against reference values |
| `src/catalog.js` | part definitions: bodies, clearances, models, where each number came from |
| `src/exporters.js` | DXF, KiCad, SVG and the text report |
| `src/viewer.js`, `src/viewer.html` | the page |
| `src/state.js` | what the page remembers: storage, older-design upgrade, undo, named copies, codes and links |
| `src/render.js` | lighting, materials and the painted faces of the Real view |
| `src/fonts/` | Archivo Narrow, Michroma and IBM Plex Mono (all SIL OFL), inlined into the single file |
| `src/models.js`, `src/sketch.js` | part meshes and the sketch underlay for the viewer, made by `tools/prep_models.mjs` and `tools/prep_sketch.py` |
| `ref/wig_ref.json` | wig outline, hole grid and sensor positions read from `WigLEDmag.kicad_pcb`; under `face`, the Wiiig face board from `wiigtop.3mf` (`tools/prep_face.py`) |
| `ref/sketch_rectified.jpg`, `.json` | the notebook page warped to mm, and its window |
| `models/` | the STEP models the STEP export places; see `models/SOURCES.md` |
| `out/integrated/`, `out/removable/` | per board `.kicad_pcb` and `.dxf`, `plan.svg`, `checks.txt`, `resolved.json`, the STEP |
| `docs/` | the two figures the slopswap readme page shows |
| `tools/to_slopswap.py` | publishes the viewer, this readme and a zip of the folder to slopswap.org/V6 (usage at the top of the file) |
| `tools/` | dev scripts: STEP → mesh, model and sketch prep, `silhouette.py` (a model's plan outline per height band, where the input parts' bodies come from), and `verify.py`, which re-reads every output with another parser and redoes the neighbour check with shapely |

The KiCad boards put the datum at (100, 100) on the sheet in every file, so they overlay. They carry the
outline on Edge.Cuts, the parts on that board as outlines on User.Drawings, and the grid planes on
User.Comments. They are a one-way export: edits made in KiCad do not come back into the JSON.

## Not verified

- **The long-travel switches (rev A8c).** The land patterns and outline boxes are the makers' drawings, and
  `V6pile/switches/src/verify.py` re-reads every file. Four models are drawn from the drawings, not from
  maker CAD, with details assumed where the drawing gives none (corner cuts, the shape of the stem's foot):
  EVQ-PV, EVP-BD, EVP-CD and both KSC SLT. On the Omron B3AL the line between rubber cap and base (3.0 above
  the board) is assumed. The SKSUAAE010 is the SKSUBBE010 model with a 0.49 shorter stem. Which of the
  SPEJ's outer terminals is closed at rest is inferred from the sheet's two turnover heights, not stated
  on it: check with a meter. None of it has been held against a part.
- **The KiCad files have not been opened in KiCad.** They are written to the v8 format and read back two
  ways (`tools/verify.py`'s own reader and the `kiutils` library): every end point on Edge.Cuts is shared
  by exactly two primitives, the rebuilt loops match the resolved shape (polygon corners within 0.007 mm of
  the outline), and on a test board with six library parts on both faces at odd angles all 99 pads land
  within 0.0001 mm of where the engine puts them. No KiCad was available where they were made, so whether
  KiCad 8 or 10 opens them without complaint is not known. The DXFs are the fallback: File → Import →
  Graphics into Edge.Cuts.
- **The library footprints and models are EasyEDA's**, taken by LCSC number and not checked against the
  makers' drawings. EasyEDA's own SMD / through-hole flag is wrong on several, so the export goes by the
  pads. Known doubts: the K1-1502SA-03's model sits 3.8 mm off its pads' centre; the ALPS SRBD110401 came
  back with a footprint named SRBD150201; the TS-1187B's model is 0.75 mm high; the Kailh Choc model
  includes a keycap; the M.2 4.8H socket and the TS2245 have no model (heights from the part numbers).
  Not at EasyEDA at all: both metal domes, the Panasonic EVQWJN005, the SAM-L2-LR12SP joystick, the
  FC05-S20FCT-00.
- A bottom-side part is the footprint mirrored left to right, then turned. KiCad's own Flip turns a
  further 180° for the same number, so check the rotation of anything on the underside after import.
- **The cantilever force is an estimate**: a plain cantilever loaded at the switch, E = 22 GPa for FR4, a
  1.6 N tact with 0.25 mm travel, square slot ends, no stress raiser at the root. Nothing was bent.
- The STEP file draws library parts as blocks, not their models.
- **The new parts and the magnetometers have not been looked at together.** The default frame sensors sit on
  the main board's underside at y = −6 (x 10, 32, 54, 76); the bar display lies over three of them and key2's
  switch is about 5.5 mm from the fourth in plan. A tact switch's dome and frame are steel and a display has a
  metal back; what they do to the probe fix is not in the magnetometer model.
- The sketch was read from one photo of a curled page. Near the breadboard it is good to 0.2 mm (the
  traced wig lands on the real outline); at the top of the band the notebook's 5 mm dots come out 4.93 to
  5.0 apart, so allow 0.5 mm there.
- The bump on the strip's edge is drawn; what it is for is a guess (it is shaped to sit in the waist of a
  breadboard standing against that edge).
- Two things in the drawing are not modelled: the second, lighter box in the right half of the band
  (about 27 × 21 mm), and the faint lines a few millimetres outside the left and right edges.
- What holds the boards 1.775 mm apart is not decided: the gap is a number, not a part.
- The neighbour check is plan only. Heights are ignored.
- The shell's plan is the 78.7 × 54.6 envelope trimmed to the wig's edge, on the shell doc's statement that
  the rail blocks run 0.6 mm past the body. Its corners are assumed to match the PCB's.
- Input parts: the SKRHADE010's 2.34 mm square stem is from SparkFun's model of a same-size switch, not the
  ALPS drawing. The K1-1210UN-01 is SparkFun's model of that part; the Hroparts drawing was not read. The
  tact switch is KiCad's TL3342 model stretched from 1.54 to the 1.7 of the TS-1187A-C-C-B. The RKJXM is
  drawn as an 11 × 11 square with a lever; its terminals (3.2 below the board) are not drawn. The thumbstick
  is Adafruit's Joy-Con type because the bench joystick is unidentified. Access holes (Ø of the actuator plus
  a margin) are a first guess at what a cap needs.
- USB-C is an 8.94 × 7.35 × 3.26 envelope from memory of an HRO TYPE-C-31-M-12 class part, not from a drawing.
- PCIe x1 right-angle: 9.4 high is from TE's page for 1-1761465-1; the 25 × 11 footprint is assumed.
- The M.2 model is SparkFun's Key E socket standing in for Key M. Same body, different key.
- Shell height is the 6.75 redesign target; the Wiiig v7 print (`Wiiig.step`) measures 7.1.
- **The wig's boards.** The top board is the countersunk holes of `wiigtop.3mf` (2026-08-19) on the body's
  outline; its 0.71 thickness is the model's (a fab makes 0.6 or 0.8). The bottom board is the WigLEDmag
  outline; its clip slots and parts are not drawn, only the 70 card-edge holes in the Real view. How the top
  board is fixed to the shell is not known. The gold land around each hole (0.26 mm wide), the column numbers
  and the plated look of the hole walls are drawn, not read from a file.
- Scrolling and pinching were tested with synthetic wheel events in headless Chrome, not on a trackpad or in
  Safari (which reports a pinch differently; that path is written but untested).
- The Real view is a picture, not a simulation: the LEDs, the image on the display, the part names printed on
  the boards and the shell's clip glints are made up to make it read. The Flat view shows only geometry.
- The Magnetometers tab's numbers are a bound from a model, not a measurement: nothing here has run on a
  board, and fields from the frame's own parts (the rail supply's inductors, an expansion card, the click wheel)
  and from the circuit on the breadboard are not in it. The frame sensors' places are a first guess that the
  schematic and the routing will move. Dragging was tested with a mouse in headless Chrome, not by touch.
- The grid arrangements (3 × 4, 3 × 6) are spread evenly over a 76 × 45 field centred on the holes, on the
  underside; the notes give the count and the rough pitch, not positions.
- Edge couplers: sizes are from the two coupler notes. Where the tongue goes on this outline, and whether the
  strip is cut away for the housing, is not drawn; the check only compares widths.
- New parts: the mini PCIe socket's 5.2 height is read off its part number, with no drawing opened; the
  SO-DIMM is one 73 × 23.5 × 4.0 block; QFN heights (0.9) are typical values; the M2 screw and spacers are a
  placeholder for an undecided part. Library displays are the module (and cover glass where the drawing has
  one) with no FPC tail.
- The page's memory was tested in headless Chrome only (reload, undo, named copies, codes, links).
- The docked-magnet field uses a point dipole, 115.4 mT·mm³ per mm³ of N52, magnet axis along the dock.
- The AMOLED's 61.8 mm FPC tail is not drawn. It needs a route and a place for its B2B plug.
- The wig outline's bottom edge is closed with a straight line; on the real board that edge belongs to
  the side-connect footprint.
- The header-to-socket mated distance (8.59 mm row to row) comes from the KiCad models, not a mated pair.

## The look

The page wears the same console look as the routing lab and the cost explorer (2026-11-25), and that look is kept in
one place: the console section of slopswap's `styles/jumperless.css`.

- `src/viewer.html` carries a copy of it in `<style id="console-copy">`, so the single file still opens from disk.
  Do not edit that block: change the look in slopswap and run its `.tools/console_copy.py src/viewer.html`, then
  `node build.mjs`.
- The `<style>` under it holds only what is this tool's own (the docks, the view, the rows, the checks). A plate,
  a button, a heading mark or a table head is not restyled here.
- `tools/to_slopswap.py` takes the copy out and links the site's stylesheet, so a change there reaches the
  published page with no rebuild.
- Inside the V6 notebook (`V6/notebook.html` on slopswap) the page gets `class="embedded"` on its `<html>` and
  hides its crumb, its name and its two tabs: the notebook's bar has them.
- The folder as it was before this is `../_v6mech-before-console-look-2026-11-25`.

