# v6mech: Jumperless V6 board outline and stack

One parameter file describes the whole mechanical stack. A browser page shows it in 3D and lets you
change it; the same code writes a KiCad board and a DXF per board, and a script turns it into a STEP
assembly. Made 2026-11-23; rev A2 the same day (outline traced from the notebook page, boards spaced
with parts between them); rev A3 the same day (input parts to choose from, and a per-board switch for what
each part opens).

## Use it

1. Open `V6_outline_viewer.html` (double-click; it needs no server and no network).
2. Drag parts in the 3D view. Tick **Edit the outline** to drag the outline's vertices, and
   **Lay the notebook sketch over it** to see the pencil drawing under the outline. Checks are on the right.
   The page keeps your changes in the browser. **Export files** gives every file as text to copy or download.
3. Under **Parts**, pick a click wheel, directional switch, joystick or buttons. Select any part to move it,
   change the board it sits on, and tick which boards are opened for it.
4. To make your changes the defaults: export "Parameters", save it over `v6_outline.json`, then
   `node build.mjs`. That rewrites `out/` and the viewer.
5. For Fusion: `pip install cadquery`, then `python3 step_export.py` writes
   `out/<variant>/V6_stack_<variant>.step`.

`v6_outline.json` can also be edited by hand; every dimension has a name, and keys starting with `_`
are comments.

## Frame of reference

- x right, y **down** (KiCad). x = 0 is the wig's left edge, y = 0 the wig body's top edge.
  Breadboard column k is at x = 2.54 × k (k = 1..30).
- z = 0 is the top face of the main board, which is also the wig PCB's top face. z is up.

## The outline

`frame.outline` is a list of vertices, clockwise from the top-left corner, traced from the notebook page
(photo a384f12f, warped so the drawn breadboard's corners land on the WigLEDmag's; read to about ±0.5 mm).
Each vertex can carry a corner:

| In the JSON | Corner |
|---|---|
| nothing | sharp |
| `"r": 2` | round |
| `"c": [cx, cy], "r": 2` | rounded chamfer: a chamfer with both ends blended. `cx` is the leg along the more horizontal edge, `cy` along the more vertical one |
| `"c": "wig"` | the WigLEDmag corner itself (2.51 × 2.11), copied point for point from its Edge.Cuts |

The WigLEDmag corner is a 2.21 × 1.58 chamfer with 1.0 mm blends; the bigger corners use the same
construction with bigger numbers.

Where the drawing and a hard reference disagree by less than the pencil's width, the reference wins: the
strip's edge is on x = −5.08 (drawn −4.8 to −5.0), the band's right edge on x = 78.74 (drawn 79.0 to 79.3),
the strip's end on the breadboard's bottom edge (drawn 0.5 lower). Everything else is as drawn, including
the 1.7 mm step in the top edge at x ≈ 45 and the 0.5 mm bump on the strip's outer edge.

In `integrated` mode the bottom board is this outline plus the breadboard's own outline as one piece; the
seam along the strip is filled, and `frame.fill_notches` closes the notch at the top-right if wanted.

## The 0.1 inch rule

- Unit pitch = (31 + n) × 2.54, n = `grid.dead_rows_left` (0, 1 or 2): the strip's width in rows.
  Two units side by side then have n + 1 dead rows between column 30 of one and column 1 of the next.
- The check places a neighbour one unit pitch away on each side and looks for overlap in plan:
  a bare breadboard (the WigLEDmag outline), and a second whole unit. Edges that just touch are fine.
- A 1×40 header from column 1 puts pins 31 to 31 + n on dead rows and the rest in the next unit's holes.
  Turn on "Show the next unit" and "Show a 1x40 header" to see it.

## How the stack is built

- `stack` lists the boards bottom to top, each with its thickness and the **gap** under it. Parts live in
  the gaps. The default is three 1.6 mm boards with 1.775 mm between them, which puts the top board flush
  with the breadboard at 6.75. "Level with the breadboard" shares the space out again after a change.
- The bottom board is the main board. In `removable` mode it is the frame alone and the wig is its own PCB
  (the real WigLEDmag outline) on a 2×35 1.27 mm right-angle header and socket, both on the top faces, so
  the mated pair is inside the sandwich.
- **Openings are automatic, and only where needed.** Each part has bodies with a plan shape and a height
  range. A board is cut only where a body passes through it. The probe lies between the bottom and top
  boards, so only a board in between is opened for it. A part that has to be reached from outside (a button,
  a flat nav pad) also opens the boards above it, with a hole the size of its actuator.
- **Every part can overrule that, board by board.** `"open": { "L2": true }` on a part opens that board for
  it even though it stops short; `false` keeps the board whole even though the part runs into it, and the
  check then says so. In the viewer these are the tick boxes under a selected part.
- Kind `ring` turns a board into a hollow spacer with `frame.ring_wall` of wall. None in the default stack.
- `features` in the JSON adds manual cuts or tabs.

## Controls

The input parts in the catalogue, with where each lands in the default stack (main board top at 0, mid
board 1.775 to 3.375, top board 5.15 to 6.75). "Top" is the part's highest point against the top face.

| Part | Size | Put on | Top | Boards opened |
|---|---|---|---|---|
| Click wheel SIQ-02FVS3, no cap (default) | base 10.3 × 11.1 × 2.0, wheel Ø14.5 from 2.0 to 4.0 | main | 2.75 below | mid; **the top board covers it** |
| same, top board opened by hand | | main | 2.75 below | mid, top (Ø15 well) |
| same, on the mid board | | mid | 0.63 above | top |
| Click wheel with the V5 cap | cap top at 5.75 | main | 1.0 below | mid, top |
| Nav stick ALPS RKJXM1015004 (through-hole, the bench part) | 11 × 11 × 6.6, lever Ø2.2 to 15 | main | lever 8.25 above; body 0.15 below | mid, top (11 × 11) |
| Nav switch ALPS SKRHADE010 (SMD) | 7.45 × 7.5 × 1.85, stem to 5.0 | mid | stem 1.63 above | top (the body reaches 0.075 into it) |
| same, on the main board | | main | 1.75 below | mid; top for access (Ø6.3) |
| Nav pad Hroparts K1-1210UN-01 (SMD, flat) | 9.9 × 9.9 × 1.7 | mid | 1.68 below | top for access (Ø8.4) |
| same, on the top board | | top | 1.7 above | none |
| Tact 5.1 × 5.1, 1.7 high (TS-1187A-C-C-B) | | mid | 1.68 below | top for access (Ø4.0) |
| same, on the top board | | top | 1.7 above | none |
| Thumbstick, Joy-Con type (Adafruit 5628) | can 17.9 × 19.9 × 5.25, cap Ø15 to 13.7 | main | cap 6.93 above | mid, top |
| Custom control | body w × d × h, actuator Ø and top height, typed in | main | as typed | as it falls |

Sources are in `src/catalog.js` beside each part. The SKRHADE010 and K1-1210UN footprints are already in
JumperlessFootprints; the RKJXM has no footprint yet (B25 says so too).

## Checks

| Check | What it tells you |
|---|---|
| 0.1 inch stacking | pitch on grid; a bare breadboard on either side; a second whole unit on either side; the pitch at which two units clear |
| Stack height | top board against breadboard top; which boards are opened, for what, and whether that leaves them in pieces |
| Clashes | parts that share space (plan overlap × height overlap); a part that runs into a board it was told not to open; parts that reach past the edge of their board |
| Standing out | how far each part stands above the top face |
| Component room | per board face, the area with nothing standing in front of it, against the 9,134 mm² of main-board courtyard from `docs/V6_area.json` |
| Probe dock | that it stays between the outer boards; wall left in a cut board; the docked magnet's field at the nearest magnetometer; whether a dead-row pin line runs down the channel |

`node build.mjs --check` exits 1 if two parts clash, a part runs into a board kept whole, or a bare
breadboard no longer fits beside the unit.

## What rev A3 shows

- The outline lies on the pencil lines to about half a millimetre (turn the sketch on to see it).
- A bare breadboard fits against either side at pitch 83.82 = 33 × 2.54, 3 dead rows. The step under the
  top-left block is the WigLEDmag corner, so the neighbour's corner nests in it exactly.
- **A second whole unit does not fit at that pitch.** The top-left block reaches x = −8.3, 3.2 mm past the
  strip, and meets the other unit's band (51 mm² of board, plus the encoder wheel). Two units clear at
  5 dead rows (pitch 88.9). Either of these brings it back to 3: pull the block in to −5.08 and move the
  encoder 1.6 mm right; or keep the block and end the band 4.8 mm short on the right (which takes the USB-C corner with it).
- The click wheel has no cap and the top board covers it; it is reached from the corner. At its V5 offsets
  from the new corner (5.83 mm from the left and top edges) its wheel, which tops out at 4.0, still meets
  the underside of the display (3.7) by 0.3 mm where the two overlap in plan. A 7.1 shell clears it by 0.05.
  The glass's square top-left corner also reaches about 1.2 mm past the top-left chamfer.
- The top edge left of the step is 0.2 mm above the display glass, so the top board has no rim there.
- USB-C at the V5 corner and a 21.9 mm M.2 socket use all of the top edge right of the step.
- Component room: about 11,600 mm² integrated (4,600 of it on the breadboard's part of the main board) and 5,800 mm² removable,
  for 9,134 mm² of parts. Gaps of 1.775 mm take parts up to about 1.5 mm.
- A Ø3.6 probe between the outer boards opens the mid board along the strip and leaves 0.46 and 0.54 mm
  walls. The strip's centreline is also a dead-row pin line. At 70 mm long with its tip at y = 1 it sticks
  out 16 mm at the bottom.

## Files

| Path | What |
|---|---|
| `v6_outline.json` | the parameters; the source of truth |
| `V6_outline_viewer.html` | the viewer, one file, built by `build.mjs` |
| `build.mjs` | writes `out/` and the viewer; plain Node, no packages |
| `step_export.py` | STEP assembly from `out/<variant>/resolved.json` (CadQuery) |
| `src/geometry.js` | parameters → outline, boards, openings, parts, checks (browser and Node) |
| `src/catalog.js` | part definitions: bodies, clearances, models, where each number came from |
| `src/exporters.js` | DXF, KiCad, SVG and the text report |
| `src/viewer.js`, `src/viewer.html` | the page |
| `src/models.js`, `src/sketch.js` | part meshes and the sketch underlay for the viewer, made by `tools/prep_models.mjs` and `tools/prep_sketch.py` |
| `ref/wig_ref.json` | wig outline, hole grid and sensor positions read from `WigLEDmag.kicad_pcb` |
| `ref/sketch_rectified.jpg`, `.json` | the notebook page warped to mm, and its window |
| `models/` | the STEP models the STEP export places; see `models/SOURCES.md` |
| `out/integrated/`, `out/removable/` | per board `.kicad_pcb` and `.dxf`, `plan.svg`, `checks.txt`, `resolved.json`, the STEP |
| `docs/` | the two figures the slopswap readme page shows |
| `tools/to_slopswap.py` | publishes the viewer, this readme and a zip of the folder to slopswap.org/V6 (usage at the top of the file) |
| `tools/` | dev scripts: STEP → mesh, model and sketch prep, `silhouette.py` (a model's plan outline per height band, where the input parts' bodies come from), and `verify.py`, which re-reads every output with another parser and redoes the neighbour check with shapely |

The KiCad boards put the datum at (100, 100) on the sheet in every file, so they overlay. They carry the
outline on Edge.Cuts, the parts on that board as outlines on User.Drawings, and the grid planes on
User.Comments. They are a one-way export: edits made in KiCad do not come back into the JSON.

## Not verified

- **The KiCad files have not been opened in KiCad.** They are written to the v8 format and were parsed
  back with a separate reader, but no KiCad was available where they were made. The DXFs are the
  fallback: File → Import → Graphics into Edge.Cuts.
- The sketch was read from one photo of a curled page. Near the breadboard it is good to 0.2 mm (the
  traced wig lands on the real outline); at the top of the band the notebook's 5 mm dots come out 4.93 to
  5.0 apart, so allow 0.5 mm there.
- The bump on the strip's edge is drawn; what it is for is a guess (it is shaped to sit in the waist of a
  breadboard standing against that edge).
- Two things in the drawing are not modelled: the second, lighter box in the right half of the band
  (about 27 × 21 mm), and the faint lines a few millimetres outside the left and right edges.
- What holds the boards 1.775 mm apart is not decided: the gap is a number, not a part.
- The neighbour check is plan only. Heights are ignored.
- The shell's plan is the 78.7 × 54.6 envelope trimmed to the wig's edge, on the shell doc's statement that
  the rail blocks run 0.6 mm past the body. Its corners are assumed to match the PCB's.
- Input parts: the SKRHADE010's 2.34 mm square stem is from SparkFun's model of a same-size switch, not the
  ALPS drawing. The K1-1210UN-01 is SparkFun's model of that part; the Hroparts drawing was not read. The
  tact switch is KiCad's TL3342 model stretched from 1.54 to the 1.7 of the TS-1187A-C-C-B. The RKJXM is
  drawn as an 11 × 11 square with a lever; its terminals (3.2 below the board) are not drawn. The thumbstick
  is Adafruit's Joy-Con type because the bench joystick is unidentified. Access holes (Ø of the actuator plus
  a margin) are a first guess at what a cap needs.
- USB-C is an 8.94 × 7.35 × 3.26 envelope from memory of an HRO TYPE-C-31-M-12 class part, not from a drawing.
- PCIe x1 right-angle: 9.4 high is from TE's page for 1-1761465-1; the 25 × 11 footprint is assumed.
- The M.2 model is SparkFun's Key E socket standing in for Key M. Same body, different key.
- Shell height is the 6.75 redesign target; the current print is 7.1. Face PCB is off (0).
- The magnetometers drawn are WigLEDmag's (8 MMC5603 on top, 9 TMAG5273 underneath), not the planned 18 MMC.
- The docked-magnet field uses a point dipole, 115.4 mT·mm³ per mm³ of N52, magnet axis along the dock.
- The AMOLED's 61.8 mm FPC tail is not drawn. It needs a route and a place for its B2B plug.
- The wig outline's bottom edge is closed with a straight line; on the real board that edge belongs to
  the side-connect footprint.
- The header-to-socket mated distance (8.59 mm row to row) comes from the KiCad models, not a mated pair.
