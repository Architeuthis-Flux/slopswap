#!/usr/bin/env python3
"""Jumperless V6 outline tool - STEP assembly for Fusion / KiCad.

    python3 step_export.py                 # both variants -> out/<variant>/V6_stack_<variant>.step
    python3 step_export.py integrated      # one variant
    python3 step_export.py --no-models     # envelopes only (small, fast)
    python3 step_export.py --all-models    # also the two 70-pin header models (adds ~16 MB to the removable file)

Reads out/<variant>/resolved.json, which `node build.mjs` writes from v6_outline.json, so the STEP always
matches the viewer and the KiCad/DXF files. Needs CadQuery:  pip install cadquery
Frame in the STEP: x right, y UP (the board's y is negated so nothing comes out mirrored), z up, mm.
"""
import json, os, sys
import cadquery as cq

HERE = os.path.dirname(os.path.abspath(__file__))
LAYER_COLORS = ['#35618f', '#b9763c', '#c9a13f', '#3f8f6d', '#646a78', '#7d5a94', '#3e9aa3', '#a2535f']
# real part models: file in models/, plus the turn that brings it into the footprint frame (x, y plan-up, z up)
MODELS = {
    # the AMOLED is left as its two envelope boxes: its STEP carries the 61.8 mm FPC tail unfolded, straight through the frame
    'tft147': ('TFT_1.47in_172x320_Touch_16P_folded.step', None),
    'encoder': ('SIQ-02FVS3-1.step', None),
    'cap': ('ClickwheelcapColor.step', None),
    'hdr_ra': ('PinHeader_2x35_P1.27mm_Horizontal.step', None),
    'skt_ra': ('PinSocket_2x35_P1.27mm_Horizontal.step', None),
    'm2': ('M.2-E.step', cq.Location(cq.Vector(0, 0, 2.21), cq.Vector(1, 0, 0), 90)),
    # inputs: the same moves tools/prep_models.mjs gives the viewer's meshes
    'nav_k1': ('Navigation_SMD_9.9x9.9mm.step', cq.Location(cq.Vector(0, 0, 1.0), cq.Vector(1, 0, 0), 90)),
    'tact': ('SW_SPST_TL3342.step', None),          # 1.54 high as modelled; the part it stands in for is 1.7
    'joycon': ('5628_Mini_Joycon_Thumbstick.step', cq.Location(cq.Vector(-9.15, -7.0, 0))),
}


def rgb(h, a=1.0):
    h = h.lstrip('#')
    return cq.Color(int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255, a)


def dedupe(pts):
    out = []
    for x, y in pts:
        p = (round(x, 4), round(-y, 4))
        if not out or p != out[-1]:
            out.append(p)
    if len(out) > 1 and out[0] == out[-1]:
        out.pop()
    return out


def prism(outer, holes, z0, z1):
    wp = cq.Workplane('XY').workplane(offset=z0).polyline(dedupe(outer)).close()
    for h in holes:
        wp = wp.polyline(dedupe(h)).close()
    return wp.extrude(z1 - z0)


def layer_solid(L):
    s = None
    for e in L['shape']:
        p = prism(e['outer'], e['holes'], L['z0'], L['z1'])
        s = p if s is None else s.union(p)
    return s


def part_location(p):
    loc = cq.Location(cq.Vector(p['x'], -p['y'], p['zPlane']), cq.Vector(0, 0, 1), p['rot'])
    if p['bottom']:
        loc = loc * cq.Location(cq.Vector(0, 0, 0), cq.Vector(0, 1, 0), 180)
    return loc


HEAVY = ('hdr_ra', 'skt_ra')            # drawn as their envelopes unless --all-models


def build(mode, use_models=True, heavy=False):
    R = json.load(open(os.path.join(HERE, 'out', mode, 'resolved.json')))
    assy = cq.Assembly(name='JumperlessV6_' + mode)
    report = []
    for i, L in enumerate(R['layers']):
        s = layer_solid(L)
        if s is None:
            continue
        vol = s.val().Volume()
        report.append((L['id'], vol, L['area'] * L['t']))
        assy.add(s, name='%s_%s' % (L['id'], L['name'].replace(' ', '_')), color=rgb(LAYER_COLORS[i % len(LAYER_COLORS)]))
    cache = {}
    for p in R['parts']:
        names = ([p['model']['name']] if p.get('model') else []) + (p.get('extra') or [])
        placed = False
        if use_models and names and p['type'] not in ('bb_shell', 'probe'):
            for n in names:
                f, pre = MODELS.get(n, (None, None))
                path = os.path.join(HERE, 'models', f) if f else None
                if not path or not os.path.exists(path) or (n in HEAVY and not heavy):
                    continue
                if n not in cache:
                    cache[n] = cq.importers.importStep(path)
                loc = part_location(p)
                if pre is not None:
                    loc = loc * pre
                assy.add(cache[n], name='%s_%s' % (p['id'], n), loc=loc)
                placed = True
        if not placed:
            s = None
            for b in p['bodies']:
                if b.get('slot'):
                    continue
                q = prism(b['pts'], [], b['z0'], b['z1'])
                s = q if s is None else s.union(q)
            if s is not None:
                col = {'bb_shell': '#26282c', 'probe': '#d0d3d6', 'wig_pcb': '#15201a', 'bb_face': '#c9a43a'}.get(p['type'], '#8a8f96')
                assy.add(s, name=p['id'], color=rgb(col, 0.6 if p['type'] == 'probe' else 1.0))
    out = os.path.join(HERE, 'out', mode, 'V6_stack_%s.step' % mode)
    assy.save(out)
    return out, report


if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    use_models = '--no-models' not in sys.argv
    for mode in (args or ['integrated', 'removable']):
        out, report = build(mode, use_models, '--all-models' in sys.argv)
        print('%s: wrote %s (%.1f MB)' % (mode, os.path.relpath(out, HERE), os.path.getsize(out) / 1e6))
        for lid, vol, want in report:
            flag = '' if abs(vol - want) <= max(0.5, 0.002 * want) else '   !! differs from area x thickness'
            print('   %s volume %.1f mm3, outline area x t = %.1f%s' % (lid, vol, want, flag))
