// Jumperless V6 outline tool - geometry engine.
// params (v6_outline.json) -> per-layer outlines with pockets, placed parts, and the checks.
// Runs unchanged in the browser (viewer) and in Node (build.mjs), so the picture and the files cannot disagree.
// Frame: x right, y DOWN (KiCad), x=0 wig left edge, y=0 wig body top edge, z=0 top face of the main board, z up. mm.
// The stack is boards with space between them: parts live in the gaps and a board is only opened where a part passes through it.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./vendor/clipper.js'), require('./catalog.js'), require('./magmodel.js'));
  else root.V6Geo = factory(root.ClipperLib, root.V6Catalog, root.V6Mag);
})(typeof self !== 'undefined' ? self : this, function (ClipperLib, Catalog, Mag) {
  'use strict';
  var SC = 1000;                      // clipper works in integers: 1 unit = 1 um
  var CT = ClipperLib.ClipType, PT = ClipperLib.PolyType, FT = ClipperLib.PolyFillType;
  var EPS = 0.02;

  // ---------- 2D helpers (regions are arrays of clipper paths; holes wind the other way) ----------
  function toC(pts) { return pts.map(function (p) { return { X: Math.round(p[0] * SC), Y: Math.round(p[1] * SC) }; }); }
  function fromC(path) { return path.map(function (q) { return [q.X / SC, q.Y / SC]; }); }
  function exec(type, subj, clip) {
    var c = new ClipperLib.Clipper(), out = new ClipperLib.Paths();
    if (subj.length) c.AddPaths(subj, PT.ptSubject, true);
    if (clip && clip.length) c.AddPaths(clip, PT.ptClip, true);
    c.Execute(type, out, FT.pftNonZero, FT.pftNonZero);
    return out;
  }
  function region(polys) {            // raw polygons (mm point lists, any winding) -> region
    var paths = polys.filter(function (p) { return p && p.length > 2; }).map(function (p) {
      var c = toC(p); if (ClipperLib.Clipper.Area(c) < 0) c.reverse(); return c;
    });
    return exec(CT.ctUnion, paths, []);
  }
  function union(a, b) { return exec(CT.ctUnion, a, b || []); }
  function diff(a, b) { return b && b.length ? exec(CT.ctDifference, a, b) : a; }
  function inter(a, b) { return exec(CT.ctIntersection, a, b); }
  function offset(a, d) {
    if (!a.length || Math.abs(d) < 1e-6) return a;
    var co = new ClipperLib.ClipperOffset(2, 0.01 * SC), out = new ClipperLib.Paths();
    co.AddPaths(a, ClipperLib.JoinType.jtRound, ClipperLib.EndType.etClosedPolygon);
    co.Execute(out, d * SC);
    return out;
  }
  function clean(a) { return union(ClipperLib.Clipper.CleanPolygons(a, 0.003 * SC).filter(function (p) { return p.length > 2; })); }
  function area(a) { var s = 0; for (var i = 0; i < a.length; i++) s += ClipperLib.Clipper.Area(a[i]); return s / (SC * SC); }
  function expolys(a) {               // -> [{outer: pts, holes: [pts]}] in mm
    var c = new ClipperLib.Clipper(), tree = new ClipperLib.PolyTree();
    c.AddPaths(a, PT.ptSubject, true);
    c.Execute(CT.ctUnion, tree, FT.pftNonZero, FT.pftNonZero);
    return ClipperLib.JS.PolyTreeToExPolygons(tree).map(function (e) {
      return { outer: fromC(e.outer), holes: (e.holes || []).map(fromC) };
    });
  }
  function bbox(a) {
    var b = { x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 };
    a.forEach(function (p) { p.forEach(function (q) {
      b.x0 = Math.min(b.x0, q.X / SC); b.x1 = Math.max(b.x1, q.X / SC); b.y0 = Math.min(b.y0, q.Y / SC); b.y1 = Math.max(b.y1, q.Y / SC);
    }); });
    return b;
  }
  function rectPts(x0, y0, x1, y1) { return [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]; }
  function circlePts(cx, cy, r) {
    var n = Math.max(32, Math.ceil(2 * Math.PI * r / 0.3)), pts = [];
    for (var i = 0; i < n; i++) pts.push([cx + r * Math.cos(2 * Math.PI * i / n), cy + r * Math.sin(2 * Math.PI * i / n)]);
    return pts;
  }
  function shapePts(s) {
    if (s.rect) return rectPts(s.rect[0], s.rect[1], s.rect[2], s.rect[3]);
    if (s.circle) return circlePts(s.circle[0], s.circle[1], s.circle[2]);
    return s.poly;
  }
  // part frame -> board frame. Bottom-side parts are mirrored in x first (as KiCad flips them), then turned
  // counter-clockwise as seen from above.
  function place(pts, x, y, rotDeg, bottom) {
    var t = rotDeg * Math.PI / 180, c = Math.cos(t), s = Math.sin(t);
    return pts.map(function (p) { var lx = bottom ? -p[0] : p[0], ly = p[1]; return [x + lx * c + ly * s, y - lx * s + ly * c]; });
  }
  function round(v, n) { var k = Math.pow(10, n == null ? 3 : n); return Math.round(v * k) / k; }


  // ---------- outline from vertices ----------
  // A vertex is {x, y} plus an optional corner treatment:
  //   (nothing)        sharp
  //   r                round corner of that radius
  //   c:[cx,cy], r     "rounded chamfer": a chamfer whose two ends are blended with radius r. cx is the leg along the
  //                    more horizontal of the two edges, cy the leg along the more vertical one (the sharp chamfer, before blending)
  //   c:'wig'          the WigLEDmag corner itself (2.51 x 2.11), copied point for point from its Edge.Cuts
  //   c:'meet'         for a vertex on a corner of the breadboard where the frame stops: the vertex itself stays sharp,
  //                    and the frame's edge is made to meet the breadboard's chamfer square, at the middle of its flat
  var WIG_C = [2.211, 1.583], WIG_R = 1.0;      // the analytic twin of the WigLEDmag corner (fits it to 0.02 mm); used when the real points are not at hand
  function vsub(a, b) { return [a[0] - b[0], a[1] - b[1]]; }
  function vlen(a) { return Math.sqrt(a[0] * a[0] + a[1] * a[1]); }
  function vunit(a) { var l = vlen(a) || 1; return [a[0] / l, a[1] / l]; }
  function fillet(A, V, B, r, availA, availB) {      // points from the A side to the B side of corner V
    var u1 = vunit(vsub(A, V)), u2 = vunit(vsub(B, V));
    var cos = Math.max(-1, Math.min(1, u1[0] * u2[0] + u1[1] * u2[1])), phi = Math.acos(cos);
    if (!(r > 0.001) || phi > Math.PI - 0.01 || phi < 0.01) return [V];
    var t = r / Math.tan(phi / 2), lim = Math.min(availA, availB);
    if (t > lim) { t = Math.max(0, lim); r = t * Math.tan(phi / 2); }
    if (r < 0.005) return [V];
    var bis = vunit([u1[0] + u2[0], u1[1] + u2[1]]), d = r / Math.sin(phi / 2);
    var C = [V[0] + bis[0] * d, V[1] + bis[1] * d];
    var T1 = [V[0] + u1[0] * t, V[1] + u1[1] * t], T2 = [V[0] + u2[0] * t, V[1] + u2[1] * t];
    var a1 = Math.atan2(T1[1] - C[1], T1[0] - C[0]), a2 = Math.atan2(T2[1] - C[1], T2[0] - C[0]), da = a2 - a1;
    while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI;
    var n = Math.max(3, Math.ceil(Math.abs(da) / (2 * Math.acos(Math.max(0, 1 - 0.004 / r))))), pts = [T1];
    for (var k = 1; k < n; k++) pts.push([C[0] + r * Math.cos(a1 + da * k / n), C[1] + r * Math.sin(a1 + da * k / n)]);
    pts.push(T2);
    return pts;
  }
  function wigCorner(ref) {                          // the WigLEDmag top-left corner as (along the horizontal leg, along the vertical leg), from the horizontal end
    var o = (ref && ref.outline) || [], pts = [];
    o.forEach(function (p) { if (p[0] <= 2.52 && p[1] <= 2.11 && p[1] >= -0.001) { var l = pts[pts.length - 1]; if (!l || Math.abs(l[0] - p[0]) + Math.abs(l[1] - p[1]) > 1e-4) pts.push([p[0], p[1]]); } });
    if (pts.length < 6) return null;
    if (pts[0][0] < pts[pts.length - 1][0]) pts.reverse();
    return pts;
  }
  function buildOutline(verts, ref, notes) {
    var n = verts.length, wc = wigCorner(ref), raw = verts.map(function (v) { return [v.x, v.y]; });
    function spec(v) {                                // -> {kind, cx, cy, r}
      if (v.c === 'wig') return wc ? { kind: 'wig', cx: wc[0][0], cy: wc[wc.length - 1][1], r: 0 } : { kind: 'chamfer', cx: WIG_C[0], cy: WIG_C[1], r: WIG_R };
      if (v.c === 'meet') return { kind: 'sharp', cx: 0, cy: 0, r: 0 };
      if (v.c && v.c.length === 2) return { kind: 'chamfer', cx: Math.max(0, +v.c[0] || 0), cy: Math.max(0, +v.c[1] || 0), r: Math.max(0, +v.r || 0) };
      if (v.r > 0) return { kind: 'round', cx: 0, cy: 0, r: +v.r };
      return { kind: 'sharp', cx: 0, cy: 0, r: 0 };
    }
    var info = verts.map(function (v, i) {
      var P = raw[(i + n - 1) % n], V = raw[i], N = raw[(i + 1) % n], dP = vsub(P, V), dN = vsub(N, V), s = spec(v);
      var prevIsH = Math.abs(dP[0]) / (vlen(dP) || 1) >= Math.abs(dN[0]) / (vlen(dN) || 1);
      var legP = 0, legN = 0, tanP = 0, tanN = 0;
      if (s.kind === 'wig') { legP = prevIsH ? s.cx : s.cy; legN = prevIsH ? s.cy : s.cx; }
      else if (s.kind === 'chamfer') {
        legP = prevIsH ? s.cx : s.cy; legN = prevIsH ? s.cy : s.cx;
        var uP = vunit(dP), uN = vunit(dN), C1 = [V[0] + uP[0] * legP, V[1] + uP[1] * legP], C2 = [V[0] + uN[0] * legN, V[1] + uN[1] * legN];
        var uc = vunit(vsub(C2, C1)), ph1 = Math.acos(Math.max(-1, Math.min(1, uP[0] * uc[0] + uP[1] * uc[1]))), ph2 = Math.acos(Math.max(-1, Math.min(1, -(uN[0] * uc[0] + uN[1] * uc[1]))));
        tanP = s.r > 0 && ph1 > 0.01 ? s.r / Math.tan(ph1 / 2) : 0; tanN = s.r > 0 && ph2 > 0.01 ? s.r / Math.tan(ph2 / 2) : 0;
      } else if (s.kind === 'round') {
        var ph = Math.acos(Math.max(-1, Math.min(1, (dP[0] * dN[0] + dP[1] * dN[1]) / ((vlen(dP) || 1) * (vlen(dN) || 1)))));
        tanP = tanN = ph > 0.01 && ph < Math.PI - 0.01 ? s.r / Math.tan(ph / 2) : 0;
      }
      return { s: s, P: P, V: V, N: N, lenP: vlen(dP), lenN: vlen(dN), prevIsH: prevIsH, wantP: legP + tanP, wantN: legN + tanN, legP: legP, legN: legN };
    });
    // two corners that want more of their shared edge than it has are both scaled down
    var scale = info.map(function () { return 1; });
    info.forEach(function (a, i) {
      var b = info[(i + 1) % n], tot = a.wantN + b.wantP;
      if (tot > a.lenN * 0.999 && tot > 0) { var k = a.lenN * 0.999 / tot; scale[i] = Math.min(scale[i], k); scale[(i + 1) % n] = Math.min(scale[(i + 1) % n], k); }
    });
    var pts = [], spans = [];
    info.forEach(function (a, i) {
      var k = scale[i], s = a.s, uP = vunit(vsub(a.P, a.V)), uN = vunit(vsub(a.N, a.V)), out;
      if (k < 0.999 && s.kind !== 'sharp' && notes) notes.push('outline vertex ' + (i + 1) + ': its corner does not fit the edges next to it and was scaled to ' + Math.round(k * 100) + ' %');
      if (s.kind === 'wig' && k >= 0.999) {
        var uh = a.prevIsH ? uP : uN, uv = a.prevIsH ? uN : uP;
        out = wc.map(function (p) { return [a.V[0] + uh[0] * p[0] + uv[0] * p[1], a.V[1] + uh[1] * p[0] + uv[1] * p[1]]; });
        if (!a.prevIsH) out.reverse();
      } else if (s.kind === 'wig' || s.kind === 'chamfer') {
        var cx = (s.kind === 'wig' ? WIG_C[0] : s.cx) * k, cy = (s.kind === 'wig' ? WIG_C[1] : s.cy) * k, r = (s.kind === 'wig' ? WIG_R : s.r) * k;
        var lp = a.prevIsH ? cx : cy, ln = a.prevIsH ? cy : cx;
        if (lp < 0.005 || ln < 0.005) out = fillet(a.P, a.V, a.N, r, a.lenP, a.lenN);
        else {
          var C1 = [a.V[0] + uP[0] * lp, a.V[1] + uP[1] * lp], C2 = [a.V[0] + uN[0] * ln, a.V[1] + uN[1] * ln], cl = vlen(vsub(C2, C1));
          out = fillet(a.P, C1, C2, r, Math.max(0, a.lenP - lp), cl / 2).concat(fillet(C1, C2, a.N, r, cl / 2, Math.max(0, a.lenN - ln)));
        }
      } else if (s.kind === 'round') out = fillet(a.P, a.V, a.N, s.r * k, a.lenP, a.lenN);
      else out = [a.V];
      spans.push({ from: pts.length, count: out.length });
      pts = pts.concat(out);
    });
    return { pts: pts, spans: spans };
  }
  var MAX_DEAD = 3;                 // the left strip is 0, 1, 2 or 3 pitches wide (0 / 2.54 / 5.08 / 7.62)
  function legacyOutline(P) {                         // parameter files from rev A1: a band height and two plain chamfers
    var f = P.frame, g = P.grid, xl = -Math.max(0, Math.min(MAX_DEAD, Math.round(g.dead_rows_left))) * g.pitch, xr = (g.cols + 1) * g.pitch, yt = -(f.band_h || 24), r = f.corner_r || 0;
    var v = [{ x: xl, y: yt, c: [f.chamfer_tl || 0, f.chamfer_tl || 0], r: r }, { x: xr, y: yt, c: [f.chamfer_tr || 0, f.chamfer_tr || 0], r: r }, { x: xr, y: 0, r: r }, { x: 0, y: 0 }];
    if (xl < 0) v.push({ x: 0, y: P.wig.height, r: r }, { x: xl, y: P.wig.height, r: r });
    return v;
  }

  // ---------- the model ----------
  function resolve(P, ref) {
    ref = ref || {};
    var g = P.grid, w = P.wig, f = P.frame;
    var pitch = g.pitch;
    var dead = Math.max(0, Math.min(MAX_DEAD, Math.round(g.dead_rows_left)));
    var xl = -dead * pitch, xr = (g.cols + 1) * pitch, unitPitch = xr - xl;
    var removable = w.mode === 'removable';
    var notes = [];
    if (Math.abs(w.width - xr) > 0.005) notes.push('wig.width ' + w.width + ' is not (cols + 1) x pitch = ' + round(xr) + '; the grid value is used');

    // --- boards in z: each sits "gap" above the one below; parts live in the gaps ---
    var layers = [];
    P.stack.forEach(function (L, i) {
      var z0, z1;
      if (i === 0) { z0 = -L.t; z1 = 0; } else { z0 = layers[i - 1].z1 + (L.gap || 0); z1 = z0 + L.t; }
      layers.push({ id: L.id, name: L.name, t: L.t, gap: i ? (L.gap || 0) : 0, kind: i === 0 ? 'base' : (L.kind === 'ring' ? 'ring' : 'board'), z0: round(z0), z1: round(z1), index: i });
    });
    var top = layers[layers.length - 1];
    var zTop = top.z1, zBot = layers[0].z0;
    // The face board on the shell. wig.face = { on, t, sits: 'on' | 'inset', header_strip }; a rev A3 file's face_pcb_t still works.
    // 'on': it lies on the shell and adds its thickness. 'inset': the shell is that much shorter and the top stays at shell.t.
    var faceP = w.face && w.face.on ? w.face : (w.face_pcb_t > 0 ? { on: true, t: w.face_pcb_t, sits: 'on', plain: true } : null);
    var faceT = faceP ? Math.max(0.2, +faceP.t || 0.71) : 0, faceInset = !!(faceP && faceP.sits === 'inset');
    var shellTop = faceInset ? Math.max(1, w.shell.t - faceT) : w.shell.t;
    var bbTop = shellTop + faceT;
    function layerById(id) { for (var i = 0; i < layers.length; i++) if (layers[i].id === id) return layers[i]; return null; }

    // --- outlines ---
    var verts = f.outline && f.outline.length > 2 ? f.outline : legacyOutline(P);
    var built = buildOutline(verts, ref, notes);
    var frameL = region([built.pts]);
    var fb = bbox(frameL), yt = round(fb.y0), yb = Math.max(w.height, round(fb.y1));
    var wigPts = ref.outline && ref.outline.length > 3 ? ref.outline : rectPts(0, 0, w.width, w.height);
    var wigRegion = region([wigPts]);
    // Where the frame runs along the breadboard, the spaces the breadboard's own outline leaves against it (the corner chamfers,
    // the waist) belong to the frame, so a board's inner edge follows the breadboard's contour: each board is then cut by
    // whichever part of the wig is at its height, less the fit gap. Only a space with more than 5 mm of edge against the frame
    // counts: the strip side does, the two short link notches beside the tongue and the far side do not.
    var frameDrawn = frameL, hugs = [];
    // Only the stretch the frame actually runs along is filled. A space the breadboard's outline leaves is one long piece
    // down a whole side (corner, waist, corner), so taking it whole put fill past the end of a strip that stops short of the
    // breadboard's corner: a tail, or an island once the breadboard's clearance was cut. besideR is, for each side of the
    // breadboard's rectangle, the stretch the drawn frame touches, 3 mm into the breadboard.
    var besideR = null, wW = w.width, wH = w.height, lip = 0.05, reach = 3;
    [[rectPts(-lip, 0, 0, wH), function (b) { return rectPts(0, b.y0, reach, b.y1); }], [rectPts(wW, 0, wW + lip, wH), function (b) { return rectPts(wW - reach, b.y0, wW, b.y1); }],
     [rectPts(0, -lip, wW, 0), function (b) { return rectPts(b.x0, 0, b.x1, reach); }], [rectPts(0, wH, wW, wH + lip), function (b) { return rectPts(b.x0, wH - reach, b.x1, wH); }]].forEach(function (side) {
      expolys(inter(frameDrawn, region([side[0]]))).forEach(function (ex) {
        var r = region([side[1](bbox(region([ex.outer])))]); besideR = besideR ? union(besideR, r) : r;
      });
    });
    expolys(diff(region([rectPts(0, 0, w.width, w.height)]), wigRegion)).forEach(function (ex) {
      var piece = region([ex.outer]), shared = area(inter(offset(piece, 0.05), diff(frameDrawn, piece))) / 0.05;
      if (shared > 5 && besideR) { var part = inter(piece, besideR); if (area(part) > 0.005) { frameL = union(frameL, part); hugs.push(round(shared, 1)); } }
    });
    // Meeting the breadboard's chamfer square (a vertex with c:'meet' on a corner of the breadboard's rectangle). The space the
    // chamfer leaves is split by the line through the middle of the chamfer's flat, at right angles to it: the frame's side
    // of the line is frame, the other side stays open. So the frame's edge runs into the chamfer square-on, at its middle,
    // and no feather of board is left along the rest of the chamfer.
    var joints = [];
    verts.forEach(function (v, vi) {
      if (v.c !== 'meet') return;
      var jx = Math.abs(v.x) <= Math.abs(v.x - wW) ? 0 : wW, jy = Math.abs(v.y) <= Math.abs(v.y - wH) ? 0 : wH, best = null, i;
      if (Math.hypot(v.x - jx, v.y - jy) > 3) { notes.push('Vertex ' + (vi + 1) + ' is set to meet the breadboard\'s chamfer but is not on a corner of the breadboard: nothing done there.'); return; }
      for (i = 0; i < wigPts.length; i++) {                    // the chamfer's flat: the longest slanting edge of the breadboard's outline at that corner
        var a = wigPts[i], b = wigPts[(i + 1) % wigPts.length], dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
        if (Math.abs(a[0] - jx) > 3.2 || Math.abs(a[1] - jy) > 3.2 || Math.abs(b[0] - jx) > 3.2 || Math.abs(b[1] - jy) > 3.2 || Math.abs(dx) < 0.05 || Math.abs(dy) < 0.05) continue;
        if (!best || len > best.len) best = { len: len, m: [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], d: [dx / len, dy / len] };
      }
      if (!best) return;
      var M = best.m, d = best.d, nn = [-d[1], d[0]], far = 12;
      var corner = inter(diff(region([rectPts(0, 0, wW, wH)]), wigRegion), region([rectPts(jx - 3.2, jy - 3.2, jx + 3.2, jy + 3.2)]));
      var half = function (sg) { return region([[[M[0] - nn[0] * far, M[1] - nn[1] * far], [M[0] + nn[0] * far, M[1] + nn[1] * far], [M[0] + nn[0] * far + sg * d[0] * far, M[1] + nn[1] * far + sg * d[1] * far], [M[0] - nn[0] * far + sg * d[0] * far, M[1] - nn[1] * far + sg * d[1] * far]]]); };
      var hp = inter(corner, half(1)), hm = inter(corner, half(-1)), touch = offset(frameDrawn, 0.15);
      var mine = area(inter(touch, hp)) >= area(inter(touch, hm)) ? hp : hm, theirs = mine === hp ? hm : hp;      // the frame's side is the one the drawn frame lies against
      frameL = diff(union(frameL, mine), theirs);
      joints.push({ vertex: vi + 1, at: [round(M[0]), round(M[1])], flat: round(best.len, 2), open: theirs });
    });
    // integrated: one board under the frame and the breadboard. Where the strip runs beside the breadboard the seam is
    // filled (the wig's left corners and waist); the rest of the wig's edge is kept as it is on the WigLEDmag.
    var fullOutline = union(frameL, wigRegion);
    var beside = inter(frameL, region([rectPts(-0.5, 0, 0, w.height)]));
    if (area(beside) > 0.2) { var bs = bbox(beside); fullOutline = union(fullOutline, region([rectPts(-0.05, bs.y0, 3, bs.y1)])); }
    var fill = Math.max(0, f.fill_notches || 0);
    if (fill > 0) fullOutline = offset(offset(fullOutline, fill), -fill);
    joints.forEach(function (j) { fullOutline = diff(fullOutline, j.open); });        // the one board keeps the same joint
    // slots of the wig's own edge that the band closes off (the two link notches beside the tongue) are not holes in one board
    fullOutline = fullOutline.filter(function (pth) { var a = ClipperLib.Clipper.Area(pth) / (SC * SC); return !(a < 0 && a > -6); });

    // --- magnetometers. show.sensor_layout "custom" (the default since rev A6) takes them from mag.list, where each has its
    //     own board and side (src/magmodel.js; the Magnetometers tab edits it). The older fixed choices still read: the
    //     WigLEDmag's own (9 TMAG5273 + 8 MMC5603), or a planned MMC5603 grid over the 76 x 45 mm hole field (3 x 6, 4 x 8) ---
    var sensLayout = (P.show && P.show.sensor_layout) || (P.mag && P.mag.list ? 'custom' : 'wigledmag'), sensorSet = { layout: sensLayout, mmc: ref.mmc || [], tmag: ref.tmag || [] };
    if (sensLayout === 'custom') {
      var mini = { layers: layers, removable: removable, wig: { pcb_t: w.pcb_t } };
      sensorSet = { layout: 'custom', mmc: [], tmag: [] };
      ((P.mag && P.mag.list) || []).forEach(function (s, i) {
        var fc = Mag.faceOf(mini, s), tm = s.kind === 'tmag';
        (tm ? sensorSet.tmag : sensorSet.mmc).push({ ref: s.ref || ((tm ? 'T' : 'M') + (i + 1)), x: +s.x, y: +s.y, side: s.side === 'bottom' ? 'B' : 'F', on: s.on, z: fc.zDie, face: fc.z, dir: fc.dir });
      });
    }
    var grids = { plan18: [3, 6], plan32: [4, 8] };
    if (grids[sensLayout]) {
      var gr0 = grids[sensLayout], fw = 76, fh = 45, fx0 = w.width / 2 - fw / 2, fy0 = (ref.rows && ref.rows.length ? (ref.rows[0] + ref.rows[ref.rows.length - 1]) / 2 : w.height / 2) - fh / 2, planned = [];
      for (var gy = 0; gy < gr0[0]; gy++) for (var gx = 0; gx < gr0[1]; gx++) planned.push({ ref: 'M' + (planned.length + 1), x: round(fx0 + (gx + 0.5) * fw / gr0[1], 2), y: round(fy0 + (gy + 0.5) * fh / gr0[0], 2), side: 'B' });
      sensorSet = { layout: sensLayout, mmc: planned, tmag: [], pitch: [round(fw / gr0[1], 2), round(fh / gr0[0], 2)] };
    }

    // --- parts ---
    var parts = [];
    function addPart(o) {
      // o: {id, type, label, x, y, rot, plane:{z, dir, bottom}, bodies:[{shape,z0,z1,...}], clearance, ...}
      var p = { id: o.id, type: o.type, label: o.label, x: o.x, y: o.y, rot: o.rot || 0, bottom: !!o.plane.bottom, zPlane: round(o.plane.z), dir: o.plane.dir,
        mountLayer: o.mountLayer || null, color: o.color, model: o.model || null, source: o.source || '', system: !!o.system, movable: o.movable !== false,
        noClash: o.noClash || [], cut: o.cut !== false, bodies: [], ghosts: [], extra: o.extra || null,
        group: o.group || null, open: o.open || null, boards: {}, accessOpen: !!(o.access && o.access.open),
        accessPts: o.access ? place(shapePts(o.access.shape), o.x, o.y, o.rot || 0, !!o.plane.bottom) : null,
        // a tongue is a feature of the top board, so it is laid out as seen from above whichever face the switch is on
        tonguePts: o.tongue ? place(o.tongue, o.x, o.y, o.rot || 0, false) : null,
        accessClear: o.access && o.access.clear != null ? o.access.clear : 0.25, cantilever: o.cantilever || null, fp: o.fp || null, lcsc: o.lcsc || null, win: o.win || null };
      function conv(b, ghost) {
        var z0 = o.plane.dir > 0 ? o.plane.z + b.z0 : o.plane.z - b.z1, z1 = o.plane.dir > 0 ? o.plane.z + b.z1 : o.plane.z - b.z0;
        var pts = place(shapePts(b.shape), o.x, o.y, o.rot || 0, !!o.plane.bottom);
        return { name: b.name || '', pts: pts, z0: round(z0), z1: round(z1), clearance: b.clearance != null ? b.clearance : (o.clearance != null ? o.clearance : 0.25), cut: !ghost && b.cut !== false && o.cut !== false, ghost: !!ghost, slot: !!b.slot, glass: !!b.glass };
      }
      (o.bodies || []).forEach(function (b) { p.bodies.push(conv(b, false)); });
      (o.ghosts || []).forEach(function (b) { p.ghosts.push(conv(b, true)); });
      p.z0 = Math.min.apply(null, p.bodies.map(function (b) { return b.z0; }));
      p.z1 = Math.max.apply(null, p.bodies.map(function (b) { return b.z1; }));
      parts.push(p);
      return p;
    }
    function plane(m, height) {
      if (m && m.on) {
        var L = layerById(m.on);
        if (!L) { notes.push('mount board ' + m.on + ' is not in the stack; using ' + layers[0].id); L = layers[0]; }
        return m.side === 'bottom' ? { z: L.z0, dir: -1, bottom: true, layer: L.id } : { z: L.z1, dir: 1, bottom: false, layer: L.id };
      }
      if (m && m.flush === 'bb') return { z: bbTop + (m.offset || 0) - height, dir: 1, bottom: false, layer: null };
      if (m && m.flush === 'top') return { z: zTop + (m.offset || 0) - height, dir: 1, bottom: false, layer: top.id };
      return { z: (m && m.z) || 0, dir: 1, bottom: false, layer: null };
    }

    // breadboard shell (+ optional face PCB)
    var sx0 = (w.width - w.shell.w) / 2, sy0 = (w.height - w.shell.h) / 2;
    // Its plan is the 78.7 x 54.6 envelope trimmed to the wig's own edge: the shell doc says the rail blocks run 0.6 mm past
    // the body, which is the same waist the WigLEDmag has. The corner shape is taken from the PCB (ASSUMPTION for the shell).
    // The two short link notches the PCB has beside its tongue are not in the shell: its top edge is filled between the corners.
    var shellShape = expolys(inter(region([rectPts(sx0, sy0, sx0 + w.shell.w, sy0 + w.shell.h)]), union(wigRegion, region([rectPts(5, 0, w.width - 5, 5)]))));
    var shellPts = shellShape.length ? shellShape[0].outer : rectPts(sx0, sy0, sx0 + w.shell.w, sy0 + w.shell.h);
    addPart({ id: 'shell', type: 'bb_shell', label: 'Breadboard shell', x: 0, y: 0, rot: 0, plane: { z: 0, dir: 1 }, system: true, movable: false, color: 0x161616,
      clearance: w.fit_gap, bodies: [{ shape: { poly: shellPts }, z0: 0, z1: shellTop, name: 'shell' }],
      noClash: ['face', 'wig_pcb', 'wig_hdr'], source: 'claude_V6_breadboard_shell_DFM.md: 78.7 x 54.6 envelope, 6.75 tall (redesign target; the current print is 7.1), rail blocks 0.6 past the body.' });
    var facePts = null;
    if (faceP) {
      // The wig's top board (ref.face, read from wiigtop.3mf): the countersunk holes on the body's outline. The file's outline also
      // has a 3.43 mm strip along the top with the 2 x 35 holes; that card edge belongs to the bottom board, so it is trimmed
      // unless header_strip is true.
      var fr = ref.face && !faceP.plain ? ref.face : null;
      var faceReg = region([fr ? fr.outline : rectPts(0, 0, w.width, w.height)]);
      if (fr && faceP.header_strip !== true) faceReg = inter(faceReg, region([rectPts(-1, 0, w.width + 1, w.height + 1)]));
      var fe = expolys(faceReg); facePts = fe.length ? fe[0].outer : rectPts(0, 0, w.width, w.height);
      addPart({ id: 'face', type: 'bb_face', label: fr ? 'Wig top board' : 'Breadboard face PCB', x: 0, y: 0, rot: 0, plane: { z: shellTop, dir: 1 }, system: true, movable: false, color: 0x101012,
        clearance: w.fit_gap, bodies: [{ shape: { poly: facePts }, z0: 0, z1: faceT, name: 'face board' }], noClash: ['shell', 'wig_pcb', 'wig_hdr', 'wig_skt'],
        source: fr ? fr.source + ': ' + fr.w + ' x ' + fr.h + ' x ' + fr.t + ', ' + fr.holes.length + ' holes.' : 'a plain rectangle (no face board data)' });
    }

    // removable wig: its own PCB (real outline) and the right-angle 1.27 mm header pair. Both halves sit on the top
    // faces, so the mated pair is inside the sandwich under the upper boards.
    var hdrRef = null;
    (ref.footprints || []).forEach(function (fp) { if (fp.name === 'PinHeader_2x35_P1.27_wiig_card') hdrRef = fp; });
    var hx = hdrRef ? hdrRef.x : 17.78, hy = hdrRef ? hdrRef.y : -0.254, span = 34 * 1.27;
    var MATE = 2.77 + 5.82;           // header plastic face to its pin row + socket body depth: row-to-row distance when mated
    if (removable) {
      addPart({ id: 'wig_pcb', type: 'wig_pcb', label: 'Wig bottom board (card edge along the top)', x: 0, y: 0, rot: 0, plane: { z: -w.pcb_t, dir: 1 }, system: true, movable: false, color: 0x101010,
        clearance: w.pcb_gap, bodies: [{ shape: { poly: wigPts }, z0: 0, z1: w.pcb_t, name: 'wig PCB' }], noClash: ['shell', 'wig_hdr', 'wig_skt'],
        source: 'Edge.Cuts of Testolomew/Hardware/WigLEDmag/WigLEDmag.kicad_pcb.' });
      var bot = w.connector_side === 'bottom';
      var H = Catalog.parts.hdr_ra_2x35, S = Catalog.parts.skt_ra_2x35;
      addPart({ id: 'wig_hdr', type: 'hdr_ra_2x35', label: H.label + ' (on the wig)', x: bot ? hx + span : hx, y: hy, rot: bot ? 270 : 90,
        plane: bot ? { z: -w.pcb_t, dir: -1, bottom: true } : { z: 0, dir: 1 }, system: true, movable: false, color: H.color, model: H.model, bodies: H.bodies, clearance: H.clearance,
        noClash: ['wig_skt', 'wig_pcb', 'shell'], source: H.source });
      addPart({ id: 'wig_skt', type: 'skt_ra_2x35', label: S.label + ' (on the main board)', x: bot ? hx + span : hx, y: hy - MATE, rot: bot ? 270 : 90,
        plane: bot ? { z: layers[0].z0, dir: -1, bottom: true } : { z: layers[0].z1, dir: 1 }, mountLayer: layers[0].id, system: true, movable: false, color: S.color, model: S.model, bodies: S.bodies, clearance: S.clearance,
        noClash: ['wig_hdr', 'wig_pcb'], source: S.source });
    }

    // probe dock: a channel in the space between the bottom and the top board. Only boards in between are cut.
    var probe = null;
    if (P.probe && P.probe.dock && P.probe.dock.enabled) {
      var pd = P.probe.dock, d = P.probe.dia, cl = pd.clearance, cw = d + 2 * cl;
      var lo = layers[0].z1, hi = layers.length > 1 ? top.z0 : lo + cw;
      var zc = pd.z != null ? pd.z : (lo + hi) / 2;
      addPart({ id: 'probe', type: 'probe', label: 'Probe in its dock', x: pd.x, y: pd.y_tip, rot: 0, plane: { z: 0, dir: 1 }, system: true, movable: false, color: 0xd8d8d8, clearance: 0,
        bodies: [{ shape: { rect: [-cw / 2, -cl, cw / 2, P.probe.len + cl] }, z0: zc - cw / 2, z1: zc + cw / 2, name: 'channel' }], noClash: [] });
      probe = { x: pd.x, y0: pd.y_tip, y1: pd.y_tip + P.probe.len, zc: round(zc), dia: d, channel_w: round(cw), cavity: [round(lo), round(hi)],
        magnet: { x: pd.x, y: pd.y_tip + P.probe.magnet.from_tip + P.probe.magnet.len / 2, z: round(zc), dia: P.probe.magnet.dia, len: P.probe.magnet.len } };
    }

    // user parts
    (P.parts || []).forEach(function (u) {
      var cat = Catalog.get ? Catalog.get(u, { zBot: zBot, zTop: zTop, layers: layers }) : Catalog.parts[u.type];
      if (!cat) { notes.push('unknown part type ' + u.type + ' (' + u.id + ')'); return; }
      var pl = plane(u.mount, cat.height), tg = null, wn = null, ubodies = cat.bodies, uaccess = null;
      // A display behind a window (rev A8): the module goes under the top board, which is cut to the active area, a little inside
      // it and with chamfered corners. With glass, a pane as thick as the top board fills the cut and ends flush with the top face;
      // the pane is the cut less the gap all round. Without, the cut is an opening like a button's.
      if (cat.group === 'display' && u.window && cat.screen && Catalog.windowShape) {
        wn = {}; for (var wk in Catalog.window) wn[wk] = u.window[wk] != null ? +u.window[wk] : Catalog.window[wk];
        pl = { z: top.z0 - cat.height + ((u.mount && u.mount.offset) || 0), dir: 1, bottom: false, layer: top.id };
        if (wn.glass) ubodies = cat.bodies.concat([{ shape: { poly: Catalog.windowShape(cat, wn, wn.gap) }, z0: cat.height, z1: cat.height + top.t, name: 'inlaid glass', clearance: wn.gap, glass: true }]);
        else uaccess = { shape: { poly: Catalog.windowShape(cat, wn, 0) }, open: true, clear: 0 };
        wn.w = round(cat.screen.w - 2 * wn.crop, 3); wn.h = round(cat.screen.h - 2 * wn.crop, 3); wn.aa = [cat.screen.w, cat.screen.h]; wn.module_t = cat.height;
        wn.chamfer = Math.max(0, Math.min(wn.chamfer, wn.w / 2 - 0.2, wn.h / 2 - 0.2));
      }
      if (u.tongue !== false && (u.tongue || cat.tongue) && Catalog.tongueShape) { tg = {}; for (var tk in Catalog.tongue) tg[tk] = u.tongue && u.tongue[tk] != null ? +u.tongue[tk] : (cat.tongue && cat.tongue[tk] != null ? cat.tongue[tk] : Catalog.tongue[tk]); }
      addPart({ id: u.id, type: u.type, label: u.name || cat.label, x: u.x, y: u.y, rot: u.rot || 0, plane: pl, mountLayer: pl.layer, color: cat.color, model: cat.model, bodies: ubodies, ghosts: cat.ghosts,
        clearance: u.clearance != null ? u.clearance : cat.clearance, source: cat.source, extra: cat.model && cat.model.extra, noClash: u.noClash || [],
        group: cat.group, access: uaccess || cat.access, tongue: tg ? Catalog.tongueShape(tg) : null, open: u.open,
        cantilever: tg ? { arm: tg.len - tg.tip, w: tg.w, len: tg.len, slot: tg.slot, nub: tg.nub || 0 } : null, fp: cat.fp, lcsc: cat.lcsc, win: wn });
    });

    // --- board shapes: the outline, manual features, then every part that passes through a board cuts its opening ---
    function zOverlap(a0, a1, b0, b1) { return Math.min(a1, b1) - Math.max(a0, b0); }
    layers.forEach(function (L) {
      var a = (L.kind === 'base' && !removable) ? fullOutline : frameL;
      L.gross = round(area(a), 1);
      if (L.kind === 'ring') { var inner = offset(a, -Math.max(0.3, f.ring_wall || 2)); a = diff(a, inner); }
      (P.features || []).forEach(function (ft) {
        if (!ft.layers || ft.layers.indexOf(L.id) < 0) return;
        var hw = ft.w / 2, hh = ft.h / 2, r = Math.min(ft.r || 0, hw - 0.01, hh - 0.01);
        var rr = region([place(rectPts(-hw + r, -hh + r, hw - r, hh - r), ft.x, ft.y, ft.rot || 0, false)]);
        if (r > 0) rr = offset(rr, r);
        a = ft.op === 'add' ? union(a, rr) : diff(a, rr);
      });
      // Which parts open this board. Automatic: a body that passes through it, and, for a part that has to be reached
      // from outside (catalogue "access"), the boards beyond its top. A part's own "open" map overrides either way:
      // true opens the board for it even if it stops short, false leaves the board whole even if the part runs into it.
      var cuts = [], cutBy = [];
      L.blocked = [];
      parts.forEach(function (p) {
        var wish = p.open && p.open[L.id] != null ? !!p.open[L.id] : null;
        var through = p.bodies.filter(function (b) { return b.cut && zOverlap(b.z0, b.z1, L.z0, L.z1) > EPS; });
        var beyond = p.dir > 0 ? L.z0 >= p.z1 - EPS : L.z1 <= p.z0 + EPS;
        // A cantilevered button's tongue belongs to the top board and to no other, whatever the stack and whichever board or
        // face the switch is on: it is the board a finger presses. A board between the switch and the top board gets the
        // switch's plain opening; no board on the far side of the switch is opened for it.
        var tongueHere = !!p.tonguePts && L.id === top.id, between = !!p.tonguePts && L.id !== top.id && p.dir > 0 && L.z0 >= p.z1 - EPS && p.accessPts && p.accessOpen;
        var state = 'whole', auto = through.length ? 'through' : p.tonguePts ? (tongueHere || between ? 'access' : 'whole') : (p.accessPts && p.accessOpen && beyond ? 'access' : 'whole');
        var tongueCut = false;
        if (wish === false) { state = through.length ? 'blocked' : 'whole'; if (through.length) L.blocked.push({ part: p, bodies: through }); }
        else if (through.length) { through.forEach(function (b) { cuts = cuts.concat(offset(region([b.pts]), b.clearance)); }); state = 'through'; }
        else if (tongueHere) { cuts = cuts.concat(region([p.tonguePts])); state = 'access'; tongueCut = true; }
        else if (wish === true || auto === 'access') {
          var shapes = p.accessPts ? [p.accessPts] : p.bodies.filter(function (b) { return !b.slot; }).map(function (b) { return b.pts; });
          cuts = cuts.concat(p.accessClear > 0 ? offset(region(shapes), p.accessClear) : region(shapes)); state = 'access';
        }
        if (!p.system || state !== 'whole') p.boards[L.id] = { state: state, auto: auto, set: wish };
        if (tongueCut) p.boards[L.id].tongue = true;
        if (state !== 'whole' && state !== 'blocked' && cutBy.indexOf(p.id) < 0) cutBy.push(p.id);
      });
      var before = area(a);
      if (cuts.length) a = diff(a, union(cuts));
      a = clean(a);
      L.region = a;
      L.shape = expolys(a);
      L.area = round(area(a), 1);
      L.pocketArea = round(before - area(a), 1);
      L.islands = L.shape.length;
      L.cutBy = cutBy;
      L.bbox = bbox(a);
    });

    // --- checks ---
    var checks = { grid: {}, flush: {}, clashes: [], neighbours: [], faces: [], probe: null, notes: notes };
    checks.joints = joints.map(function (j) { return { vertex: j.vertex, at: j.at, flat: j.flat }; });      // where the frame's edge meets a chamfer of the breadboard square
    checks.grid = { pitch: round(unitPitch), dead_rows: dead + 1, cols: g.cols, left_plane: round(xl), right_plane: round(xr), strip_w: round(-xl), on_grid: Math.abs(unitPitch / pitch - Math.round(unitPitch / pitch)) < 1e-6,
      dead_x: (function () { var a = []; for (var j = 0; j <= dead; j++) a.push(round(-j * pitch)); return a; })() };
    // The simplified outline: left strip plane to right plane, top edge to bottom edge. Kevin wants it square. Square on the unit
    // pitch also puts the height on the 2.54 grid, so a unit stood above another keeps its hole rows on the grid too.
    (function () {
      var H = round(yb - yt), bw = round(Math.max(fb.x1, xr) - fb.x0), rows = H / pitch;
      checks.grid.overall = { w: round(unitPitch), h: H, widest: bw, band: round(-yt), square: Math.abs(unitPitch - H) < 0.05, square_widest: Math.abs(bw - H) < 0.05,
        band_square: round(unitPitch - yb), band_square_widest: round(bw - yb), rows_high: round(rows, 3), v_on_grid: Math.abs(rows - Math.round(rows)) < 0.002 };
    })();
    checks.flush = { frame_top: round(zTop), bb_top: round(bbTop), shell_top: round(shellTop), face_t: round(faceT), delta: round(zTop - bbTop), delta_shell: round(zTop - shellTop), total: round(zTop - zBot), stack_above_base: round(zTop),
      gaps: layers.slice(1).map(function (L) { return { below: L.id, gap: round(L.gap) }; }) };

    parts.forEach(function (p) {
      var x0 = 1e9, x1 = -1e9;
      p.bodies.forEach(function (b) { b.pts.forEach(function (q) { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); }); });
      p.xmin = round(x0); p.xmax = round(x1);
    });

    // side by side on the 0.1 inch grid: this unit's plan against a neighbour one unit pitch away.
    // Plan only (heights are ignored), and edges that just touch do not count.
    function shiftX(a, dx) { var k = Math.round(dx * SC); return a.map(function (p) { return p.map(function (q) { return { X: q.X + k, Y: q.Y }; }); }); }
    function partPlan(p) { var polys = []; p.bodies.forEach(function (b) { if (!b.slot) polys.push(b.pts); }); return region(polys); }
    var boardsPlan = [];
    layers.forEach(function (L) { boardsPlan = boardsPlan.concat(L.region); });
    boardsPlan = union(boardsPlan, removable ? wigRegion : []);
    var unitPlan = boardsPlan;
    parts.forEach(function (p) { unitPlan = unitPlan.concat(partPlan(p)); });
    unitPlan = union(unitPlan);
    function versus(id, label, nb) {
      var nbE = offset(nb, -0.02), items = [];
      var tot = inter(unitPlan, nbE), ar = area(tot);
      if (ar > 0.02) {
        layers.forEach(function (L) { var o = area(inter(L.region, nbE)); if (o > 0.02) items.push({ what: L.id + ' ' + L.name, mm2: round(o, 1) }); });
        parts.forEach(function (p) { if (p.id === 'shell' || p.id === 'wig_pcb') return; var o = area(inter(partPlan(p), nbE)); if (o > 0.02) items.push({ what: p.label, id: p.id, mm2: round(o, 1) }); });
      }
      var b = ar > 0.02 ? bbox(tot) : null;
      return { id: id, label: label, overlap_mm2: ar > 0.02 ? round(ar, 1) : 0, depth: b ? round(b.x1 - b.x0, 2) : 0, y0: b ? round(b.y0, 1) : null, y1: b ? round(b.y1, 1) : null, items: items };
    }
    checks.neighbours.push(versus('wig_left', 'A bare breadboard (WigLEDmag outline) on the left', shiftX(wigRegion, -unitPitch)));
    checks.neighbours.push(versus('wig_right', 'A bare breadboard (WigLEDmag outline) on the right', shiftX(wigRegion, unitPitch)));
    checks.neighbours.push(versus('unit_left', 'Another whole unit on the left', shiftX(unitPlan, -unitPitch)));
    checks.neighbours.push(versus('unit_right', 'Another whole unit on the right', shiftX(unitPlan, unitPitch)));
    var clearAt = null;
    for (var kx = 0; kx <= 8 && clearAt == null; kx++) if (area(inter(unitPlan, offset(shiftX(unitPlan, unitPitch + kx * pitch), -0.02))) <= 0.02) clearAt = kx;
    checks.grid.units_clear_at = clearAt == null ? null : { pitch: round(unitPitch + clearAt * pitch), dead_rows: dead + 1 + clearAt, extra_rows: clearAt };

    // an edge coupler between this unit and the next: what it needs between the two boards' shoulders, against the rows on hand
    var cpl = Catalog.couplers && g.coupler && Catalog.couplers[g.coupler];
    if (cpl) {
      var have = dead * pitch, needRows = Math.ceil((cpl.gap - 1e-6) / pitch);
      checks.grid.coupler = { key: g.coupler, label: cpl.label, gap: cpl.gap, across: cpl.across, len: cpl.len, thick: cpl.thick, tongue: cpl.tongue, tip_gap: cpl.tip_gap, have: round(have), fits: have + 1e-6 >= cpl.gap,
        spare: round(have - cpl.gap, 2), rows_needed: needRows, strip_needed: round(needRows * pitch), source: cpl.source,
        x0: round(xr), x1: round(xr + have), yc: round(w.height / 2, 2), zc: round(-layers[0].t / 2, 2) };
    }

    // parts that reach past the edge of the board they sit on (wanted for an edge wheel or a connector mouth; worth seeing either way)
    checks.overhang = [];
    parts.forEach(function (p) {
      var L = p.mountLayer && !p.system ? layerById(p.mountLayer) : null; if (!L) return;
      var edge = (L.kind === 'base' && !removable) ? fullOutline : frameL, o = diff(partPlan(p), edge), ar = area(o);
      if (ar > 0.05) { var b = bbox(o); checks.overhang.push({ id: p.id, label: p.label, layer: L.id, mm2: round(ar, 1), x: [round(b.x0, 2), round(b.x1, 2)], y: [round(b.y0, 2), round(b.y1, 2)] }); }
    });

    // a part that runs into a board it was told not to open
    // cantilevered buttons: the tongue is cut in the top board. A plain cantilever, loaded at the switch: k = 3 E I / L^3.
    // E = 22 GPa is a usual flexural modulus for FR4 (ASSUMPTION), the switch's own force and travel are typical tact figures.
    checks.cantilevers = [];
    parts.forEach(function (p) {
      if (!p.cantilever) return;
      var st = p.boards[top.id], rec = { id: p.id, label: p.label, board: top.id, t: top.t, switch_on: p.mountLayer, underside: p.bottom };
      if (!st || !st.tongue) { rec.none = true; rec.why = st && st.state === 'through' ? 'through' : st && st.set === false ? 'kept' : 'unknown'; checks.cantilevers.push(rec); return; }
      // Where the switch is against the tongue. below: on a board under the top board, pressed from above (the usual way).
      // under: soldered to the underside of the top board, on the tongue itself, pressing on the board below.
      // away: anywhere else (hanging under a lower board, or on top of the top board): the tongue cannot work it.
      var gap = null;
      if (p.mountLayer === top.id && p.bottom) {
        var land = null; layers.forEach(function (L) { if (L.id !== top.id && L.z1 <= p.z0 + EPS) land = L; });
        rec.under = true; rec.lands = land ? land.id : null; gap = land ? p.z0 - land.z1 : null;
      } else if (p.dir > 0 && p.z1 <= top.z0 + EPS) gap = top.z0 - p.z1;
      else rec.away = true;
      var slotR = region([p.tonguePts]); rec.broken = round(area(diff(diff(offset(slotR, 0.8), slotR), top.region)), 1); if (rec.broken <= 0.3) rec.broken = 0;
      var E = 22000, c = p.cantilever, I = c.w * Math.pow(top.t, 3) / 12, k = 3 * E * I / Math.pow(c.arm, 3);
      rec.arm = round(c.arm, 2); rec.w = c.w; rec.k = round(k, 1); rec.nub = c.nub || 0;
      if (gap != null) {
        var travel = Math.max(0, gap - (c.nub || 0)) + 0.25;
        rec.gap = round(gap, 3); rec.travel = round(travel, 2); rec.far = gap - (c.nub || 0) > 1;       // more than a millimetre of air: the tongue will not get there
        rec.force = round(k * travel + 1.6, 1); rec.board_force = round(k * travel, 1); rec.stress = round(3 * E * top.t * travel / (2 * c.arm * c.arm), 0);
        rec.with_nub = round(k * (Math.max(0, gap - 0.2) + 0.25) + 1.6, 1);
        rec.thin = { t: 0.8, force: round(3 * E * (c.w * 0.512 / 12) / Math.pow(c.arm, 3) * travel + 1.6, 1) };
      }
      checks.cantilevers.push(rec);
    });
    // displays behind a window: what the cut and the pane come to, and the room left under the module (for switches under it)
    checks.windows = [];
    parts.forEach(function (p) {
      if (!p.win) return;
      var k = p.win, below = null; layers.forEach(function (L) { if (L.z1 <= p.z0 + EPS) below = L; });
      checks.windows.push({ id: p.id, label: p.label, board: top.id, t: top.t, w: k.w, h: k.h, crop: k.crop, chamfer: round(k.chamfer, 2), aa: k.aa,
        shown_pct: round(100 * (k.w * k.h - 2 * k.chamfer * k.chamfer) / (k.aa[0] * k.aa[1]), 1),
        glass: k.glass ? { w: round(k.w - 2 * k.gap, 3), h: round(k.h - 2 * k.gap, 3), t: top.t, gap: k.gap } : null,
        z_module: [round(p.z0, 3), round(p.z0 + k.module_t, 3)], below: below ? below.id : null, under: below ? round(p.z0 - below.z1, 3) : null });
    });
    checks.blocked = [];
    layers.forEach(function (L) { L.blocked.forEach(function (q) {
      var ar = area(inter(region(q.bodies.map(function (b) { return b.pts; })), L.region));
      if (ar > 0.05) checks.blocked.push({ id: q.part.id, label: q.part.label, layer: L.id, name: L.name, mm2: round(ar, 1) });
    }); delete L.blocked; });
    // how far each part stands above the top face (or hangs below the underside)
    checks.proud = [];
    parts.forEach(function (p) {
      if (p.system) return;
      var up = round(p.z1 - Math.max(zTop, bbTop), 2), down = round(zBot - p.z0, 2);
      p.proud = up; p.below = down;
      if (up > 0.05) checks.proud.push({ id: p.id, label: p.label, side: 'top', by: up });
      if (down > 0.05) checks.proud.push({ id: p.id, label: p.label, side: 'underside', by: down });
    });

    // part against part
    for (var i = 0; i < parts.length; i++) for (var j = i + 1; j < parts.length; j++) {
      var A = parts[i], B = parts[j];
      if (A.noClash.indexOf(B.id) >= 0 || B.noClash.indexOf(A.id) >= 0) continue;
      var worst = null;
      A.bodies.forEach(function (ba) { B.bodies.forEach(function (bb) {
        if (ba.slot || bb.slot) return;
        var dz = zOverlap(ba.z0, ba.z1, bb.z0, bb.z1);
        if (dz <= EPS) return;
        var ar = area(inter(region([ba.pts]), region([bb.pts])));
        if (ar > 0.05 && (!worst || ar * dz > worst.area * worst.dz)) worst = { area: round(ar, 2), dz: round(dz, 2), a: ba.name, b: bb.name };
      }); });
      if (worst) checks.clashes.push({ a: A.id, b: B.id, labels: [A.label, B.label], bodies: [worst.a, worst.b], overlap_mm2: worst.area, overlap_z: worst.dz });
    }

    // room: each board face, less whatever stands in the space in front of it. Under a facing board the headroom is the
    // gap (shared with whatever hangs from that board); where the facing board is cut away or ends it is more.
    var minGap = P.room && P.room.min_gap != null ? P.room.min_gap : 0.6;
    function occupied(zA, zB) {
      var polys = [];
      parts.forEach(function (p) { p.bodies.forEach(function (b) {
        if (b.slot) return;
        if (zOverlap(b.z0, b.z1, zA, zB) > EPS) polys = polys.concat(offset(region([b.pts]), 0.2));
      }); });
      return polys.length ? union(polys) : [];
    }
    var placeable = 0;
    layers.forEach(function (L, k) {
      [1, -1].forEach(function (dir) {
        var n1 = layers[k + dir], zf = dir > 0 ? L.z1 : L.z0;
        var face = { layer: L.id, name: L.name, side: dir > 0 ? 'top' : 'bottom' };
        if (L.kind === 'ring') { face.counts = false; face.spacer = true; face.free = 0; checks.faces.push(face); return; }
        if (!n1) {
          var occ0 = dir > 0 ? occupied(zf + 0.05, zf + 1.0) : occupied(zf - 1.0, zf - 0.05);
          face.open = true; face.height = 'open';
          var fr0 = diff(L.region, occ0);
          face.free = round(area(fr0), 0); face.free_open = 0;
          if (L.kind === 'base' && !removable) face.under_bb = round(area(inter(fr0, wigRegion)), 0);
          face.counts = !(dir > 0);                 // the top of the top board is the user's face, not component room
        } else {
          var gap = round(dir > 0 ? n1.z0 - L.z1 : L.z0 - n1.z1, 3), reach = Math.max(gap, 1.0);
          var occ = dir > 0 ? occupied(zf + 0.05, zf + reach) : occupied(zf - reach, zf - 0.05);
          var under = inter(L.region, n1.region), clear = diff(L.region, n1.region);
          face.height = gap;
          face.free = gap >= minGap ? round(area(diff(under, occ)), 0) : 0;
          if (L.kind === 'base' && !removable) face.under_bb = round(area(inter(diff(L.region, occ), wigRegion)), 0);
          face.free_open = round(area(diff(clear, occ)), 0);
          face.counts = true;
        }
        if (face.counts) placeable += face.free + (face.free_open || 0);
        checks.faces.push(face);
      });
    });
    checks.area = { budget: P.area_budget_mm2 || 0, placeable: round(placeable, 0), fill: placeable > 0 ? round((P.area_budget_mm2 || 0) / placeable, 3) : null,
      frame_face: round(area(frameL), 0), full_face: round(area(fullOutline), 0), min_gap: minGap };

    checks.split = layers.filter(function (L) { return L.islands !== 1; }).map(function (L) { return { layer: L.id, name: L.name, pieces: L.islands }; });

    // probe dock
    if (probe) {
      var innerX = sx0 - w.fit_gap;      // where the upper boards' strip ends against the shell
      var wl = (probe.x - probe.channel_w / 2) - xl, wr = innerX - (probe.x + probe.channel_w / 2);
      var sens = [];
      sensorSet.mmc.forEach(function (s) { sens.push({ kind: 'MMC5603', ref: s.ref, x: s.x, y: s.y, z: s.z != null ? s.z : (s.side === 'F' ? 0 : -w.pcb_t), range: 3 }); });
      sensorSet.tmag.forEach(function (s) { sens.push({ kind: 'TMAG5273', ref: s.ref, x: s.x, y: s.y, z: s.z != null ? s.z : (s.side === 'F' ? 0 : -w.pcb_t), range: 40 }); });
      var m = probe.magnet, mom = 115.4 * Math.PI * Math.pow(m.dia / 2, 2) * m.len;     // mT*mm^3, Br 1.45 T (N52), the convention in wireless-probe-sensing.md
      var near = null;
      sens.forEach(function (s) {
        var dx = s.x - m.x, dy = s.y - m.y, dz = s.z - m.z, r = Math.sqrt(dx * dx + dy * dy + dz * dz), cosT = dy / r;   // magnet axis lies along y in the dock
        var B = mom / (r * r * r) * Math.sqrt(1 + 3 * cosT * cosT);
        if (!near || B / s.range > near.frac) near = { kind: s.kind, ref: s.ref, r: round(r, 1), B_mT: round(B, 3), range_mT: s.range, frac: B / s.range };
      });
      var cutsEnds = [];
      [layers[0], top].forEach(function (L) { if (L.cutBy.indexOf('probe') >= 0 && cutsEnds.indexOf(L.id) < 0) cutsEnds.push(L.id); });
      checks.probe = { wall_left: round(wl, 2), wall_right: round(wr, 2), channel_w: probe.channel_w, zc: probe.zc, cavity: probe.cavity, room_z: round(probe.cavity[1] - probe.cavity[0], 2),
        cuts_outer: cutsEnds, cuts: layers.filter(function (L) { return L.cutBy.indexOf('probe') >= 0; }).map(function (L) { return L.id; }),
        sticks_out: round(Math.max(0, probe.y1 - yb), 1), moment: round(mom, 0), nearest: near,
        dead_row_in_channel: checks.grid.dead_x.filter(function (x) { return Math.abs(x - probe.x) < probe.channel_w / 2; }) };
    }

    // breadboard grid (for drawing): columns at pitch from the wig edge; rows from the real board when known
    var rows = ref.rows && ref.rows.length ? ref.rows : (function () { var a = []; for (var r = 0; r < 20; r++) if (r !== 2 && r !== 3 && r !== 16 && r !== 17) a.push(3.556 + r * pitch); return a; })();
    var cols = []; for (var k = 1; k <= g.cols; k++) cols.push(round(k * pitch));

    var out = {
      params: P, removable: removable,
      planes: { xl: round(xl), xr: round(xr), yt: yt, yb: yb, pitch: round(unitPitch), dead: dead, x0: round(fb.x0), x1: round(Math.max(fb.x1, xr)) },
      z: { top: round(zTop), bottom: round(zBot), bbTop: round(bbTop), shellTop: round(shellTop) },
      outline: { verts: verts.map(function (v, i) { return { x: v.x, y: v.y, from: built.spans[i].from, count: built.spans[i].count }; }), pts: built.pts },
      layers: layers, parts: parts, probe: probe, checks: checks,
      wig: { x0: 0, y0: 0, w: w.width, h: w.height, pcb_t: w.pcb_t, shell: { x0: sx0, y0: sy0, w: w.shell.w, h: w.shell.h, t: round(shellTop) }, face_t: faceT, face: faceP ? { t: faceT, z0: round(shellTop), z1: round(bbTop), inset: faceInset, real: !!(ref.face && !faceP.plain), strip: faceP.header_strip === true, pts: facePts, y0: round(bbox(region([facePts])).y0), holes: ref.face && !faceP.plain ? ref.face.holes.filter(function (q) { return faceP.header_strip === true || q[1] >= 0; }) : null } : null,
        outline: wigPts, rows: rows, cols: cols,
        card_holes: ref.face ? ref.face.holes.filter(function (q) { return q[1] < 0; }) : [],
        sensors: sensorSet }
    };
    // the layout as a list the Magnetometers tab can show and edit, whichever way it was chosen
    sensorSet.list = sensLayout === 'custom' ? ((P.mag && P.mag.list) || []) : Mag.legacyList(out, ref, sensLayout);
    return out;
  }

  // a plain-data copy of the result (no clipper paths) for JSON, STEP export and tests
  function plain(R) {
    return {
      meta: R.params.meta, mode: R.removable ? 'removable' : 'integrated', planes: R.planes, z: R.z, outline: R.outline,
      layers: R.layers.map(function (L) { return { id: L.id, name: L.name, kind: L.kind, t: L.t, z0: L.z0, z1: L.z1, area: L.area, gross: L.gross, pocketArea: L.pocketArea, islands: L.islands, cutBy: L.cutBy, shape: L.shape }; }),
      parts: R.parts.map(function (p) { return { id: p.id, type: p.type, label: p.label, x: p.x, y: p.y, rot: p.rot, bottom: p.bottom, zPlane: p.zPlane, dir: p.dir, z0: p.z0, z1: p.z1, model: p.model, extra: p.extra, source: p.source, boards: p.boards,
        bodies: p.bodies.map(function (b) { return { name: b.name, pts: b.pts, z0: b.z0, z1: b.z1, slot: b.slot, glass: b.glass }; }), ghosts: p.ghosts.map(function (b) { return { name: b.name, pts: b.pts, z0: b.z0, z1: b.z1 }; }) }; }),
      probe: R.probe, wig: R.wig, checks: R.checks
    };
  }

  return { resolve: resolve, plain: plain, buildOutline: buildOutline, legacyOutline: legacyOutline, util: { region: region, union: union, diff: diff, inter: inter, offset: offset, area: area, expolys: expolys, place: place, rectPts: rectPts, circlePts: circlePts, round: round } };
});
