// Jumperless V6 outline tool - geometry engine.
// params (v6_outline.json) -> per-layer outlines with pockets, placed parts, and the checks.
// Runs unchanged in the browser (viewer) and in Node (build.mjs), so the picture and the files cannot disagree.
// Frame: x right, y DOWN (KiCad), x=0 wig left edge, y=0 wig body top edge, z=0 top face of the main board, z up. mm.
// The stack is boards with space between them: parts live in the gaps and a board is only opened where a part passes through it.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./vendor/clipper.js'), require('./catalog.js'), require('./magmodel.js'));
  else root.V6Geo = factory(root.ClipperLib, root.V6Catalog, root.V6Mag);
})(typeof self !== 'undefined' ? self : this, function (ClipperLib, Catalog, Mag) {
  'use strict';
  var SC = 1000;                      // clipper works in integers: 1 unit = 1 um
  var CT = ClipperLib.ClipType, PT = ClipperLib.PolyType, FT = ClipperLib.PolyFillType;
  var EPS = 0.02;

  // ---------- 2D helpers (regions are arrays of clipper paths; holes wind the other way) ----------
  function toC(pts) { return pts.map(function (p) { return { X: Math.round(p[0] * SC), Y: Math.round(p[1] * SC) }; }); }
  function fromC(path) { return path.map(function (q) { return [q.X / SC, q.Y / SC]; }); }
  function exec(type, subj, clip) {
    var c = new ClipperLib.Clipper(), out = new ClipperLib.Paths();
    if (subj.length) c.AddPaths(subj, PT.ptSubject, true);
    if (clip && clip.length) c.AddPaths(clip, PT.ptClip, true);
    c.Execute(type, out, FT.pftNonZero, FT.pftNonZero);
    return out;
  }
  function region(polys) {            // raw polygons (mm point lists, any winding) -> region
    var paths = polys.filter(function (p) { return p && p.length > 2; }).map(function (p) {
      var c = toC(p); if (ClipperLib.Clipper.Area(c) < 0) c.reverse(); return c;
    });
    return exec(CT.ctUnion, paths, []);
  }
  function union(a, b) { return exec(CT.ctUnion, a, b || []); }
  function diff(a, b) { return b && b.length ? exec(CT.ctDifference, a, b) : a; }
  function inter(a, b) { return exec(CT.ctIntersection, a, b); }
  function offset(a, d) {
    if (!a.length || Math.abs(d) < 1e-6) return a;
    var co = new ClipperLib.ClipperOffset(2, 0.01 * SC), out = new ClipperLib.Paths();
    co.AddPaths(a, ClipperLib.JoinType.jtRound, ClipperLib.EndType.etClosedPolygon);
    co.Execute(out, d * SC);
    return out;
  }
  function clean(a) { return union(ClipperLib.Clipper.CleanPolygons(a, 0.003 * SC).filter(function (p) { return p.length > 2; })); }
  function area(a) { var s = 0; for (var i = 0; i < a.length; i++) s += ClipperLib.Clipper.Area(a[i]); return s / (SC * SC); }
  function expolys(a) {               // -> [{outer: pts, holes: [pts]}] in mm
    var c = new ClipperLib.Clipper(), tree = new ClipperLib.PolyTree();
    c.AddPaths(a, PT.ptSubject, true);
    c.Execute(CT.ctUnion, tree, FT.pftNonZero, FT.pftNonZero);
    return ClipperLib.JS.PolyTreeToExPolygons(tree).map(function (e) {
      return { outer: fromC(e.outer), holes: (e.holes || []).map(fromC) };
    });
  }
  function bbox(a) {
    var b = { x0: 1e9, y0: 1e9, x1: -1e9, y1: -1e9 };
    a.forEach(function (p) { p.forEach(function (q) {
      b.x0 = Math.min(b.x0, q.X / SC); b.x1 = Math.max(b.x1, q.X / SC); b.y0 = Math.min(b.y0, q.Y / SC); b.y1 = Math.max(b.y1, q.Y / SC);
    }); });
    return b;
  }
  function rectPts(x0, y0, x1, y1) { return [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]; }
  // a region mirrored left to right about x = w / 2 (each path reversed, so outers stay outers and holes stay holes)
  function mirrorRegion(a, w) { var k = Math.round(w * SC); return a.map(function (p) { return p.map(function (q) { return { X: k - q.X, Y: q.Y }; }).reverse(); }); }
  function circlePts(cx, cy, r) {
    var n = Math.max(32, Math.ceil(2 * Math.PI * r / 0.3)), pts = [];
    for (var i = 0; i < n; i++) pts.push([cx + r * Math.cos(2 * Math.PI * i / n), cy + r * Math.sin(2 * Math.PI * i / n)]);
    return pts;
  }
  function shapePts(s) {
    if (s.rect) return rectPts(s.rect[0], s.rect[1], s.rect[2], s.rect[3]);
    if (s.circle) return circlePts(s.circle[0], s.circle[1], s.circle[2]);
    return s.poly;
  }
  // part frame -> board frame. Bottom-side parts are mirrored in x first (as KiCad flips them), then turned
  // counter-clockwise as seen from above.
  function place(pts, x, y, rotDeg, bottom) {
    var t = rotDeg * Math.PI / 180, c = Math.cos(t), s = Math.sin(t);
    return pts.map(function (p) { var lx = bottom ? -p[0] : p[0], ly = p[1]; return [x + lx * c + ly * s, y - lx * s + ly * c]; });
  }
  // board frame -> part frame: place() undone
  function unplace(pts, x, y, rotDeg, bottom) {
    var t = rotDeg * Math.PI / 180, c = Math.cos(t), s = Math.sin(t);
    return pts.map(function (p) { var dx = p[0] - x, dy = p[1] - y, lx = dx * c - dy * s, ly = dx * s + dy * c; return [bottom ? -lx : lx, ly]; });
  }
  function round(v, n) { var k = Math.pow(10, n == null ? 3 : n); return Math.round(v * k) / k; }


  // ---------- outline from vertices ----------
  // A vertex is {x, y} plus an optional corner treatment:
  //   (nothing)        sharp
  //   r                round corner of that radius
  //   c:[cx,cy], r     "rounded chamfer": a chamfer whose two ends are blended with radius r. cx is the leg along the
  //                    more horizontal of the two edges, cy the leg along the more vertical one (the sharp chamfer, before blending)
  //   c:'wig'          the WigLEDmag corner itself (2.51 x 2.11), copied point for point from its Edge.Cuts
  //   c:'meet'         for a vertex on a corner of the breadboard where the frame stops: the vertex itself stays sharp,
  //                    and the frame's edge is made to meet the breadboard's chamfer square, at the middle of its flat
  var WIG_C = [2.211, 1.583], WIG_R = 1.0;      // the analytic twin of the WigLEDmag corner (fits it to 0.02 mm); used when the real points are not at hand
  function vsub(a, b) { return [a[0] - b[0], a[1] - b[1]]; }
  function vlen(a) { return Math.sqrt(a[0] * a[0] + a[1] * a[1]); }
  function vunit(a) { var l = vlen(a) || 1; return [a[0] / l, a[1] / l]; }
  function fillet(A, V, B, r, availA, availB) {      // points from the A side to the B side of corner V
    var u1 = vunit(vsub(A, V)), u2 = vunit(vsub(B, V));
    var cos = Math.max(-1, Math.min(1, u1[0] * u2[0] + u1[1] * u2[1])), phi = Math.acos(cos);
    if (!(r > 0.001) || phi > Math.PI - 0.01 || phi < 0.01) return [V];
    var t = r / Math.tan(phi / 2), lim = Math.min(availA, availB);
    if (t > lim) { t = Math.max(0, lim); r = t * Math.tan(phi / 2); }
    if (r < 0.005) return [V];
    var bis = vunit([u1[0] + u2[0], u1[1] + u2[1]]), d = r / Math.sin(phi / 2);
    var C = [V[0] + bis[0] * d, V[1] + bis[1] * d];
    var T1 = [V[0] + u1[0] * t, V[1] + u1[1] * t], T2 = [V[0] + u2[0] * t, V[1] + u2[1] * t];
    var a1 = Math.atan2(T1[1] - C[1], T1[0] - C[0]), a2 = Math.atan2(T2[1] - C[1], T2[0] - C[0]), da = a2 - a1;
    while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI;
    var n = Math.max(3, Math.ceil(Math.abs(da) / (2 * Math.acos(Math.max(0, 1 - 0.004 / r))))), pts = [T1];
    for (var k = 1; k < n; k++) pts.push([C[0] + r * Math.cos(a1 + da * k / n), C[1] + r * Math.sin(a1 + da * k / n)]);
    pts.push(T2);
    return pts;
  }
  function wigCorner(ref) {                          // the WigLEDmag top-left corner as (along the horizontal leg, along the vertical leg), from the horizontal end
    var o = (ref && ref.outline) || [], pts = [];
    o.forEach(function (p) { if (p[0] <= 2.52 && p[1] <= 2.11 && p[1] >= -0.001) { var l = pts[pts.length - 1]; if (!l || Math.abs(l[0] - p[0]) + Math.abs(l[1] - p[1]) > 1e-4) pts.push([p[0], p[1]]); } });
    if (pts.length < 6) return null;
    if (pts[0][0] < pts[pts.length - 1][0]) pts.reverse();
    return pts;
  }
  function buildOutline(verts, ref, notes) {
    var n = verts.length, wc = wigCorner(ref), raw = verts.map(function (v) { return [v.x, v.y]; });
    function spec(v) {                                // -> {kind, cx, cy, r}
      if (v.c === 'wig') return wc ? { kind: 'wig', cx: wc[0][0], cy: wc[wc.length - 1][1], r: 0 } : { kind: 'chamfer', cx: WIG_C[0], cy: WIG_C[1], r: WIG_R };
      if (v.c === 'meet') return { kind: 'sharp', cx: 0, cy: 0, r: 0 };
      if (v.c && v.c.length === 2) return { kind: 'chamfer', cx: Math.max(0, +v.c[0] || 0), cy: Math.max(0, +v.c[1] || 0), r: Math.max(0, +v.r || 0) };
      if (v.r > 0) return { kind: 'round', cx: 0, cy: 0, r: +v.r };
      return { kind: 'sharp', cx: 0, cy: 0, r: 0 };
    }
    var info = verts.map(function (v, i) {
      var P = raw[(i + n - 1) % n], V = raw[i], N = raw[(i + 1) % n], dP = vsub(P, V), dN = vsub(N, V), s = spec(v);
      var prevIsH = Math.abs(dP[0]) / (vlen(dP) || 1) >= Math.abs(dN[0]) / (vlen(dN) || 1);
      var legP = 0, legN = 0, tanP = 0, tanN = 0;
      if (s.kind === 'wig') { legP = prevIsH ? s.cx : s.cy; legN = prevIsH ? s.cy : s.cx; }
      else if (s.kind === 'chamfer') {
        legP = prevIsH ? s.cx : s.cy; legN = prevIsH ? s.cy : s.cx;
        var uP = vunit(dP), uN = vunit(dN), C1 = [V[0] + uP[0] * legP, V[1] + uP[1] * legP], C2 = [V[0] + uN[0] * legN, V[1] + uN[1] * legN];
        var uc = vunit(vsub(C2, C1)), ph1 = Math.acos(Math.max(-1, Math.min(1, uP[0] * uc[0] + uP[1] * uc[1]))), ph2 = Math.acos(Math.max(-1, Math.min(1, -(uN[0] * uc[0] + uN[1] * uc[1]))));
        tanP = s.r > 0 && ph1 > 0.01 ? s.r / Math.tan(ph1 / 2) : 0; tanN = s.r > 0 && ph2 > 0.01 ? s.r / Math.tan(ph2 / 2) : 0;
      } else if (s.kind === 'round') {
        var ph = Math.acos(Math.max(-1, Math.min(1, (dP[0] * dN[0] + dP[1] * dN[1]) / ((vlen(dP) || 1) * (vlen(dN) || 1)))));
        tanP = tanN = ph > 0.01 && ph < Math.PI - 0.01 ? s.r / Math.tan(ph / 2) : 0;
      }
      return { s: s, P: P, V: V, N: N, lenP: vlen(dP), lenN: vlen(dN), prevIsH: prevIsH, wantP: legP + tanP, wantN: legN + tanN, legP: legP, legN: legN };
    });
    // two corners that want more of their shared edge than it has are both scaled down
    var scale = info.map(function () { return 1; });
    info.forEach(function (a, i) {
      var b = info[(i + 1) % n], tot = a.wantN + b.wantP;
      if (tot > a.lenN * 0.999 && tot > 0) { var k = a.lenN * 0.999 / tot; scale[i] = Math.min(scale[i], k); scale[(i + 1) % n] = Math.min(scale[(i + 1) % n], k); }
    });
    var pts = [], spans = [];
    info.forEach(function (a, i) {
      var k = scale[i], s = a.s, uP = vunit(vsub(a.P, a.V)), uN = vunit(vsub(a.N, a.V)), out;
      if (k < 0.999 && s.kind !== 'sharp' && notes) notes.push('outline vertex ' + (i + 1) + ': its corner does not fit the edges next to it and was scaled to ' + Math.round(k * 100) + ' %');
      if (s.kind === 'wig' && k >= 0.999) {
        var uh = a.prevIsH ? uP : uN, uv = a.prevIsH ? uN : uP;
        out = wc.map(function (p) { return [a.V[0] + uh[0] * p[0] + uv[0] * p[1], a.V[1] + uh[1] * p[0] + uv[1] * p[1]]; });
        if (!a.prevIsH) out.reverse();
      } else if (s.kind === 'wig' || s.kind === 'chamfer') {
        var cx = (s.kind === 'wig' ? WIG_C[0] : s.cx) * k, cy = (s.kind === 'wig' ? WIG_C[1] : s.cy) * k, r = (s.kind === 'wig' ? WIG_R : s.r) * k;
        var lp = a.prevIsH ? cx : cy, ln = a.prevIsH ? cy : cx;
        if (lp < 0.005 || ln < 0.005) out = fillet(a.P, a.V, a.N, r, a.lenP, a.lenN);
        else {
          var C1 = [a.V[0] + uP[0] * lp, a.V[1] + uP[1] * lp], C2 = [a.V[0] + uN[0] * ln, a.V[1] + uN[1] * ln], cl = vlen(vsub(C2, C1));
          out = fillet(a.P, C1, C2, r, Math.max(0, a.lenP - lp), cl / 2).concat(fillet(C1, C2, a.N, r, cl / 2, Math.max(0, a.lenN - ln)));
        }
      } else if (s.kind === 'round') out = fillet(a.P, a.V, a.N, s.r * k, a.lenP, a.lenN);
      else out = [a.V];
      spans.push({ from: pts.length, count: out.length });
      pts = pts.concat(out);
    });
    return { pts: pts, spans: spans };
  }
  var MAX_DEAD = 3;                 // the left strip is 0, 1, 2 or 3 pitches wide (0 / 2.54 / 5.08 / 7.62)
  function legacyOutline(P) {                         // parameter files from rev A1: a band height and two plain chamfers
    var f = P.frame, g = P.grid, xl = -Math.max(0, Math.min(MAX_DEAD, Math.round(g.dead_rows_left))) * g.pitch, xr = (g.cols + 1) * g.pitch, yt = -(f.band_h || 24), r = f.corner_r || 0;
    var v = [{ x: xl, y: yt, c: [f.chamfer_tl || 0, f.chamfer_tl || 0], r: r }, { x: xr, y: yt, c: [f.chamfer_tr || 0, f.chamfer_tr || 0], r: r }, { x: xr, y: 0, r: r }, { x: 0, y: 0 }];
    if (xl < 0) v.push({ x: 0, y: P.wig.height, r: r }, { x: xl, y: P.wig.height, r: r });
    return v;
  }

  // ---------- the model ----------
  function resolve(P, ref) {
    ref = ref || {};
    var g = P.grid, w = P.wig, f = P.frame;
    var pitch = g.pitch;
    var dead = Math.max(0, Math.min(MAX_DEAD, Math.round(g.dead_rows_left)));
    // The strip (the probe's side) is on the left as drawn, or on the right after a left-to-right flip: frame.side (rev A12).
    // xl and xr are the unit's left and right grid planes either way. W0 is the breadboard's right edge; the strip's outer
    // plane is xl or xr, and the extender stands against the breadboard's other side.
    var W0 = (g.cols + 1) * pitch, mir = f.side === 'right';
    var xl = mir ? 0 : -dead * pitch, xr = mir ? W0 + dead * pitch : W0, unitPitch = xr - xl;
    var removable = w.mode === 'removable';
    var notes = [];
    if (Math.abs(w.width - W0) > 0.005) notes.push('wig.width ' + w.width + ' is not (cols + 1) x pitch = ' + round(W0) + '; the grid value is used');

    // --- boards in z: each sits "gap" above the one below; parts live in the gaps ---
    var layers = [];
    P.stack.forEach(function (L, i) {
      var z0, z1;
      if (i === 0) { z0 = -L.t; z1 = 0; } else { z0 = layers[i - 1].z1 + (L.gap || 0); z1 = z0 + L.t; }
      layers.push({ id: L.id, name: L.name, t: L.t, gap: i ? (L.gap || 0) : 0, kind: i === 0 ? 'base' : (L.kind === 'ring' ? 'ring' : 'board'), z0: round(z0), z1: round(z1), index: i });
    });
    var top = layers[layers.length - 1];
    var zTop = top.z1, zBot = layers[0].z0;
    // The face board on the shell. wig.face = { on, t, sits: 'on' | 'inset', header_strip }; a rev A3 file's face_pcb_t still works.
    // 'on': it lies on the shell and adds its thickness. 'inset': the shell is that much shorter and the top stays at shell.t.
    var faceP = w.face && w.face.on ? w.face : (w.face_pcb_t > 0 ? { on: true, t: w.face_pcb_t, sits: 'on', plain: true } : null);
    var faceT = faceP ? Math.max(0.2, +faceP.t || 0.71) : 0, faceInset = !!(faceP && faceP.sits === 'inset');
    var shellTop = faceInset ? Math.max(1, w.shell.t - faceT) : w.shell.t;
    var bbTop = shellTop + faceT;
    function layerById(id) { for (var i = 0; i < layers.length; i++) if (layers[i].id === id) return layers[i]; return null; }

    // --- outlines ---
    var verts = f.outline && f.outline.length > 2 ? f.outline : legacyOutline(P);
    var built = buildOutline(verts, ref, notes);
    var frameL = region([built.pts]);
    var fb = bbox(frameL), yt = round(fb.y0), yb = Math.max(w.height, round(fb.y1));
    var wigPts = ref.outline && ref.outline.length > 3 ? ref.outline : rectPts(0, 0, w.width, w.height);
    var wigRegion = region([wigPts]);
    // rev A11d: the waist in the breadboard's right side made deeper than the WigLEDmag's own (wig.waist_r, mm in from the right
    // edge), so that a board on that side can bow far enough into it to carry a column of holes on the grid plane. The cut is
    // taken out of the breadboard's own outline, so its PCB, shell and top board all get it. waist.own is what the traced outline has.
    // The top board is cut to the half-pitch line instead (once the waist is deep enough for a column on the seam), so that the
    // countersinks of the two columns either side of the seam keep the same land: the shell's seam gives the whole wall to the
    // breadboard, which would leave the extender's countersinks 0.1 mm past its own edge.
    // With the strip on the right (frame.side, rev A12) the extender stands against the breadboard's LEFT side, and it is that
    // waist that is cut: the block below is run on the mirror image of the breadboard and what it makes is mirrored back.
    var waist = null, waistCut = null, waistCutFace = null, wigFaceRegion = null;
    if (mir) { wigPts = wigPts.map(function (q) { return [W0 - q[0], q[1]]; }).reverse(); wigRegion = mirrorRegion(wigRegion, W0); }
    (function () {
      var W0 = w.width, mid = wigPts.filter(function (p) { return p[0] > W0 - 3 && p[0] < W0 - 0.002 && p[1] > 4 && p[1] < w.height - 4; });
      if (!mid.length) { waist = { own: 0, depth: 0, deepened: false, y0: null, y1: null, flat: null }; return; }
      var ya = Math.min.apply(null, mid.map(function (p) { return p[1]; })), yb = Math.max.apply(null, mid.map(function (p) { return p[1]; }));
      var own = round(W0 - Math.min.apply(null, mid.map(function (p) { return p[0]; })), 3), d = Math.min(1.6, +w.waist_r || 0);
      // it just matches (rev A12b): with an extender that skips no row, the waist is at least as deep as the column on the seam needs
      var exA = P.extender; if (exA && exA.on && !(+exA.dead_rows > 0)) d = Math.max(d, round(W0 - (P.grid.cols * P.grid.pitch + (+exA.chan || 2.04) / 2 + 0.5), 3));
      waist = { own: own, depth: own, deepened: false, y0: round(ya, 3), y1: round(yb, 3), flat: null };
      if (!(d > own + 1e-6)) return;
      var ramp = Math.min(1.8, (yb - ya) / 4);
      function cutOf(dd) { return region([[[W0 + 1, ya], [W0, ya], [W0 - dd, ya + ramp], [W0 - dd, yb - ramp], [W0, yb], [W0 + 1, yb]]]); }
      var df = d < 1 ? d : Math.max(d, P.grid.pitch / 2 + w.fit_gap / 2);
      waistCut = cutOf(d); waistCutFace = cutOf(df); wigFaceRegion = diff(wigRegion, waistCutFace);
      wigRegion = diff(wigRegion, waistCut);
      var we = expolys(wigRegion); if (we.length) wigPts = we[0].outer;
      waist = { own: own, depth: round(d, 3), face: round(df, 3), deepened: true, y0: round(ya, 3), y1: round(yb, 3), flat: [round(ya + ramp, 3), round(yb - ramp, 3)] };
    })();
    if (mir) {
      wigPts = wigPts.map(function (q) { return [W0 - q[0], q[1]]; }).reverse(); wigRegion = mirrorRegion(wigRegion, W0);
      if (waistCut) waistCut = mirrorRegion(waistCut, W0); if (waistCutFace) waistCutFace = mirrorRegion(waistCutFace, W0); if (wigFaceRegion) wigFaceRegion = mirrorRegion(wigFaceRegion, W0);
      if (waist) waist.side = 'left';
    }
    // Where the frame runs along the breadboard, the spaces the breadboard's own outline leaves against it (the corner chamfers,
    // the waist) belong to the frame, so a board's inner edge follows the breadboard's contour: each board is then cut by
    // whichever part of the wig is at its height, less the fit gap. Only a space with more than 5 mm of edge against the frame
    // counts: the strip side does, the two short link notches beside the tongue and the far side do not.
    var frameDrawn = frameL, hugs = [];
    // Only the stretch the frame actually runs along is filled. A space the breadboard's outline leaves is one long piece
    // down a whole side (corner, waist, corner), so taking it whole put fill past the end of a strip that stops short of the
    // breadboard's corner: a tail, or an island once the breadboard's clearance was cut. besideR is, for each side of the
    // breadboard's rectangle, the stretch the drawn frame touches, 3 mm into the breadboard.
    var besideR = null, wW = w.width, wH = w.height, lip = 0.05, reach = 3;
    [[rectPts(-lip, 0, 0, wH), function (b) { return rectPts(0, b.y0, reach, b.y1); }], [rectPts(wW, 0, wW + lip, wH), function (b) { return rectPts(wW - reach, b.y0, wW, b.y1); }],
     [rectPts(0, -lip, wW, 0), function (b) { return rectPts(b.x0, 0, b.x1, reach); }], [rectPts(0, wH, wW, wH + lip), function (b) { return rectPts(b.x0, wH - reach, b.x1, wH); }]].forEach(function (side) {
      expolys(inter(frameDrawn, region([side[0]]))).forEach(function (ex) {
        var r = region([side[1](bbox(region([ex.outer])))]); besideR = besideR ? union(besideR, r) : r;
      });
    });
    expolys(diff(region([rectPts(0, 0, w.width, w.height)]), wigRegion)).forEach(function (ex) {
      var piece = region([ex.outer]), shared = area(inter(offset(piece, 0.05), diff(frameDrawn, piece))) / 0.05;
      if (shared > 5 && besideR) { var part = inter(piece, besideR); if (area(part) > 0.005) { frameL = union(frameL, part); hugs.push(round(shared, 1)); } }
    });
    // Meeting the breadboard's chamfer square (a vertex with c:'meet' on a corner of the breadboard's rectangle). The space the
    // chamfer leaves is split by the line through the middle of the chamfer's flat, at right angles to it: the frame's side
    // of the line is frame, the other side stays open. So the frame's edge runs into the chamfer square-on, at its middle,
    // and no feather of board is left along the rest of the chamfer.
    var joints = [];
    verts.forEach(function (v, vi) {
      if (v.c !== 'meet') return;
      var jx = Math.abs(v.x) <= Math.abs(v.x - wW) ? 0 : wW, jy = Math.abs(v.y) <= Math.abs(v.y - wH) ? 0 : wH, best = null, i;
      if (Math.hypot(v.x - jx, v.y - jy) > 3) { notes.push('Vertex ' + (vi + 1) + ' is set to meet the breadboard\'s chamfer but is not on a corner of the breadboard: nothing done there.'); return; }
      for (i = 0; i < wigPts.length; i++) {                    // the chamfer's flat: the longest slanting edge of the breadboard's outline at that corner
        var a = wigPts[i], b = wigPts[(i + 1) % wigPts.length], dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
        if (Math.abs(a[0] - jx) > 3.2 || Math.abs(a[1] - jy) > 3.2 || Math.abs(b[0] - jx) > 3.2 || Math.abs(b[1] - jy) > 3.2 || Math.abs(dx) < 0.05 || Math.abs(dy) < 0.05) continue;
        if (!best || len > best.len) best = { len: len, m: [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], d: [dx / len, dy / len] };
      }
      if (!best) return;
      var M = best.m, d = best.d, nn = [-d[1], d[0]], far = 12;
      var corner = inter(diff(region([rectPts(0, 0, wW, wH)]), wigRegion), region([rectPts(jx - 3.2, jy - 3.2, jx + 3.2, jy + 3.2)]));
      var half = function (sg) { return region([[[M[0] - nn[0] * far, M[1] - nn[1] * far], [M[0] + nn[0] * far, M[1] + nn[1] * far], [M[0] + nn[0] * far + sg * d[0] * far, M[1] + nn[1] * far + sg * d[1] * far], [M[0] - nn[0] * far + sg * d[0] * far, M[1] - nn[1] * far + sg * d[1] * far]]]); };
      var hp = inter(corner, half(1)), hm = inter(corner, half(-1)), touch = offset(frameDrawn, 0.15);
      var mine = area(inter(touch, hp)) >= area(inter(touch, hm)) ? hp : hm, theirs = mine === hp ? hm : hp;      // the frame's side is the one the drawn frame lies against
      frameL = diff(union(frameL, mine), theirs);
      joints.push({ vertex: vi + 1, at: [round(M[0]), round(M[1])], flat: round(best.len, 2), open: theirs });
    });
    // integrated: one board under the frame and the breadboard. Where the strip runs beside the breadboard the seam is
    // filled (the wig's corners and waist on that side); the rest of the wig's edge is kept as it is on the WigLEDmag.
    var fullOutline = union(frameL, wigRegion);
    [[rectPts(-0.5, 0, 0, w.height), function (bs) { return rectPts(-0.05, bs.y0, 3, bs.y1); }],
     [rectPts(wW, 0, wW + 0.5, w.height), function (bs) { return rectPts(wW - 3, bs.y0, wW + 0.05, bs.y1); }]].forEach(function (sd) {
      var beside = inter(frameL, region([sd[0]]));
      if (area(beside) > 0.2) fullOutline = union(fullOutline, region([sd[1](bbox(beside))]));
    });
    var fill = Math.max(0, f.fill_notches || 0);
    if (fill > 0) fullOutline = offset(offset(fullOutline, fill), -fill);
    joints.forEach(function (j) { fullOutline = diff(fullOutline, j.open); });        // the one board keeps the same joint
    // slots of the wig's own edge that the band closes off (the two link notches beside the tongue) are not holes in one board
    fullOutline = fullOutline.filter(function (pth) { var a = ClipperLib.Clipper.Area(pth) / (SC * SC); return !(a < 0 && a > -6); });

    // --- magnetometers. show.sensor_layout "custom" (the default since rev A6) takes them from mag.list, where each has its
    //     own board and side (src/magmodel.js; the Magnetometers tab edits it). The older fixed choices still read: the
    //     WigLEDmag's own (9 TMAG5273 + 8 MMC5603), or a planned MMC5603 grid over the 76 x 45 mm hole field (3 x 6, 4 x 8) ---
    var sensLayout = (P.show && P.show.sensor_layout) || (P.mag && P.mag.list ? 'custom' : 'wigledmag'), sensorSet = { layout: sensLayout, mmc: ref.mmc || [], tmag: ref.tmag || [] };
    if (sensLayout === 'custom') {
      var mini = { layers: layers, removable: removable, wig: { pcb_t: w.pcb_t } };
      sensorSet = { layout: 'custom', mmc: [], tmag: [] };
      ((P.mag && P.mag.list) || []).forEach(function (s, i) {
        var fc = Mag.faceOf(mini, s), tm = s.kind === 'tmag';
        (tm ? sensorSet.tmag : sensorSet.mmc).push({ ref: s.ref || ((tm ? 'T' : 'M') + (i + 1)), x: +s.x, y: +s.y, side: s.side === 'bottom' ? 'B' : 'F', on: s.on, z: fc.zDie, face: fc.z, dir: fc.dir });
      });
    }
    var grids = { plan18: [3, 6], plan32: [4, 8] };
    if (grids[sensLayout]) {
      var gr0 = grids[sensLayout], fw = 76, fh = 45, fx0 = w.width / 2 - fw / 2, fy0 = (ref.rows && ref.rows.length ? (ref.rows[0] + ref.rows[ref.rows.length - 1]) / 2 : w.height / 2) - fh / 2, planned = [];
      for (var gy = 0; gy < gr0[0]; gy++) for (var gx = 0; gx < gr0[1]; gx++) planned.push({ ref: 'M' + (planned.length + 1), x: round(fx0 + (gx + 0.5) * fw / gr0[1], 2), y: round(fy0 + (gy + 0.5) * fh / gr0[0], 2), side: 'B' });
      sensorSet = { layout: sensLayout, mmc: planned, tmag: [], pitch: [round(fw / gr0[1], 2), round(fh / gr0[0], 2)] };
    }

    // --- parts ---
    var parts = [];
    function addPart(o, into) {             // into: a list other than this unit's parts (the extender's)
      // o: {id, type, label, x, y, rot, plane:{z, dir, bottom}, bodies:[{shape,z0,z1,...}], clearance, ...}
      var p = { id: o.id, type: o.type, label: o.label, x: o.x, y: o.y, rot: o.rot || 0, bottom: !!o.plane.bottom, zPlane: round(o.plane.z), dir: o.plane.dir,
        mountLayer: o.mountLayer || null, color: o.color, model: o.model || null, source: o.source || '', system: !!o.system, movable: o.movable !== false,
        noClash: o.noClash || [], cut: o.cut !== false, bodies: [], ghosts: [], extra: o.extra || null,
        group: o.group || null, open: o.open || null, boards: {}, accessOpen: !!(o.access && o.access.open),
        accessPts: o.access ? place(shapePts(o.access.shape), o.x, o.y, o.rot || 0, !!o.plane.bottom) : null,
        // a tongue is a feature of the top board, so it is laid out as seen from above whichever face the switch is on
        tonguePts: o.tongue ? place(o.tongue, o.x, o.y, o.rot || 0, false) : null,
        accessClear: o.access && o.access.clear != null ? o.access.clear : 0.25, cantilever: o.cantilever || null, fp: o.fp || null, lcsc: o.lcsc || null, win: o.win || null };
      function conv(b, ghost) {
        var z0 = o.plane.dir > 0 ? o.plane.z + b.z0 : o.plane.z - b.z1, z1 = o.plane.dir > 0 ? o.plane.z + b.z1 : o.plane.z - b.z0;
        var pts = place(shapePts(b.shape), o.x, o.y, o.rot || 0, !!o.plane.bottom);
        return { name: b.name || '', pts: pts, z0: round(z0), z1: round(z1), clearance: b.clearance != null ? b.clearance : (o.clearance != null ? o.clearance : 0.25), cut: !ghost && b.cut !== false && o.cut !== false, ghost: !!ghost, slot: !!b.slot, glass: !!b.glass };
      }
      (o.bodies || []).forEach(function (b) { p.bodies.push(conv(b, false)); });
      (o.ghosts || []).forEach(function (b) { p.ghosts.push(conv(b, true)); });
      p.z0 = Math.min.apply(null, p.bodies.map(function (b) { return b.z0; }));
      p.z1 = Math.max.apply(null, p.bodies.map(function (b) { return b.z1; }));
      (into || parts).push(p);
      return p;
    }
    function plane(m, height) {
      if (m && m.on) {
        var L = layerById(m.on);
        if (!L) { notes.push('mount board ' + m.on + ' is not in the stack; using ' + layers[0].id); L = layers[0]; }
        return m.side === 'bottom' ? { z: L.z0, dir: -1, bottom: true, layer: L.id } : { z: L.z1, dir: 1, bottom: false, layer: L.id };
      }
      if (m && m.flush === 'bb') return { z: bbTop + (m.offset || 0) - height, dir: 1, bottom: false, layer: null };
      if (m && m.flush === 'top') return { z: zTop + (m.offset || 0) - height, dir: 1, bottom: false, layer: top.id };
      return { z: (m && m.z) || 0, dir: 1, bottom: false, layer: null };
    }

    // --- the extender (rev A11): a narrow breadboard that stands against this unit's right side and plugs into the socket in
    //     the side of the top band (a part of type skt_ra_127). Each of its rows goes to one pin of that socket, so it has no
    //     crossbar of its own. Its left edge is on this unit's right grid plane and its first column is dead_rows pitches past
    //     it, so both boards' holes are on one 0.1 inch grid. It is another unit: nothing of it cuts this unit's boards or
    //     counts in this unit's checks. What it is made of is in R.extender; checks.extender says how the two meet.
    // --- rev A11e: the press-in joint (extender.join 'press'). An upright socket on the mid board (a part of type skt_v_127)
    //     with the top and the bottom board opened over and under it, so a pin can go all the way through; and in the bottom
    //     board a knob-shaped cutout running out to the right edge. A tab of the extender's one board fills it from the back,
    //     its upright pins going up into the socket. The knob is wider than its neck, so the tab cannot be pulled out
    //     sideways. The cutout belongs to the unit: it is there with or without an extender.
    // --- rev A12: with the strip on the right (frame.side) the extender, its socket and the press-in cutout are on the LEFT.
    //     The two blocks below are written for the right side. They are run unchanged on the mirror image: PX is the design
    //     with the side sockets where their mirror images are, wigX / wigFaceX the breadboard mirrored, refX the reference
    //     board with its top board's holes mirrored, and "xr" inside them is W0, the mirrored breadboard's right edge. What
    //     they make (press, ext) is mirrored back afterwards.
    var PX = P, wigX = wigRegion, wigFaceX = wigFaceRegion, refX = ref;
    if (mir) (function () {
      var k, cx = { zBot: zBot, zTop: zTop, layers: layers };
      PX = {}; for (k in P) PX[k] = P[k];
      PX.parts = (P.parts || []).map(function (u) {
        if (!((Catalog.sideKinds && Catalog.sideKinds[u.type]) || u.type === 'skt_ra_127' || u.type === 'skt_v_127')) return u;
        var m = partMirror(u, W0, cx), c = {}; for (var kk in u) c[kk] = u[kk]; c.x = m.x; c.y = m.y; c.rot = m.rot; return c;
      });
      wigX = mirrorRegion(wigRegion, W0); wigFaceX = wigFaceRegion ? mirrorRegion(wigFaceRegion, W0) : null;
      refX = {}; for (k in ref) refX[k] = ref[k];
      if (ref.face && ref.face.holes) { refX.face = {}; for (k in ref.face) refX.face[k] = ref.face[k]; refX.face.holes = ref.face.holes.map(function (h) { return [W0 - h[0], h[1], h[2], h[3]]; }); }
    })();
    var notes0 = notes.length;
    var press = null;
    (function (P, xr, wigRegion, wigFaceRegion, ref) {
      var XJ = P.extender || {}; if (XJ.join !== 'press') return;
      var vp = null; (P.parts || []).forEach(function (u) { if (!vp && u.type === 'skt_v_127') vp = u; });
      if (!vp) return;
      var vc = Catalog.get(vp), gapT = 0.05, m = 0.6, under = 0.8;
      var kx0 = vp.x - 0.92 - m, kx1 = Math.min(vp.x + 2.19 + m, xr - 1.0), ky0 = vp.y - 0.8 - m, ky1 = vp.y + vc.span + 0.8 + m, nw = Math.max(2, ky1 - ky0 - 2 * under), yc = (ky0 + ky1) / 2;
      var shape = union(region([rectPts(kx0, ky0, kx1, ky1)]), region([rectPts(kx1 - 0.2, yc - nw / 2, xr + 0.3, yc + nw / 2)]));
      press = { id: vp.id, n: vc.n, pins: vc.pins, h: vc.height, x: +vp.x, y: +vp.y, span: vc.span, len: vc.len, knob: [round(kx0), round(ky0), round(kx1), round(ky1)], neck: round(nw), under: round((ky1 - ky0 - nw) / 2), gap: gapT,
        rects: [[kx0, ky0, kx1, ky1], [kx1, yc - nw / 2, xr, yc + nw / 2]],
        cut: inter(shape, region([rectPts(kx0 - 1, ky0 - 1, xr + 0.01, ky1 + 1)])), tab: inter(offset(shape, -gapT), region([rectPts(kx0 - 1, ky0 - 1, xr + 0.3, ky1 + 1)])) };
    })(PX, W0, wigX, wigFaceX, refX);
    var ext = null;
    if (P.extender && P.extender.on) (function (P, xr, wigRegion, wigFaceRegion, ref) {
      var X = {}, XD = Catalog.extender || {}, k;
      for (k in XD) X[k] = XD[k];
      for (k in P.extender) if (k.charAt(0) !== '_') X[k] = P.extender[k];
      var edRaw = Math.round(+X.dead_rows), en = Math.max(1, Math.min(40, Math.round(+X.cols) || 11)), ed = Math.max(0, Math.min(MAX_DEAD + 1, isFinite(edRaw) ? edRaw : 1));      // 0 since rev A11d: no hole position skipped
      var ex0 = xr, ex1 = round(xr + (ed + en) * pitch), eh = Math.max(0, +X.head || 0), H = w.height, W = w.width, quiet = [];
      var rowsY = ref.rows && ref.rows.length ? ref.rows : (function () { var a = []; for (var r = 0; r < 20; r++) if (r !== 2 && r !== 3 && r !== 16 && r !== 17) a.push(3.556 + r * pitch); return a; })();
      var ecols = []; for (k = 0; k < en; k++) ecols.push(round(xr + (ed + k) * pitch));
      // its plan: the breadboard part has the wig's own corners; the head stands beside the top band, a rounded chamfer on its free corner
      var bodyR = region([buildOutline([{ x: ex0, y: 0, c: 'wig' }, { x: ex1, y: 0, c: 'wig' }, { x: ex1, y: H, c: 'wig' }, { x: ex0, y: H, c: 'wig' }], ref, quiet).pts]);
      // its outline as vertices (rev A12b): the four it is given by its columns and its head, or the ones a design has in
      // extender.outline (the page's outline controls edit those). The breadboard part is always kept.
      var boardR = bodyR, eoV = null;
      if (X.outline && X.outline.length > 2) eoV = X.outline;
      else if (eh > 0.5) {
        var cw = Math.min(5.5, (ex1 - ex0) / 3), ch = Math.min(4.8, eh / 3);
        eoV = [{ x: ex0, y: -eh, r: Math.min(1.2, eh / 3) }, { x: ex1, y: -eh, c: [cw, ch], r: Math.min(2, ch) }, { x: ex1, y: H, c: 'wig' }, { x: ex0, y: H, c: 'wig' }];
      } else eoV = [{ x: ex0, y: 0, c: 'wig' }, { x: ex1, y: 0, c: 'wig' }, { x: ex1, y: H, c: 'wig' }, { x: ex0, y: H, c: 'wig' }];
      var eoB = buildOutline(eoV, ref, quiet); boardR = union(bodyR, region([eoB.pts]));
      // the key: the waist the breadboard has in its right side is filled by this board's edge, less the fit gap, so the two
      // cannot slide along the seam. The corners' spaces are left alone.
      var keyed = 0;
      function keyOf(gap, reg) {             // reg: the breadboard's top board, whose waist is cut deeper than the shell's (rev A11d)
        var kk = [];
        // the breadboard's edge is a few um inside its rectangle all the way down, which would join the waist to the corners:
        // only the middle of the side is looked at, and a sliver thinner than 0.06 is dropped
        var left = offset(offset(diff(region([rectPts(W - 3, 4, W, H - 4)]), reg || wigRegion), -0.03), 0.03);
        expolys(left).forEach(function (e) {
          var pc = region([e.outer]), b = bbox(pc);
          if (area(pc) < 0.5 || b.x1 < W - 0.05) return;
          kk = kk.concat(inter(offset(union(pc, region([rectPts(W - 0.04, b.y0, W + 2, b.y1)])), -gap), region([rectPts(W - 3, b.y0, W + 1, b.y1)])));
        });
        return kk;
      }
      var sx = (W - w.shell.w) / 2, sy = (H - w.shell.h) / 2;
      var shellR = inter(bodyR, region([rectPts(ex0 + sx, sy, ex1 - sx, sy + w.shell.h)])), faceR = faceP ? bodyR : null;
      if (X.key !== false) {
        var kb = keyOf(w.pcb_gap), ks = keyOf(w.fit_gap);
        if (kb.length) { boardR = union(boardR, kb); keyed = round(area(inter(union(kb), region([rectPts(0, 0, W, H)]))), 2); }
        if (ks.length) shellR = union(shellR, ks);
        if (faceR) { var kf = wigFaceRegion ? keyOf(w.fit_gap, wigFaceRegion) : ks; if (kf.length) faceR = union(faceR, kf); }
      }
      // only if asked for (rev A11b: the head is the one board): a second board over the head, level with the frame's top board,
      // following the top of this board's own shell
      var coverR = [];
      if (X.cover === true && eh > 0.5 && layers.length > 1) coverR = clean(diff(inter(boardR, region([rectPts(ex0 - 1, -eh - 1, ex1 + 1, 4)])), offset(shellR, w.fit_gap)));
      // the ties: the wig's top board has a hole beside each rail pair, on its first and last columns (wiigtop.3mf). This board has
      // the same on its own first column, so a wire staple across the seam goes down one of each.
      var tieY = [], tieX = round(g.cols * pitch), big = null;
      ((ref.face && ref.face.holes) || []).forEach(function (h) {
        if (h[2] < 1.5 || h[1] < 0) return;
        if (!big) big = [h[2], h[3]];
        if (h[0] > W / 2 && !rowsY.some(function (r) { return Math.abs(r - h[1]) < 0.05; }) && !tieY.some(function (t) { return Math.abs(t - h[1]) < 0.05; })) { tieY.push(h[1]); if (Math.abs(h[0] - g.cols * pitch) > 0.05) tieX = round(h[0]); }
      });
      var tieRef = tieY.length > 0;
      if (!tieRef) tieY = [8.636, 46.736];
      tieY.sort(function (a, b) { return a - b; }); big = big || [2.032, 1.2];
      var kind = X.ties === 'staple' ? 'staple' : 'none', wire = Math.max(0.3, +X.wire || 1.0);       // only if asked for (rev A11c)
      // With no dead row the first column stands on the grid plane, in the part of this board that bows into the breadboard's waist.
      // The rails are at the breadboard's corners, where there is no waist to bow into, so they start rail_skip columns later.
      var skip = ed === 0 ? Math.max(1, Math.min(3, Math.round(+X.rail_skip) || 1)) : 0, nR = rowsY.length, tc = Math.min(skip, en - 1);
      function isRail(i) { return nR >= 8 && (i < 2 || i >= nR - 2); }
      var holes = [];
      if (faceR) {
        ecols.forEach(function (cx, ci) { rowsY.forEach(function (cy, ri) { if (ci < skip && isRail(ri)) return; holes.push([cx, cy, big[0], big[1]]); }); });
        tieY.forEach(function (ty) { holes.push([ecols[tc], ty, big[0], big[1]]); if (en - 1 > tc) holes.push([ecols[en - 1], ty, big[0], big[1]]); });
      }
      // That column on the grid plane: the breadboard keeps a wall beside its own last column, and this board's first channel is open
      // on that side, closed by that wall. chan and clip are the shell's channel and the spring clip's width (2.04 and 1.86 in
      // claude_V6_breadboard_shell_DFM.md); the clip's solder tab wants land on this board 0.55 either side of the column line.
      var seamCol = null;
      if (ed === 0) {
        var chan = +X.chan || 2.04, clipW = +X.clip || 1.86, mainY = rowsY.filter(function (y, i) { return !isRail(i); });
        var c0 = mainY[0] - pitch / 2 - 0.25, c1 = mainY[mainY.length - 1] + pitch / 2 + 0.25, lastCol = g.cols * pitch;
        var strip = region([rectPts(W - 3, c0, W + 3, c1)]), space = diff(strip, wigRegion);
        var ueMin = bbox(space).x0, ueMax = bbox(inter(wigRegion, strip)).x1;                                   // the breadboard's edge along the channels: deepest and shallowest
        var eSpace = diff(region([rectPts(W - 3, c0, xr + 0.6, c1)]), boardR), ebMax = area(eSpace) > 0.001 ? bbox(eSpace).x1 : W - 3;     // this board's edge there, where it is furthest right
        var wall = round(ueMin - (lastCol + chan / 2), 3), clear = round((xr - clipW / 2) - ueMax, 3), land = round((xr - 0.55) - ebMax, 3);
        // the two top boards: the land each keeps outside the countersinks of its column beside the seam
        var cs = big[0], fLand = null;
        if (faceR) {
          var fSpace = diff(region([rectPts(W - 3, c0, xr + 0.6, c1)]), faceR), feMax = area(fSpace) > 0.001 ? bbox(fSpace).x1 : W - 3;
          var uf = wigFaceRegion || wigRegion, ufMin = bbox(diff(strip, uf)).x0;
          fLand = { ext: round((xr - cs / 2) - feMax, 3), unit: round(ufMin - (lastCol + cs / 2), 3), countersink: cs };
        }
        seamCol = { x: round(xr), chan: chan, clip: clipW, face_land: fLand, y0: round(c0, 2), y1: round(c1, 2), unit_edge: [round(ueMin, 3), round(ueMax, 3)], wall: wall, clip_clear: clear, board_edge: round(ebMax, 3), land: land,
          need: round(W - (lastCol + chan / 2 + 0.5), 3), has: waist ? waist.depth : 0, own: waist ? waist.own : 0, bowed: X.key !== false && keyed > 0,
          fits: X.key !== false && wall >= 0.4 - 1e-6 && clear >= 0.05 - 1e-6 && land >= 0.1 - 1e-6 && (!fLand || (fLand.ext >= 0.1 - 1e-6 && fLand.unit >= 0.1 - 1e-6)) };
        if (!seamCol.fits) notes.push('The extender has no dead row, but its first column does not fit on the seam: ' + (X.key === false ? 'its edge does not bow into the waist.' : 'the waist in the breadboard\'s side is ' + seamCol.has + ' mm deep and a column there needs ' + seamCol.need + '.'));
      }
      var room = Math.min.apply(null, tieY.map(function (ty) { return Math.min.apply(null, rowsY.map(function (r) { return Math.abs(r - ty); })); }));
      // the socket it plugs into, and its own header: plastic face on this board's edge, pin 1 level with the socket's
      var SKs = Catalog.sideKinds, sp = null; (P.parts || []).forEach(function (u) { if (!sp && SKs[u.type]) sp = u; });
      var SK = SKs[sp ? sp.type : 'skt_ra_127'];             // which socket it is (rev A11d): its depth, pitch and height, and the header and pin length that mate
      var port = null, hy = -3.2, hn = Math.max(2, en);
      if (sp) {
        var sc = Catalog.get(sp), rot = (((+sp.rot || 0) % 360) + 360) % 360, onTop = !!sp.mount && sp.mount.on === layers[0].id && sp.mount.side !== 'bottom';
        var faces = Math.abs(rot - 180) < 0.01 && onTop, mouth = round(sp.x + SK.depth);
        hy = +sp.y; hn = sc.n;
        port = { id: sp.id, kind: sp.type, kind_label: SK.label, pitch: SK.pitch, high: SK.high, price: SK.price, pin: SK.pin, takes: SK.takes, n: sc.n, pins: sc.pins, len: sc.len, faces: faces, mouth_x: mouth, inset: round(xr - mouth), y0: round(sp.y - sc.span - SK.end), y1: round(sp.y + SK.end) };
        port.engage = faces ? round(Math.max(0, Math.min(SK.pin, SK.pin - Math.max(0, port.inset))), 2) : 0;        // how far the header's pins go in
        port.pin_ok = !SK.takes || (port.engage >= SK.takes[0] - 1e-6 && port.engage <= SK.takes[1] + 1e-6);              // inside the insertion depth its maker gives
        port.room = layers.length > 1 ? round(top.z0 - SK.high, 2) : null;                                                // under the top board; negative = it stands into it
        port.open_seam = faces && port.inset < -0.005 ? round(-port.inset) : 0;                          // a mouth that stands out past the edge holds the seam open
        if (!faces) notes.push('The side socket (' + sp.id + ') is not on top of the main board with its mouth to the right (rotation 180), so the extender\'s header does not meet it.');
      }
      var boardOwn = boardR;                 // without the press-in tab, which lies under the unit's upper boards on purpose
      if (press) {
        var L1p = layers.length > 1 ? layers[1] : null, tipZ = L1p ? round(L1p.z1 + press.h, 2) : 4, pinL = round(tipZ - 1.0, 2), vk = (Catalog.vertKinds || {})[String(press.h)];
        port = { id: press.id, kind: 'skt_v_127', kind_label: 'upright 1.27 mm socket on the mid board, ' + press.h + ' high', pitch: 1.27, high: press.h, price: vk ? vk.price : null, pin: pinL, takes: null, n: press.n, pins: press.pins, len: press.len,
          faces: true, mouth_x: round(xr), inset: 0, y0: round(press.y - 0.8), y1: round(press.y + press.span + 0.8), engage: press.h, pin_ok: true, open_seam: 0, room: L1p ? round(zTop - (L1p.z1 + press.h), 2) : null,
          press: { x: press.x, y: press.y, knob: press.knob, neck: press.neck, under: press.under, gap: press.gap, pin_len: pinL, pin_tip: tipZ, socket_z: L1p ? [round(L1p.z1, 3), round(L1p.z1 + press.h, 3)] : null, bottom_t: layers[0].t, top_z: round(zTop) } };
        hn = press.n; hy = press.y; boardR = union(boardR, press.tab);
      }
      var HD = press ? Catalog.get({ type: 'hdr_v_127', dims: { n: hn, pin: port.pin } }) : Catalog.get({ type: SK.hdr, dims: { n: hn, pin: SK.pin } }), extParts = [];
      addPart({ id: 'ext_hdr', type: press ? 'hdr_v_127' : SK.hdr, label: HD.label + ' (on the extender)', x: press ? press.x : round(xr + 2.77), y: hy, rot: press ? 0 : 180, plane: { z: 0, dir: 1 }, system: true, movable: false, color: HD.color, bodies: HD.bodies, clearance: HD.clearance, source: HD.source }, extParts);
      var hy0 = press ? round(hy - 0.8) : round(hy - HD.span - SK.pitch / 2), hy1 = press ? round(hy + HD.span + 0.8) : round(hy + SK.pitch / 2);
      var railRows = rowsY.length >= 4 && X.jumpers === true ? [rowsY[0], rowsY[1], rowsY[rowsY.length - 2], rowsY[rowsY.length - 1]] : [];
      ext = { x0: round(ex0), x1: ex1, y0: round(-eh), y1: H, w: round(ex1 - ex0), cols: ecols, rows: rowsY, n_cols: en, n_rows: 2 * en, dead: ed, col_gap: round((ed + 1) * pitch), head: round(eh), keyed: keyed,
        z: { board: [round(-layers[0].t), 0], shell: [0, round(shellTop)], face: faceR ? [round(shellTop), round(bbTop)] : null, cover: coverR.length ? [top.z0, top.z1] : null, top: round(bbTop) },
        shapes: { board: expolys(clean(boardR)), shell: expolys(clean(shellR)), face: faceR ? expolys(clean(faceR)) : [], cover: expolys(coverR) },
        plan: union(boardOwn, coverR),
        holes: holes, hole: big, parts: extParts, port: port,
        header: { n: hn, pins: 2 * hn, x: round(xr + 2.77), y: hy, y0: hy0, y1: hy1, covered: hy0 >= -eh - 1e-6 && hy1 <= 1e-6 },
        ties: { kind: kind, wire: wire, hole: big[1], from_ref: tieRef, room: round(room, 3), at: tieY.map(function (ty) { return [tieX, round(ty)]; }),
          list: kind === 'none' ? [] : tieY.map(function (ty) { return { y: round(ty), x0: tieX, x1: ecols[tc], span: round(ecols[tc] - tieX) }; }) },
        jumpers: railRows.map(function (ry) { return { y: round(ry), x0: round(g.cols * pitch), x1: ecols[tc] }; }),
        rail_skip: skip, seam_col: seamCol, outline: { pts: eoB.pts, verts: eoV.map(function (v) { return { x: v.x, y: v.y }; }), src: eoV, own: !!(X.outline && X.outline.length > 2) } };
    })(PX, W0, wigX, wigFaceX, refX);
    // rev A12: mirrored back. Every x of what the two blocks made, their regions, and the extender's own parts turned to lie
    // on the mirror image of where the blocks put them. x0 < x1 whichever side; cols[0] is still the column next to the unit.
    // for the drawing of its header's pins: pin_x the middle of the 6.6 mm pins, pin_y the first one's y, step from one to the next
    if (ext) { ext.side = mir ? 'left' : 'right'; ext.header.pin_x = round(ext.x0 - 0.7); ext.header.pin_y = ext.header.y; ext.header.step = -1.27; }
    if (mir) (function () {
      function MX(x) { return round(W0 - x); }
      function MR(a) { return mirrorRegion(a, W0); }
      function MP(pts) { return pts.map(function (q) { return [round(W0 - q[0], 4), q[1]]; }).reverse(); }
      function ME(list) { return (list || []).map(function (e) { return { outer: MP(e.outer), holes: e.holes.map(MP) }; }); }
      function box(q) { return [MX(q[2]), q[1], MX(q[0]), q[3]]; }
      for (var i = notes0; i < notes.length; i++) notes[i] = String(notes[i]).replace('with its mouth to the right (rotation 180)', 'with its mouth to the left (rotation 0)');
      if (press) {
        var real = null; (P.parts || []).forEach(function (u) { if (!real && u.id === press.id) real = u; });
        press.cut = MR(press.cut); press.tab = MR(press.tab); press.knob = box(press.knob); press.rects = press.rects.map(box);
        if (real) { press.x = +real.x; press.y = +real.y; }
      }
      if (!ext) return;
      var a0 = ext.x0, a1 = ext.x1;
      ext.x0 = MX(a1); ext.x1 = MX(a0); ext.cols = ext.cols.map(MX);
      ['board', 'shell', 'face', 'cover'].forEach(function (k) { ext.shapes[k] = ME(ext.shapes[k]); });
      ext.plan = MR(ext.plan);
      ext.holes = ext.holes.map(function (h) { return [MX(h[0]), h[1], h[2], h[3]]; });
      ext.parts.forEach(function (p) {
        var polys = p.bodies.map(function (b) { return unplace(b.pts, p.x, p.y, p.rot, false); }), cat = Catalog.parts[p.type];
        var m = mirrorTurn(polys, cat && cat.mouth, p.x, p.y, p.rot, false, W0);
        p.bodies.forEach(function (b, bi) { b.pts = place(polys[bi], m.x, m.y, m.rot, false); });
        p.ghosts.forEach(function (b) { b.pts = place(unplace(b.pts, p.x, p.y, p.rot, false), m.x, m.y, m.rot, false); });
        p.x = round(m.x); p.y = round(m.y); p.rot = m.rot;
      });
      var hp = ext.parts[0];
      if (ext.port) { ext.port.mouth_x = MX(ext.port.mouth_x); if (ext.port.press && ext.port.press.knob) ext.port.press.knob = box(ext.port.press.knob); }
      if (hp) { ext.header.x = hp.x; ext.header.y = hp.y; }          // the header's own origin as it really lies (turned half round); its pins are at the same heights
      ext.header.pin_x = MX(ext.header.pin_x);
      ext.ties.at = ext.ties.at.map(function (q) { return [MX(q[0]), q[1]]; });
      ext.ties.list.forEach(function (t) { var b0 = MX(t.x1), b1 = MX(t.x0); t.x0 = b0; t.x1 = b1; });
      ext.jumpers.forEach(function (t) { var b0 = MX(t.x1), b1 = MX(t.x0); t.x0 = b0; t.x1 = b1; });
      if (ext.seam_col) { var sc = ext.seam_col; sc.x = MX(sc.x); sc.unit_edge = [MX(sc.unit_edge[1]), MX(sc.unit_edge[0])]; if (sc.board_edge != null) sc.board_edge = MX(sc.board_edge); sc.side = 'left'; }
    })();

    // breadboard shell (+ optional face PCB)
    var sx0 = (w.width - w.shell.w) / 2, sy0 = (w.height - w.shell.h) / 2;
    // Its plan is the 78.7 x 54.6 envelope trimmed to the wig's own edge: the shell doc says the rail blocks run 0.6 mm past
    // the body, which is the same waist the WigLEDmag has. The corner shape is taken from the PCB (ASSUMPTION for the shell).
    // The two short link notches the PCB has beside its tongue are not in the shell: its top edge is filled between the corners.
    var shellShape = expolys(inter(region([rectPts(sx0, sy0, sx0 + w.shell.w, sy0 + w.shell.h)]), union(wigRegion, region([rectPts(5, 0, w.width - 5, 5)]))));
    var shellPts = shellShape.length ? shellShape[0].outer : rectPts(sx0, sy0, sx0 + w.shell.w, sy0 + w.shell.h);
    addPart({ id: 'shell', type: 'bb_shell', label: 'Breadboard shell', x: 0, y: 0, rot: 0, plane: { z: 0, dir: 1 }, system: true, movable: false, color: 0x161616,
      clearance: w.fit_gap, bodies: [{ shape: { poly: shellPts }, z0: 0, z1: shellTop, name: 'shell' }],
      noClash: ['face', 'wig_pcb', 'wig_hdr'], source: 'claude_V6_breadboard_shell_DFM.md: 78.7 x 54.6 envelope, 6.75 tall (redesign target; the current print is 7.1), rail blocks 0.6 past the body.' });
    var facePts = null;
    if (faceP) {
      // The wig's top board (ref.face, read from wiigtop.3mf): the countersunk holes on the body's outline. The file's outline also
      // has a 3.43 mm strip along the top with the 2 x 35 holes; that card edge belongs to the bottom board, so it is trimmed
      // unless header_strip is true.
      var fr = ref.face && !faceP.plain ? ref.face : null;
      var faceReg = region([fr ? fr.outline : rectPts(0, 0, w.width, w.height)]);
      if (fr && faceP.header_strip !== true) faceReg = inter(faceReg, region([rectPts(-1, 0, w.width + 1, w.height + 1)]));
      if (waistCutFace) faceReg = diff(faceReg, waistCutFace);
      var fe = expolys(faceReg); facePts = fe.length ? fe[0].outer : rectPts(0, 0, w.width, w.height);
      addPart({ id: 'face', type: 'bb_face', label: fr ? 'Wig top board' : 'Breadboard face PCB', x: 0, y: 0, rot: 0, plane: { z: shellTop, dir: 1 }, system: true, movable: false, color: 0x101012,
        clearance: w.fit_gap, bodies: [{ shape: { poly: facePts }, z0: 0, z1: faceT, name: 'face board' }], noClash: ['shell', 'wig_pcb', 'wig_hdr', 'wig_skt'],
        source: fr ? fr.source + ': ' + fr.w + ' x ' + fr.h + ' x ' + fr.t + ', ' + fr.holes.length + ' holes.' : 'a plain rectangle (no face board data)' });
    }

    // removable wig: its own PCB (real outline) and the right-angle 1.27 mm header pair. Both halves sit on the top
    // faces, so the mated pair is inside the sandwich under the upper boards.
    var hdrRef = null;
    (ref.footprints || []).forEach(function (fp) { if (fp.name === 'PinHeader_2x35_P1.27_wiig_card') hdrRef = fp; });
    var hx = hdrRef ? hdrRef.x : 17.78, hy = hdrRef ? hdrRef.y : -0.254, span = 34 * 1.27;
    var MATE = 2.77 + 5.82;           // header plastic face to its pin row + socket body depth: row-to-row distance when mated
    if (removable) {
      addPart({ id: 'wig_pcb', type: 'wig_pcb', label: 'Wig bottom board (card edge along the top)', x: 0, y: 0, rot: 0, plane: { z: -w.pcb_t, dir: 1 }, system: true, movable: false, color: 0x101010,
        clearance: w.pcb_gap, bodies: [{ shape: { poly: wigPts }, z0: 0, z1: w.pcb_t, name: 'wig PCB' }], noClash: ['shell', 'wig_hdr', 'wig_skt'],
        source: 'Edge.Cuts of Testolomew/Hardware/WigLEDmag/WigLEDmag.kicad_pcb.' });
      var bot = w.connector_side === 'bottom';
      var H = Catalog.parts.hdr_ra_2x35, S = Catalog.parts.skt_ra_2x35;
      addPart({ id: 'wig_hdr', type: 'hdr_ra_2x35', label: H.label + ' (on the wig)', x: bot ? hx + span : hx, y: hy, rot: bot ? 270 : 90,
        plane: bot ? { z: -w.pcb_t, dir: -1, bottom: true } : { z: 0, dir: 1 }, system: true, movable: false, color: H.color, model: H.model, bodies: H.bodies, clearance: H.clearance,
        noClash: ['wig_skt', 'wig_pcb', 'shell'], source: H.source });
      addPart({ id: 'wig_skt', type: 'skt_ra_2x35', label: S.label + ' (on the main board)', x: bot ? hx + span : hx, y: hy - MATE, rot: bot ? 270 : 90,
        plane: bot ? { z: layers[0].z0, dir: -1, bottom: true } : { z: layers[0].z1, dir: 1 }, mountLayer: layers[0].id, system: true, movable: false, color: S.color, model: S.model, bodies: S.bodies, clearance: S.clearance,
        noClash: ['wig_hdr', 'wig_pcb'], source: S.source });
    }

    // probe dock: a channel in the space between the bottom and the top board. Only boards in between are cut.
    var probe = null;
    if (P.probe && P.probe.dock && P.probe.dock.enabled) {
      var pd = P.probe.dock, d = P.probe.dia, cl = pd.clearance, cw = d + 2 * cl;
      var lo = layers[0].z1, hi = layers.length > 1 ? top.z0 : lo + cw;
      var zc = pd.z != null ? pd.z : (lo + hi) / 2;
      addPart({ id: 'probe', type: 'probe', label: 'Probe in its dock', x: pd.x, y: pd.y_tip, rot: 0, plane: { z: 0, dir: 1 }, system: true, movable: false, color: 0xd8d8d8, clearance: 0,
        bodies: [{ shape: { rect: [-cw / 2, -cl, cw / 2, P.probe.len + cl] }, z0: zc - cw / 2, z1: zc + cw / 2, name: 'channel' }], noClash: [] });
      probe = { x: pd.x, y0: pd.y_tip, y1: pd.y_tip + P.probe.len, zc: round(zc), dia: d, channel_w: round(cw), cavity: [round(lo), round(hi)],
        magnet: { x: pd.x, y: pd.y_tip + P.probe.magnet.from_tip + P.probe.magnet.len / 2, z: round(zc), dia: P.probe.magnet.dia, len: P.probe.magnet.len } };
    }

    // user parts
    (P.parts || []).forEach(function (u) {
      var cat = Catalog.get ? Catalog.get(u, { zBot: zBot, zTop: zTop, layers: layers }) : Catalog.parts[u.type];
      if (!cat) { notes.push('unknown part type ' + u.type + ' (' + u.id + ')'); return; }
      var pl = plane(u.mount, cat.height), tg = null, wn = null, ubodies = cat.bodies, uaccess = null;
      // A display behind a window (rev A8): the module goes under the top board, which is cut to the active area, a little inside
      // it and with chamfered corners. With glass, a pane as thick as the top board fills the cut and ends flush with the top face;
      // the pane is the cut less the gap all round. Without, the cut is an opening like a button's.
      if (cat.group === 'display' && u.window && cat.screen && Catalog.windowShape) {
        wn = {}; for (var wk in Catalog.window) wn[wk] = u.window[wk] != null ? +u.window[wk] : Catalog.window[wk];
        pl = { z: top.z0 - cat.height + ((u.mount && u.mount.offset) || 0), dir: 1, bottom: false, layer: top.id };
        if (wn.glass) ubodies = cat.bodies.concat([{ shape: { poly: Catalog.windowShape(cat, wn, wn.gap) }, z0: cat.height, z1: cat.height + top.t, name: 'inlaid glass', clearance: wn.gap, glass: true }]);
        else uaccess = { shape: { poly: Catalog.windowShape(cat, wn, 0) }, open: true, clear: 0 };
        wn.w = round(cat.screen.w - 2 * wn.crop, 3); wn.h = round(cat.screen.h - 2 * wn.crop, 3); wn.aa = [cat.screen.w, cat.screen.h]; wn.module_t = cat.height;
        wn.chamfer = Math.max(0, Math.min(wn.chamfer, wn.w / 2 - 0.2, wn.h / 2 - 0.2));
      }
      if (u.tongue !== false && (u.tongue || cat.tongue) && Catalog.tongueShape) { tg = {}; for (var tk in Catalog.tongue) tg[tk] = u.tongue && u.tongue[tk] != null ? +u.tongue[tk] : (cat.tongue && cat.tongue[tk] != null ? cat.tongue[tk] : Catalog.tongue[tk]); }
      addPart({ id: u.id, type: u.type, label: u.name || cat.label, x: u.x, y: u.y, rot: u.rot || 0, plane: pl, mountLayer: pl.layer, color: cat.color, model: cat.model, bodies: ubodies, ghosts: cat.ghosts,
        clearance: u.clearance != null ? u.clearance : cat.clearance, source: cat.source, extra: cat.model && cat.model.extra, noClash: u.noClash || [],
        group: cat.group, access: uaccess || cat.access, tongue: tg ? Catalog.tongueShape(tg) : null, open: u.open,
        cantilever: tg ? { arm: tg.len - tg.tip, w: tg.w, len: tg.len, slot: tg.slot, nub: tg.nub || 0 } : null, fp: cat.fp, lcsc: cat.lcsc, win: wn });
    });

    // --- board shapes: the outline, manual features, then every part that passes through a board cuts its opening ---
    function zOverlap(a0, a1, b0, b1) { return Math.min(a1, b1) - Math.max(a0, b0); }
    layers.forEach(function (L) {
      var a = (L.kind === 'base' && !removable) ? fullOutline : frameL;
      L.gross = round(area(a), 1);
      if (L.kind === 'ring') { var inner = offset(a, -Math.max(0.3, f.ring_wall || 2)); a = diff(a, inner); }
      (P.features || []).forEach(function (ft) {
        if (!ft.layers || ft.layers.indexOf(L.id) < 0) return;
        var hw = ft.w / 2, hh = ft.h / 2, r = Math.min(ft.r || 0, hw - 0.01, hh - 0.01);
        var rr = region([place(rectPts(-hw + r, -hh + r, hw - r, hh - r), ft.x, ft.y, ft.rot || 0, false)]);
        if (r > 0) rr = offset(rr, r);
        a = ft.op === 'add' ? union(a, rr) : diff(a, rr);
      });
      // Which parts open this board. Automatic: a body that passes through it, and, for a part that has to be reached
      // from outside (catalogue "access"), the boards beyond its top. A part's own "open" map overrides either way:
      // true opens the board for it even if it stops short, false leaves the board whole even if the part runs into it.
      var cuts = [], cutBy = [];
      L.blocked = [];
      parts.forEach(function (p) {
        var wish = p.open && p.open[L.id] != null ? !!p.open[L.id] : null;
        var through = p.bodies.filter(function (b) { return b.cut && zOverlap(b.z0, b.z1, L.z0, L.z1) > EPS; });
        var beyond = p.dir > 0 ? L.z0 >= p.z1 - EPS : L.z1 <= p.z0 + EPS;
        // A cantilevered button's tongue belongs to the top board and to no other, whatever the stack and whichever board or
        // face the switch is on: it is the board a finger presses. A board between the switch and the top board gets the
        // switch's plain opening; no board on the far side of the switch is opened for it.
        var tongueHere = !!p.tonguePts && L.id === top.id, between = !!p.tonguePts && L.id !== top.id && p.dir > 0 && L.z0 >= p.z1 - EPS && p.accessPts && p.accessOpen;
        var state = 'whole', auto = through.length ? 'through' : p.tonguePts ? (tongueHere || between ? 'access' : 'whole') : (p.accessPts && p.accessOpen && beyond ? 'access' : 'whole');
        var tongueCut = false;
        if (wish === false) { state = through.length ? 'blocked' : 'whole'; if (through.length) L.blocked.push({ part: p, bodies: through }); }
        else if (through.length) { through.forEach(function (b) { cuts = cuts.concat(offset(region([b.pts]), b.clearance)); }); state = 'through'; }
        else if (tongueHere) { cuts = cuts.concat(region([p.tonguePts])); state = 'access'; tongueCut = true; }
        else if (wish === true || auto === 'access') {
          var shapes = p.accessPts ? [p.accessPts] : p.bodies.filter(function (b) { return !b.slot; }).map(function (b) { return b.pts; });
          cuts = cuts.concat(p.accessClear > 0 ? offset(region(shapes), p.accessClear) : region(shapes)); state = 'access';
        }
        if (!p.system || state !== 'whole') p.boards[L.id] = { state: state, auto: auto, set: wish };
        if (tongueCut) p.boards[L.id].tongue = true;
        if (state !== 'whole' && state !== 'blocked' && cutBy.indexOf(p.id) < 0) cutBy.push(p.id);
      });
      if (press && L.kind === 'base') { cuts = cuts.concat(press.cut); cutBy.push('tab'); }       // the knob-shaped cutout for the press-in tab (rev A11e)
      var before = area(a);
      if (cuts.length) a = diff(a, union(cuts));
      a = clean(a);
      L.region = a;
      L.shape = expolys(a);
      L.area = round(area(a), 1);
      L.pocketArea = round(before - area(a), 1);
      L.islands = L.shape.length;
      L.cutBy = cutBy;
      L.bbox = bbox(a);
    });

    // --- checks ---
    var checks = { grid: {}, flush: {}, clashes: [], neighbours: [], faces: [], probe: null, notes: notes };
    checks.joints = joints.map(function (j) { return { vertex: j.vertex, at: j.at, flat: j.flat }; });      // where the frame's edge meets a chamfer of the breadboard square
    checks.grid = { pitch: round(unitPitch), dead_rows: dead + 1, cols: g.cols, left_plane: round(xl), right_plane: round(xr), strip_w: round(dead * pitch), strip_side: mir ? 'right' : 'left', on_grid: Math.abs(unitPitch / pitch - Math.round(unitPitch / pitch)) < 1e-6,
      dead_x: (function () { var a = []; for (var j = 0; j <= dead; j++) a.push(round(mir ? W0 + j * pitch : -j * pitch)); return a; })() };
    // The simplified outline: left strip plane to right plane, top edge to bottom edge. Kevin wants it square. Square on the unit
    // pitch also puts the height on the 2.54 grid, so a unit stood above another keeps its hole rows on the grid too.
    (function () {
      var H = round(yb - yt), bw = round(Math.max(fb.x1, xr) - Math.min(fb.x0, xl)), rows = H / pitch;
      checks.grid.overall = { w: round(unitPitch), h: H, widest: bw, band: round(-yt), square: Math.abs(unitPitch - H) < 0.05, square_widest: Math.abs(bw - H) < 0.05,
        band_square: round(unitPitch - yb), band_square_widest: round(bw - yb), rows_high: round(rows, 3), v_on_grid: Math.abs(rows - Math.round(rows)) < 0.002 };
    })();
    checks.flush = { frame_top: round(zTop), bb_top: round(bbTop), shell_top: round(shellTop), face_t: round(faceT), delta: round(zTop - bbTop), delta_shell: round(zTop - shellTop), total: round(zTop - zBot), stack_above_base: round(zTop),
      gaps: layers.slice(1).map(function (L) { return { below: L.id, gap: round(L.gap) }; }) };

    parts.forEach(function (p) {
      var x0 = 1e9, x1 = -1e9;
      p.bodies.forEach(function (b) { b.pts.forEach(function (q) { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); }); });
      p.xmin = round(x0); p.xmax = round(x1);
    });

    // side by side on the 0.1 inch grid: this unit's plan against a neighbour one unit pitch away.
    // Plan only (heights are ignored), and edges that just touch do not count.
    function shiftX(a, dx) { var k = Math.round(dx * SC); return a.map(function (p) { return p.map(function (q) { return { X: q.X + k, Y: q.Y }; }); }); }
    function partPlan(p) { var polys = []; p.bodies.forEach(function (b) { if (!b.slot) polys.push(b.pts); }); return region(polys); }
    var boardsPlan = [];
    layers.forEach(function (L) { boardsPlan = boardsPlan.concat(L.region); });
    boardsPlan = union(boardsPlan, removable ? wigRegion : []);
    var unitPlan = boardsPlan;
    parts.forEach(function (p) { unitPlan = unitPlan.concat(partPlan(p)); });
    unitPlan = union(unitPlan);
    function versus(id, label, nb) {
      var nbE = offset(nb, -0.02), items = [];
      var tot = inter(unitPlan, nbE), ar = area(tot);
      if (ar > 0.02) {
        layers.forEach(function (L) { var o = area(inter(L.region, nbE)); if (o > 0.02) items.push({ what: L.id + ' ' + L.name, mm2: round(o, 1) }); });
        parts.forEach(function (p) { if (p.id === 'shell' || p.id === 'wig_pcb') return; var o = area(inter(partPlan(p), nbE)); if (o > 0.02) items.push({ what: p.label, id: p.id, mm2: round(o, 1) }); });
      }
      var b = ar > 0.02 ? bbox(tot) : null;
      return { id: id, label: label, overlap_mm2: ar > 0.02 ? round(ar, 1) : 0, depth: b ? round(b.x1 - b.x0, 2) : 0, y0: b ? round(b.y0, 1) : null, y1: b ? round(b.y1, 1) : null, items: items };
    }
    checks.neighbours.push(versus('wig_left', 'A bare breadboard (WigLEDmag outline) on the left', shiftX(wigRegion, -unitPitch)));
    checks.neighbours.push(versus('wig_right', 'A bare breadboard (WigLEDmag outline) on the right', shiftX(wigRegion, unitPitch)));
    checks.neighbours.push(versus('unit_left', 'Another whole unit on the left', shiftX(unitPlan, -unitPitch)));
    checks.neighbours.push(versus('unit_right', 'Another whole unit on the right', shiftX(unitPlan, unitPitch)));
    var clearAt = null;
    for (var kx = 0; kx <= 8 && clearAt == null; kx++) if (area(inter(unitPlan, offset(shiftX(unitPlan, unitPitch + kx * pitch), -0.02))) <= 0.02) clearAt = kx;
    checks.grid.units_clear_at = clearAt == null ? null : { pitch: round(unitPitch + clearAt * pitch), dead_rows: dead + 1 + clearAt, extra_rows: clearAt };

    // an edge coupler between this unit and the next: what it needs between the two boards' shoulders, against the rows on hand
    var cpl = Catalog.couplers && g.coupler && Catalog.couplers[g.coupler];
    if (cpl) {
      var have = dead * pitch, needRows = Math.ceil((cpl.gap - 1e-6) / pitch);
      checks.grid.coupler = { key: g.coupler, label: cpl.label, gap: cpl.gap, across: cpl.across, len: cpl.len, thick: cpl.thick, tongue: cpl.tongue, tip_gap: cpl.tip_gap, have: round(have), fits: have + 1e-6 >= cpl.gap,
        spare: round(have - cpl.gap, 2), rows_needed: needRows, strip_needed: round(needRows * pitch), source: cpl.source,
        x0: round(W0), x1: round(W0 + have), yc: round(w.height / 2, 2), zc: round(-layers[0].t / 2, 2) };
    }

    // the extender against this unit: what the two share in plan, how the socket and its header meet, and what ties the seam.
    // play: the header pair alone is a short joint at the top of a long seam, so 0.1 mm of side play in it shows at the far
    // bottom corner multiplied by (distance to that corner / length of the joint). near: the magnetometer closest to a tie
    // hole or the socket, to know before anything of steel, or a magnet, is put there.
    checks.extender = null;
    if (ext) (function () {
      var ov = versus('extender', 'The extender against this unit', ext.plan), pt = ext.port, need = ext.n_rows, play = null, near = null;
      if (pt && pt.len > 0) { var yc = (pt.y0 + pt.y1) / 2; play = { joint: pt.len, arm: round(ext.y1 - yc, 1), corner: round(0.1 * (ext.y1 - yc) / pt.len, 2) }; }
      var spots = ext.ties.at.map(function (q) { return { x: q[0], y: q[1], what: 'a tie hole' }; });
      if (pt) spots.push({ x: pt.mouth_x + (mir ? 2.9 : -2.9), y: (pt.y0 + pt.y1) / 2, what: 'the socket' });
      sensorSet.mmc.concat(sensorSet.tmag).forEach(function (s) { spots.forEach(function (q) { var d = Math.hypot(s.x - q.x, s.y - q.y); if (!near || d < near.d) near = { ref: s.ref, d: round(d, 1), what: q.what }; }); });
      var pw = mir ? xr - ext.x0 : ext.x1 - xl;
      if (pt && pt.press && press) pt.press.mags = sensorSet.mmc.concat(sensorSet.tmag).filter(function (s) { return press.rects.some(function (q) { return s.x > q[0] - 1.5 && s.x < q[2] + 1.5 && s.y > q[1] - 1.5 && s.y < q[3] + 1.5; }); }).map(function (s) { return s.ref; });
      checks.extender = { cols: ext.n_cols, rows: need, dead: ext.dead, col_gap: ext.col_gap, rail_skip: ext.rail_skip, seam_col: ext.seam_col, x0: ext.x0, x1: ext.x1, w: ext.w, head: ext.head, cover: !!ext.z.cover, keyed: ext.keyed,
        pair_w: round(pw), pair_rows: round(pw / pitch, 3), on_grid: Math.abs(pw / pitch - Math.round(pw / pitch)) < 1e-6,
        port: pt, need: need, spare: pt ? pt.pins - need : null, header: ext.header, overlap: ov, seam: round(ext.y1 - ext.y0, 2), tied: ext.ties.list.length > 0, play: play,
        side: ext.side,
        ties: { kind: ext.ties.kind, n: ext.ties.list.length, span: round(Math.abs(ext.cols[0] - ext.ties.at[0][0])), wire: ext.ties.wire, hole: ext.ties.hole, room: ext.ties.room, from_ref: ext.ties.from_ref, at: ext.ties.at },
        jumpers: ext.jumpers.length, jumper_span: ext.jumpers.length ? round(ext.jumpers[0].x1 - ext.jumpers[0].x0) : null, near: near };
    })();

    // parts that reach past the edge of the board they sit on (wanted for an edge wheel or a connector mouth; worth seeing either way)
    checks.overhang = [];
    parts.forEach(function (p) {
      var L = p.mountLayer && !p.system ? layerById(p.mountLayer) : null; if (!L) return;
      var edge = (L.kind === 'base' && !removable) ? fullOutline : frameL, o = diff(partPlan(p), edge), ar = area(o);
      if (ar > 0.05) { var b = bbox(o); checks.overhang.push({ id: p.id, label: p.label, layer: L.id, mm2: round(ar, 1), x: [round(b.x0, 2), round(b.x1, 2)], y: [round(b.y0, 2), round(b.y1, 2)] }); }
    });

    // a part that runs into a board it was told not to open
    // cantilevered buttons: the tongue is cut in the top board. A plain cantilever, loaded at the switch: k = 3 E I / L^3.
    // E = 22 GPa is a usual flexural modulus for FR4 (ASSUMPTION), the switch's own force and travel are typical tact figures.
    checks.cantilevers = [];
    parts.forEach(function (p) {
      if (!p.cantilever) return;
      var st = p.boards[top.id], rec = { id: p.id, label: p.label, board: top.id, t: top.t, switch_on: p.mountLayer, underside: p.bottom };
      if (!st || !st.tongue) { rec.none = true; rec.why = st && st.state === 'through' ? 'through' : st && st.set === false ? 'kept' : 'unknown'; checks.cantilevers.push(rec); return; }
      // Where the switch is against the tongue. below: on a board under the top board, pressed from above (the usual way).
      // under: soldered to the underside of the top board, on the tongue itself, pressing on the board below.
      // away: anywhere else (hanging under a lower board, or on top of the top board): the tongue cannot work it.
      var gap = null;
      if (p.mountLayer === top.id && p.bottom) {
        var land = null; layers.forEach(function (L) { if (L.id !== top.id && L.z1 <= p.z0 + EPS) land = L; });
        rec.under = true; rec.lands = land ? land.id : null; gap = land ? p.z0 - land.z1 : null;
      } else if (p.dir > 0 && p.z1 <= top.z0 + EPS) gap = top.z0 - p.z1;
      else rec.away = true;
      var slotR = region([p.tonguePts]); rec.broken = round(area(diff(diff(offset(slotR, 0.8), slotR), top.region)), 1); if (rec.broken <= 0.3) rec.broken = 0;
      var E = 22000, c = p.cantilever, I = c.w * Math.pow(top.t, 3) / 12, k = 3 * E * I / Math.pow(c.arm, 3);
      rec.arm = round(c.arm, 2); rec.w = c.w; rec.k = round(k, 1); rec.nub = c.nub || 0;
      if (gap != null) {
        var travel = Math.max(0, gap - (c.nub || 0)) + 0.25;
        rec.gap = round(gap, 3); rec.travel = round(travel, 2); rec.far = gap - (c.nub || 0) > 1;       // more than a millimetre of air: the tongue will not get there
        rec.force = round(k * travel + 1.6, 1); rec.board_force = round(k * travel, 1); rec.stress = round(3 * E * top.t * travel / (2 * c.arm * c.arm), 0);
        rec.with_nub = round(k * (Math.max(0, gap - 0.2) + 0.25) + 1.6, 1);
        rec.thin = { t: 0.8, force: round(3 * E * (c.w * 0.512 / 12) / Math.pow(c.arm, 3) * travel + 1.6, 1) };
      }
      checks.cantilevers.push(rec);
    });
    // displays behind a window: what the cut and the pane come to, and the room left under the module (for switches under it)
    checks.windows = [];
    parts.forEach(function (p) {
      if (!p.win) return;
      var k = p.win, below = null; layers.forEach(function (L) { if (L.z1 <= p.z0 + EPS) below = L; });
      checks.windows.push({ id: p.id, label: p.label, board: top.id, t: top.t, w: k.w, h: k.h, crop: k.crop, chamfer: round(k.chamfer, 2), aa: k.aa,
        shown_pct: round(100 * (k.w * k.h - 2 * k.chamfer * k.chamfer) / (k.aa[0] * k.aa[1]), 1),
        glass: k.glass ? { w: round(k.w - 2 * k.gap, 3), h: round(k.h - 2 * k.gap, 3), t: top.t, gap: k.gap } : null,
        z_module: [round(p.z0, 3), round(p.z0 + k.module_t, 3)], below: below ? below.id : null, under: below ? round(p.z0 - below.z1, 3) : null });
    });
    checks.blocked = [];
    layers.forEach(function (L) { L.blocked.forEach(function (q) {
      var ar = area(inter(region(q.bodies.map(function (b) { return b.pts; })), L.region));
      if (ar > 0.05) checks.blocked.push({ id: q.part.id, label: q.part.label, layer: L.id, name: L.name, mm2: round(ar, 1) });
    }); delete L.blocked; });
    // how far each part stands above the top face (or hangs below the underside)
    checks.proud = [];
    parts.forEach(function (p) {
      if (p.system) return;
      var up = round(p.z1 - Math.max(zTop, bbTop), 2), down = round(zBot - p.z0, 2);
      p.proud = up; p.below = down;
      if (up > 0.05) checks.proud.push({ id: p.id, label: p.label, side: 'top', by: up });
      if (down > 0.05) checks.proud.push({ id: p.id, label: p.label, side: 'underside', by: down });
    });

    // part against part
    for (var i = 0; i < parts.length; i++) for (var j = i + 1; j < parts.length; j++) {
      var A = parts[i], B = parts[j];
      if (A.noClash.indexOf(B.id) >= 0 || B.noClash.indexOf(A.id) >= 0) continue;
      var worst = null;
      A.bodies.forEach(function (ba) { B.bodies.forEach(function (bb) {
        if (ba.slot || bb.slot) return;
        var dz = zOverlap(ba.z0, ba.z1, bb.z0, bb.z1);
        if (dz <= EPS) return;
        var ar = area(inter(region([ba.pts]), region([bb.pts])));
        if (ar > 0.05 && (!worst || ar * dz > worst.area * worst.dz)) worst = { area: round(ar, 2), dz: round(dz, 2), a: ba.name, b: bb.name };
      }); });
      if (worst) checks.clashes.push({ a: A.id, b: B.id, labels: [A.label, B.label], bodies: [worst.a, worst.b], overlap_mm2: worst.area, overlap_z: worst.dz });
    }

    // room: each board face, less whatever stands in the space in front of it. Under a facing board the headroom is the
    // gap (shared with whatever hangs from that board); where the facing board is cut away or ends it is more.
    var minGap = P.room && P.room.min_gap != null ? P.room.min_gap : 0.6;
    function occupied(zA, zB) {
      var polys = [];
      parts.forEach(function (p) { p.bodies.forEach(function (b) {
        if (b.slot) return;
        if (zOverlap(b.z0, b.z1, zA, zB) > EPS) polys = polys.concat(offset(region([b.pts]), 0.2));
      }); });
      return polys.length ? union(polys) : [];
    }
    var placeable = 0;
    layers.forEach(function (L, k) {
      [1, -1].forEach(function (dir) {
        var n1 = layers[k + dir], zf = dir > 0 ? L.z1 : L.z0;
        var face = { layer: L.id, name: L.name, side: dir > 0 ? 'top' : 'bottom' };
        if (L.kind === 'ring') { face.counts = false; face.spacer = true; face.free = 0; checks.faces.push(face); return; }
        if (!n1) {
          var occ0 = dir > 0 ? occupied(zf + 0.05, zf + 1.0) : occupied(zf - 1.0, zf - 0.05);
          face.open = true; face.height = 'open';
          var fr0 = diff(L.region, occ0);
          face.free = round(area(fr0), 0); face.free_open = 0;
          if (L.kind === 'base' && !removable) face.under_bb = round(area(inter(fr0, wigRegion)), 0);
          face.counts = !(dir > 0);                 // the top of the top board is the user's face, not component room
        } else {
          var gap = round(dir > 0 ? n1.z0 - L.z1 : L.z0 - n1.z1, 3), reach = Math.max(gap, 1.0);
          var occ = dir > 0 ? occupied(zf + 0.05, zf + reach) : occupied(zf - reach, zf - 0.05);
          var under = inter(L.region, n1.region), clear = diff(L.region, n1.region);
          face.height = gap;
          face.free = gap >= minGap ? round(area(diff(under, occ)), 0) : 0;
          if (L.kind === 'base' && !removable) face.under_bb = round(area(inter(diff(L.region, occ), wigRegion)), 0);
          face.free_open = round(area(diff(clear, occ)), 0);
          face.counts = true;
        }
        if (face.counts) placeable += face.free + (face.free_open || 0);
        checks.faces.push(face);
      });
    });
    checks.area = { budget: P.area_budget_mm2 || 0, placeable: round(placeable, 0), fill: placeable > 0 ? round((P.area_budget_mm2 || 0) / placeable, 3) : null,
      frame_face: round(area(frameL), 0), full_face: round(area(fullOutline), 0), min_gap: minGap };

    checks.split = layers.filter(function (L) { return L.islands !== 1; }).map(function (L) { return { layer: L.id, name: L.name, pieces: L.islands }; });

    // probe dock
    if (probe) {
      // the strip's outer plane on one side of the channel, the shell on the other
      var wl = mir ? (probe.x - probe.channel_w / 2) - (sx0 + w.shell.w + w.fit_gap) : (probe.x - probe.channel_w / 2) - xl;
      var wr = mir ? xr - (probe.x + probe.channel_w / 2) : (sx0 - w.fit_gap) - (probe.x + probe.channel_w / 2);
      var sens = [];
      sensorSet.mmc.forEach(function (s) { sens.push({ kind: 'MMC5603', ref: s.ref, x: s.x, y: s.y, z: s.z != null ? s.z : (s.side === 'F' ? 0 : -w.pcb_t), range: 3 }); });
      sensorSet.tmag.forEach(function (s) { sens.push({ kind: 'TMAG5273', ref: s.ref, x: s.x, y: s.y, z: s.z != null ? s.z : (s.side === 'F' ? 0 : -w.pcb_t), range: 40 }); });
      var m = probe.magnet, mom = 115.4 * Math.PI * Math.pow(m.dia / 2, 2) * m.len;     // mT*mm^3, Br 1.45 T (N52), the convention in wireless-probe-sensing.md
      var near = null;
      sens.forEach(function (s) {
        var dx = s.x - m.x, dy = s.y - m.y, dz = s.z - m.z, r = Math.sqrt(dx * dx + dy * dy + dz * dz), cosT = dy / r;   // magnet axis lies along y in the dock
        var B = mom / (r * r * r) * Math.sqrt(1 + 3 * cosT * cosT);
        if (!near || B / s.range > near.frac) near = { kind: s.kind, ref: s.ref, r: round(r, 1), B_mT: round(B, 3), range_mT: s.range, frac: B / s.range };
      });
      var cutsEnds = [];
      [layers[0], top].forEach(function (L) { if (L.cutBy.indexOf('probe') >= 0 && cutsEnds.indexOf(L.id) < 0) cutsEnds.push(L.id); });
      checks.probe = { wall_left: round(wl, 2), wall_right: round(wr, 2), channel_w: probe.channel_w, zc: probe.zc, cavity: probe.cavity, room_z: round(probe.cavity[1] - probe.cavity[0], 2),
        cuts_outer: cutsEnds, cuts: layers.filter(function (L) { return L.cutBy.indexOf('probe') >= 0; }).map(function (L) { return L.id; }),
        sticks_out: round(Math.max(0, probe.y1 - yb), 1), moment: round(mom, 0), nearest: near,
        dead_row_in_channel: checks.grid.dead_x.filter(function (x) { return Math.abs(x - probe.x) < probe.channel_w / 2; }) };
    }

    // breadboard grid (for drawing): columns at pitch from the wig edge; rows from the real board when known
    var rows = ref.rows && ref.rows.length ? ref.rows : (function () { var a = []; for (var r = 0; r < 20; r++) if (r !== 2 && r !== 3 && r !== 16 && r !== 17) a.push(3.556 + r * pitch); return a; })();
    var cols = []; for (var k = 1; k <= g.cols; k++) cols.push(round(k * pitch));

    var out = {
      params: P, removable: removable,
      planes: { xl: round(xl), xr: round(xr), yt: yt, yb: yb, pitch: round(unitPitch), dead: dead, x0: round(Math.min(fb.x0, xl)), x1: round(Math.max(fb.x1, xr)), side: mir ? 'right' : 'left', w: round(W0) },
      z: { top: round(zTop), bottom: round(zBot), bbTop: round(bbTop), shellTop: round(shellTop) },
      outline: { verts: verts.map(function (v, i) { return { x: v.x, y: v.y, from: built.spans[i].from, count: built.spans[i].count }; }), pts: built.pts },
      layers: layers, parts: parts, probe: probe, checks: checks, extender: ext,
      wig: { x0: 0, y0: 0, w: w.width, h: w.height, pcb_t: w.pcb_t, waist: waist, shell: { x0: sx0, y0: sy0, w: w.shell.w, h: w.shell.h, t: round(shellTop) }, face_t: faceT, face: faceP ? { t: faceT, z0: round(shellTop), z1: round(bbTop), inset: faceInset, real: !!(ref.face && !faceP.plain), strip: faceP.header_strip === true, pts: facePts, y0: round(bbox(region([facePts])).y0), holes: ref.face && !faceP.plain ? ref.face.holes.filter(function (q) { return faceP.header_strip === true || q[1] >= 0; }) : null } : null,
        outline: wigPts, rows: rows, cols: cols,
        card_holes: ref.face ? ref.face.holes.filter(function (q) { return q[1] < 0; }) : [],
        sensors: sensorSet }
    };
    // the layout as a list the Magnetometers tab can show and edit, whichever way it was chosen
    sensorSet.list = sensLayout === 'custom' ? ((P.mag && P.mag.list) || []) : Mag.legacyList(out, ref, sensLayout);
    return out;
  }

  // a plain-data copy of the result (no clipper paths) for JSON, STEP export and tests
  function plain(R) {
    return {
      meta: R.params.meta, mode: R.removable ? 'removable' : 'integrated', planes: R.planes, z: R.z, outline: R.outline,
      layers: R.layers.map(function (L) { return { id: L.id, name: L.name, kind: L.kind, t: L.t, z0: L.z0, z1: L.z1, area: L.area, gross: L.gross, pocketArea: L.pocketArea, islands: L.islands, cutBy: L.cutBy, shape: L.shape }; }),
      parts: R.parts.map(function (p) { return { id: p.id, type: p.type, label: p.label, x: p.x, y: p.y, rot: p.rot, bottom: p.bottom, zPlane: p.zPlane, dir: p.dir, z0: p.z0, z1: p.z1, model: p.model, extra: p.extra, source: p.source, boards: p.boards,
        bodies: p.bodies.map(function (b) { return { name: b.name, pts: b.pts, z0: b.z0, z1: b.z1, slot: b.slot, glass: b.glass }; }), ghosts: p.ghosts.map(function (b) { return { name: b.name, pts: b.pts, z0: b.z0, z1: b.z1 }; }) }; }),
      probe: R.probe, wig: R.wig, checks: R.checks,
      extender: R.extender ? (function (E) { var o = {}; for (var k in E) if (k !== 'plan') o[k] = E[k]; return o; })(R.extender) : null
    };
  }

  // ---------- outline operations (rev A12): the humps of the outline, and the left-to-right flip ----------
  // These work on the parameter set (P.frame.outline and what hangs on it), not on a resolved model, so the page and the
  // checks use the same code. Nothing here is called by resolve().
  //
  // The outline is read as three outer edges between four corner vertices:
  //   top    from the top-left corner (TL) to the top-right corner (TR)
  //   right  from TR down to the lowest vertex on the right grid plane
  //   left   from the lowest vertex on the left grid plane up to TL
  // and what is left over, the run along the breadboard. Each edge has a base line (the grid plane for a side; for the top
  // edge its level nearest the breadboard). A HUMP is a run of vertices that stand outside that line. It may take in the
  // corner at either end of its edge, which then stands out with it.
  var HUMP_EPS = 0.05;
  function r4(v) { return Math.round(v * 1e4) / 1e4; }
  function vclone(v) { var o = {}; for (var k in v) o[k] = Array.isArray(v[k]) ? v[k].slice() : v[k]; return o; }
  function sideInfo(P) {
    var g = P.grid, dead = Math.max(0, Math.min(MAX_DEAD, Math.round(g.dead_rows_left))), W = (g.cols + 1) * g.pitch, mir = P.frame.side === 'right';
    return { W: W, H: P.wig.height, mir: mir, dead: dead, pitch: g.pitch, xl: mir ? 0 : -dead * g.pitch, xr: mir ? W + dead * g.pitch : W };
  }
  // the same vertices as a list that starts at the top-left corner and runs clockwise as seen on screen (y down)
  function normalise(verts) {
    var a = 0, n = verts.length, i;
    for (i = 0; i < n; i++) { var p = verts[i], q = verts[(i + 1) % n]; a += p.x * q.y - q.x * p.y; }
    var v = a < 0 ? verts.slice().reverse() : verts.slice(), tl = 0;
    for (i = 1; i < n; i++) if (v[i].x + v[i].y < v[tl].x + v[tl].y - 1e-9) tl = i;
    return v.slice(tl).concat(v.slice(0, tl));
  }
  // how much of an edge a corner's own shape takes, measured from its vertex along x or along y
  function legOf(v, axis) {
    if (v.c === 'wig') return axis === 'x' ? 2.51 : 2.11;
    if (Array.isArray(v.c)) return (axis === 'x' ? +v.c[0] : +v.c[1]) + 0.6 * (+v.r || 0);
    return +v.r || 0;
  }
  function edgesOf(P) {
    var S = sideInfo(P), V = normalise(P.frame.outline), n = V.length, i, tr = 0, br = -1, bl = -1;
    for (i = 1; i < n; i++) if (V[i].x - V[i].y > V[tr].x - V[tr].y + 1e-9) tr = i;
    for (i = tr; i < n; i++) if (Math.abs(V[i].x - S.xr) < 0.06 && (br < 0 || V[i].y > V[br].y)) br = i;
    if (br < 0) { br = tr; for (i = tr + 1; i < n; i++) if (V[i].x + V[i].y > V[br].x + V[br].y) br = i; }
    for (i = br + 1; i < n; i++) if (Math.abs(V[i].x - S.xl) < 0.06 && (bl < 0 || V[i].y > V[bl].y)) bl = i;
    if (bl < 0) { bl = n; for (i = br + 1; i < n; i++) if (bl === n || V[i].x - V[i].y < V[bl].x - V[bl].y) bl = i; }
    var yB = -1e9; for (i = 0; i <= tr; i++) yB = Math.max(yB, V[i].y);
    // each edge as a list in rising order of its own coordinate (x along the top, y down a side), with how to read and set a vertex
    var E = {
      top: { side: 'top', axis: 'x', list: V.slice(0, tr + 1), a: function (v) { return v.x; }, out: function (v) { return yB - v.y; }, setA: function (v, a) { v.x = r4(a); }, setOut: function (v, o) { v.y = r4(yB - o); }, base: yB },
      right: { side: 'right', axis: 'y', list: V.slice(tr, br + 1), a: function (v) { return v.y; }, out: function (v) { return v.x - S.xr; }, setA: function (v, a) { v.y = r4(a); }, setOut: function (v, o) { v.x = r4(S.xr + o); }, base: S.xr },
      left: { side: 'left', axis: 'y', list: V.slice(bl).concat([V[0]]).reverse(), a: function (v) { return v.y; }, out: function (v) { return S.xl - v.x; }, setA: function (v, a) { v.y = r4(a); }, setOut: function (v, o) { v.x = r4(S.xl - o); }, base: S.xl }
    };
    E.inner = V.slice(br + 1, bl);
    E.S = S;
    // put the edges back together as one outline, clockwise from TL (the corner vertices are shared between two lists)
    E.join = function () { var lf = E.left.list.slice().reverse(); return E.top.list.concat(E.right.list.slice(1), E.inner, lf.slice(0, lf.length - 1)); };
    return E;
  }
  function humpsOn(e) {
    var L = e.list, m = L.length - 1, list = [], k = 0;
    while (k <= m) {
      if (e.out(L[k]) <= HUMP_EPS) { k++; continue; }
      var k0 = k; while (k <= m && e.out(L[k]) > HUMP_EPS) k++;
      var k1 = k - 1, out = 0, j; for (j = k0; j <= k1; j++) out = Math.max(out, e.out(L[j]));
      var p0 = k0, p1 = k1; while (e.out(L[p0]) < out - 0.01) p0++; while (e.out(L[p1]) < out - 0.01) p1--;
      list.push({ side: e.side, axis: e.axis, k0: k0, k1: k1, p0: p0, p1: p1, end0: k0 === 0, end1: k1 === m, out: r4(out),
        a0: r4(e.a(L[k0 === 0 ? 0 : k0 - 1])), a1: r4(e.a(L[k1 === m ? m : k1 + 1])), flat0: r4(e.a(L[p0])), flat1: r4(e.a(L[p1])), n: k1 - k0 + 1 });
    }
    list.forEach(function (h, i) { h.key = e.side + ':' + i; });
    return list;
  }
  // every hump of the outline, with a sentence saying where it is
  function humps(P) {
    var E = edgesOf(P), all = [];
    ['top', 'left', 'right'].forEach(function (sd) {
      humpsOn(E[sd]).forEach(function (h) {
        var lo = h.axis === 'x' ? 'left' : 'top', hi = h.axis === 'x' ? 'right' : 'bottom';
        h.where = h.end0 && h.end1 ? 'the whole edge' : h.end0 ? 'from the ' + (h.axis === 'x' ? 'top-left' : 'top') + ' corner to ' + h.axis + ' ' + round(h.a1, 2) : h.end1 ? 'from ' + h.axis + ' ' + round(h.a0, 2) + ' to the ' + (h.axis === 'x' ? 'top-right' : 'bottom') + ' corner' : h.axis + ' ' + round(h.a0, 2) + ' to ' + round(h.a1, 2);
        h.label = (sd === 'top' ? 'Top edge' : sd === 'left' ? 'Left side' : 'Right side') + ', ' + round(h.out, 2) + ' mm ' + (sd === 'top' ? 'up' : 'out') + ', ' + h.where;
        h.lo = lo; h.hi = hi;
        all.push(h);
      });
    });
    return all;
  }
  function findHump(E, key) { var sd = String(key).split(':')[0], i = +String(key).split(':')[1], e = E[sd]; if (!e || !e.list) return null; var h = humpsOn(e)[i]; return h ? { e: e, h: h } : null; }
  function rising(e) { var L = e.list; for (var k = 1; k < L.length; k++) if (e.a(L[k]) < e.a(L[k - 1]) - 1e-6) return false; return true; }
  function commit(P, E) { P.frame.outline = E.join(); return true; }
  // Change one hump: a0 / a1 move the step at that end (not an end that is the corner), out its height, slide the whole hump
  // along its edge. Returns { ok } or { ok: false, why }; nothing is changed when it does not fit.
  function humpSet(P, key, ch) {
    var keep = P.frame.outline.map(vclone), saved = P.frame.outline;
    P.frame.outline = keep.map(vclone);
    var E = edgesOf(P), f = findHump(E, key);
    function fail(why) { P.frame.outline = saved; return { ok: false, why: why }; }
    if (!f) return fail('no such hump');
    var e = f.e, h = f.h, L = e.list, m = L.length - 1, k;
    if (ch.out != null) {
      var o = +ch.out; if (!(o > HUMP_EPS)) { P.frame.outline = saved; return humpRemove(P, key); }
      for (k = h.k0; k <= h.k1; k++) e.setOut(L[k], e.out(L[k]) * o / h.out);
    }
    function shift(k0, k1, d) { for (var j = k0; j <= k1; j++) if (j > 0 && j < m) e.setA(L[j], e.a(L[j]) + d); }
    if (ch.slide != null && +ch.slide) shift(h.k0 - 1, h.k1 + 1, +ch.slide);
    if (ch.a0 != null && !h.end0) { var d0 = +ch.a0 - h.a0; if (h.p0 === h.p1 && h.n === 1) shift(h.k0 - 1, h.k0 - 1, d0); else shift(h.k0 - 1, h.p0 === h.p1 ? h.p0 - 1 : h.p0, d0); }
    if (ch.a1 != null && !h.end1) { var d1 = +ch.a1 - h.a1; if (h.p0 === h.p1 && h.n === 1) shift(h.k1 + 1, h.k1 + 1, d1); else shift(h.p0 === h.p1 ? h.p1 + 1 : h.p1, h.k1 + 1, d1); }
    if (!rising(e)) return fail('it would run past the next corner of the outline');
    var lo = e.a(L[0]) + (h.end0 ? 0 : legOf(L[0], e.axis)), hi = e.a(L[m]) - (h.end1 ? 0 : legOf(L[m], e.axis));
    if ((!h.end0 && e.a(L[h.k0 - 1]) < lo - 1e-6) || (!h.end1 && e.a(L[h.k1 + 1]) > hi + 1e-6)) return fail('it would run into the corner at the end of that edge');
    commit(P, E); return { ok: true };
  }
  // what a hump is made of, as a list of points along its edge: { a, o, spec, end } (end 0 or 1: it is the corner at that end)
  function capture(e, h) {
    var L = e.list, m = L.length - 1, prof = [], k;
    for (k = Math.max(0, h.k0 - 1); k <= Math.min(m, h.k1 + 1); k++) {
      var v = L[k], sp = vclone(v); delete sp.x; delete sp.y;
      prof.push({ a: e.a(v), o: k < h.k0 || k > h.k1 ? 0 : e.out(v), spec: sp, end: k === 0 ? 0 : k === m ? 1 : null, run: k >= h.k0 && k <= h.k1 });
    }
    return prof;
  }
  function removeOn(e, h) {
    var L = e.list, m = L.length - 1, drop = [], k;
    for (k = h.k0; k <= h.k1; k++) { if (k === 0 || k === m) e.setOut(L[k], 0); else drop.push(k); }
    // a root that only marked where the hump left the base line says nothing once the hump is gone
    [h.k0 - 1, h.k1 + 1].forEach(function (rk, i) {
      if (rk <= 0 || rk >= m) return;
      var beyond = L[i === 0 ? rk - 1 : rk + 1];
      if (Math.abs(e.out(L[rk])) <= HUMP_EPS && Math.abs(e.out(beyond)) <= HUMP_EPS) drop.push(rk);
    });
    drop.sort(function (a, b) { return b - a; }).forEach(function (j) { L.splice(j, 1); });
  }
  function humpRemove(P, key) {
    var E = edgesOf(P), f = findHump(E, key); if (!f) return { ok: false, why: 'no such hump' };
    removeOn(f.e, f.h); commit(P, E); return { ok: true };
  }
  // lay a captured hump on an edge. The points between its ends must fall on a clear stretch of the base line.
  function layOn(e, prof) {
    var L = e.list, m = L.length - 1, inner = prof.filter(function (q) { return q.end == null; }), k;
    if (inner.length) {
      var a0 = inner[0].a, a1 = inner[inner.length - 1].a;
      if (a0 < e.a(L[0]) + 0.05 || a1 > e.a(L[m]) - 0.05) return 'there is no room for it on that edge';
      for (k = m - 1; k >= 1; k--) { var ak = e.a(L[k]); if (ak > a0 - 0.05 && ak < a1 + 0.05) { if (Math.abs(e.out(L[k])) > HUMP_EPS) return 'another hump is in the way there'; L.splice(k, 1); } }
      m = L.length - 1;
      var at = 1; while (at < m && e.a(L[at]) < a0) at++;
      inner.forEach(function (q, i) { var v = { x: 0, y: 0 }; for (var kk in q.spec) v[kk] = q.spec[kk]; L.splice(at + i, 0, v); e.setA(v, q.a); e.setOut(v, q.o); });
    }
    m = L.length - 1;
    prof.forEach(function (q) { if (q.end === 0) e.setOut(L[0], q.o); else if (q.end === 1) e.setOut(L[m], q.o); });
    if (!rising(e)) return 'it does not fit there';
    return null;
  }
  // the same hump at the other end of its edge: mirrored along the edge, the edge's own corners staying where they are.
  // about: mirror about this coordinate instead of the middle of the edge (the flip uses the breadboard's middle, so a hump
  // that stays has its steps exactly where they were)
  function humpOtherEnd(P, key, about) {
    var saved = P.frame.outline; P.frame.outline = saved.map(vclone);
    var E = edgesOf(P), f = findHump(E, key);
    if (!f) { P.frame.outline = saved; return { ok: false, why: 'no such hump' }; }
    var e = f.e, L = e.list, s = about != null ? 2 * about : e.a(L[0]) + e.a(L[L.length - 1]), prof = capture(e, f.h);
    removeOn(e, f.h);
    var why = layOn(e, prof.slice().reverse().map(function (q) { return { a: s - q.a, o: q.o, spec: q.spec, end: q.end == null ? null : 1 - q.end }; }));
    if (why) { P.frame.outline = saved; return { ok: false, why: why }; }
    commit(P, E); return { ok: true };
  }
  // a hump of one side on the other side, at the same height. Where that side is shorter (it ends at the breadboard's corner
  // when there is no strip on it) the hump's lower end is pulled up to fit, its slope kept.
  function humpOtherSide(P, key) {
    var saved = P.frame.outline; P.frame.outline = saved.map(vclone);
    var E = edgesOf(P), f = findHump(E, key);
    function fail(why) { P.frame.outline = saved; return { ok: false, why: why }; }
    if (!f || f.e.axis !== 'y') return fail('only a hump on the left or the right side can change sides');
    var e = f.e, t = E[e.side === 'left' ? 'right' : 'left'], prof = capture(e, f.h), TL = t.list, tm = TL.length - 1, i;
    removeOn(e, f.h);
    var tTop = t.a(TL[0]), tBot = t.a(TL[tm]), endBot = prof.filter(function (q) { return q.end === 1; })[0], hasTop = prof.some(function (q) { return q.end === 0; });
    if (endBot && Math.abs(endBot.a - tBot) > 0.05) return fail('it runs to the bottom corner of its side, and the other side ends at a different height');
    // the stretch of the other side it may use: between that side's corners, less what their own shapes take
    var inner = prof.filter(function (q) { return q.end == null; }), top = -1, bot = -1, omax = 0;
    // (a rounded root needs a little of the edge for itself as well: half its radius)
    var lo = tTop + (hasTop ? 0 : legOf(TL[0], 'y') + 0.2 + (inner.length ? 0.5 * (+inner[0].spec.r || 0) : 0)), hi = tBot - (endBot ? 0 : legOf(TL[tm], 'y') + 0.2 + (inner.length ? 0.5 * (+inner[inner.length - 1].spec.r || 0) : 0));
    prof.forEach(function (q) { omax = Math.max(omax, q.o); });
    for (i = 0; i < inner.length; i++) if (inner[i].o >= omax - 0.01) { if (top < 0) top = i; bot = i; }
    if (inner.length) {
      var over = inner[inner.length - 1].a - hi, under = lo - inner[0].a;
      if (over > 1e-6) for (i = Math.max(0, bot); i < inner.length; i++) inner[i].a -= over;                        // the lower slope, moved up as it is
      if (under > 1e-6) for (i = 0; i <= (top < 0 ? inner.length - 1 : top); i++) inner[i].a += under;             // the upper slope, moved down
      for (i = 1; i < inner.length; i++) if (inner[i].a < inner[i - 1].a - 1e-6) return fail('that side is too short for it');
      if (inner[0].a < lo - 1e-6 || inner[inner.length - 1].a > hi + 1e-6) return fail('that side is too short for it');
    }
    var why = layOn(t, prof);
    if (why) return fail(why);
    commit(P, E); return { ok: true };
  }
  // a new hump in the middle of the longest clear stretch of an edge
  function humpAdd(P, side) {
    var saved = P.frame.outline; P.frame.outline = saved.map(vclone);
    var E = edgesOf(P), e = E[side], best = null, k;
    if (!e || !e.list) { P.frame.outline = saved; return { ok: false, why: 'no such edge' }; }
    var L = e.list, m = L.length - 1;
    for (k = 0; k < m; k++) {
      if (Math.abs(e.out(L[k])) > HUMP_EPS || Math.abs(e.out(L[k + 1])) > HUMP_EPS) continue;
      var a0 = e.a(L[k]) + (k === 0 ? legOf(L[0], e.axis) + 0.3 : 0.3), a1 = e.a(L[k + 1]) - (k + 1 === m ? legOf(L[m], e.axis) + 0.3 : 0.3);
      if (!best || a1 - a0 > best.a1 - best.a0) best = { a0: a0, a1: a1 };
    }
    if (!best || best.a1 - best.a0 < 6) { P.frame.outline = saved; return { ok: false, why: 'there is no clear stretch of at least 6 mm on that edge' }; }
    var len = Math.min(14, (best.a1 - best.a0) * 0.6), mid = (best.a0 + best.a1) / 2, out = 1.5, run = 1.5;
    var why = layOn(e, [{ a: mid - len / 2, o: 0, spec: { r: 0.8 }, end: null }, { a: mid - len / 2 + run, o: out, spec: { r: 0.8 }, end: null }, { a: mid + len / 2 - run, o: out, spec: { r: 0.8 }, end: null }, { a: mid + len / 2, o: 0, spec: { r: 0.8 }, end: null }]);
    if (why) { P.frame.outline = saved; return { ok: false, why: why }; }
    commit(P, E); return { ok: true };
  }

  // ---- the flip ----
  // A part the other way round. A real part cannot be mirrored, so it is turned instead: about the axis its mouth lies on
  // when the catalogue says where its mouth is, otherwise about whichever axis its plan is more nearly symmetric on. Its
  // plan's middle goes to the mirror image of where it was.
  function mirrorTurn(polys, mouth, x, y, rot, bottom, W) {
    var A = region(polys), b = bbox(A), cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2, axis;
    rot = +rot || 0;
    if (mouth) axis = Math.abs(mouth[0]) > Math.abs(mouth[1]) ? 'y' : 'x';
    else {
      var kx = Math.round(2 * cx * SC), ky = Math.round(2 * cy * SC);
      var Ax = A.map(function (p) { return p.map(function (q) { return { X: kx - q.X, Y: q.Y }; }).reverse(); }), Ay = A.map(function (p) { return p.map(function (q) { return { X: q.X, Y: ky - q.Y }; }).reverse(); });
      axis = area(exec(CT.ctXor, A, Ax)) <= area(exec(CT.ctXor, A, Ay)) + 0.01 ? 'x' : 'y';
    }
    // axis 'x': the plan is its own mirror image left to right, so the turn is -rot. 'y': top to bottom, so 180 - rot.
    var rot2 = (((axis === 'x' ? -rot : 180 - rot) % 360) + 360) % 360;
    var was = place([[cx, cy]], +x, +y, rot, bottom)[0], off = place([[cx, cy]], 0, 0, rot2, bottom)[0];
    return { x: r4(W - was[0] - off[0]), y: r4(was[1] - off[1]), rot: rot2, axis: axis };
  }
  function partMirror(u, W, ctx) {
    var cat = Catalog.get ? Catalog.get(u, ctx || {}) : Catalog.parts[u.type], rot = +u.rot || 0, bottom = !!(u.mount && u.mount.side === 'bottom');
    if (!cat || !cat.bodies || !cat.bodies.length) return { x: r4(W - u.x), y: u.y, rot: ((-rot % 360) + 360) % 360, axis: 'x' };
    var polys = cat.bodies.concat(cat.ghosts || []).map(function (b) { return shapePts(b.shape); });
    var fpx = cat.fp && Catalog.footprints && Catalog.footprints[cat.fp];
    if (fpx && fpx.pads) fpx.pads.forEach(function (pd) { polys.push(rectPts(pd.x - pd.w / 2, pd.y - pd.h / 2, pd.x + pd.w / 2, pd.y + pd.h / 2)); });
    return mirrorTurn(polys, cat.mouth, u.x, u.y, rot, bottom, W);
  }
  // what a part does when the board is flipped, unless it says otherwise (part.on_flip): a USB socket and a click wheel stay
  // on their own side, in their corner; everything else goes with the board.
  function flipMode(u) {
    if (u.on_flip === 'flip' || u.on_flip === 'stay' || u.on_flip === 'corner') return u.on_flip;
    var c = Catalog.parts && Catalog.parts[u.type];
    return /^usb/i.test(u.type) || (c && c.group === 'wheel') ? 'corner' : 'flip';
  }
  function swapLR(t) { return String(t).replace(/\b(left|right|Left|Right)\b/g, function (w) { return { left: 'right', right: 'left', Left: 'Right', Right: 'Left' }[w]; }); }
  // Flip the design left to right about the breadboard's middle: the strip and the probe's dock change sides, and the extender
  // with them. opt: { parts: { id: 'flip' | 'stay' | 'corner' } (else flipMode), humps: { key: 'stay' } (else they flip),
  // corners: 'stay' | 'flip', mag: false to leave the magnetometers, ctx: for the catalogue }.
  //   flip    the part goes to the mirror image of its place, turned to face the mirrored way
  //   corner  it stays on its own side and keeps its place measured from that side's top corner of the outline
  //   stay    it is not touched
  // A hump that stays keeps its side and its size: one on the top edge has its steps where they were (and still runs to the
  // corner if it did), one on a side is at the same height on the same side, against whatever plane is there now.
  // corners: 'stay' leaves each top corner's own shape (chamfer, radius) on its side. Flipping twice with the same choices
  // gives the design back.
  function ctxOf(P) {
    var layers = [];
    (P.stack || []).forEach(function (L, i) { var z0 = i === 0 ? -L.t : layers[i - 1].z1 + (L.gap || 0); layers.push({ id: L.id, name: L.name, t: L.t, z0: z0, z1: z0 + L.t, index: i }); });
    return layers.length ? { zBot: layers[0].z0, zTop: layers[layers.length - 1].z1, layers: layers } : {};
  }
  function flip(P, opt) {
    opt = opt || {};
    var S = sideInfo(P), W = S.W, f = P.frame, before = edgesOf(P), hb = humps(P), ctx = opt.ctx || ctxOf(P);
    var TL0 = before.top.list[0], TR0 = before.top.list[before.top.list.length - 1], c0 = { TL: [TL0.x, TL0.y], TR: [TR0.x, TR0.y] };
    function mirrorVerts(list) { return normalise(list.map(function (v) { var o = vclone(v); o.x = r4(W - v.x); if (o.n) o.n = swapLR(o.n); return o; }).reverse()); }
    f.outline = mirrorVerts(f.outline);
    if (f.outline_drawn) f.outline_drawn = mirrorVerts(f.outline_drawn);
    f.side = S.mir ? 'left' : 'right';
    var report = { side: f.side, humps: [], kept: {}, parts: [], notes: [] };
    // humps that stay: after the mirror each is on the other end or the other side; bring it back. The sides first, because
    // a block on a side takes the top corner out with it, and the top edge's humps are then set against the corners as they end up.
    hb.slice().sort(function (a, b) { return (a.side === 'top' ? 1 : 0) - (b.side === 'top' ? 1 : 0); }).forEach(function (h) {
      if (!opt.humps || opt.humps[h.key] !== 'stay') return;
      // found again by its size and by either of its ends (a corner end moves when another hump on that corner has moved)
      var now = humps(P), want = h.side === 'top' ? 'top' : (h.side === 'left' ? 'right' : 'left'), a0 = h.side === 'top' ? W - h.a1 : h.a0, a1 = h.side === 'top' ? W - h.a0 : h.a1, hit = null;
      now.forEach(function (q) { if (!hit && q.side === want && Math.abs(q.out - h.out) < 0.02 && ((!q.end0 && Math.abs(q.a0 - a0) < 0.02) || (!q.end1 && Math.abs(q.a1 - a1) < 0.02) || (q.end0 && q.end1))) hit = q; });
      if (!hit) { report.notes.push('The hump "' + h.label + '" was not found after the flip and went with the board.'); return; }
      var res = h.side === 'top' ? humpOtherEnd(P, hit.key, W / 2) : humpOtherSide(P, hit.key);
      if (!res.ok) report.notes.push('The hump "' + h.label + '" could not stay on its side (' + res.why + ') and went with the board.');
      else report.humps.push(h.key);        // a hump that stayed is again the one it was: same edge, same place in it
    });
    var after = edgesOf(P), TL1 = after.top.list[0], TR1 = after.top.list[after.top.list.length - 1];
    if (opt.corners === 'stay') ['c', 'r', 'n'].forEach(function (k) { var a = TL1[k], b = TR1[k]; if (b === undefined) delete TL1[k]; else TL1[k] = b; if (a === undefined) delete TR1[k]; else TR1[k] = a; });
    P.frame.outline = after.join();
    var c1 = { TL: [TL1.x, TL1.y], TR: [TR1.x, TR1.y] };
    (P.parts || []).forEach(function (u) {
      var mode = (opt.parts && opt.parts[u.id]) || flipMode(u);
      if (mode === 'stay') { report.parts.push({ id: u.id, mode: mode }); return; }
      if (mode === 'corner') {
        var k = Math.hypot(u.x - c0.TL[0], u.y - c0.TL[1]) <= Math.hypot(u.x - c0.TR[0], u.y - c0.TR[1]) ? 'TL' : 'TR';
        u.x = r4(u.x + c1[k][0] - c0[k][0]); u.y = r4(u.y + c1[k][1] - c0[k][1]);
        report.parts.push({ id: u.id, mode: mode, corner: k });
        return;
      }
      var m = partMirror(u, W, ctx);
      u.x = m.x; u.y = m.y; u.rot = m.rot;
      if (u.tongue && u.tongue.dir != null) u.tongue.dir = (((m.axis === 'x' ? 180 - u.tongue.dir : -u.tongue.dir) % 360) + 360) % 360;
      report.parts.push({ id: u.id, mode: 'flip', axis: m.axis });
    });
    if (P.probe && P.probe.dock && P.probe.dock.x != null) P.probe.dock.x = r4(W - P.probe.dock.x);
    if (opt.mag !== false && P.mag && P.mag.list) P.mag.list.forEach(function (q) { q.x = r4(W - q.x); });
    (P.features || []).forEach(function (ft) { ft.x = r4(W - ft.x); if (ft.rot) ft.rot = ((-ft.rot % 360) + 360) % 360; });
    // the humps that stayed, under the names they have now (a name is the edge and the place in it)
    var nowAll = humps(P);
    hb.forEach(function (h) { if (report.humps.indexOf(h.key) < 0) return; nowAll.forEach(function (q) { if (q.side === h.side && Math.abs(q.out - h.out) < 0.02 && (Math.abs(q.a0 - h.a0) < 6 || Math.abs(q.a1 - h.a1) < 6 || q.end0 === h.end0 && q.end1 === h.end1)) report.kept[q.key] = true; }); });
    return report;
  }
  var ops = { sideInfo: sideInfo, normalise: normalise, edges: edgesOf, humps: humps, humpSet: humpSet, humpRemove: humpRemove, humpOtherEnd: humpOtherEnd, humpOtherSide: humpOtherSide, humpAdd: humpAdd, partMirror: partMirror, flipMode: flipMode, flip: flip };

  return { resolve: resolve, plain: plain, buildOutline: buildOutline, legacyOutline: legacyOutline, ops: ops, util: { region: region, union: union, diff: diff, inter: inter, offset: offset, area: area, expolys: expolys, place: place, rectPts: rectPts, circlePts: circlePts, round: round } };
});
