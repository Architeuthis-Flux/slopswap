// Jumperless V6 outline tool - the magnetometer layout model.
// Where the probe tracker's sensors sit (params.mag.list), and how well a layout places the probe's magnet at every
// breadboard hole. Runs unchanged in the browser (the Magnetometers tab) and in Node (build.mjs, tools/magcheck.mjs).
//
// The model is Testolomew's (src/magfit/MagFit.h): a point dipole, positions in mm, fields in mT, the moment in
// mT*mm^3, B = 3 r (m.r) / r^5 - m / r^3. The fit holds the magnet's strength, so it has five unknowns (where the
// magnet is, and which way it points); the strength can be freed (six) and a uniform ambient field added (three more).
// What is reported is the error bound of that fit (Cramer-Rao): the square root of the x, y part of (J^T W J)^-1,
// rms over the probe standing upright and leaning four ways. Each reading's error is taken as
//     noise^2 + zero^2 + (gain * |B|)^2
// which is how the 2026-11-01 bench describes an MMC5603NJ (0.3 to 0.45 uT a sample, a zero good to about 1 uT, gain,
// turn and place good to about 1 %). A reading past 0.95 of full scale on any axis takes the part out of the fit.
// It is a floor: Testolomew's own fit, run on the arrangements below (V6pile/maglayout's harness), comes out 1.3 to 1.5
// times it at the median hole and two to three times at the worst with the bench magnet, about twice it with a 2 x 1 mm one.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.V6Mag = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  // range mT, noise mT a reading, die: how far the sensing element is from the board face, body: plan size and height
  var KINDS = {
    mmc: { name: 'MMC5603', range: 3, noise: 0.0004, die: 0.2, w: 0.8, h: 0.4 },
    tmag: { name: 'TMAG5273', range: 40, noise: 0.012, die: 0.55, w: 2.9, h: 1.1 }
  };
  var SATURATED = 0.95, HALF_PITCH = 1.27, AMBIENT_STEP = 0.010;      // the ambient change the "shift" map shows: 10 uT
  var MAGNETS = [                                                      // strengths in mT*mm^3
    { id: 'bench', label: 'Bench probe, measured', strength: 1900 },
    { id: 'probe', label: 'As drawn in the dock', strength: null },
    { id: 'n42_3x6', label: '3 x 6 mm N42', strength: 4390 },
    { id: 'clip', label: 'Clip magnet, measured', strength: 16000 },
    { id: 'other', label: 'Other', strength: null }
  ];
  function round(v, n) { var k = Math.pow(10, n == null ? 3 : n); return Math.round(v * k) / k; }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  // a cylinder magnet's moment in mT*mm^3: Br * V / 4 pi (115.4 per mm^3 at 1.45 T, the convention in wireless-probe-sensing.md)
  function cylinderStrength(dia, len, brT) { return (brT || 1.45) * 1000 * Math.PI * dia * dia / 4 * len / (4 * Math.PI); }
  function strengthOf(P) {
    var m = (P.mag && P.mag.magnet) || {}, pm = (P.probe && P.probe.magnet) || { dia: 2, len: 1 };
    if (m.use === 'probe') return cylinderStrength(pm.dia, pm.len);
    for (var i = 0; i < MAGNETS.length; i++) if (MAGNETS[i].id === m.use && MAGNETS[i].strength) return MAGNETS[i].strength;
    return Math.max(1, +m.strength || 1900);
  }
  function settings(P) {
    var g = P.mag || {};
    return { strength: strengthOf(P), height: g.height != null ? +g.height : 2, lean: g.lean != null ? +g.lean : 25,
      noise: (g.noise_uT != null ? +g.noise_uT : 0.4) / 1000, zero: (g.zero_uT != null ? +g.zero_uT : 1) / 1000, gain: (g.gain_pct != null ? +g.gain_pct : 1) / 100,
      uniform: g.ambient === 'fitted', free: g.hold_strength === false };
  }

  // ---------- plan geometry on the resolved model's plain data ----------
  function inPoly(pts, x, y) {
    var c = false;
    for (var i = 0, j = pts.length - 1; i < pts.length; j = i++) {
      var a = pts[i], b = pts[j];
      if ((a[1] > y) !== (b[1] > y) && x < (b[0] - a[0]) * (y - a[1]) / (b[1] - a[1]) + a[0]) c = !c;
    }
    return c;
  }
  function inShape(shape, x, y) {            // shape: [{ outer, holes }]
    for (var i = 0; i < shape.length; i++) {
      if (!inPoly(shape[i].outer, x, y)) continue;
      var hole = false;
      for (var k = 0; k < shape[i].holes.length; k++) if (inPoly(shape[i].holes[k], x, y)) { hole = true; break; }
      if (!hole) return true;
    }
    return false;
  }
  function inWig(R, x, y) { return inPoly(R.wig.outline, x, y); }
  function layerOf(R, id) { for (var i = 0; i < R.layers.length; i++) if (R.layers[i].id === id) return R.layers[i]; return null; }
  // the face a sensor sits on: z of the face, which way the part stands off it, and the die's z
  function faceOf(R, s) {
    var k = KINDS[s.kind] || KINDS.mmc, top = s.side !== 'bottom', L = s.on === 'wig' ? null : layerOf(R, s.on);
    var z1 = L ? L.z1 : 0, z0 = L ? L.z0 : -(R.removable ? R.wig.pcb_t : R.layers[0].t);
    return { z: top ? z1 : z0, dir: top ? 1 : -1, zDie: round(top ? z1 + k.die : z0 - k.die), layer: L };
  }
  // every sensor of the list with its z and what is wrong with where it sits
  function place(R, list) {
    return (list || []).map(function (s, i) {
      var k = KINDS[s.kind] || KINDS.mmc, f = faceOf(R, s), o = { i: i, ref: s.ref || ((s.kind === 'tmag' ? 'T' : 'M') + (i + 1)), x: +s.x, y: +s.y, z: f.zDie, kind: KINDS[s.kind] ? s.kind : 'mmc', on: s.on, side: s.side === 'bottom' ? 'bottom' : 'top' };
      o.bb = inWig(R, o.x, o.y);                             // under the breadboard, whichever board carries it
      o.board = s.on === 'wig' ? (R.removable ? 'wig PCB' : R.layers[0].id + ' ' + R.layers[0].name + ', under the breadboard') : (f.layer ? f.layer.id + ' ' + f.layer.name : 'no such board');
      var e = k.w / 2 + 0.2, pts = [[o.x - e, o.y - e], [o.x + e, o.y - e], [o.x + e, o.y + e], [o.x - e, o.y + e], [o.x, o.y]];
      var on = s.on === 'wig' ? function (q) { return inWig(R, q[0], q[1]) && (R.removable || inShape(R.layers[0].shape, q[0], q[1])); } : function (q) { return !!f.layer && inShape(f.layer.shape, q[0], q[1]); };
      o.off = !pts.every(on);
      o.under = null;                                        // a part that stands on the same face over the same spot
      var a = Math.min(f.z, f.z + f.dir * k.h), b = Math.max(f.z, f.z + f.dir * k.h);
      (R.parts || []).forEach(function (p) {
        if (o.under || p.id === 'wig_pcb' || (p.id === 'shell' && s.on === 'wig' && f.dir > 0 && k.h <= 0.6)) return;      // a low part fits in the shell's own pockets, as on the WigLEDmag
        p.bodies.forEach(function (body) { if (!o.under && body.z1 > a + 0.02 && body.z0 < b - 0.02 && pts.some(function (q) { return inPoly(body.pts, q[0], q[1]); })) o.under = p.label || p.id; });
      });
      return o;
    });
  }
  // the legacy fixed layouts as lists, so an old file's choice can be turned into a list to edit
  function legacyList(R, ref, name) {
    var out = [];
    if (name === 'plan18' || name === 'plan32') return gridList(R, name === 'plan18' ? 3 : 4, name === 'plan18' ? 6 : 8);
    (ref.mmc || []).forEach(function (s) { out.push({ x: s.x, y: s.y, on: 'wig', side: s.side === 'F' ? 'top' : 'bottom', kind: 'mmc', ref: s.ref }); });
    (ref.tmag || []).forEach(function (s) { out.push({ x: s.x, y: s.y, on: 'wig', side: s.side === 'F' ? 'top' : 'bottom', kind: 'tmag', ref: s.ref }); });
    return out;
  }
  function gridList(R, ny, nx) {             // spread evenly over the 76 x 45 hole field, on the underside
    var rows = R.wig.rows, fw = 76, fh = 45, fx0 = R.wig.w / 2 - fw / 2, fy0 = (rows[0] + rows[rows.length - 1]) / 2 - fh / 2, out = [];
    for (var gy = 0; gy < ny; gy++) for (var gx = 0; gx < nx; gx++) out.push({ x: round(fx0 + (gx + 0.5) * fw / nx, 2), y: round(fy0 + (gy + 0.5) * fh / ny, 2), on: 'wig', side: 'bottom', kind: 'mmc' });
    return out;
  }

  // ---------- the field and the bound ----------
  // field (mT) at r = sensor - magnet from moment m; out[0..2]
  function field(rx, ry, rz, mx, my, mz, out) {
    var r2 = rx * rx + ry * ry + rz * rz, r = Math.sqrt(r2), r5 = r2 * r2 * r, d = 3 * (rx * mx + ry * my + rz * mz) / r5, k = 1 / (r2 * r);
    out[0] = rx * d - mx * k; out[1] = ry * d - my * k; out[2] = rz * d - mz * k;
  }
  var _B = [0, 0, 0], _G = [0, 0, 0, 0, 0, 0, 0, 0, 0], _a = [0, 0, 0], _b = [0, 0, 0], _s = [0, 0, 0];
  // dB_i/dr_j into G[3 * i + j]; dB/d(magnet position) is its negative
  function gradient(rx, ry, rz, mx, my, mz, G) {
    var r2 = rx * rx + ry * ry + rz * rz, r = Math.sqrt(r2), r5 = r2 * r2 * r, r7 = r5 * r2, md = rx * mx + ry * my + rz * mz, rr = [rx, ry, rz], mm = [mx, my, mz];
    for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++)
      G[3 * i + j] = (i === j ? 3 * md / r5 : 0) + 3 * (rr[i] * mm[j] + mm[i] * rr[j]) / r5 - 15 * rr[i] * rr[j] * md / r7;
  }
  function invert(A, n) {                    // Gauss-Jordan in place on a copy; null if singular
    var M = [], i, j, c, r;
    for (i = 0; i < n; i++) { M.push(new Float64Array(2 * n)); for (j = 0; j < n; j++) M[i][j] = A[i * n + j]; M[i][n + i] = 1; }
    for (c = 0; c < n; c++) {
      var p = c; for (r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
      if (!(Math.abs(M[p][c]) > 1e-300)) return null;
      var t = M[c]; M[c] = M[p]; M[p] = t;
      var d = M[c][c]; for (j = 0; j < 2 * n; j++) M[c][j] /= d;
      for (r = 0; r < n; r++) { if (r === c) continue; var f = M[r][c]; if (!f) continue; for (j = 0; j < 2 * n; j++) M[r][j] -= f * M[c][j]; }
    }
    return M;                                // the inverse is columns n .. 2n-1
  }
  // The bound for the magnet at (px, py, pz) with unit direction v. sens: [{x, y, z, range, noise}].
  // Returns { xy: mm or Infinity, used, sat, shift: mm the fix moves for a 10 uT uniform step the fit is not told of }.
  function boundAt(sens, px, py, pz, vx, vy, vz, o) {
    var S = o.strength, n = 5 + (o.free ? 1 : 0) + (o.uniform ? 3 : 0), F = new Float64Array(n * n), used = 0, sat = 0, i, j, k, a, q;
    // two unit vectors across v: the direction's two free steps
    if (Math.abs(vx) < 0.9) { _a[0] = 0; _a[1] = vz; _a[2] = -vy; } else { _a[0] = -vz; _a[1] = 0; _a[2] = vx; }
    var al = Math.sqrt(_a[0] * _a[0] + _a[1] * _a[1] + _a[2] * _a[2]); _a[0] /= al; _a[1] /= al; _a[2] /= al;
    _b[0] = vy * _a[2] - vz * _a[1]; _b[1] = vz * _a[0] - vx * _a[2]; _b[2] = vx * _a[1] - vy * _a[0];
    var J = new Float64Array(3 * n), T = o.uniform ? null : new Float64Array(3 * n);       // T: J^T W e_k summed, for the ambient shift
    for (q = 0; q < sens.length; q++) {
      var s = sens[q], rx = s.x - px, ry = s.y - py, rz = s.z - pz, lim = SATURATED * s.range;
      field(rx, ry, rz, S * vx, S * vy, S * vz, _B);
      if (Math.abs(_B[0]) >= lim || Math.abs(_B[1]) >= lim || Math.abs(_B[2]) >= lim) { sat++; continue; }
      used++;
      var bm2 = _B[0] * _B[0] + _B[1] * _B[1] + _B[2] * _B[2], w = 1 / (s.noise * s.noise + o.zero * o.zero + o.gain * o.gain * bm2);
      gradient(rx, ry, rz, S * vx, S * vy, S * vz, _G);
      for (a = 0; a < 3; a++) { J[a * n] = -_G[3 * a]; J[a * n + 1] = -_G[3 * a + 1]; J[a * n + 2] = -_G[3 * a + 2]; }
      field(rx, ry, rz, S * _a[0], S * _a[1], S * _a[2], _s); for (a = 0; a < 3; a++) J[a * n + 3] = _s[a];
      field(rx, ry, rz, S * _b[0], S * _b[1], S * _b[2], _s); for (a = 0; a < 3; a++) J[a * n + 4] = _s[a];
      k = 5;
      if (o.free) { for (a = 0; a < 3; a++) J[a * n + k] = _B[a] / S; k++; }
      if (o.uniform) for (a = 0; a < 3; a++) for (j = 0; j < 3; j++) J[a * n + k + j] = a === j ? 1 : 0;
      for (a = 0; a < 3; a++) for (i = 0; i < n; i++) { var ji = J[a * n + i] * w; if (!ji) continue; for (j = i; j < n; j++) F[i * n + j] += ji * J[a * n + j]; if (T) T[a * n + i] += ji; }
    }
    if (3 * used < n + 1) return { xy: Infinity, used: used, sat: sat, shift: Infinity };
    for (i = 0; i < n; i++) for (j = 0; j < i; j++) F[i * n + j] = F[j * n + i];
    var M = invert(F, n);
    if (!M) return { xy: Infinity, used: used, sat: sat, shift: Infinity };
    var v = M[0][n] + M[1][n + 1], shift = 0;
    if (T) for (a = 0; a < 3; a++) {         // the step for a uniform change along axis a: C J^T W e_a * 10 uT; the worst axis is kept
      var sx = 0, sy = 0; for (i = 0; i < n; i++) { sx += M[0][n + i] * T[a * n + i]; sy += M[1][n + i] * T[a * n + i]; }
      var d = Math.sqrt(sx * sx + sy * sy) * AMBIENT_STEP; if (d > shift) shift = d;
    }
    return { xy: v > 0 ? Math.sqrt(v) : Infinity, used: used, sat: sat, shift: shift };
  }
  function orientations(leanDeg, quick) {
    var t = leanDeg * Math.PI / 180, s = Math.sin(t), c = Math.cos(t), o = [[0, 0, 1]];
    if (leanDeg > 0.5) { o.push([s, 0, c], [0, s, c]); if (!quick) o.push([-s, 0, c], [0, -s, c]); }
    return o;
  }
  function sensorsFor(placed) { return placed.map(function (p) { var k = KINDS[p.kind] || KINDS.mmc; return { x: p.x, y: p.y, z: p.z, range: k.range, noise: k.noise }; }); }
  // every hole: err (mm), shift (mm), used (fewest sensors in range over the orientations). opts.step > 1 takes every step-th column.
  function evaluate(R, placed, st, opts) {
    opts = opts || {};
    var cols = R.wig.cols, rows = R.wig.rows, nx = cols.length, ny = rows.length, n = nx * ny, sens = sensorsFor(placed), or = orientations(st.lean, opts.quick), step = opts.step || 1;
    var err = new Float64Array(n), shift = new Float64Array(n), used = new Int16Array(n), z = R.z.bbTop + st.height;
    var o = { strength: st.strength, zero: st.zero, gain: st.gain, free: st.free, uniform: st.uniform };
    for (var iy = 0; iy < ny; iy++) for (var ix = 0; ix < nx; ix++) {
      var h = iy * nx + ix;
      if (step > 1 && ix % step) { err[h] = NaN; shift[h] = NaN; used[h] = -1; continue; }
      var e2 = 0, s2 = 0, u = 999, bad = false;
      for (var k = 0; k < or.length; k++) {
        var b = boundAt(sens, cols[ix], rows[iy], z, or[k][0], or[k][1], or[k][2], o);
        if (b.used < u) u = b.used;
        if (!isFinite(b.xy)) { bad = true; break; }
        e2 += b.xy * b.xy; s2 += b.shift * b.shift;
      }
      err[h] = bad ? Infinity : Math.sqrt(e2 / or.length); shift[h] = bad ? Infinity : Math.sqrt(s2 / or.length); used[h] = u === 999 ? 0 : u;
    }
    return { err: err, shift: shift, used: used, nx: nx, ny: ny, n: n };
  }
  function stats(a) {
    var f = [], worst = -1, at = -1, ok = 0, nofix = 0, count = 0, i;
    for (i = 0; i < a.length; i++) { var v = a[i]; if (v !== v) continue; count++; if (!isFinite(v)) { nofix++; if (worst !== Infinity) { worst = Infinity; at = i; } continue; } f.push(v); if (v < HALF_PITCH) ok++; if (v > worst) { worst = v; at = i; } }
    f.sort(function (x, y) { return x - y; });
    function pct(p) { if (!f.length) return Infinity; var k = (f.length - 1) * p, lo = Math.floor(k), hi = Math.ceil(k); return f[lo] + (f[hi] - f[lo]) * (k - lo); }
    var sq = 0; for (i = 0; i < f.length; i++) sq += Math.min(f[i], 50) * Math.min(f[i], 50);
    return { count: count, ok: ok, nofix: nofix, median: nofix > count / 2 ? Infinity : pct(0.5), p90: nofix > count / 10 ? Infinity : pct(0.9), worst: worst, at: at, rms: Math.sqrt((sq + nofix * 2500) / Math.max(1, count)) };
  }
  // the whole reading of a layout: per-hole arrays and the numbers on them
  function summary(R, list, P, opts) {
    var placed = place(R, list), st = settings(P), ev = evaluate(R, placed, st, opts), s = stats(ev.err), sh = stats(ev.shift);
    var nb = 0; placed.forEach(function (p) { if (p.bb) nb++; });
    return { placed: placed, ev: ev, st: st, stats: s, shift: st.uniform ? null : sh, n: placed.length, on_bb: nb, on_frame: placed.length - nb,
      worst_hole: s.at >= 0 ? { col: s.at % ev.nx + 1, row: Math.floor(s.at / ev.nx) + 1 } : null };
  }
  // the docked probe's field at each sensor (mT, the largest axis), its magnet lying along y in the dock
  function docked(R, placed, strength) {
    if (!R.probe || !R.probe.magnet) return [];
    var m = R.probe.magnet, out = [];
    placed.forEach(function (p) { field(p.x - m.x, p.y - m.y, p.z - m.z, 0, strength, 0, _B); var b = Math.max(Math.abs(_B[0]), Math.abs(_B[1]), Math.abs(_B[2])), k = KINDS[p.kind]; out.push({ ref: p.ref, B: b, sat: b >= SATURATED * k.range }); });
    return out;
  }

  // what the check report says about the layout
  function report(R, P, opts) {
    var list = R.wig.sensors.list || [], s = summary(R, list, P, opts), st = s.stats, f = function (v) { return isFinite(v) ? round(v, 2) : null; };
    var dk = docked(R, s.placed, s.st.strength).filter(function (d) { return d.sat; }).map(function (d) { return d.ref; });
    return { n: s.n, on_bb: s.on_bb, on_frame: s.on_frame, strength: Math.round(s.st.strength), height: s.st.height, median: f(st.median), p90: f(st.p90), worst: f(st.worst), ok: st.ok, holes: st.count, nofix: st.nofix,
      worst_hole: s.worst_hole, ambient: s.st.uniform ? 'fitted' : 'zeroed', shift_median: s.shift ? f(s.shift.median) : null, shift_worst: s.shift ? f(s.shift.worst) : null,
      off: s.placed.filter(function (p) { return p.off; }).map(function (p) { return p.ref; }), under: s.placed.filter(function (p) { return p.under; }).map(function (p) { return p.ref + ' (' + p.under + ')'; }), docked_saturated: dk };
  }

  // ---------- arrangements to load and compare ----------
  // Positions are in the unit's own frame (x from the wig's left edge, y down from its top edge). The frame sensors sit on
  // the bottom board's underside (the top band's row at y = -6 clears the wig's card edge), the breadboard ones on the underside
  // of the board under the breadboard. The mixed ones were laid out by hand; improve() moves them by under a millimetre's worth of error.
  function arrangements(R, ref) {
    var L0 = R.layers[0].id;
    function fr(a) { return a.map(function (q) { return { x: q[0], y: q[1], on: L0, side: 'bottom', kind: 'mmc' }; }); }
    function bb(a) { return a.map(function (q) { return { x: q[0], y: q[1], on: 'wig', side: 'bottom', kind: 'mmc' }; }); }
    var A = PRESET_POINTS, out = [];
    out.push({ id: 'b6f6', label: '6 under + 6 on the frame', list: bb(A.b6f6.bb).concat(fr(A.b6f6.fr)) });
    out.push({ id: 'b6f3', label: '6 under + 3 on the frame', list: bb(A.b6f3.bb).concat(fr(A.b6f3.fr)) });
    out.push({ id: 'b4f8', label: '4 under + 8 on the frame', list: bb(A.b4f8.bb).concat(fr(A.b4f8.fr)) });
    out.push({ id: 'b3f9', label: '3 under + 9 on the frame', list: bb(A.b3f9.bb).concat(fr(A.b3f9.fr)) });
    out.push({ id: 'f12', label: 'Frame only: 8 top + 4 left', list: fr(A.f12.fr) });
    out.push({ id: 'b12', label: '12 under, 3 x 4', list: gridList(R, 3, 4) });
    out.push({ id: 'plan18', label: '18 under, 3 x 6 (the earlier plan)', list: gridList(R, 3, 6) });
    out.push({ id: 'wigledmag', label: 'WigLEDmag as built: 8 MMC + 9 TMAG', list: legacyList(R, ref || {}, 'wigledmag') });
    return out;
  }
  var PRESET_POINTS = {
    b6f6: { bb: [[26, 24], [52, 24], [72, 14], [14, 46], [42, 46], [70, 44]], fr: [[10, -6], [32, -6], [54, -6], [76, -6], [-2.54, 16], [-2.54, 38]] },
    b6f3: { bb: [[20, 20], [50, 16], [72, 22], [14, 45], [42, 45], [70, 46]], fr: [[20, -6], [58, -6], [-2.54, 30]] },
    b4f8: { bb: [[38, 28], [70, 26], [24, 47], [60, 47]], fr: [[5, -6], [23, -6], [41, -6], [59, -6], [76, -6], [-2.54, 13], [-2.54, 30], [-2.54, 48]] },
    b3f9: { bb: [[70, 26], [30, 45], [66, 47]], fr: [[5, -6], [20, -6], [35, -6], [50, -6], [64, -6], [76, -6], [-2.54, 13], [-2.54, 30], [-2.54, 48]] },
    f12: { fr: [[2, -6], [12.6, -6], [23.1, -6], [33.7, -6], [44.3, -6], [54.9, -6], [65.4, -6], [76, -6], [-2.54, 8], [-2.54, 21.3], [-2.54, 34.7], [-2.54, 48]] }
  };

  // ---------- improve: nudge the sensors toward a lower rms error, each kept on its own board ----------
  // One pass tries every sensor at eight points `step` mm away and keeps a move that lowers the score (the rms error over
  // every third column of holes, plus a quarter of the worst of them). allowed(sensor, x, y) says whether it may sit there. Returns { list, score, moved }.
  function score(R, list, P) { var s = stats(evaluate(R, place(R, list), settings(P), { step: 3, quick: true }).err); return s.rms + 0.25 * Math.min(50, s.worst); }       // the rms, and a quarter of the worst hole so one corner is not traded away
  function allowedAt(R, list, i, x, y) {
    var s = clone(list[i]); s.x = x; s.y = y;
    var p = place(R, [s])[0];
    if (p.off || p.under) return false;
    if ((list[i].on === 'wig') !== p.bb) return false;                    // a breadboard sensor stays under the breadboard, a frame sensor on the frame
    for (var k = 0; k < list.length; k++) if (k !== i && Math.abs(list[k].x - x) < 3 && Math.abs(list[k].y - y) < 3) return false;
    return true;
  }
  function improvePass(R, list, P, step, from) {
    var best = from != null ? from : score(R, list, P), moved = 0, dirs = [[1, 0], [-1, 0], [0, 1], [0, -1], [0.7, 0.7], [-0.7, 0.7], [0.7, -0.7], [-0.7, -0.7]];
    list = clone(list);
    for (var i = 0; i < list.length; i++) {
      var x0 = list[i].x, y0 = list[i].y, bx = x0, by = y0;
      for (var d = 0; d < dirs.length; d++) {
        var x = round(x0 + dirs[d][0] * step, 2), y = round(y0 + dirs[d][1] * step, 2);
        if (!allowedAt(R, list, i, x, y)) continue;
        list[i].x = x; list[i].y = y;
        var sc = score(R, list, P);
        if (sc < best - 1e-6) { best = sc; bx = x; by = y; }
      }
      list[i].x = bx; list[i].y = by;
      if (bx !== x0 || by !== y0) moved++;
    }
    return { list: list, score: best, moved: moved };
  }

  return { KINDS: KINDS, MAGNETS: MAGNETS, HALF_PITCH: HALF_PITCH, AMBIENT_STEP: AMBIENT_STEP, cylinderStrength: cylinderStrength, strengthOf: strengthOf, settings: settings, place: place, faceOf: faceOf, inWig: inWig, inPoly: inPoly, inShape: inShape,
    legacyList: legacyList, gridList: gridList, report: report, boundAt: boundAt, orientations: orientations, evaluate: evaluate, stats: stats, summary: summary, docked: docked, arrangements: arrangements, PRESET_POINTS: PRESET_POINTS,
    score: score, allowedAt: allowedAt, improvePass: improvePass, sensorsFor: sensorsFor };
});
