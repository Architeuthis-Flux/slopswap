// Jumperless V6 outline tool - file writers. Each takes the resolved model (V6Geo.resolve) and returns text.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.V6Export = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var OX = 100, OY = 100;             // where the datum (wig top-left) lands on the KiCad sheet, same in every file
  function n(v) { return (Math.round(v * 10000) / 10000).toString(); }
  function slug(L) { return L.id + '_' + L.name.replace(/[^A-Za-z0-9]+/g, '_').replace(/^_|_$/g, ''); }
  function uuid(seed) {               // stable pseudo-uuid so regenerated files diff cleanly
    var h = [0x811c9dc5, 0x01000193, 0xdeadbeef, 0x9e3779b9];
    for (var i = 0; i < seed.length; i++) for (var k = 0; k < 4; k++) { h[k] ^= seed.charCodeAt(i) + k * 131; h[k] = Math.imul(h[k], 16777619) >>> 0; }
    var s = h.map(function (v) { return ('00000000' + v.toString(16)).slice(-8); }).join('');
    return s.slice(0, 8) + '-' + s.slice(8, 12) + '-4' + s.slice(13, 16) + '-a' + s.slice(17, 20) + '-' + s.slice(20, 32);
  }
  function loops(L) { var a = []; L.shape.forEach(function (e) { a.push(e.outer); e.holes.forEach(function (h) { a.push(h); }); }); return a; }

  // ---- DXF (R12 ASCII, mm, y up). One closed polyline per outline loop on layer Edge.Cuts; part outlines on PARTS. ----
  function dxf(R, L) {
    var o = [];
    function p() { for (var i = 0; i < arguments.length; i += 2) { o.push(arguments[i]); o.push(arguments[i + 1]); } }
    p(0, 'SECTION', 2, 'HEADER', 9, '$ACADVER', 1, 'AC1009', 9, '$INSUNITS', 70, 4, 0, 'ENDSEC');
    p(0, 'SECTION', 2, 'TABLES', 0, 'TABLE', 2, 'LAYER', 70, 3);
    [['Edge.Cuts', 7], ['PARTS', 3], ['GRID', 8]].forEach(function (l) { p(0, 'LAYER', 2, l[0], 70, 0, 62, l[1], 6, 'CONTINUOUS'); });
    p(0, 'ENDTAB', 0, 'ENDSEC', 0, 'SECTION', 2, 'ENTITIES');
    function poly(pts, layer) {
      p(0, 'POLYLINE', 8, layer, 66, 1, 70, 1);
      pts.forEach(function (q) { p(0, 'VERTEX', 8, layer, 10, n(q[0]), 20, n(-q[1])); });
      p(0, 'SEQEND', 8, layer);
    }
    loops(L).forEach(function (lp) { poly(lp, 'Edge.Cuts'); });
    R.parts.forEach(function (pt) { pt.bodies.forEach(function (b) { if (!b.slot) poly(b.pts, 'PARTS'); }); });
    [R.planes.xl, R.planes.xr].forEach(function (x) { p(0, 'LINE', 8, 'GRID', 10, n(x), 20, n(-R.planes.yt + 4), 11, n(x), 21, n(-R.planes.yb - 4)); });
    p(0, 'ENDSEC', 0, 'EOF');
    return o.join('\n') + '\n';
  }

  // ---- KiCad board (v8 file format; KiCad 9 and 10 open it). Edge.Cuts = this layer's outline. ----
  // ---- a closed polygon back into lines and arcs ----
  // The boards' shapes come out of polygon arithmetic, where every fillet and every offset corner is a run of short chords.
  // fitLoop() finds those runs again: at least three chords in a row whose ends all lie on one circle (within tol) and whose
  // sagitta is small become one arc through the run's first, middle and last vertex; everything else stays a line. The
  // primitives reuse the polygon's own vertices as end points, so each one starts exactly where the last one ended and the
  // loop is closed by construction. A loop that is one circle all the way round comes back as a circle.
  function dist(a, b) { return Math.hypot(a[0] - b[0], a[1] - b[1]); }
  function circle3(a, b, c) {
    var d = 2 * (a[0] * (b[1] - c[1]) + b[0] * (c[1] - a[1]) + c[0] * (a[1] - b[1]));
    if (Math.abs(d) < 1e-9) return null;
    var a2 = a[0] * a[0] + a[1] * a[1], b2 = b[0] * b[0] + b[1] * b[1], c2 = c[0] * c[0] + c[1] * c[1];
    var x = (a2 * (b[1] - c[1]) + b2 * (c[1] - a[1]) + c2 * (a[1] - b[1])) / d, y = (a2 * (c[0] - b[0]) + b2 * (a[0] - c[0]) + c2 * (b[0] - a[0])) / d;
    return { x: x, y: y, r: Math.hypot(a[0] - x, a[1] - y) };
  }
  function fitLoop(pts, tol) {
    tol = tol || 0.006;
    var P = [], i, N;
    pts.forEach(function (q) { var l = P[P.length - 1]; if (!l || dist(q, l) > 2e-4) P.push([+q[0], +q[1]]); });
    if (P.length > 1 && dist(P[0], P[P.length - 1]) < 2e-4) P.pop();
    for (var pass = 0; pass < 2; pass++) for (i = P.length - 1; i >= 0 && P.length > 3; i--) {        // a vertex on the straight line between its neighbours says nothing
      var a = P[(i + P.length - 1) % P.length], b = P[i], c = P[(i + 1) % P.length], L = dist(a, c);
      if (L > 1e-9 && Math.abs((c[0] - a[0]) * (a[1] - b[1]) - (a[0] - b[0]) * (c[1] - a[1])) / L < 4e-4 && (b[0] - a[0]) * (c[0] - b[0]) + (b[1] - a[1]) * (c[1] - b[1]) > 0) P.splice(i, 1);
    }
    N = P.length; if (N < 3) return [];
    function at(j) { return P[((j % N) + N) % N]; }
    function run(s, k) {                           // do vertices s .. s+k lie on one arc?
      var c = circle3(at(s), at(s + (k >> 1)), at(s + k));
      if (!c || c.r > 400 || c.r < 0.12) return null;
      var chord = Math.sqrt(8 * c.r * 0.05), sgn = 0, sweep = 0;
      for (var j = 0; j <= k; j++) {
        var q = at(s + j);
        if (Math.abs(Math.hypot(q[0] - c.x, q[1] - c.y) - c.r) > tol) return null;
        if (j < k) {
          var q2 = at(s + j + 1), d = dist(q, q2);
          if (d > chord) return null;
          var cr = (q[0] - c.x) * (q2[1] - c.y) - (q[1] - c.y) * (q2[0] - c.x), sg = cr > 0 ? 1 : -1;
          if (sgn && sg !== sgn) return null; sgn = sg; sweep += 2 * Math.asin(Math.min(1, d / (2 * c.r)));
        }
      }
      return sweep < 5.6 ? c : null;
    }
    var whole = N >= 8 ? circle3(P[0], P[Math.floor(N / 3)], P[Math.floor(2 * N / 3)]) : null;
    if (whole && whole.r < 400 && P.every(function (q) { return Math.abs(Math.hypot(q[0] - whole.x, q[1] - whole.y) - whole.r) <= tol; }) && dist(P[0], P[1]) <= Math.sqrt(8 * whole.r * 0.05))
      return [{ t: 'circle', c: [whole.x, whole.y], r: whole.r }];
    var s0 = 0, longest = -1;                     // start where the longest straight edge ends: never the inside of an arc
    for (i = 0; i < N; i++) { var d0 = dist(P[i], at(i + 1)); if (d0 > longest) { longest = d0; s0 = i + 1; } }
    var out = [], done = 0;
    while (done < N) {
      var s = s0 + done, k = 0, left = N - done;
      if (left >= 3 && run(s, 3)) { k = 3; while (k < left && run(s, k + 1)) k++; }
      if (k >= 3) { out.push({ t: 'arc', a: at(s), m: at(s + (k >> 1)), b: at(s + k) }); done += k; }
      else { out.push({ t: 'line', a: at(s), b: at(s + 1) }); done += 1; }
    }
    return out;
  }

  // ---- a library footprint (Catalog.footprints, plain pads and drawings) written out as a KiCad 8 footprint on a board ----
  // side: false = front. On the back the footprint is written the way KiCad stores a flipped one: its own y mirrored, its
  // layers swapped, and turned a further 180 degrees, which is the tool's "mirrored in x, then turned" for a bottom part.
  // A pad's angle in a board file is the pad's own angle plus the footprint's.
  function q(sv) { return '"' + String(sv).replace(/\\/g, '/').replace(/"/g, "'") + '"'; }
  function footprintText(fp, o) {
    var bot = !!o.bottom, ang = ((o.rot || 0) + (bot ? 180 : 0)) % 360, id = 0, out = [];
    function U() { return uuid(o.seed + ':' + (id++)); }
    function Y(v) { return bot ? -v : v; }
    function lay(l) { return bot ? l.replace(/^F\./, '~').replace(/^B\./, 'F.').replace(/^~/, 'B.') : l; }
    function pt(v) { return n(v[0]) + ' ' + n(Y(v[1])); }
    function stroke(w) { return '(stroke (width ' + n(w || 0.12) + ') (type solid))'; }
    var ys = [], xs = [];
    (fp.pads || []).forEach(function (p) { xs.push(p.x); ys.push(p.y - p.h / 2, p.y + p.h / 2); });
    (fp.gfx || []).forEach(function (g) { if (g.s) ys.push(g.s[1]); if (g.e) ys.push(g.e[1]); if (g.p) g.p.forEach(function (v) { ys.push(v[1]); }); });
    var top = ys.length ? Math.min.apply(0, ys) : -1, btm = ys.length ? Math.max.apply(0, ys) : 1;
    out.push('\t(footprint ' + q('v6mech:' + fp.name) + '\n\t\t(layer ' + q(bot ? 'B.Cu' : 'F.Cu') + ')\n\t\t(uuid ' + q(U()) + ')\n\t\t(at ' + n(OX + o.x) + ' ' + n(OY + o.y) + (ang ? ' ' + n(ang) : '') + ')');
    if (o.descr) out.push('\t\t(descr ' + q(o.descr) + ')');
    function prop(name, val, y, layer, hide) {
      out.push('\t\t(property ' + q(name) + ' ' + q(val) + '\n\t\t\t(at 0 ' + n(Y(y)) + (ang ? ' ' + n(ang) : ' 0') + ')\n\t\t\t(layer ' + q(lay(layer)) + ')' + (hide ? '\n\t\t\t(hide yes)' : '') + '\n\t\t\t(uuid ' + q(U()) + ')\n\t\t\t(effects\n\t\t\t\t(font\n\t\t\t\t\t(size 0.8 0.8)\n\t\t\t\t\t(thickness 0.12)\n\t\t\t\t)' + (bot ? '\n\t\t\t\t(justify mirror)' : '') + '\n\t\t\t)\n\t\t)');
    }
    prop('Reference', o.ref, top - 1.1, 'F.SilkS'); prop('Value', o.value, btm + 1.1, 'F.Fab');
    if (o.lcsc) prop('LCSC', o.lcsc, 0, 'F.Fab', true);
    // EasyEDA's own attribute is not to be trusted (it calls plain SMD switches through-hole): go by the numbered pads
    var numbered = (fp.pads || []).filter(function (p) { return p.n !== ''; }), nSmd = numbered.filter(function (p) { return p.t === 'smd'; }).length;
    out.push('\t\t(attr ' + (fp.attr === 'outline' ? 'board_only exclude_from_pos_files exclude_from_bom' : nSmd * 2 >= numbered.length && numbered.length ? 'smd' : 'through_hole') + ')');
    (fp.gfx || []).forEach(function (g) {
      var L = '(layer ' + q(lay(g.l)) + ')\n\t\t\t(uuid ' + q(U()) + ')\n\t\t)';
      if (g.k === 'line') out.push('\t\t(fp_line\n\t\t\t(start ' + pt(g.s) + ')\n\t\t\t(end ' + pt(g.e) + ')\n\t\t\t' + stroke(g.w) + '\n\t\t\t' + L);
      else if (g.k === 'rect') out.push('\t\t(fp_rect\n\t\t\t(start ' + pt(g.s) + ')\n\t\t\t(end ' + pt(g.e) + ')\n\t\t\t' + stroke(g.w) + '\n\t\t\t(fill none)\n\t\t\t' + L);
      else if (g.k === 'circle') out.push('\t\t(fp_circle\n\t\t\t(center ' + pt(g.c) + ')\n\t\t\t(end ' + pt(g.e) + ')\n\t\t\t' + stroke(g.w) + '\n\t\t\t(fill none)\n\t\t\t' + L);
      else if (g.k === 'arc') out.push('\t\t(fp_arc\n\t\t\t(start ' + pt(g.s) + ')\n\t\t\t(mid ' + pt(g.m) + ')\n\t\t\t(end ' + pt(g.e) + ')\n\t\t\t' + stroke(g.w) + '\n\t\t\t' + L);
      else if (g.k === 'poly') out.push('\t\t(fp_poly\n\t\t\t(pts ' + g.p.map(function (v) { return '(xy ' + pt(v) + ')'; }).join(' ') + ')\n\t\t\t' + stroke(g.w) + '\n\t\t\t(fill none)\n\t\t\t' + L);
    });
    (fp.pads || []).forEach(function (p) {
      var a = (((bot ? -p.a : p.a) + ang) % 360 + 360) % 360, sh = p.poly ? 'custom' : p.s;
      var t = '\t\t(pad ' + q(p.n) + ' ' + p.t + ' ' + sh + '\n\t\t\t(at ' + n(p.x) + ' ' + n(Y(p.y)) + (a ? ' ' + n(a) : '') + ')\n\t\t\t(size ' + n(p.w) + ' ' + n(p.h) + ')';
      if (p.d) t += '\n\t\t\t(drill ' + (p.d.length > 1 ? 'oval ' + n(p.d[0]) + ' ' + n(p.d[1]) : n(p.d[0])) + (p.do ? ' (offset ' + n(p.do[0]) + ' ' + n(Y(p.do[1])) + ')' : '') + ')';
      t += '\n\t\t\t(layers ' + p.l.map(function (l) { return q(lay(l)); }).join(' ') + ')';
      if (p.rr != null && sh === 'roundrect') t += '\n\t\t\t(roundrect_rratio ' + n(p.rr) + ')';
      if (p.poly) t += '\n\t\t\t(options\n\t\t\t\t(clearance outline)\n\t\t\t\t(anchor rect)\n\t\t\t)\n\t\t\t(primitives' + p.poly.map(function (pl) { return '\n\t\t\t\t(gr_poly\n\t\t\t\t\t(pts ' + pl.map(function (v) { return '(xy ' + pt(v) + ')'; }).join(' ') + ')\n\t\t\t\t\t(width 0)\n\t\t\t\t\t(fill yes)\n\t\t\t\t)'; }).join('') + '\n\t\t\t)';
      out.push(t + '\n\t\t\t(uuid ' + q(U()) + ')\n\t\t)');
    });
    out.push('\t)');
    return out.join('\n');
  }
  // the same footprint as a library file (.kicad_mod), front side, unplaced
  function kicadMod(fp) {
    var t = footprintText(fp, { x: -OX, y: -OY, rot: 0, ref: 'REF**', value: fp.name, seed: 'mod:' + fp.name, descr: 'EasyEDA footprint, written by v6mech. Check it against the datasheet.' });
    return t.replace(/^\t/gm, '').replace(/^\(footprint "v6mech:([^"]*)"/, '(footprint "$1"\n\t(version 20240108)\n\t(generator "v6mech")\n\t(generator_version "8.0")').replace(/\n\t\(uuid "[^"]*"\)\n\t\(at 0 0\)/, '') + '\n';
  }
  function kicadMods(R) {
    var lib = fpLib(), o = {};
    R.parts.forEach(function (p) { if (p.fp && lib[p.fp] && !p.system) o[p.fp.replace(/[^A-Za-z0-9_.+-]/g, '_')] = kicadMod(lib[p.fp]); });
    return o;
  }
  function fpLib() { var C = typeof V6Catalog !== 'undefined' ? V6Catalog : (typeof require === 'function' ? require('./catalog.js') : null); return (C && C.footprints) || {}; }
  // what the KiCad file will hold for the parts on one board: the real footprint where the library has one, otherwise the
  // part's outline as a footprint that is only a drawing
  function footprintsOn(R, L) {
    var lib = fpLib();
    return R.parts.filter(function (p) { return p.mountLayer === L.id && !p.system; }).map(function (p) {
      var fp = p.fp && lib[p.fp];
      if (fp) return { part: p, real: true, name: fp.name, fp: fp, x: p.x, y: p.y, rot: p.rot, bottom: p.bottom };
      var b = p.bodies.filter(function (bd) { return !bd.slot; });
      return { part: p, real: false, name: 'outline_' + p.type, x: p.x, y: p.y, rot: 0, bottom: false,
        fp: { name: 'outline_' + p.type, attr: 'outline', pads: [], gfx: b.map(function (bd) { return { k: 'poly', l: p.bottom ? 'B.CrtYd' : 'F.CrtYd', w: 0.05, p: bd.pts.map(function (v) { return [v[0] - p.x, v[1] - p.y]; }) }; }) } };
    });
  }

  function kicad(R, L) {
    var o = [], id = 0;
    function U(tag) { return uuid(L.id + ':' + tag + ':' + (id++)); }
    function xy(q) { return '(xy ' + n(OX + q[0]) + ' ' + n(OY + q[1]) + ')'; }
    o.push('(kicad_pcb');
    o.push('\t(version 20240108)');
    o.push('\t(generator "v6mech")');
    o.push('\t(generator_version "8.0")');
    o.push('\t(general\n\t\t(thickness ' + n(L.t) + ')\n\t\t(legacy_teardrops no)\n\t)');
    o.push('\t(paper "A4")');
    o.push('\t(title_block\n\t\t(title "Jumperless V6 - ' + L.id + ' ' + L.name + '")\n\t\t(rev "' + (R.params.meta.rev || '') + '")\n\t\t(comment 1 "' + (R.removable ? 'removable wig' : 'integrated breadboard') + ', z ' + n(L.z0) + ' to ' + n(L.z1) + ' mm above the main board top face")\n\t\t(comment 2 "generated by v6mech from v6_outline.json - edit there, or treat this file as a one-way export")\n\t)');
    o.push('\t(layers');
    [[0, 'F.Cu', 'signal'], [31, 'B.Cu', 'signal'], [32, 'B.Adhes', 'user', 'B.Adhesive'], [33, 'F.Adhes', 'user', 'F.Adhesive'], [34, 'B.Paste', 'user'], [35, 'F.Paste', 'user'],
      [36, 'B.SilkS', 'user', 'B.Silkscreen'], [37, 'F.SilkS', 'user', 'F.Silkscreen'], [38, 'B.Mask', 'user'], [39, 'F.Mask', 'user'], [40, 'Dwgs.User', 'user', 'User.Drawings'],
      [41, 'Cmts.User', 'user', 'User.Comments'], [42, 'Eco1.User', 'user', 'User.Eco1'], [43, 'Eco2.User', 'user', 'User.Eco2'], [44, 'Edge.Cuts', 'user'], [45, 'Margin', 'user'],
      [46, 'B.CrtYd', 'user', 'B.Courtyard'], [47, 'F.CrtYd', 'user', 'F.Courtyard'], [48, 'B.Fab', 'user'], [49, 'F.Fab', 'user']].forEach(function (l) {
      o.push('\t\t(' + l[0] + ' "' + l[1] + '" ' + l[2] + (l[3] ? ' "' + l[3] + '"' : '') + ')');
    });
    o.push('\t)');
    o.push('\t(setup\n\t\t(pad_to_mask_clearance 0)\n\t\t(allow_soldermask_bridges_in_footprints no)\n\t)');
    o.push('\t(net 0 "")');
    function gpoly(pts, layer, width, tag) {
      o.push('\t(gr_poly\n\t\t(pts ' + pts.map(xy).join(' ') + ')\n\t\t(stroke\n\t\t\t(width ' + width + ')\n\t\t\t(type solid)\n\t\t)\n\t\t(fill none)\n\t\t(layer "' + layer + '")\n\t\t(uuid "' + U(tag) + '")\n\t)');
    }
    function gline(a, b, layer, tag) {
      o.push('\t(gr_line\n\t\t(start ' + n(OX + a[0]) + ' ' + n(OY + a[1]) + ')\n\t\t(end ' + n(OX + b[0]) + ' ' + n(OY + b[1]) + ')\n\t\t(stroke\n\t\t\t(width 0.1)\n\t\t\t(type default)\n\t\t)\n\t\t(layer "' + layer + '")\n\t\t(uuid "' + U(tag) + '")\n\t)');
    }
    function gtext(t, at, layer, tag, size) {
      size = size || 1;
      o.push('\t(gr_text "' + t.replace(/"/g, "'") + '"\n\t\t(at ' + n(OX + at[0]) + ' ' + n(OY + at[1]) + ')\n\t\t(layer "' + layer + '")\n\t\t(uuid "' + U(tag) + '")\n\t\t(effects\n\t\t\t(font\n\t\t\t\t(size ' + size + ' ' + size + ')\n\t\t\t\t(thickness ' + n(size * 0.15) + ')\n\t\t\t)\n\t\t\t(justify left bottom)\n\t\t)\n\t)');
    }
    function edge(prims) {
      prims.forEach(function (g) {
        var tail = '\n\t\t(stroke\n\t\t\t(width 0.05)\n\t\t\t(type default)\n\t\t)\n\t\t' + (g.t === 'circle' ? '(fill none)\n\t\t' : '') + '(layer "Edge.Cuts")\n\t\t(uuid "' + U('edge') + '")\n\t)';
        function P(v) { return n(OX + v[0]) + ' ' + n(OY + v[1]); }
        if (g.t === 'line') o.push('\t(gr_line\n\t\t(start ' + P(g.a) + ')\n\t\t(end ' + P(g.b) + ')' + tail);
        else if (g.t === 'arc') o.push('\t(gr_arc\n\t\t(start ' + P(g.a) + ')\n\t\t(mid ' + P(g.m) + ')\n\t\t(end ' + P(g.b) + ')' + tail);
        else o.push('\t(gr_circle\n\t\t(center ' + P(g.c) + ')\n\t\t(end ' + P([g.c[0] + g.r, g.c[1]]) + ')' + tail);
      });
    }
    footprintsOn(R, L).forEach(function (f) {
      o.push(footprintText(f.fp, { x: f.x, y: f.y, rot: f.rot, bottom: f.bottom, ref: String(f.part.id).toUpperCase(), value: String(f.part.label).slice(0, 60), lcsc: f.part.lcsc, seed: L.id + ':fp:' + f.part.id,
        descr: f.real ? 'EasyEDA footprint for LCSC ' + (f.part.lcsc || '?') + ', placed by v6mech. Check it against the datasheet.' : 'v6mech: outline only, no footprint in the library for this part. Rotation is already in the drawing.' }));
    });
    loops(L).forEach(function (lp) { edge(fitLoop(lp)); });
    // parts that sit on or pass through this layer, as reference outlines
    R.parts.forEach(function (pt) {
      var here = pt.mountLayer === L.id;
      pt.bodies.forEach(function (b) { if (!b.slot && (here || Math.min(b.z1, L.z1) - Math.max(b.z0, L.z0) > 0.02)) { gpoly(b.pts, 'Dwgs.User', 0.1, 'part'); } });
      if (here) gtext(pt.id + (pt.bottom ? ' (bottom)' : ''), [pt.x, pt.y], 'Dwgs.User', 'label', 0.8);
    });
    // stacking planes and the datum
    gline([R.planes.xl, R.planes.yt - 5], [R.planes.xl, R.planes.yb + 5], 'Cmts.User', 'plane');
    gline([R.planes.xr, R.planes.yt - 5], [R.planes.xr, R.planes.yb + 5], 'Cmts.User', 'plane');
    gline([-2, 0], [2, 0], 'Cmts.User', 'datum'); gline([0, -2], [0, 2], 'Cmts.User', 'datum');
    gtext('left grid plane x=' + n(R.planes.xl), [R.planes.xl + 0.5, R.planes.yb + 4.5], 'Cmts.User', 'txt', 0.8);
    gtext('right grid plane x=' + n(R.planes.xr) + '  (unit pitch ' + n(R.planes.pitch) + ' = ' + Math.round(R.planes.pitch / 2.54) + ' x 2.54)', [R.planes.xr - 52, R.planes.yb + 6.5], 'Cmts.User', 'txt', 0.8);
    gtext(L.id + ' ' + L.name + '  t=' + n(L.t) + '  z ' + n(L.z0) + '..' + n(L.z1), [R.planes.xl, R.planes.yt - 2], 'Cmts.User', 'txt', 1.2);
    o.push(')');
    return o.join('\n') + '\n';
  }

  // ---- the wig's top board: its outline as lines and arcs, its holes as one footprint of plated holes ----
  function kicadFace(R) {
    var f = R.wig.face; if (!f || !f.holes) return '';
    var L = { id: 'WT', name: 'Wig top board', t: f.t, z0: f.z0, z1: f.z1, shape: [{ outer: f.pts, holes: [] }] };
    var txt = kicad({ parts: [], planes: R.planes, params: R.params, removable: R.removable }, L), ring = 0.26;
    var fp = { name: 'wig_top_holes', attr: 'through_hole', gfx: [], pads: f.holes.map(function (h, i) { var csk = h[2] > h[3] + 0.05; return { n: csk ? String(i + 1) : '', t: 'thru_hole', s: 'circle', x: h[0], y: h[1], a: 0, w: +(h[2] + (csk ? 2 * ring : 0.4)).toFixed(3), h: +(h[2] + (csk ? 2 * ring : 0.4)).toFixed(3), d: [h[3]], l: ['*.Cu', '*.Mask'] }; }) };
    var body = footprintText(fp, { x: 0, y: 0, rot: 0, ref: 'HOLES', value: f.holes.length + ' holes from wiigtop.3mf', seed: 'WT:holes', descr: 'Drill ' + f.holes[0][3] + ', land = the ' + f.holes[0][2] + ' countersink plus a ' + ring + ' ring (the ring is a guess). The countersink itself is not in this file: it is a fab note.' });
    return txt.replace(/\n\)\n$/, '\n' + body + '\n)\n');
  }

  // ---- SVG plan of the whole stack ----
  var LAYER_COLORS = ['#35618f', '#b9763c', '#c9a13f', '#3f8f6d', '#646a78', '#7d5a94', '#3e9aa3', '#a2535f'];
  function svg(R) {
    var x0 = R.planes.xl - 8, y0 = R.planes.yt - 8, w = R.planes.xr - R.planes.xl + 16 + 30, h = R.planes.yb - R.planes.yt + 16;
    var o = ['<svg xmlns="http://www.w3.org/2000/svg" viewBox="' + n(x0) + ' ' + n(y0) + ' ' + n(w) + ' ' + n(h) + '" width="' + n(w * 8) + '" height="' + n(h * 8) + '" font-family="Helvetica, Arial, sans-serif">'];
    o.push('<rect x="' + n(x0) + '" y="' + n(y0) + '" width="' + n(w) + '" height="' + n(h) + '" fill="#ffffff"/>');
    function d(pts) { return 'M' + pts.map(function (q) { return n(q[0]) + ' ' + n(q[1]); }).join('L') + 'Z'; }
    R.layers.forEach(function (L, i) {
      var c = LAYER_COLORS[i % LAYER_COLORS.length];
      var path = L.shape.map(function (e) { return d(e.outer) + e.holes.map(d).join(''); }).join('');
      o.push('<path d="' + path + '" fill="' + c + '" fill-opacity="0.13" fill-rule="evenodd" stroke="' + c + '" stroke-width="0.18"/>');
      o.push('<rect x="' + n(R.planes.xr + 6) + '" y="' + n(R.planes.yt + i * 4) + '" width="3" height="2.4" fill="' + c + '" fill-opacity="0.5" stroke="' + c + '" stroke-width="0.15"/>');
      o.push('<text x="' + n(R.planes.xr + 10) + '" y="' + n(R.planes.yt + i * 4 + 2) + '" font-size="2">' + L.id + ' ' + L.name + ' ' + n(L.t) + '</text>');
    });
    R.wig.cols.forEach(function (cx) { R.wig.rows.forEach(function (cy) { o.push('<rect x="' + n(cx - 0.5) + '" y="' + n(cy - 0.5) + '" width="1" height="1" fill="#999"/>'); }); });
    R.parts.forEach(function (pt) {
      pt.bodies.forEach(function (b) { if (!b.slot) o.push('<path d="' + d(b.pts) + '" fill="none" stroke="#111" stroke-width="0.15" stroke-dasharray="' + (pt.bottom ? '0.6 0.4' : 'none') + '"/>'); });
      if (!pt.system) o.push('<text x="' + n(pt.x) + '" y="' + n(pt.y) + '" font-size="1.8" text-anchor="middle">' + pt.id + '</text>');
    });
    [R.planes.xl, R.planes.xr].forEach(function (x) { o.push('<line x1="' + n(x) + '" y1="' + n(y0) + '" x2="' + n(x) + '" y2="' + n(y0 + h) + '" stroke="#d22" stroke-width="0.12" stroke-dasharray="1 0.6"/>'); });
    o.push('</svg>');
    return o.join('\n') + '\n';
  }

  // ---- plain-text check report ----
  function report(R) {
    var c = R.checks, o = [];
    o.push('Jumperless V6 outline - ' + (R.removable ? 'removable wig' : 'integrated breadboard') + ' - ' + (R.params.meta.rev || ''));
    o.push('');
    o.push('GRID   unit pitch ' + c.grid.pitch + ' mm = ' + Math.round(c.grid.pitch / 2.54) + ' x 2.54 (' + (c.grid.on_grid ? 'on grid' : 'OFF GRID') + '), ' + c.grid.dead_rows + ' dead row(s) between units, left strip ' + c.grid.strip_w + ' mm');
    o.push('       grid planes x = ' + c.grid.left_plane + ' and x = ' + c.grid.right_plane + '; dead-row pin lines on this unit at x = ' + c.grid.dead_x.join(', '));
    c.neighbours.forEach(function (n) {
      if (!n.overlap_mm2) o.push('       fits   ' + n.label);
      else o.push('   !!  ' + n.label + ': overlaps ' + n.overlap_mm2 + ' mm2, up to ' + n.depth + ' mm, y ' + n.y0 + ' .. ' + n.y1 + ' (' + n.items.map(function (i) { return i.what + ' ' + i.mm2; }).join('; ') + ')');
    });
    if (c.grid.units_clear_at && c.grid.units_clear_at.extra_rows > 0) o.push('       two whole units clear each other at pitch ' + c.grid.units_clear_at.pitch + ' (' + c.grid.units_clear_at.dead_rows + ' dead rows). Plan view only.');
    o.push('');
    if (c.grid.coupler) { var q = c.grid.coupler; o.push((q.fits ? '   ok  ' : '   !!  ') + 'edge coupler ' + q.label + ': needs ' + q.gap + ' mm between the boards, the strip leaves ' + q.have + (q.fits ? ' (' + q.spare + ' spare)' : '; first fits with a ' + q.strip_needed + ' mm strip')); }
    if (R.wig.face) o.push('FACE   ' + (R.wig.face.real ? 'wig top board (holes from wiigtop.3mf), ' + R.wig.face.holes.length + ' holes, ' + (R.wig.face.strip ? 'with' : 'no') + ' card edge' : 'plain face board') + ', ' + R.wig.face.t + ' thick, z ' + R.wig.face.z0 + ' .. ' + R.wig.face.z1 + (R.wig.face.inset ? ' (let into the shell)' : ' (on the shell)') + '; it reaches y = ' + R.wig.face.y0 + ', so ' + (R.wig.face.y0 < -0.01 ? (-R.wig.face.y0).toFixed(2) + ' mm of it lies over the frame' : 'none of it lies over the frame'));
    o.push('STACK  top board z = ' + c.flush.frame_top + ', ' + (R.wig.face ? 'shell top z = ' + c.flush.shell_top + ' (' + (c.flush.delta_shell >= 0 ? '+' : '') + c.flush.delta_shell + '), ' : '') + 'breadboard top z = ' + c.flush.bb_top + ' (' + (c.flush.delta >= 0 ? '+' : '') + c.flush.delta + '), boards ' + c.flush.total + ' mm thick in all' + (R.wig.face ? ', ' + (Math.max(c.flush.frame_top, c.flush.bb_top) - R.z.bottom).toFixed(2) + ' to the top of the wig top board' : '') + '; gaps ' + c.flush.gaps.map(function (q) { return q.gap + ' under ' + q.below; }).join(', '));
    R.layers.forEach(function (L) { o.push('       ' + L.id + ' ' + (L.name + '              ').slice(0, 14) + ' ' + L.kind + (L.kind.length < 5 ? ' ' : '') + ' t ' + L.t + '  z ' + L.z0 + ' .. ' + L.z1 + '   net ' + L.area + ' mm2 (openings ' + L.pocketArea + ')' + (L.islands !== 1 ? '  !! in ' + L.islands + ' pieces' : '') + (L.cutBy.length ? '   opened for ' + L.cutBy.join(', ') : '   whole')); });
    o.push('');
    o.push('CLASHES ' + (c.clashes.length ? '' : 'none'));
    c.clashes.forEach(function (k) { o.push('   !!  ' + k.labels[0] + '  x  ' + k.labels[1] + ': ' + k.overlap_mm2 + ' mm2 over ' + k.overlap_z + ' mm of height'); });
    o.push('');
    c.blocked.forEach(function (k) { o.push('   !!  ' + k.label + ' runs into ' + k.layer + ' ' + k.name + ' (' + k.mm2 + ' mm2), which is set to stay whole for it'); });
    c.overhang.forEach(function (v) { o.push('   ..  ' + v.label + ' reaches ' + v.mm2 + ' mm2 past the edge of ' + v.layer + ' (x ' + v.x[0] + ' .. ' + v.x[1] + ', y ' + v.y[0] + ' .. ' + v.y[1] + ')'); });
    o.push('');
    if (c.cantilevers && c.cantilevers.length) {
      o.push('CANTILEVERED BUTTONS  (estimate: plain cantilever, E = 22 GPa, switch 1.6 N and 0.25 mm)');
      c.cantilevers.forEach(function (k) { o.push(k.none ? '   ..  ' + k.id + ': no board above is opened for it, so there is no tongue' : '   ' + (k.force <= 4 ? 'ok' : k.force <= 10 ? '..' : '!!') + '  ' + k.id + ': tongue ' + k.arm + ' x ' + k.w + ' in ' + k.board + ' (' + k.t + ' mm): about ' + k.force + ' N to click (' + k.k + ' N/mm over ' + k.travel + ' mm, ' + k.stress + ' MPa at the root); about ' + k.thin.force + ' N in a 0.8 mm board'); if (k.broken) o.push('   !!  ' + k.id + ': the slot is less than 0.8 mm from an edge or another opening (' + k.broken + ' mm2 of the ring round it is not board)'); });
      o.push('');
    }
    o.push('KICAD  footprints placed in each board file (real = the EasyEDA footprint for the LCSC number, outline = a drawing only)');
    R.layers.forEach(function (L) { var f = footprintsOn(R, L); o.push('       ' + L.id + ': ' + (f.length ? f.map(function (q) { return q.part.id + (q.real ? ' real ' + q.name : ' outline'); }).join('; ') : 'none')); });
    o.push('');
    o.push('PARTS  where each sits, and which boards are opened for it');
    R.parts.forEach(function (p) {
      if (p.system) return;
      var b = R.layers.map(function (L) { var st = p.boards[L.id]; return !st || st.state === 'whole' ? null : L.id + (st.state === 'through' ? ' through' : st.state === 'access' ? (st.set === true ? ' opened by hand' : ' opened to reach it') : ' BLOCKED'); }).filter(Boolean);
      var kept = R.layers.filter(function (L) { var st = p.boards[L.id]; return st && st.set === false; }).map(function (L) { return L.id; });
      o.push('       ' + (p.id + '         ').slice(0, 9) + ' ' + p.label + ': on ' + (p.mountLayer || 'no board') + (p.bottom ? ' underside' : '') + ', z ' + p.z0 + ' .. ' + p.z1 + (p.proud > 0.05 ? ', ' + p.proud + ' above the top face' : ', ' + (-p.proud) + ' below the top face') + '; ' + (b.length ? b.join(', ') : 'no board opened') + (kept.length ? '; kept whole by hand: ' + kept.join(', ') : ''));
    });
    o.push('');
    o.push('ROOM   board face with nothing standing in front of it (gap at least ' + c.area.min_gap + ' mm; two faces across a gap share its height)');
    c.faces.forEach(function (f) { if (f.counts) o.push('       ' + f.layer + ' ' + (f.side + '  ').slice(0, 6) + ' ' + ('      ' + (f.free + (f.free_open || 0))).slice(-6) + ' mm2   headroom ' + (f.open ? 'open' : f.height + ' mm') + (f.under_bb ? '   (' + f.under_bb + ' of it under the breadboard)' : '')); });
    o.push('       total ' + c.area.placeable + ' mm2 against ' + c.area.budget + ' mm2 of main-board courtyard = ' + (c.area.fill != null ? Math.round(c.area.fill * 100) + ' % fill' : 'n/a') + ' (a board like this stops routing near 45 %)');
    if (c.probe) {
      o.push('');
      o.push('PROBE  between the boards: axis at z ' + c.probe.zc + ' in the ' + c.probe.room_z + ' mm space from z ' + c.probe.cavity[0] + ' to ' + c.probe.cavity[1] + '; channel ' + c.probe.channel_w + ' wide, opens ' + (c.probe.cuts.length ? c.probe.cuts.join(', ') : 'no board') + (c.probe.cuts_outer.length ? '   !! reaches into ' + c.probe.cuts_outer.join(', ') : '') + '; walls ' + c.probe.wall_left + ' / ' + c.probe.wall_right + ' mm; sticks out ' + c.probe.sticks_out + ' mm');
      if (c.probe.nearest) o.push('       docked magnet (' + c.probe.moment + ' mT*mm3) reads ' + c.probe.nearest.B_mT + ' mT at ' + c.probe.nearest.kind + ' ' + c.probe.nearest.ref + ', ' + c.probe.nearest.r + ' mm away (range +/-' + c.probe.nearest.range_mT + ' mT)');
      if (c.probe.dead_row_in_channel.length) o.push('   !!  dead-row pin line x = ' + c.probe.dead_row_in_channel.join(', ') + ' runs down the probe channel');
    }
    if (c.mag) {
      var g = c.mag, mm = function (v) { return v == null ? 'no fix' : v; };
      o.push('');
      o.push('MAG    ' + g.n + ' magnetometers: ' + g.on_bb + ' under the breadboard, ' + g.on_frame + ' on the frame. Magnet ' + g.strength + ' mT*mm3, ' + g.height + ' mm above the breadboard\'s top; ambient field ' + (g.ambient === 'fitted' ? 'fitted with the magnet' : 'taken out by the zero'));
      o.push('       error bound of the fix, mm: median ' + mm(g.median) + ', 90th percentile ' + mm(g.p90) + ', worst ' + mm(g.worst) + (g.worst_hole ? ' (column ' + g.worst_hole.col + ', hole row ' + g.worst_hole.row + ')' : '') + '; ' + g.ok + ' of ' + g.holes + ' holes within half a pitch' + (g.nofix ? '; no fix at ' + g.nofix : ''));
      if (g.shift_median != null) o.push('       a 10 uT change of the ambient field the zero does not know moves the fix ' + mm(g.shift_median) + ' mm (median), ' + mm(g.shift_worst) + ' (worst)');
      if (g.off.length) o.push('   !!  not on their board: ' + g.off.join(', '));
      if (g.under.length) o.push('   !!  under a part: ' + g.under.join(', '));
      if (g.docked_saturated.length) o.push('   ..  past full scale while the probe is docked: ' + g.docked_saturated.join(', '));
    }
    c.notes.forEach(function (t) { o.push('NOTE   ' + t); });
    return o.join('\n') + '\n';
  }

  return { dxf: dxf, kicad: kicad, kicadFace: kicadFace, kicadMod: kicadMod, kicadMods: kicadMods, fitLoop: fitLoop, footprintsOn: footprintsOn, svg: svg, report: report, slug: slug, LAYER_COLORS: LAYER_COLORS, OX: OX, OY: OY };
});
