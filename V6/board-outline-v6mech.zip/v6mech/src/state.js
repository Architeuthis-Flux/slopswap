// Jumperless V6 outline tool - what the page remembers between reloads.
// Everything is kept in this browser's own storage (localStorage, keys v6mech.*). Nothing is sent anywhere.
//   v6mech.state  { params, ui, cam, t }   the working design, the view settings and the camera
//   v6mech.saves  { name: { params, t } }  named copies
// A design can also travel as a code (the differences from the built-in design, base64) in a link's #p= part.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.V6State = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var K = { state: 'v6mech.state', saves: 'v6mech.saves', old: 'v6mech.params' };
  var store = null;
  try { store = typeof localStorage !== 'undefined' ? localStorage : null; if (store) { store.setItem('v6mech.t', '1'); store.removeItem('v6mech.t'); } } catch (e) { store = null; }
  function get(k) { try { var s = store && store.getItem(k); return s ? JSON.parse(s) : null; } catch (e) { return null; } }
  function put(k, v) { try { if (!store) return false; store.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function isObj(o) { return o && typeof o === 'object' && !Array.isArray(o); }

  // merge(defaults, saved): saved wins; objects merge key by key; arrays and plain values are taken whole from saved.
  // Comment keys (starting with "_") always come from the defaults, so a newer page explains itself.
  function merge(d, s) {
    if (!isObj(d) || !isObj(s)) return s === undefined ? clone(d) : clone(s);
    var o = {}, k;
    for (k in d) o[k] = k.charAt(0) === '_' ? d[k] : (k in s ? merge(d[k], s[k]) : clone(d[k]));
    for (k in s) if (!(k in o) && k.charAt(0) !== '_') o[k] = clone(s[k]);
    return o;
  }
  // diff(defaults, params): only what differs, for a short code. Arrays that differ go whole.
  function diff(d, p) {
    if (!isObj(d) || !isObj(p)) return JSON.stringify(d) === JSON.stringify(p) ? undefined : p;
    var o = {}, n = 0, k;
    for (k in p) { if (k.charAt(0) === '_') continue; var v = diff(d[k], p[k]); if (v !== undefined) { o[k] = v; n++; } }
    return n ? o : undefined;
  }
  // bring a design made by an older page up to this one
  function migrate(p, defaults) {
    var o = merge(defaults, p), old = p.meta && p.meta.rev, changes = [];
    o.meta = clone(defaults.meta);
    if (p.wig && p.wig.face === undefined && p.wig.face_pcb_t !== undefined) {      // rev A3 and older: a plain face of a given thickness
      if (p.wig.face_pcb_t > 0) o.wig.face = { on: true, t: p.wig.face_pcb_t, sits: 'on', header_strip: true, plain: true };       // 0 was the old default: the new default (the Wiiig face board) stands
    }
    delete o.wig.face_pcb_t;
    var m = old && /^A([0-9]+)/.exec(old), n = m ? +m[1] : 99;
    if (n <= 4) {
      // rev A5: the top board has no card edge (rev A4 drew it by default); the inside corner follows the breadboard's chamfer;
      // the top-left block slopes in to the strip with no flat under it. Only the as-drawn vertices are touched.
      if (o.wig.face && !o.wig.face.plain) o.wig.face.header_strip = false;
      var ov = o.frame && o.frame.outline;
      if (ov) for (var i = 0; i < ov.length; i++) {
        var q = ov[i], nx = ov[(i + 1) % ov.length];
        if (Math.abs(q.x) < 1e-6 && Math.abs(q.y) < 1e-6 && q.c === undefined && !q.r) q.c = 'wig';
        if (q.c === 'wig' && Math.abs(q.y) < 1e-6 && q.x < -0.01 && Math.abs(nx.y) < 1e-6 && nx.x < q.x - 2.3 && (nx.r || 0) <= 1.01 && nx.c === undefined) {
          var step = q.x - nx.x; delete q.c; q.y = 1.583; q.r = 1.0; nx.y = +(1.583 - step * 1.583 / 2.211).toFixed(3); nx.r = 2.0;
          q.n = 'the top-left block slopes out from here along the corner chamfer of a breadboard standing on the left'; nx.n = 'left edge of the top-left block; no flat under it';
        }
      }
    }
    if (n <= 5) {
      // rev A6: the magnetometers are a list of their own (mag.list, the Magnetometers tab). A file that still had the old
      // default (the WigLEDmag's sensors) takes the new one; an explicit 3 x 6 or 4 x 8 is kept and becomes a list when edited.
      if (!p.show || !p.show.sensor_layout || p.show.sensor_layout === 'wigledmag') o.show.sensor_layout = 'custom';
    }
    if (n <= 6) {
      // rev A7: the 2.2 inch bar display is the default, with two cantilevered keys beside it (the keys went again in rev A10d,
      // so the built-in design has none to add now and the display lands where A10d puts it). Only a design whose parts are
      // still the old default set is touched: a display that was moved or changed, or any added part, is left as it was.
      var ps = o.parts || [], std = { display: 1, encoder: 1, usbc: 1, port: 1 }, dsp = ps.filter(function (q) { return q.id === 'display'; })[0];
      if (dsp && dsp.type === 'display_amoled147' && Math.abs(dsp.x - 19) < 0.01 && Math.abs(dsp.y + 11.8) < 0.01 && ps.every(function (q) { return std[q.id]; })) {
        var dd = (defaults.parts || []).filter(function (q) { return q.id === 'display'; })[0];
        if (dd) { dsp.type = dd.type; dsp.x = dd.x; dsp.y = dd.y; dsp.rot = dd.rot; dsp.mount = clone(dd.mount); delete dsp.open; }
        (defaults.parts || []).forEach(function (q) { if (/^key[0-9]+$/.test(q.id)) ps.push(clone(q)); });
      }
    }
    var sub = old && /^A[0-9]+([a-z])/.exec(old);
    if (n < 10 || (n === 10 && (!sub || sub[1] < 'c'))) {
      // rev A10c: where the strip stops at the breadboard's bottom-left corner, its end meets the breadboard's chamfer square, at
      // the middle of the flat. Only the as-drawn vertex is touched: still on the corner and still sharp.
      var wh = o.wig && o.wig.height;
      (o.frame && o.frame.outline || []).forEach(function (q) {
        if (Math.abs(q.x) < 1e-6 && Math.abs(q.y - wh) < 2e-3 && q.c === undefined && !q.r) { q.c = 'meet'; q.n = "the strip ends level with the breadboard's bottom edge; its end meets the breadboard's corner chamfer square, at the middle of the flat"; }
      });
    }
    if (n < 10 || (n === 10 && (!sub || sub[1] < 'd'))) {
      // rev A10d: the two cantilevered keys to the right of the display are gone, and the display has moved right so that its
      // picture is centred on the breadboard. Only what is still as drawn is touched: a key that was moved, turned, remounted
      // or given its own openings stays, and so does a display that was moved, turned or changed for another.
      var dnew = (defaults.parts || []).filter(function (q) { return q.id === 'display'; })[0];
      var keyAsDrawn = function (q, x) { return q.type === 'btn_cantilever' && Math.abs(q.x - x) < 0.01 && Math.abs(q.y + 5) < 0.01 && (q.rot || 0) === 90 && !!q.mount && q.mount.on === 'L1' && q.mount.side === 'top' && !q.open; };
      o.parts = (o.parts || []).filter(function (q) { return !((q.id === 'key1' && keyAsDrawn(q, 64.5)) || (q.id === 'key2' && keyAsDrawn(q, 70.5))); });
      o.parts.forEach(function (q) {
        if (dnew && q.id === 'display' && q.type === 'display_tft220bar' && Math.abs(q.x - 30) < 0.01 && Math.abs(q.y + 9.9) < 0.01 && (q.rot || 0) === 90) { q.x = dnew.x; q.y = dnew.y; }
      });
    }
    if (n < 11 || (n === 11 && (!sub || sub[1] < 'c'))) {
      // rev A11c: two ports. The general expansion port is the one on the top edge (an M.2 socket in the built-in design), and the
      // 1.27 mm right-angle socket in the unit's right side is a part of its own, "side": routable lanes only, for the extender.
      // Rev A11 and A11b had put that socket in the port's place. Where a design still has it there it becomes "side", and the
      // built-in top port comes back if the design then has no port. Any other design keeps its port as it is and is given the
      // side socket, unless it already has one. The staples and the rail jumpers those two revisions drew are gone, and so is
      // the board over the extender's head that rev A11 drew.
      var dside = (defaults.parts || []).filter(function (q) { return q.id === 'side'; })[0], dport = (defaults.parts || []).filter(function (q) { return q.id === 'port'; })[0];
      var ps2 = o.parts = o.parts || [], isPort = function (q) { return /^port/.test(q.id); };
      var inPort = ps2.filter(function (q) { return isPort(q) && q.type === 'skt_ra_127'; })[0], hasSide = ps2.some(function (q) { return q.id === 'side'; });
      if (inPort && !hasSide) {
        inPort.id = 'side';
        if (dport && !ps2.some(isPort)) ps2.push(clone(dport));
        changes.push('The socket in the right side is now a part of its own, and the expansion port is back on the top edge.');
      } else if (dside && !hasSide && !ps2.some(function (q) { return q.type === 'skt_ra_127'; })) {
        ps2.push(clone(dside));
        if (n < 11) changes.push('A header socket for the extender has been added in the right side; the expansion port is as it was.');
      }
      if (p.extender && o.extender) {
        if (n === 11 && !sub && p.extender.cover === true) o.extender.cover = false;
        if ((p.extender.ties && p.extender.ties !== 'none') || p.extender.jumpers) { o.extender.ties = 'none'; o.extender.jumpers = false; changes.push('The staples and the rail jumpers are gone from the extender.'); }
      }
    }
    if (n < 11 || (n === 11 && (!sub || sub[1] < 'd'))) {
      // rev A11d: no hole position is skipped between the breadboard and the extender. A design whose extender still has the one
      // dead row it was drawn with gets none; the waist that makes room for the column (wig.waist_r) is a new setting and starts
      // at its default either way. Two or three dead rows were chosen, and are kept.
      if (p.extender && o.extender && +p.extender.dead_rows === 1) {
        o.extender.dead_rows = 0;
        changes.push('The extender no longer skips a row: its first column is on the unit\'s grid plane, and the waist in the breadboard\'s side is ' + (defaults.wig && defaults.wig.waist_r) + ' mm deep for it.');
      }
    }
    return { params: o, from_rev: old && old !== defaults.meta.rev ? old : null, changes: changes };
  }
  function valid(p) { return !!(p && p.stack && p.stack.length && p.grid && p.wig && p.frame); }

  function b64e(s) { var b = typeof btoa === 'function' ? btoa(unescape(encodeURIComponent(s))) : Buffer.from(s, 'utf8').toString('base64'); return b.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function b64d(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return typeof atob === 'function' ? decodeURIComponent(escape(atob(s))) : Buffer.from(s, 'base64').toString('utf8'); }
  function encode(params, defaults) { return b64e(JSON.stringify(diff(defaults, params) || {})); }
  // accepts a code, a whole link with #p=, or the JSON of a v6_outline.json
  function decode(text, defaults) {
    text = String(text || '').trim();
    if (!text) throw new Error('nothing to read');
    var o;
    if (text.charAt(0) === '{') o = JSON.parse(text);
    else { var m = text.match(/[#&?]p=([A-Za-z0-9_\-]+)/); o = JSON.parse(b64d(m ? m[1] : text)); }
    var r = migrate(o, defaults);
    if (!valid(r.params)) throw new Error('that is not a V6 outline');
    return r.params;
  }

  function load(defaults, hash) {
    var note = null, from = 'built-in', p = null, st = get(K.state) || {}, upgraded = false;
    if (hash && /[#&]p=/.test(hash)) { try { p = decode(hash, defaults); from = 'link'; note = 'Opened from a link. Your own last design is kept under Saved designs as "before the link".'; if (valid(st.params)) putSave('before the link', st.params); } catch (e) { note = 'The link could not be read (' + e.message + ').'; p = null; } }
    if (!p && valid(st.params)) { var r = migrate(st.params, defaults); p = r.params; from = 'saved'; if (r.from_rev) note = 'Your saved design was made with rev ' + r.from_rev + '; it has been brought up to ' + defaults.meta.rev + '. New settings start at their defaults.' + (r.changes.length ? ' ' + r.changes.join(' ') : ''); upgraded = true; }
    if (!p) { var o = get(K.old); if (valid(o)) { var r2 = migrate(o, defaults); p = r2.params; from = 'saved'; note = 'Your design from the earlier page (rev ' + (r2.from_rev || '?') + ') has been brought up to ' + defaults.meta.rev + '.'; } }
    if (!p) p = clone(defaults);
    return { params: p, ui: st.ui || null, cam: from === 'link' ? null : (st.cam || null), from: from, note: note, storage: !!store, upgraded: upgraded };
  }
  function save(params, ui, cam) { return put(K.state, { params: params, ui: ui, cam: cam, t: Date.now() }); }

  function saves() { var s = get(K.saves) || {}; return Object.keys(s).map(function (n) { return { name: n, t: s[n].t, rev: s[n].params && s[n].params.meta && s[n].params.meta.rev }; }).sort(function (a, b) { return b.t - a.t; }); }
  function putSave(name, params) { var s = get(K.saves) || {}; s[name] = { params: clone(params), t: Date.now() }; return put(K.saves, s); }
  function getSave(name, defaults) { var s = get(K.saves) || {}; return s[name] ? migrate(s[name].params, defaults).params : null; }
  function delSave(name) { var s = get(K.saves) || {}; delete s[name]; return put(K.saves, s); }

  // undo: snapshots of the design as text; a step is recorded when the design has stopped changing for a moment
  function History(max) { this.max = max || 80; this.list = []; this.at = -1; }
  History.prototype.push = function (params) {
    var s = JSON.stringify(params);
    if (this.at >= 0 && this.list[this.at] === s) return false;
    this.list = this.list.slice(0, this.at + 1); this.list.push(s);
    if (this.list.length > this.max) this.list.shift();
    this.at = this.list.length - 1; return true;
  };
  History.prototype.canUndo = function () { return this.at > 0; };
  History.prototype.canRedo = function () { return this.at < this.list.length - 1; };
  History.prototype.undo = function () { return this.canUndo() ? JSON.parse(this.list[--this.at]) : null; };
  History.prototype.redo = function () { return this.canRedo() ? JSON.parse(this.list[++this.at]) : null; };

  return { load: load, save: save, saves: saves, putSave: putSave, getSave: getSave, delSave: delSave, encode: encode, decode: decode, merge: merge, diff: diff, migrate: migrate, valid: valid, History: History, available: function () { return !!store; } };
});
