// Jumperless V6 outline tool - what the page remembers between reloads.
// Everything is kept in this browser's own storage (localStorage, keys v6mech.*). Nothing is sent anywhere.
//   v6mech.state  { params, ui, cam, t }   the working design, the view settings and the camera
//   v6mech.saves  { name: { params, t } }  named copies
// A design can also travel as a code (the differences from the built-in design, base64) in a link's #p= part.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.V6State = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';
  var K = { state: 'v6mech.state', saves: 'v6mech.saves', old: 'v6mech.params' };
  var store = null;
  try { store = typeof localStorage !== 'undefined' ? localStorage : null; if (store) { store.setItem('v6mech.t', '1'); store.removeItem('v6mech.t'); } } catch (e) { store = null; }
  function get(k) { try { var s = store && store.getItem(k); return s ? JSON.parse(s) : null; } catch (e) { return null; } }
  function put(k, v) { try { if (!store) return false; store.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function isObj(o) { return o && typeof o === 'object' && !Array.isArray(o); }

  // merge(defaults, saved): saved wins; objects merge key by key; arrays and plain values are taken whole from saved.
  // Comment keys (starting with "_") always come from the defaults, so a newer page explains itself.
  function merge(d, s) {
    if (!isObj(d) || !isObj(s)) return s === undefined ? clone(d) : clone(s);
    var o = {}, k;
    for (k in d) o[k] = k.charAt(0) === '_' ? d[k] : (k in s ? merge(d[k], s[k]) : clone(d[k]));
    for (k in s) if (!(k in o) && k.charAt(0) !== '_') o[k] = clone(s[k]);
    return o;
  }
  // diff(defaults, params): only what differs, for a short code. Arrays that differ go whole.
  function diff(d, p) {
    if (!isObj(d) || !isObj(p)) return JSON.stringify(d) === JSON.stringify(p) ? undefined : p;
    var o = {}, n = 0, k;
    for (k in p) { if (k.charAt(0) === '_') continue; var v = diff(d[k], p[k]); if (v !== undefined) { o[k] = v; n++; } }
    return n ? o : undefined;
  }
  // bring a design made by an older page up to this one
  function migrate(p, defaults) {
    var o = merge(defaults, p), old = p.meta && p.meta.rev;
    o.meta = clone(defaults.meta);
    if (p.wig && p.wig.face === undefined && p.wig.face_pcb_t !== undefined) {      // rev A3 and older: a plain face of a given thickness
      if (p.wig.face_pcb_t > 0) o.wig.face = { on: true, t: p.wig.face_pcb_t, sits: 'on', header_strip: true, plain: true };       // 0 was the old default: the new default (the Wiiig face board) stands
    }
    delete o.wig.face_pcb_t;
    var m = old && /^A([0-9]+)/.exec(old), n = m ? +m[1] : 99;
    if (n <= 4) {
      // rev A5: the top board has no card edge (rev A4 drew it by default); the inside corner follows the breadboard's chamfer;
      // the top-left block slopes in to the strip with no flat under it. Only the as-drawn vertices are touched.
      if (o.wig.face && !o.wig.face.plain) o.wig.face.header_strip = false;
      var ov = o.frame && o.frame.outline;
      if (ov) for (var i = 0; i < ov.length; i++) {
        var q = ov[i], nx = ov[(i + 1) % ov.length];
        if (Math.abs(q.x) < 1e-6 && Math.abs(q.y) < 1e-6 && q.c === undefined && !q.r) q.c = 'wig';
        if (q.c === 'wig' && Math.abs(q.y) < 1e-6 && q.x < -0.01 && Math.abs(nx.y) < 1e-6 && nx.x < q.x - 2.3 && (nx.r || 0) <= 1.01 && nx.c === undefined) {
          var step = q.x - nx.x; delete q.c; q.y = 1.583; q.r = 1.0; nx.y = +(1.583 - step * 1.583 / 2.211).toFixed(3); nx.r = 2.0;
          q.n = 'the top-left block slopes out from here along the corner chamfer of a breadboard standing on the left'; nx.n = 'left edge of the top-left block; no flat under it';
        }
      }
    }
    return { params: o, from_rev: old && old !== defaults.meta.rev ? old : null };
  }
  function valid(p) { return !!(p && p.stack && p.stack.length && p.grid && p.wig && p.frame); }

  function b64e(s) { var b = typeof btoa === 'function' ? btoa(unescape(encodeURIComponent(s))) : Buffer.from(s, 'utf8').toString('base64'); return b.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function b64d(s) { s = s.replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; return typeof atob === 'function' ? decodeURIComponent(escape(atob(s))) : Buffer.from(s, 'base64').toString('utf8'); }
  function encode(params, defaults) { return b64e(JSON.stringify(diff(defaults, params) || {})); }
  // accepts a code, a whole link with #p=, or the JSON of a v6_outline.json
  function decode(text, defaults) {
    text = String(text || '').trim();
    if (!text) throw new Error('nothing to read');
    var o;
    if (text.charAt(0) === '{') o = JSON.parse(text);
    else { var m = text.match(/[#&?]p=([A-Za-z0-9_\-]+)/); o = JSON.parse(b64d(m ? m[1] : text)); }
    var r = migrate(o, defaults);
    if (!valid(r.params)) throw new Error('that is not a V6 outline');
    return r.params;
  }

  function load(defaults, hash) {
    var note = null, from = 'built-in', p = null, st = get(K.state) || {};
    if (hash && /[#&]p=/.test(hash)) { try { p = decode(hash, defaults); from = 'link'; note = 'Opened from a link. Your own last design is kept under Saved designs as "before the link".'; if (valid(st.params)) putSave('before the link', st.params); } catch (e) { note = 'The link could not be read (' + e.message + ').'; p = null; } }
    if (!p && valid(st.params)) { var r = migrate(st.params, defaults); p = r.params; from = 'saved'; if (r.from_rev) note = 'Your saved design was made with rev ' + r.from_rev + '; it has been brought up to ' + defaults.meta.rev + '. New settings start at their defaults.'; }
    if (!p) { var o = get(K.old); if (valid(o)) { var r2 = migrate(o, defaults); p = r2.params; from = 'saved'; note = 'Your design from the earlier page (rev ' + (r2.from_rev || '?') + ') has been brought up to ' + defaults.meta.rev + '.'; } }
    if (!p) p = clone(defaults);
    return { params: p, ui: st.ui || null, cam: from === 'link' ? null : (st.cam || null), from: from, note: note, storage: !!store };
  }
  function save(params, ui, cam) { return put(K.state, { params: params, ui: ui, cam: cam, t: Date.now() }); }

  function saves() { var s = get(K.saves) || {}; return Object.keys(s).map(function (n) { return { name: n, t: s[n].t, rev: s[n].params && s[n].params.meta && s[n].params.meta.rev }; }).sort(function (a, b) { return b.t - a.t; }); }
  function putSave(name, params) { var s = get(K.saves) || {}; s[name] = { params: clone(params), t: Date.now() }; return put(K.saves, s); }
  function getSave(name, defaults) { var s = get(K.saves) || {}; return s[name] ? migrate(s[name].params, defaults).params : null; }
  function delSave(name) { var s = get(K.saves) || {}; delete s[name]; return put(K.saves, s); }

  // undo: snapshots of the design as text; a step is recorded when the design has stopped changing for a moment
  function History(max) { this.max = max || 80; this.list = []; this.at = -1; }
  History.prototype.push = function (params) {
    var s = JSON.stringify(params);
    if (this.at >= 0 && this.list[this.at] === s) return false;
    this.list = this.list.slice(0, this.at + 1); this.list.push(s);
    if (this.list.length > this.max) this.list.shift();
    this.at = this.list.length - 1; return true;
  };
  History.prototype.canUndo = function () { return this.at > 0; };
  History.prototype.canRedo = function () { return this.at < this.list.length - 1; };
  History.prototype.undo = function () { return this.canUndo() ? JSON.parse(this.list[--this.at]) : null; };
  History.prototype.redo = function () { return this.canRedo() ? JSON.parse(this.list[++this.at]) : null; };

  return { load: load, save: save, saves: saves, putSave: putSave, getSave: getSave, delSave: delSave, encode: encode, decode: decode, merge: merge, diff: diff, migrate: migrate, valid: valid, History: History, available: function () { return !!store; } };
});
