// Jumperless V6 outline tool - the viewer. Everything it draws comes from V6Geo.resolve(params); it holds no geometry of its own.
(function () {
  'use strict';
  var Geo = window.V6Geo, Cat = window.V6Catalog, Exp = window.V6Export, Mag = window.V6Mag, T = window.THREE;
  var MODELS = window.V6_MODELS || {}, PARTMODELS = window.V6_PARTMODELS || {};
  Object.keys(PARTMODELS).forEach(function (k) { MODELS['lib_' + k] = PARTMODELS[k]; });
  var SWITCHMODELS = window.V6_SWITCHMODELS || {};          // the long-travel switches: a group marked mv is the actuator, zm the housing's top under it
  Object.keys(SWITCHMODELS).forEach(function (k) { MODELS[k] = SWITCHMODELS[k]; });
  var REF = window.V6_REF || {}, DEFAULTS = window.V6_DEFAULTS, SKETCH = window.V6_SKETCH || null;
  var KEY = 'v6mech.params';
  var $ = function (id) { return document.getElementById(id); };
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    if (attrs) for (var k in attrs) { if (k === 'text') e.textContent = attrs[k]; else if (k === 'html') e.innerHTML = attrs[k]; else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), attrs[k]); else if (attrs[k] != null) e.setAttribute(k, attrs[k]); }
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }

  // ---------- state: the design (P), how it is being looked at (ui) and the camera all come back after a reload ----------
  var State = window.V6State, Rn = window.V6Render;
  var boot = State.load(DEFAULTS, location.hash);
  var P = boot.params;
  var R = null;
  var ui = { browse: { q: '', group: 'all', mine: false }, sel: null, vsel: null, editOutline: false, sketch: false, sketchOpacity: 0.6, explode: 0, clipAxis: 'off', clipPos: 0.5, envelopes: false, planes: true, hidden: {}, hideShell: false,
    render: { mode: 'real', bg: 'console', bgColor: '#27272b', ground: 'shadow', shadows: true, exposure: 1, light: 1, sun: 215, fov: 30, rotate: false, edges: false, decals: true, wheel: 'pan',
      boardOpacity: 1, texture: 'smooth', shellTex: 'smooth', rig: 'studio', keyColor: '#ffffff', keyLevel: 1, fillColor: '#ffffff', fillLevel: 1, rimColor: '#ffffff', rimLevel: 0, skyColor: '#ffffff', ambLevel: 1 },
    // the view controls that sit in the 3D view itself: where the strip is docked (bottom, top, left, right, off) and what is in it
    viewbar: { dock: 'bottom', items: ['explode', 'extout', 'opacity', 'shell', 'mode'], fold: false },
    layout: { dock: { 'panel-design': 'left', 'panel-checks': 'right' }, w: { left: 348, right: 338 }, h: 300, ratio: { left: 0.55, right: 0.5, bottom: 0.5 }, solo: false, text: 'm' }, fold: { 'Look': true, 'Probe dock': true, 'Saved designs': true, 'Readings': true }, panels: {},
    // the left-to-right flip (rev A12): what stays behind when the board is flipped. humps: { key: 'stay' }; corners: the two top corners' own shapes
    flip: { humps: {}, corners: 'stay', mag: 'flip', said: '' }, humpSaid: '',
    tab: 'outline', mag: { sel: null, parts: true, ref: null } };       // tab: which of the two the page shows, 'outline' or 'mag' (the Magnetometers tab, src/magtab.js)
  if (boot.ui) Object.keys(ui).forEach(function (k) { var v = boot.ui[k]; if (v === undefined) return; if (ui[k] && typeof ui[k] === 'object') { for (var j in v) ui[k][j] = v[j]; } else ui[k] = v; });
  if (boot.from === 'link') { try { history.replaceState(null, '', location.pathname + location.search); } catch (e) { /* a file:// page may refuse */ } }
  if (location.hash === '#magnetometers') ui.tab = 'mag'; else if (ui.tab !== 'mag') ui.tab = 'outline';
  ui.mag.sel = null;
  var magTab = null, sceneStale = false;
  var hist = new State.History(80), saveT = null, histT = null, notice = boot.note || (State.available() ? null : 'This browser is not letting the page keep anything, so the design will not survive a reload here. Use Copy code or Export to keep it.');
  function camState() { return camera ? { p: camera.position.toArray(), t: controls.target.toArray() } : null; }
  function saveView() { clearTimeout(saveT); saveT = setTimeout(function () { State.save(P, ui, camState()); }, 250); }
  function save() { saveView(); clearTimeout(histT); histT = setTimeout(function () { if (hist.push(P)) syncUndo(); }, 400); }
  function syncUndo() { var u = $('btn-undo'), r = $('btn-redo'); if (u) u.disabled = !hist.canUndo(); if (r) r.disabled = !hist.canRedo(); }
  function adopt(p) { P = p; ui.mag.sel = null; if (magTab) magTab.stop(); if (ui.sel && !P.parts.some(function (q) { return q.id === ui.sel; })) ui.sel = null; if (ui.vsel != null && ui.vsel >= P.frame.outline.length) ui.vsel = null; rebuild(true); }
  function undo() { clearTimeout(histT); hist.push(P); var p = hist.undo(); if (p) { adopt(p); syncUndo(); } }
  function redo() { var p = hist.redo(); if (p) { adopt(p); syncUndo(); } }

  // ---------- three ----------
  var view = $('view'), renderer = null, scene, camera, controls, unit, ghost, deco, handles, sketchTex = null;
  var raycaster = T ? new T.Raycaster() : null, pointer = T ? new T.Vector2() : null;
  var clipPlane = T ? new T.Plane(new T.Vector3(-1, 0, 0), 0) : null;
  function cssVar(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
  function initThree() {
    if (!T) return false;
    try { renderer = new T.WebGLRenderer({ antialias: true, alpha: true }); } catch (e) { renderer = null; }
    if (!renderer) { $('fallback').style.display = 'block'; return false; }
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.localClippingEnabled = true;
    view.insertBefore(renderer.domElement, view.firstChild);
    scene = new T.Scene();
    camera = new T.PerspectiveCamera(ui.render.fov || 30, 1, 1, 3000);
    controls = new T.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true; controls.dampingFactor = 0.12; controls.screenSpacePanning = true;
    Rn.setup(renderer, scene);
    controls.addEventListener('end', saveView);
    // Scrolling moves the view and pinching zooms it, about the pointer, the way a page or a map behaves. A mouse wheel can be
    // given its old job (zoom) under View. The wheel is taken here, before OrbitControls sees it; touch screens are left to it.
    function perPx() { return 2 * camera.position.distanceTo(controls.target) * Math.tan(camera.fov * Math.PI / 360) / Math.max(1, view.clientHeight); }
    function panBy(dx, dy) {
      var k = perPx(), d = new T.Vector3().setFromMatrixColumn(camera.matrix, 0).multiplyScalar(dx * k).add(new T.Vector3().setFromMatrixColumn(camera.matrix, 1).multiplyScalar(-dy * k));
      camera.position.add(d); controls.target.add(d);
    }
    function zoomAt(cx, cy, f) {
      var rc = view.getBoundingClientRect(), d = camera.position.distanceTo(controls.target), nd = Math.max(15, Math.min(2200, d * f)), k = perPx(); f = nd / d;
      var p = controls.target.clone().add(new T.Vector3().setFromMatrixColumn(camera.matrix, 0).multiplyScalar((cx - rc.left - rc.width / 2) * k)).add(new T.Vector3().setFromMatrixColumn(camera.matrix, 1).multiplyScalar(-(cy - rc.top - rc.height / 2) * k));
      camera.position.sub(p).multiplyScalar(f).add(p); controls.target.sub(p).multiplyScalar(f).add(p);
    }
    view.addEventListener('wheel', function (ev) {
      if (ev.target !== renderer.domElement) return;
      ev.preventDefault(); ev.stopPropagation();
      var m = ev.deltaMode === 1 ? 16 : ev.deltaMode === 2 ? 400 : 1, dx = ev.deltaX * m, dy = ev.deltaY * m;
      if (ev.ctrlKey || ev.metaKey) zoomAt(ev.clientX, ev.clientY, Math.exp(Math.max(-80, Math.min(80, dy)) * 0.01));               // a pinch, or ctrl + wheel
      else if (ui.render.wheel === 'zoom') zoomAt(ev.clientX, ev.clientY, Math.exp(Math.max(-300, Math.min(300, dy)) * 0.0016));
      else if (ev.shiftKey && !dx) panBy(dy, 0);
      else panBy(dx, dy);
    }, { capture: true, passive: false });
    var pinch = 1;                                                            // Safari reports a pinch as gesture events instead
    view.addEventListener('gesturestart', function (ev) { ev.preventDefault(); pinch = ev.scale || 1; });
    view.addEventListener('gesturechange', function (ev) { ev.preventDefault(); var sc = ev.scale || 1; zoomAt(ev.clientX, ev.clientY, pinch / sc); pinch = sc; });
    view.addEventListener('gestureend', function (ev) { ev.preventDefault(); });
    if (window.ResizeObserver) new ResizeObserver(function () { resize(); }).observe(view);
    window.V6Nav = { panBy: panBy, zoomAt: zoomAt };
    var camT = null; controls.addEventListener('change', function () { if (ui.render.rotate) return; clearTimeout(camT); camT = setTimeout(saveView, 350); });      // the view coasts on after the pointer lets go
    unit = new T.Group(); ghost = new T.Group(); deco = new T.Group(); handles = new T.Group();
    scene.add(unit); scene.add(ghost); scene.add(deco); scene.add(handles);
    window.addEventListener('resize', resize);
    if (window.ResizeObserver) new ResizeObserver(resize).observe(view);
    resize();
    bindPointer();
    (function loop() { requestAnimationFrame(loop); controls.autoRotate = !!ui.render.rotate && !drag; controls.autoRotateSpeed = 1.2; controls.update(); if (ui.tab !== 'mag') renderer.render(scene, camera); })();       // nothing is drawn in 3D while the Magnetometers tab has the view
    return true;
  }
  var lastMode = null;
  // the design's look plus the view's surface choices, for the materials
  function lookNow(extra) { var o = {}, k; for (k in P.look) o[k] = P.look[k]; o.texture = ui.render.texture; o.shellTex = ui.render.shellTex; for (k in (extra || {})) o[k] = extra[k]; return o; }
  // what stands to the right of the unit: the extender (when it is on that side), then the next unit. extraLeft: an extender on the left
  function extraWide() { return R ? (P.show.neighbour ? R.planes.pitch : 0) + (R.extender ? Math.max(0, R.extender.x1 - R.planes.xr) : 0) : 0; }
  function extraLeft() { return R && R.extender ? Math.max(0, R.planes.x0 - R.extender.x0) : 0; }
  function applyRender() {
    if (!renderer || !R) return;
    var pl = R.planes, wide = extraWide();
    Rn.apply(ui.render, { x0: pl.x0 - extraLeft(), x1: pl.x1 + wide, y0: pl.yt, y1: pl.yb, zb: R.z.bottom - (R.wig.face ? 0 : 0) - 1.5 });
    if (camera.fov !== ui.render.fov) { camera.fov = ui.render.fov || 30; camera.updateProjectionMatrix(); }
    if (lastMode !== ui.render.mode) { lastMode = ui.render.mode; Rn.refreshMaterials(scene); }
    view.setAttribute('data-bg', ui.render.bg);
    view.setAttribute('data-ground', ui.render.mode === 'lines' ? '' : ui.render.ground);
  }
  function resize() {
    if (!renderer) return;
    var w = Math.max(1, view.clientWidth), h = Math.max(1, view.clientHeight);
    renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
  }
  function setView(name) {
    if (!camera) return;
    // look along a fixed direction and back off until the whole unit fits the viewport
    var pl = R ? R.planes : { x0: -8.3, x1: 78.74, yt: -24.7, yb: 55 }, wide = extraWide(), wl = extraLeft();
    var t = [(pl.x0 - wl + pl.x1 + wide) / 2, 2.5, (pl.yt + pl.yb) / 2];
    var dir = { iso: [-0.42, 0.72, 0.62], top: [0, 1, 0.001], under: [-0.25, -0.85, 0.45], left: [-1, 0.22, 0.05], topedge: [0.05, 0.3, -1], bottomedge: [0, 0.3, 1] }[name] || [-0.42, 0.72, 0.62];
    var len = Math.sqrt(dir[0] * dir[0] + dir[1] * dir[1] + dir[2] * dir[2]);
    var rad = 0.5 * Math.sqrt(Math.pow(pl.x1 - pl.x0 + wide + wl, 2) + Math.pow(pl.yb - pl.yt, 2)) + 6;
    var half = camera.fov * Math.PI / 360, fit = Math.min(half, Math.atan(Math.tan(half) * camera.aspect));
    var dist = rad / Math.sin(fit) * 1.02;
    camera.position.set(t[0] + dir[0] / len * dist, t[1] + dir[1] / len * dist, t[2] + dir[2] / len * dist);
    controls.target.set(t[0], t[1], t[2]); controls.update(); saveView();
  }

  // materials
  var mats = {};
  function mat(color, o) {
    o = o || {};
    var key = color + ':' + (o.opacity || 1) + ':' + (o.metal || 0) + ':' + (o.side || 0);
    if (!mats[key]) mats[key] = new T.MeshStandardMaterial({ envMapIntensity: 0.6, color: color, roughness: o.rough != null ? o.rough : 0.7, metalness: o.metal || 0.05, transparent: (o.opacity || 1) < 1, opacity: o.opacity || 1, depthWrite: (o.opacity || 1) >= 1, side: o.side ? T.DoubleSide : T.FrontSide });
    return mats[key];
  }
  var lineMat = T ? new T.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.35 }) : null;
  var ghostMat = T ? new T.MeshStandardMaterial({ color: 0x7f8891, transparent: true, opacity: 0.22, depthWrite: false, roughness: 1 }) : null;

  function extrude(polys, z0, z1, material, edges) {
    var shapes = polys.map(function (e) {
      var s = new T.Shape(e.outer.map(function (q) { return new T.Vector2(q[0], -q[1]); }));
      (e.holes || []).forEach(function (h) { s.holes.push(new T.Path(h.map(function (q) { return new T.Vector2(q[0], -q[1]); }))); });
      return s;
    });
    var g = new T.ExtrudeGeometry(shapes, { depth: Math.max(0.001, z1 - z0), bevelEnabled: false, curveSegments: 1 });
    g.rotateX(-Math.PI / 2); g.translate(0, z0, 0);          // world: X = x, Y = z (up), Z = plan y
    var m = new T.Mesh(g, material);
    if (edges !== false) { var ls = new T.LineSegments(new T.EdgesGeometry(g, 30), lineMat); ls.userData.edge = true; m.add(ls); m.userData.hasEdges = true; }
    return m;
  }
  function b64(s) { var bin = atob(s), n = bin.length, u = new Uint8Array(n); for (var i = 0; i < n; i++) u[i] = bin.charCodeAt(i); return u.buffer; }
  var geoCache = {};
  // An actuator drawn pressed: every point of it goes down by the travel and stops at the housing's top (zm); what is already below stays.
  // So a plunger's wall shortens, and a rubber cap that goes further than it stands proud ends flat on the housing.
  function pressedGeo(name, i, e, press, zm) {
    var key = name + '|pressed|' + press + '|' + i; if (geoCache[key]) return geoCache[key];
    var g = e.geo.clone(), p = g.attributes.position.array, floor = zm == null ? -1e9 : zm;
    for (var j = 1; j < p.length; j += 3) p[j] = p[j] - press >= floor ? p[j] - press : Math.min(p[j], floor - 0.02);      // 0.02 under, so a flattened skirt does not flicker against the housing's top
    g.attributes.position.needsUpdate = true; g.computeVertexNormals(); g.userData = { keep: true }; geoCache[key] = g; return g;
  }
  // how far a part's actuator is drawn pressed: its travel when the part is ticked Pressed or all buttons are shown pressed, else 0
  function pressOf(p) { var c = Cat.parts[p.type], u = c && c.travel ? userPart(p.id) : null; return c && c.travel && (P.show.pressed || (u && u.pressed)) ? c.travel : 0; }
  function model(name, press) {
    var m = MODELS[name]; if (!m) return null;
    if (!geoCache[name]) geoCache[name] = m.groups.map(function (gr) {
      var src = gr.q ? new Int16Array(b64(gr.pos)) : new Float32Array(b64(gr.pos)), out = new Float32Array(src.length), k = gr.q ? m.s : 1;
      for (var i = 0; i < src.length; i += 3) { out[i] = src[i] * k; out[i + 1] = src[i + 2] * k; out[i + 2] = -src[i + 1] * k; }   // model (x, y, z up) -> (x, z, plan y = -y)
      var g = new T.BufferGeometry();
      g.setAttribute('position', new T.BufferAttribute(out, 3));
      g.setIndex(new T.BufferAttribute(gr.i32 ? new Uint32Array(b64(gr.idx)) : new Uint16Array(b64(gr.idx)), 1));
      g.computeVertexNormals(); g.userData.keep = true;
      var c = gr.color, lum = Math.max(c[0], c[1], c[2]);
      var col = new T.Color(Math.max(c[0], 0.045), Math.max(c[1], 0.045), Math.max(c[2], 0.05));
      return { geo: g, mv: !!gr.mv, mat: new T.MeshStandardMaterial({ color: col, roughness: lum > 0.5 ? 0.3 : 0.55, metalness: (c[0] > c[2] * 1.5 && lum > 0.4) || lum > 0.7 ? 0.85 : 0.1 }) };
    });
    var grp = new T.Group();
    geoCache[name].forEach(function (e, i) { grp.add(new T.Mesh(e.mv && press ? pressedGeo(name, i, e, press, m.zm) : e.geo, e.mat)); });
    return grp;
  }

  function holesMesh(x0, y0, z, color) {
    var w = R.wig, pos = [], idx = [], h = 0.95, n = 0;
    w.cols.forEach(function (cx) { w.rows.forEach(function (cy) {
      pos.push(cx - h, z, cy - h, cx + h, z, cy - h, cx + h, z, cy + h, cx - h, z, cy + h);
      idx.push(n, n + 2, n + 1, n, n + 3, n + 2); n += 4;
    }); });
    var g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(new Float32Array(pos), 3)); g.setIndex(idx); g.computeVertexNormals();
    return new T.Mesh(g, new T.MeshBasicMaterial({ color: color }));
  }

  function partObject(p) {
    var grp = new T.Group(); grp.userData.partId = p.id;
    var selected = ui.sel === p.id;
    function bodies(material, list) { (list || p.bodies).forEach(function (b) { if (!b.slot && !b.glass) grp.add(extrude([{ outer: b.pts, holes: [] }], b.z0, b.z1, material)); }); }
    var mode = ui.render.mode, real = mode === 'real';
    if (p.type === 'bb_shell') {
      if (!ui.hideShell) {
        bodies(Rn.shell(mode, lookNow()));
        if (!R.wig.face) { if (real) grp.add(Rn.shellDecal(R.wig, P.look, p.z1 + 0.012)); else grp.add(holesMesh(0, 0, p.z1 + 0.02, 0xa67c2e)); }
        grp.traverse(function (o) { o.userData.lineColor = 0x8c8c98; });
      }
    } else if (p.type === 'bb_face') {
      if (!ui.hideShell) {
        var fc = R.wig.face, b0 = p.bodies[0];
        if (fc.holes) {              // the real board: every hole cut through at its small diameter; the countersinks and lands are painted on
          var key = 'face:' + fc.holes.length + ':' + fc.y0 + ':' + b0.z0 + ':' + b0.z1;
          if (!geoCache[key]) {
            var holes = fc.holes.map(function (h) { var a = [], n = h[3] > 1 ? 14 : 8; for (var i = 0; i < n; i++) a.push([h[0] + Math.cos(i / n * 6.2832) * h[3] / 2, h[1] - Math.sin(i / n * 6.2832) * h[3] / 2]); return a; });
            var fm = extrude([{ outer: b0.pts, holes: holes }], b0.z0, b0.z1, null, false); fm.geometry.userData.keep = true; geoCache[key] = fm.geometry;
          }
          var mk = Rn.MASK[P.look.face_mask] || Rn.MASK.black;
          var face = new T.Mesh(geoCache[key], real ? Rn.board(mode, mk, lookNow({ mask: P.look.face_mask, plated: true })) : mat(0xc9a43a, { metal: 0.6, rough: 0.4 }));
          face.userData.lineColor = 0xd9b441; grp.add(face);
          if (real) grp.add(Rn.faceDecal(fc, P.look, b0.z1 + 0.012));
          var ol = new T.LineSegments(new T.EdgesGeometry(new T.ExtrudeGeometry(new T.Shape(b0.pts.map(function (q) { return new T.Vector2(q[0], -q[1]); })), { depth: 0.001, bevelEnabled: false }).rotateX(-Math.PI / 2).translate(0, b0.z1, 0), 30), lineMat); ol.userData.edge = true; face.add(ol); face.userData.hasEdges = true;
        } else { bodies(mat(0xc9a43a, { metal: 0.6, rough: 0.4 })); grp.add(holesMesh(0, 0, p.z1 + 0.02, 0x1a1a1a)); }
      }
    } else if (p.type === 'wig_pcb') {
      bodies(real ? Rn.board(mode, '#15201a', lookNow()) : mat(0x15201a, { rough: 0.6 }));
      if (real && R.wig.card_holes && R.wig.card_holes.length) grp.add(Rn.padsDecal(R.wig.card_holes, P.look, p.z1 + 0.012));
      grp.traverse(function (o) { o.userData.lineColor = 0x70f899; });
    } else if (p.type === 'probe') {
      var pr = R.probe, len = pr.y1 - pr.y0;
      var c = new T.Mesh(new T.CylinderGeometry(pr.dia / 2, pr.dia / 2, len - 3, 24), mat(0xd9dcdf, { metal: 0.5, rough: 0.35 }));
      c.rotation.x = Math.PI / 2; c.position.set(pr.x, pr.zc, pr.y0 + 3 + (len - 3) / 2); grp.add(c);
      var tip = new T.Mesh(new T.CylinderGeometry(pr.dia / 2, 0.4, 3, 24), mat(0x2b2b2b));
      tip.rotation.x = Math.PI / 2; tip.position.set(pr.x, pr.zc, pr.y0 + 1.5); grp.add(tip);
      var mg = new T.Mesh(new T.CylinderGeometry(pr.magnet.dia / 2 + 0.05, pr.magnet.dia / 2 + 0.05, pr.magnet.len, 16), mat(0xd43c2f));
      mg.rotation.x = Math.PI / 2; mg.position.set(pr.magnet.x, pr.magnet.z, pr.magnet.y); grp.add(mg);
    } else {
      var hasModel = p.model && MODELS[p.model.name];
      if (hasModel) {
        var outer = new T.Group(), inner = new T.Group();
        outer.position.set(p.x, p.zPlane, p.y); outer.rotation.y = p.rot * Math.PI / 180;
        if (p.bottom) inner.rotation.z = Math.PI;
        inner.add(model(p.model.name, pressOf(p)));
        (p.extra || []).forEach(function (n) { var m = model(n); if (m) inner.add(m); });
        outer.add(inner); grp.add(outer);
        if (ui.envelopes || selected) bodies(new T.MeshBasicMaterial({ color: selected ? 0xffb300 : 0x2277dd, wireframe: true, transparent: true, opacity: 0.5 }));
      } else {
        bodies(real ? Rn.part(mode, p.color != null ? p.color : 0x888888) : mat(p.color != null ? p.color : 0x888888, { metal: 0.3, rough: 0.5 }));
        if (selected) bodies(new T.MeshBasicMaterial({ color: 0xffb300, wireframe: true, transparent: true, opacity: 0.6 }));
      }
      if (P.show.plugged !== false) bodies(mat(0x2d7fd0, { opacity: 0.28, side: 1 }), p.ghosts);
      var pc = Cat.parts[p.type];
      var pane = p.bodies.filter(function (b) { return b.glass; })[0];     // a pane let into the board above the module: the picture goes under it
      if (real && pc && pc.screen && P.look.screen !== false) grp.add(Rn.screenMesh(p, pc.screen, (pane ? pane.z0 : p.z1) + 0.015));
      if (pane) grp.add(extrude([{ outer: pane.pts, holes: [] }], pane.z0, pane.z1, mat(0xbfe6f2, { opacity: real ? 0.16 : 0.35, side: 1 })));
    }
    return grp;
  }

  // The extender (rev A11): the narrow breadboard standing against the unit's right side, from R.extender. Its boards, shell and
  // top board are drawn like the unit's own; its header in black with gold pins; the staples and the rail jumpers as bent wire.
  function extenderObject() {
    var E = R.extender, grp = new T.Group(), mode = ui.render.mode, real = mode === 'real', nL = R.layers.length, LC = Exp.LAYER_COLORS;
    grp.userData.ext = true;
    function slab(shape, z, material, lineColor, lift, isBoard) {
      if (!shape || !shape.length || !z) return null;
      var m = extrude(shape, z[0], z[1], material);
      m.position.y = (lift || 0) * ui.explode; m.userData.lineColor = lineColor; m.children.forEach(function (ch) { ch.userData.lineColor = lineColor; });
      if (isBoard) m.traverse(function (x) { if (x.isMesh) x.userData.isBoard = true; });
      grp.add(m); return m;
    }
    if (!ui.hidden[R.layers[0].id]) slab(E.shapes.board, E.z.board, Rn.board(mode, LC[0], lookNow()), parseInt(LC[0].slice(1), 16), 0, true);
    if (E.z.cover && !ui.hidden[R.layers[nL - 1].id]) { var lcT = LC[(nL - 1) % LC.length]; slab(E.shapes.cover, E.z.cover, Rn.board(mode, lcT, lookNow()), parseInt(lcT.slice(1), 16), nL - 1, true); }
    if (!ui.hideShell) {
      slab(E.shapes.shell, E.z.shell, Rn.shell(mode, lookNow()), 0x8c8c98, 0, false);
      if (E.z.face && E.shapes.face.length) {         // its top board: every hole cut through, the countersinks and lands painted on, as on the wig's
        var fo = E.shapes.face[0].outer, sig = [E.x1, E.n_cols, E.dead, E.keyed, E.z.face[0], E.z.face[1]].join(':'), key = 'extface:' + sig;
        if (!geoCache[key]) {
          var holes = E.holes.map(function (h) { var a = [], n = h[3] > 1 ? 14 : 8; for (var i = 0; i < n; i++) a.push([h[0] + Math.cos(i / n * 6.2832) * h[3] / 2, h[1] - Math.sin(i / n * 6.2832) * h[3] / 2]); return a; });
          var fm = extrude([{ outer: fo, holes: holes }], E.z.face[0], E.z.face[1], null, false); fm.geometry.userData.keep = true; geoCache[key] = fm.geometry;
        }
        var mk = Rn.MASK[P.look.face_mask] || Rn.MASK.black;
        var face = new T.Mesh(geoCache[key], real ? Rn.board(mode, mk, lookNow({ mask: P.look.face_mask, plated: true })) : mat(0xc9a43a, { metal: 0.6, rough: 0.4 }));
        face.userData.lineColor = 0xd9b441; grp.add(face);
        if (real) { var dc = Rn.faceDecal({ holes: E.holes, pts: fo, y0: 'ext:' + sig }, P.look, E.z.face[1] + 0.012); if (dc) grp.add(dc); }
      } else {                                        // no top board: the holes as squares on the shell
        var pos = [], idx = [], n0 = 0, hh = 0.95, zt = E.z.shell[1] + 0.02;
        E.cols.forEach(function (cx) { E.rows.forEach(function (cy) { pos.push(cx - hh, zt, cy - hh, cx + hh, zt, cy - hh, cx + hh, zt, cy + hh, cx - hh, zt, cy + hh); idx.push(n0, n0 + 2, n0 + 1, n0, n0 + 3, n0 + 2); n0 += 4; }); });
        var hg = new T.BufferGeometry(); hg.setAttribute('position', new T.BufferAttribute(new Float32Array(pos), 3)); hg.setIndex(idx); hg.computeVertexNormals();
        grp.add(new T.Mesh(hg, new T.MeshBasicMaterial({ color: 0xa67c2e })));
      }
    }
    // the header on its head: the plastic as its box, the two rows of pins one by one (they are inside the socket when it is plugged in)
    var gold = real ? Rn.part(mode, 0xd9b441, { metal: 0.85 }) : mat(0xd9b441, { metal: 0.6, rough: 0.3 }), black = real ? Rn.part(mode, 0x141414, { metal: 0.05 }) : mat(0x141414, { rough: 0.6 });
    E.parts.forEach(function (p) { p.bodies.forEach(function (b) { if (b.name !== 'pins') grp.add(extrude([{ outer: b.pts, holes: [] }], b.z0, b.z1, black)); }); });
    var prs = E.port && E.port.press;
    // pressed in from the back (rev A11e): the pins stand upright on the tab, two rows, from the header's base up to the socket's top
    if (prs) {             // read from the header's own pins body, so they are right whichever side the extender is on
      var pb = null; E.parts.forEach(function (p) { p.bodies.forEach(function (b) { if (b.name === 'pins') pb = b; }); });
      if (pb) { var bx0 = 1e9, bx1 = -1e9, by0 = 1e9; pb.pts.forEach(function (q) { bx0 = Math.min(bx0, q[0]); bx1 = Math.max(bx1, q[0]); by0 = Math.min(by0, q[1]); }); var pl = pb.z1 - pb.z0;
        for (var k2 = 0; k2 < E.header.n; k2++) [bx0 + 0.2, bx1 - 0.2].forEach(function (px) { var vp = new T.Mesh(new T.BoxGeometry(0.4, pl, 0.4), gold); vp.position.set(px, pb.z0 + pl / 2, by0 + 0.2 + k2 * 1.27); grp.add(vp); }); }
    }
    else for (var k = 0; k < E.header.n; k++) [0.95, 2.22].forEach(function (pz) {
      var pin = new T.Mesh(new T.BoxGeometry(6.6, 0.4, 0.4), gold); pin.position.set(E.header.pin_x, pz, E.header.pin_y + k * E.header.step); grp.add(pin);
    });
    // a staple or a jumper: a bridge lying on the top face and a leg down the hole at each end
    function wireU(x0, x1, y, dia, leg, color) {
      var m = real ? Rn.part(mode, color, { metal: 0.9, rough: 0.3 }) : mat(color, { metal: 0.6, rough: 0.3 }), r = dia / 2, zt = E.z.top;
      var br = new T.Mesh(new T.CylinderGeometry(r, r, x1 - x0, 10), m); br.rotation.z = Math.PI / 2; br.position.set((x0 + x1) / 2, zt + r, y); grp.add(br);
      [x0, x1].forEach(function (x) { var lg = new T.Mesh(new T.CylinderGeometry(r, r, leg + r, 10), m); lg.position.set(x, zt + r - (leg + r) / 2, y); grp.add(lg); });
    }
    if (!ui.hideShell) {
      E.ties.list.forEach(function (t) { wireU(t.x0, t.x1, t.y, E.ties.wire, 5, 0xc8ccd2); });
      E.jumpers.forEach(function (t) { wireU(t.x0, t.x1, t.y, 0.64, 6, 0xd9b441); });
    }
    // the extender moved away for a look at the joint: straight down when it presses in from the back, to the right when it slides in sideways
    var xo = +ui.extOut || 0; if (xo) { if (prs) grp.position.y = -xo; else grp.position.x = E.side === 'left' ? -xo : xo; }
    return grp;
  }

  function header40() {
    var grp = new T.Group(), s = P.show, pitch = P.grid.pitch, rows = R.wig.rows;
    var cy = rows[Math.max(0, Math.min(rows.length - 1, s.header40_row | 0))], c0 = Math.max(1, s.header40_col | 0);
    var z = R.z.bbTop, x0 = c0 * pitch, x1 = (c0 + 39) * pitch;
    var body = new T.Mesh(new T.BoxGeometry(x1 - x0 + pitch, 2.5, pitch), mat(0x101010)); body.position.set((x0 + x1) / 2, z + 1.25, cy); grp.add(body);
    for (var k = 0; k < 40; k++) {
      var x = (c0 + k) * pitch, st = pinState(x);
      var pin = new T.Mesh(new T.BoxGeometry(0.64, 11.5, 0.64), mat(st === 'hole' ? 0xd9b441 : st === 'next' ? 0x35a56a : 0xd43c2f, { metal: 0.6, rough: 0.3 }));
      pin.position.set(x, z + 2.75, cy); grp.add(pin);          // 3 mm into the hole, 2.5 mm of plastic, 6 mm above
    }
    return grp;
  }
  function pinState(x) {            // where a 0.1" pin at x lands: this unit's hole, the neighbour's hole, or a dead row
    var pitch = P.grid.pitch, n = P.grid.cols, k = x / pitch;
    if (Math.abs(k - Math.round(k)) < 1e-6 && Math.round(k) >= 1 && Math.round(k) <= n) return 'hole';
    var kn = (x - R.planes.pitch) / pitch;
    if (Math.abs(kn - Math.round(kn)) < 1e-6 && Math.round(kn) >= 1 && Math.round(kn) <= n) return 'next';
    return 'dead';
  }

  function buildScene() {
    if (!renderer) return;
    [unit, ghost, deco, handles].forEach(function (g) { while (g.children.length) { var c = g.children.pop(); c.traverse(function (o) { if (o.geometry && !o.geometry.userData.keep) o.geometry.dispose(); }); } });
    var idx = {}; R.layers.forEach(function (L, i) { idx[L.id] = i; });
    R.layers.forEach(function (L, i) {
      if (ui.hidden[L.id] || !L.shape.length) return;
      var lc = Exp.LAYER_COLORS[i % Exp.LAYER_COLORS.length];
      var m = extrude(L.shape, L.z0, L.z1, Rn.board(ui.render.mode, lc, lookNow()));
      m.position.y = i * ui.explode; m.userData.layerId = L.id; m.userData.lineColor = parseInt(lc.slice(1), 16); m.children.forEach(function (ch) { ch.userData.lineColor = m.userData.lineColor; });
      if (ui.render.mode === 'real' && ui.render.decals !== false && !(drag && drag.moved)) { var dc = Rn.boardDecal(L, R.parts, { x0: R.planes.x0 - 2, x1: R.planes.x1 + 2, y0: R.planes.yt - 2, y1: R.planes.yb + 2 }, P.look); if (dc) m.add(dc); }
      m.traverse(function (x) { if (x.isMesh) x.userData.isBoard = true; });      // Board opacity fades these
      unit.add(m);
    });
    R.parts.forEach(function (p) {
      var o = partObject(p), li = p.mountLayer != null && idx[p.mountLayer] != null ? idx[p.mountLayer] : 0;
      if (p.mountLayer && ui.hidden[p.mountLayer] && !p.system) return;
      o.position.y = li * ui.explode; unit.add(o);
    });
    if (P.show.sensors) {
      var s = R.wig.sensors;
      // a sensor from mag.list knows its board's face (face, dir) and rides that board when the stack is exploded; an older layout's sits on the wig PCB
      function sensorBox(q, w, h, d, col) { var b = new T.Mesh(new T.BoxGeometry(w, h, d), mat(col)), li = q.on && idx[q.on] != null ? idx[q.on] : 0; b.position.set(q.x, (q.face != null ? q.face + q.dir * h / 2 : (q.side === 'F' ? h / 2 : -R.wig.pcb_t - h / 2)) + li * ui.explode, q.y); if (!(q.on && q.on !== 'wig' && ui.hidden[q.on])) unit.add(b); }
      s.mmc.forEach(function (q) { sensorBox(q, 0.9, 0.5, 0.9, 0x18b7c9); });
      s.tmag.forEach(function (q) { sensorBox(q, 2.9, 1.1, 1.6, 0xc0399f); });
    }
    if (R.extender) unit.add(extenderObject());
    Rn.finish([unit], ui.render);
    if (P.show.neighbour) {
      var g = unit.clone(true);
      g.children.slice().forEach(function (ch) { if (ch.userData.ext) g.remove(ch); });      // the next unit is a unit, not a second extender
      g.traverse(function (o) { if (o.isMesh) { o.material = ghostMat; o.castShadow = false; if (o.userData.decal) o.visible = false; } if (o.isLineSegments) o.visible = false; });
      g.position.x = R.planes.pitch + (R.extender ? Math.max(0, R.extender.x1 - R.planes.xr) : 0); ghost.add(g);      // past the extender, where there is one on that side
    }
    if (P.show.header40) deco.add(header40());
    var cp = R.checks.grid.coupler;
    if (cp && (P.show.coupler || P.show.neighbour)) {          // the edge coupler, centred in the space between this unit's breadboard and the next
      var cm = new T.Mesh(new T.BoxGeometry(cp.across, cp.thick, cp.len), new T.MeshStandardMaterial({ color: cp.fits ? 0xfc0289 : 0xff4d3d, transparent: true, opacity: 0.55, roughness: 0.5, depthWrite: false }));
      cm.position.set((cp.x0 + cp.x1) / 2, cp.zc, cp.yc); cm.add(new T.LineSegments(new T.EdgesGeometry(cm.geometry), new T.LineBasicMaterial({ color: 0xfc0289 }))); deco.add(cm);
    }
    if (ui.planes) {
      [R.planes.xl, R.planes.xr].forEach(function (x) {
        var pl = new T.Mesh(new T.PlaneGeometry(R.planes.yb - R.planes.yt + 10, 18), new T.MeshBasicMaterial({ color: 0xd43c2f, transparent: true, opacity: 0.1, side: T.DoubleSide, depthWrite: false }));
        pl.rotation.y = Math.PI / 2; pl.position.set(x, 3, (R.planes.yt + R.planes.yb) / 2); deco.add(pl);
      });
    }
    if (P.show.neighbour || P.show.header40) {       // mark where dead-row pins would land
      var zs = R.z.top + 0.04, mk = new T.MeshBasicMaterial({ color: 0xd43c2f });
      R.checks.grid.dead_x.forEach(function (dx) { [0, R.planes.side === 'right' ? -R.planes.pitch : R.planes.pitch].forEach(function (off) { R.wig.rows.forEach(function (cy) {
        var q = new T.Mesh(new T.PlaneGeometry(1.1, 1.1), mk); q.rotation.x = -Math.PI / 2; q.position.set(dx + off, Math.max(zs, R.z.bbTop + 0.04), cy); deco.add(q);
      }); }); });
    }
    if (ui.sketch && SKETCH) {                         // Kevin's notebook page, rectified, lying just above the top face
      if (!sketchTex) { sketchTex = new T.TextureLoader().load(SKETCH.src); sketchTex.minFilter = T.LinearFilter; sketchTex.encoding = T.sRGBEncoding; }
      var sw = SKETCH.x1 - SKETCH.x0, sh = SKETCH.y1 - SKETCH.y0, sg = new T.PlaneGeometry(sw, sh);
      sg.rotateX(-Math.PI / 2);
      var sm = new T.Mesh(sg, new T.MeshBasicMaterial({ map: sketchTex, transparent: true, opacity: ui.sketchOpacity, depthWrite: false, depthTest: false }));
      sm.position.set((SKETCH.x0 + SKETCH.x1) / 2, Math.max(R.z.top, R.z.bbTop) + 0.3, (SKETCH.y0 + SKETCH.y1) / 2); sm.renderOrder = 5; deco.add(sm);
    }
    if (ui.editOutline || ui.sketch) {                 // the outline as a line, and its vertices as dots to drag
      var hy = Math.max(R.z.top, R.z.bbTop) + 0.45, lp = [];
      RO().pts.concat([RO().pts[0]]).forEach(function (q) { lp.push(new T.Vector3(q[0], hy, q[1])); });
      var ol = new T.Line(new T.BufferGeometry().setFromPoints(lp), new T.LineBasicMaterial({ color: 0xe0245e, depthTest: false })); ol.renderOrder = 6; handles.add(ol);
    }
    if (ui.editOutline) {
      var hy2 = Math.max(R.z.top, R.z.bbTop) + 0.5, cp = [];
      RO().verts.concat([RO().verts[0]]).forEach(function (q) { cp.push(new T.Vector3(q.x, hy2, q.y)); });
      var cl = new T.Line(new T.BufferGeometry().setFromPoints(cp), new T.LineBasicMaterial({ color: 0x1f6fd0, transparent: true, opacity: 0.45, depthTest: false })); cl.renderOrder = 6; handles.add(cl);
      RO().verts.forEach(function (q, i) {
        var on = ui.vsel === i || (ui.vmulti || []).indexOf(i) >= 0, ds = +ui.dotSize || 0.85, hm = new T.Mesh(new T.SphereGeometry((on ? 1.35 : 1) * ds, 16, 12), new T.MeshBasicMaterial({ color: on ? 0xffb300 : 0x1f6fd0, depthTest: false }));
        hm.position.set(q.x, hy2, q.y); hm.renderOrder = 7; hm.userData.vertex = i; handles.add(hm);
      });
    }
    Rn.linear([unit, ghost, deco, handles]);
    applyClip(); applyRender();
  }
  function applyClip() {
    if (!renderer) return;
    if (ui.clipAxis === 'off') { renderer.clippingPlanes = []; return; }
    var pl = R.planes, t = ui.clipPos;
    if (ui.clipAxis === 'x') { clipPlane.normal.set(-1, 0, 0); clipPlane.constant = pl.x0 - extraLeft() - 1 + t * (pl.x1 + extraWide() - pl.x0 + extraLeft() + 2); }
    else if (ui.clipAxis === 'y') { clipPlane.normal.set(0, 0, -1); clipPlane.constant = pl.yt - 1 + t * (pl.yb - pl.yt + 2); }
    else { clipPlane.normal.set(0, -1, 0); clipPlane.constant = R.z.bottom - 6 + t * (R.z.top - R.z.bottom + 9 + R.layers.length * ui.explode); }
    renderer.clippingPlanes = [clipPlane];
  }

  // ---------- pointer: hover, select, drag parts in plan ----------
  var drag = null, pending = false;
  function pickPart(ev) {
    var r = renderer.domElement.getBoundingClientRect();
    pointer.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
    raycaster.setFromCamera(pointer, camera);
    var hits = raycaster.intersectObjects(unit.children, true);
    for (var i = 0; i < hits.length; i++) {
      if (hits[i].object.isLineSegments) continue;
      if (renderer.clippingPlanes.length && clipPlane.distanceToPoint(hits[i].point) < 0) continue;
      var o = hits[i].object;
      while (o && !o.userData.partId && !o.userData.layerId) o = o.parent;
      if (o && o.userData.partId) return { id: o.userData.partId, point: hits[i].point };
      if (o && o.userData.layerId) return { layer: o.userData.layerId, point: hits[i].point };
    }
    return null;
  }
  function pickVertex(ev) {
    if (!ui.editOutline) return null;
    var r = renderer.domElement.getBoundingClientRect();
    pointer.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
    raycaster.setFromCamera(pointer, camera);
    var hits = raycaster.intersectObjects(handles.children, false);
    for (var i = 0; i < hits.length; i++) if (hits[i].object.userData.vertex != null) return { vertex: hits[i].object.userData.vertex, point: hits[i].object.position.clone() };
    return null;
  }
  function userPart(id) { for (var i = 0; i < P.parts.length; i++) if (P.parts[i].id === id) return P.parts[i]; return null; }
  function resolved(id) { for (var i = 0; i < R.parts.length; i++) if (R.parts[i].id === id) return R.parts[i]; return null; }
  function bindPointer() {
    var dom = renderer.domElement, tip = $('tip');
    dom.addEventListener('pointerdown', function (ev) {
      if (ev.button !== 0) return;
      var hv = pickVertex(ev);
      if (hv) {
        // shift-click adds a dot to the selection or takes it out; a plain press on a dot that is not selected starts a new one.
        // Dragging one of the selected dots moves them all by the same amount.
        var q0 = OV()[hv.vertex], vm0 = VM(), at0 = vm0.indexOf(hv.vertex);
        if (ev.shiftKey) { if (at0 >= 0 && vm0.length > 1) vm0.splice(at0, 1); else if (at0 < 0) vm0.push(hv.vertex); } else if (at0 < 0) ui.vmulti = vm0 = [hv.vertex];
        ui.vsel = hv.vertex; ui.sel = null;
        drag = { vertex: hv.vertex, x0: q0.x, y0: q0.y, group: vm0.filter(function (i) { return i !== hv.vertex; }).map(function (i) { return { i: i, x: OV()[i].x, y: OV()[i].y }; }), plane: new T.Plane(new T.Vector3(0, 1, 0), -hv.point.y), dx: q0.x - hv.point.x, dy: q0.y - hv.point.z, moved: false }; controls.enabled = false; dom.setPointerCapture(ev.pointerId);
        rebuild(true); return;
      }
      var h = pickPart(ev);
      if (h && h.id) {
        var changed = ui.sel !== h.id; ui.sel = h.id;
        var u = userPart(h.id);
        if (u) { drag = { id: h.id, plane: new T.Plane(new T.Vector3(0, 1, 0), -h.point.y), dx: u.x - h.point.x, dy: u.y - h.point.z, moved: false }; controls.enabled = false; dom.setPointerCapture(ev.pointerId); }
        if (changed) { rebuild(true); }
      }
    });
    dom.addEventListener('pointermove', function (ev) {
      if (drag) {
        var r = dom.getBoundingClientRect();
        pointer.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
        raycaster.setFromCamera(pointer, camera);
        var pt = new T.Vector3();
        if (!raycaster.ray.intersectPlane(drag.plane, pt)) return;
        var u = drag.vertex != null ? OV()[drag.vertex] : userPart(drag.id), step = ev.shiftKey ? 1.27 : 0.05;
        u.x = Math.round((pt.x + drag.dx) / step) * step; u.y = Math.round((pt.z + drag.dy) / step) * step;
        u.x = +u.x.toFixed(3); u.y = +u.y.toFixed(3); drag.moved = true;
        if (drag.vertex != null) {
          var ovl = OV(), nV = ovl.length, moving = (drag.group || []).map(function (g) { return g.i; }).concat([drag.vertex]);
          // a little snap: within 0.6 mm of a neighbour's x or y the edge to it goes vertical or horizontal (a neighbour that moves along does not count)
          if (ui.snapHV !== false && !ev.altKey) [(drag.vertex + nV - 1) % nV, (drag.vertex + 1) % nV].forEach(function (ni) { if (moving.indexOf(ni) >= 0) return; var nb = ovl[ni]; if (Math.abs(u.x - nb.x) < 0.6) u.x = nb.x; if (Math.abs(u.y - nb.y) < 0.6) u.y = nb.y; });
          (drag.group || []).forEach(function (g) { ovl[g.i].x = +(g.x + u.x - drag.x0).toFixed(3); ovl[g.i].y = +(g.y + u.y - drag.y0).toFixed(3); });
        }
        if (!pending) { pending = true; requestAnimationFrame(function () { pending = false; rebuild(false, true); }); }
        return;
      }
      var hv2 = pickVertex(ev);
      if (hv2) { tip.textContent = 'outline vertex ' + (hv2.vertex + 1) + ' (drag to move)'; tip.style.display = 'block'; var vr0 = view.getBoundingClientRect(); tip.style.left = (ev.clientX - vr0.left + 14) + 'px'; tip.style.top = (ev.clientY - vr0.top + 12) + 'px'; return; }
      var h = pickPart(ev);
      if (h && h.id) { var p = resolved(h.id); tip.textContent = p.label + (userPart(h.id) ? ' (drag to move)' : ''); tip.style.display = 'block'; }
      else if (h && h.layer) { var L = R.layers.filter(function (x) { return x.id === h.layer; })[0]; tip.textContent = L.id + ' ' + L.name + ', ' + L.t + ' mm'; tip.style.display = 'block'; }
      else tip.style.display = 'none';
      var vr = view.getBoundingClientRect(); tip.style.left = (ev.clientX - vr.left + 14) + 'px'; tip.style.top = (ev.clientY - vr.top + 12) + 'px';
    });
    function end(ev) { if (!drag) return; var m = drag.moved; drag = null; controls.enabled = true; try { dom.releasePointerCapture(ev.pointerId); } catch (e) { /* not captured */ } if (m) rebuild(true); }
    dom.addEventListener('pointerup', end); dom.addEventListener('pointercancel', end);
    dom.addEventListener('pointerleave', function () { tip.style.display = 'none'; });
    dom.addEventListener('dblclick', function (ev) { if (!pickPart(ev)) setView('iso'); });
    window.addEventListener('keydown', function (ev) {
      if (/INPUT|SELECT|TEXTAREA/.test((ev.target.tagName || ''))) return;
      if ((ev.ctrlKey || ev.metaKey) && (ev.key === 'z' || ev.key === 'Z')) { ev.preventDefault(); if (ev.shiftKey) redo(); else undo(); return; }
      if ((ev.ctrlKey || ev.metaKey) && ev.key === 'y') { ev.preventDefault(); redo(); return; }
      if (ui.tab === 'mag') { if (!ev.ctrlKey && !ev.metaKey) magTab.key(ev); return; }
      var u = ui.editOutline && ui.vsel != null ? OV()[ui.vsel] : (ui.sel ? userPart(ui.sel) : null); if (!u) return;
      if (!(ui.editOutline && ui.vsel != null) && !ev.ctrlKey && !ev.metaKey && !ev.altKey) {
        var k = ev.key.toLowerCase(), did = true;
        if (k === 'r') turnPart(u, ev.shiftKey ? 45 : 90); else if (k === 'd') duplicatePart(u); else if (k === 'p' && Cat.parts[u.type] && Cat.parts[u.type].travel) { if (u.pressed) delete u.pressed; else u.pressed = true; } else if (k === 'f' && u.mount && u.mount.on) u.mount.side = u.mount.side === 'bottom' ? 'top' : 'bottom';
        else if (ev.key === 'Delete' || ev.key === 'Backspace') removePart(u); else did = false;
        if (did) { ev.preventDefault(); rebuild(true); return; }
      }
      var s = ev.shiftKey ? 1.27 : 0.1, d = { ArrowLeft: [-s, 0], ArrowRight: [s, 0], ArrowUp: [0, -s], ArrowDown: [0, s] }[ev.key];
      if (!d) return;
      u.x = +(u.x + d[0]).toFixed(3); u.y = +(u.y + d[1]).toFixed(3); ev.preventDefault(); rebuild(true);
    });
  }

  // ---------- controls ----------
  function num(v, step, set, o) {
    o = o || {};
    return el('input', { type: 'number', value: v, step: step, min: o.min, max: o.max, id: o.id, 'aria-label': o.label, onchange: function (e) { var x = parseFloat(e.target.value); if (isNaN(x)) return; if (o.min != null) x = Math.max(o.min, x); if (o.max != null) x = Math.min(o.max, x); set(x); rebuild(true); } });
  }
  function seg(options, value, set) {
    return el('span', { class: 'seg', role: 'group' }, options.map(function (o) { return el('button', { type: 'button', 'aria-pressed': String(o[0] === value), text: o[1], onclick: function () { set(o[0]); rebuild(true); } }); }));
  }
  function chk(value, set, id) { return el('input', { type: 'checkbox', id: id, onchange: function (e) { set(e.target.checked); rebuild(true); } }, []); }
  function row(label, control, unitTxt, forId) { return el('div', { class: 'row' }, [el('label', { text: label, for: forId }), el('span', {}, [control, unitTxt ? el('span', { class: 'u', text: unitTxt }) : null])]); }
  function sel(options, value, set, id) {
    var s = el('select', { id: id, onchange: function (e) { set(e.target.value); rebuild(true); } }, options.map(function (o) { return el('option', { value: o[0], text: o[1] }); }));
    s.value = value; return s;
  }
  function check(id, label, value, set) { var c = chk(value, set, id); c.checked = !!value; return el('div', { class: 'row' }, [el('label', { for: id, text: label }), c]); }

  function mountValue(m) { if (m.flush) return 'flush:' + m.flush; if (m.on) return m.on + ':' + (m.side || 'top'); return 'z'; }
  function mountOptions() {
    var o = [];
    R.layers.forEach(function (L) { o.push([L.id + ':top', 'on ' + L.id + ' top']); o.push([L.id + ':bottom', 'on ' + L.id + ' bottom']); });
    o.push(['flush:top', 'flush with the top board']); o.push(['flush:bb', 'flush with breadboard top']);
    return o;
  }
  function currentPort() {
    var ids = P.parts.filter(function (p) { return /^port/.test(p.id); }).map(function (p) { return p.type; });
    if (!ids.length) return 'none';
    for (var k in Cat.portTypes) if (JSON.stringify(Cat.portTypes[k].parts) === JSON.stringify(ids)) return k;
    return 'none';
  }
  function setPort(kind) {
    var old = P.parts.filter(function (p) { return /^port/.test(p.id); })[0];
    var x = old ? old.x : 56, mount = old ? clone(old.mount) : { on: R.layers[0].id, side: 'top' };
    P.parts = P.parts.filter(function (p) { return !/^port/.test(p.id); });
    var yt = R.planes.yt, types = Cat.portTypes[kind].parts;
    var back = { m2_socket: 8.35, pcie_x1_ra: 11, sfp_cage: 0, minipcie: 6.0, sodimm_ddr4: 23.5 };
    types.forEach(function (t, i) {
      P.parts.push({ id: i ? 'port' + (i + 1) : 'port', type: t, x: +(x + (types.length > 1 ? (i - (types.length - 1) / 2) * 15.5 : 0)).toFixed(2), y: +(yt + 1.15 + back[t]).toFixed(2), rot: 0, mount: clone(mount) });
    });
    if (ui.sel && /^port/.test(ui.sel)) ui.sel = null;
  }

  // The header socket in the unit's right side (rev A11c: a part of its own, beside the expansion port on the top edge). It
  // goes where the top band ends: mouth in the right edge, pin 1 the lowest, just above the breadboard's corner.
  function sidePart() { return P.parts.filter(function (p) { return !!Cat.sideKinds[p.type]; })[0] || null; }
  // rev A12: these setters are written for an extender on the right. With the strip on the right it is on the left, and a part
  // they place goes to the mirror image of that place, turned to face the other way (Geo.ops.partMirror, as the flip does).
  function onExtSide(u) { if (R.planes.side !== 'right') return u; var m = Geo.ops.partMirror(u, P.wig.width); u.x = m.x; u.y = m.y; u.rot = m.rot; return u; }
  // rev A11e: how the extender plugs in. 'press' takes the side socket out and puts an upright socket on the mid board, with the
  // top and the bottom board opened for it; 'side' puts the side socket back.
  // rev A12b: the outline controls work on the extender's own outline too (Outline, Outline of: the extender). Its vertices are
  // kept in extender.outline, first taken from the four it is given by its columns and its head. Not while the board is flipped.
  function editExt() { return ui.outlineOf === 'ext' && !!R.extender && R.extender.side !== 'left' && !!R.extender.outline; }
  function OV() { if (!editExt()) return P.frame.outline; var ex = P.extender; if (!ex.outline || ex.outline.length < 3) ex.outline = clone(R.extender.outline.src); return ex.outline; }
  function RO() { return editExt() ? R.extender.outline : R.outline; }
  // rev A12c: the hump operations on the extender's outline. They are run on a stand-in design whose outline is the extender's,
  // moved so that its seam edge is the left grid plane and its far edge the right one; what comes back is the extender's own outline.
  function extHumpP() {
    var E = R.extender, ex = P.extender; if (!E || !E.outline || E.side === 'left') return null;
    var src = ex.outline && ex.outline.length > 2 ? ex.outline : E.outline.src, pitch = P.grid.pitch, x0 = R.planes.xr;
    return { x0: x0, P: { grid: { cols: Math.round(E.w / pitch) - 1, pitch: pitch, dead_rows_left: 0 }, wig: { height: P.wig.height }, frame: { outline: clone(src).map(function (v) { v.x = +(v.x - x0).toFixed(4); return v; }) } } };
  }
  function extHumpDo(fn) {
    var q = extHumpP(); if (!q) return { ok: false, why: 'the extender is not shown, or the board is flipped' };
    var res = fn(q.P); if (!res || res.ok !== false) P.extender.outline = q.P.frame.outline.map(function (v) { v.x = +(v.x + q.x0).toFixed(4); return v; });
    return res;
  }
  function VM() { var nv = OV().length; ui.vmulti = (ui.vmulti || []).filter(function (i) { return i < nv; }); return ui.vmulti; }      // the vertices selected together (rev A12c)
  function vertPart() { return P.parts.filter(function (p) { return p.type === 'skt_v_127'; })[0] || null; }
  function setJoin(v) {
    var ex = P.extender, vs = vertPart(), s = sidePart(); ex.join = v;
    if (v === 'press') {
      if (s) { P.parts = P.parts.filter(function (p) { return p !== s; }); if (ui.sel === s.id) ui.sel = null; }
      if (!vs) { var op = {}; op[R.layers[0].id] = true; op[R.layers[R.layers.length - 1].id] = true; P.parts.push(onExtSide({ id: 'vert', type: 'skt_v_127', x: +(P.wig.width - 5.6).toFixed(2), y: -15.9, rot: 0, mount: { on: R.layers[Math.min(1, R.layers.length - 1)].id, side: 'top' }, dims: { n: 11, h: 2.1 }, open: op })); }
    } else { if (vs) { P.parts = P.parts.filter(function (p) { return p !== vs; }); if (ui.sel === vs.id) ui.sel = null; } if (!s) setSide(true); }
  }
  function stackKey() { var S = P.stack; return S.length > 2 ? S[S.length - 1].t + '/' + S[0].t : ''; }
  function setStack(v) {                 // top and bottom board thickness; the mid board stays, and the two spaces share what is left under the shell's height
    var S = P.stack, q = String(v).split('/'); if (S.length < 3) return;
    S[2].t = +q[0]; S[0].t = +q[1]; var gsp = +((P.wig.shell.t - S[2].t - S[1].t) / 2).toFixed(3); S[1].gap = gsp; S[2].gap = gsp;
  }
  function setSideKind(v) {             // another socket in the same place: its mouth stays on the edge, and its positions go to that kind's own count when the pitch changes
    var s = sidePart(), K = Cat.sideKinds[v], K0 = s && Cat.sideKinds[s.type]; if (!s || !K) return;
    onExtSide(s);                         // (on the left: to its mirror image on the right, changed there, and back)
    s.dims = { n: K0 && K0.pitch === K.pitch ? Cat.ra127(s.dims && s.dims.n) : K.n }; s.type = v; s.x = +(P.wig.width - K.depth - (K.lead || 0)).toFixed(2);       // a socket with leads at its mouth end stands that far inside the edge
    onExtSide(s);
  }
  function setSide(on) {
    var s = sidePart(), d = Cat.side;
    if (!on) { if (s) { P.parts = P.parts.filter(function (p) { return p !== s; }); if (ui.sel === s.id) ui.sel = null; } return; }
    if (!s) {
      // on the right: turned 180, mouth in the right edge, pin 1 the lowest. With the strip on the right the extender is on the left,
      // and the socket goes to the mirror image of that: turned 0, mouth in the left edge, pin 1 the highest
      P.parts.push(onExtSide({ id: P.parts.some(function (p) { return p.id === d.id; }) ? newId(d.id) : d.id, type: d.type, x: +(P.wig.width - d.back).toFixed(2), y: d.y, rot: d.rot, mount: { on: R.layers[0].id, side: 'top' }, dims: { n: Cat.ra127(R.extender ? R.extender.n_rows / 2 : d.n) } }));
    }
  }
  function newId(type) { var n = 1, id, stem = type.split('_')[0]; do { id = stem + (n++); } while (P.parts.some(function (p) { return p.id === id; })); return id; }
  function partSize(type) {              // plan size and height of a catalogue part, from its bodies
    try {
      var c = Cat.get({ type: type }, { zBot: R.z.bottom, zTop: R.z.top, layers: R.layers }), x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
      c.bodies.forEach(function (b) { var sh = b.shape, pts = sh.rect ? [[sh.rect[0], sh.rect[1]], [sh.rect[2], sh.rect[3]]] : sh.circle ? [[sh.circle[0] - sh.circle[2], sh.circle[1] - sh.circle[2]], [sh.circle[0] + sh.circle[2], sh.circle[1] + sh.circle[2]]] : sh.poly;
        pts.forEach(function (q) { x0 = Math.min(x0, q[0]); y0 = Math.min(y0, q[1]); x1 = Math.max(x1, q[0]); y1 = Math.max(y1, q[1]); }); });
      return { w: +(x1 - x0).toFixed(1), d: +(y1 - y0).toFixed(1), h: +(+c.height).toFixed(2) };
    } catch (e) { return null; }
  }
  function addPartOfType(t) {
    var cat = Cat.parts[t], id = newId(t), pl = R.planes, at = controls ? [controls.target.x, controls.target.z] : [60, pl.yt / 2];
    if (!(at[0] > pl.x0 + 2 && at[0] < pl.x1 - 2 && at[1] > pl.yt + 2 && at[1] < pl.yb - 2) || (at[0] > -1 && at[0] < P.wig.width + 1 && at[1] > -1)) at = [68, -12];      // not over the breadboard, not off the unit
    P.parts.push({ id: id, type: t, x: +at[0].toFixed(1), y: +at[1].toFixed(1), rot: 0, mount: cat.group === 'display' ? { flush: 'top', offset: 0 } : { on: boardFor(cat.on), side: 'top' } });
    ui.sel = id; ui.lastAdd = t;
  }
  function turnPart(u, by) { u.rot = (((u.rot || 0) + by) % 360 + 360) % 360; }
  function duplicatePart(u) {
    var d = clone(u), sz = partSize(u.type) || { w: 6 }; d.id = newId(u.type); d.x = +(u.x + Math.max(3, Math.min(sz.w, 12)) + 1).toFixed(2);
    if (d.x > R.planes.x1 - 2) { d.x = u.x; d.y = +(u.y + 6).toFixed(2); }
    P.parts.push(d); ui.sel = d.id;
  }
  function removePart(u) { P.parts = P.parts.filter(function (p) { return p.id !== u.id; }); if (ui.sel === u.id) ui.sel = null; }
  // A display of this type turned by rot, measured from the part's own x, y: sx = where the middle of its picture (the active
  // area) lies along x, ymax = its lowest edge (largest y, the side towards the breadboard), cover glass included.
  function displaySeat(type, rot) {
    var cat = Cat.parts[type], pts = [];
    if (!cat || !cat.bodies || !cat.bodies.length) return null;
    cat.bodies.forEach(function (b) { var q = b.shape; (q.rect ? Geo.util.rectPts(q.rect[0], q.rect[1], q.rect[2], q.rect[3]) : q.circle ? Geo.util.circlePts(q.circle[0], q.circle[1], q.circle[2]) : q.poly || []).forEach(function (pt) { pts.push(pt); }); });
    var ymax = Math.max.apply(null, Geo.util.place(pts, 0, 0, rot || 0, false).map(function (pt) { return pt[1]; }));
    return { sx: Geo.util.place([[0, cat.screen ? cat.screen.cy || 0 : 0]], 0, 0, rot || 0, false)[0][0], ymax: ymax };
  }
  function boardFor(where) { var st = P.stack; return where === 'top' ? st[st.length - 1].id : (where === 'mid' && st.length > 2 ? st[1].id : st[0].id); }
  function controlValue(ctl) { var u = userPart(ctl.ids[0]); return u ? u.type : 'none'; }
  function setControl(ctl, type) {
    ctl.ids.forEach(function (id, i) {
      var u = userPart(id);
      if (type === 'none') { P.parts = P.parts.filter(function (q) { return q.id !== id; }); if (ui.sel === id) ui.sel = null; return; }
      var on = boardFor(Cat.parts[type].on);
      if (u) { u.type = type; u.mount = { on: on, side: 'top' }; delete u.open; delete u.dims; }
      else P.parts.push({ id: id, type: type, x: ctl.at[i][0], y: ctl.at[i][1], rot: ctl.at[i][2], mount: { on: on, side: 'top' } });
    });
    if (type !== 'none') ui.sel = ctl.ids[0];
  }
  function boardText(st) {
    if (st.state === 'through') return 'it passes through';
    if (st.tongue) return 'the tongue is cut in it';
    if (st.state === 'access') return st.set === true ? 'opened (your choice)' : 'opened to reach it';
    if (st.state === 'blocked') return 'kept whole, and it runs into this board';
    return st.set === false ? 'kept whole (your choice)' : 'whole';
  }

  // ---------- view controls: one list. Each is shown in the panel's View section, or pinned into the strip in the 3D view ----------
  var VIEW_ID = { explode: 'c-ex', extout: 'c-xo', opacity: 'c-bop', shell: 'c-hs', bg: 'c-bg', ground: 'c-ground', light: 'c-light', sun: 'c-sun', exposure: 'c-exp', shadows: 'c-shadow', decals: 'c-decals', edges: 'c-edges', fov: 'c-fov', wheel: 'c-wheel', rotate: 'c-rot', clip: 'c-clip', clipPos: 'c-clipp', env: 'c-env' };
  function rset(k, v, sceneToo, redraw) { ui.render[k] = v; applyRender(); if (sceneToo) buildScene(); saveView(); if (redraw) renderControls(); }
  function viewItems() {
    var rs = ui.render, real = rs.mode === 'real';
    function sel(k, opts, o) { o = o || {}; return function (id) { var x = el('select', { id: id, onchange: function (e) { var v = e.target.value; if (o.set) o.set(v); else rset(k, isNaN(+v) || v === '' ? v : +v, o.scene, o.redraw); } }, opts.map(function (q) { return el('option', { value: q[0], text: q[1] }); })); x.value = String(o.get ? o.get() : rs[k]); return x; }; }
    function range(k, min, max, step, o) { o = o || {}; return function (id) { return el('input', { type: 'range', id: id, min: min, max: max, step: step, value: o.get ? o.get() : (rs[k] != null ? rs[k] : o.def), oninput: function (e) { var v = parseFloat(e.target.value); if (o.set) o.set(v); else rset(k, v, o.scene); } }); }; }
    function chk(k, o) { o = o || {}; return function (id) { var x = el('input', { type: 'checkbox', id: id, onchange: function (e) { if (o.set) o.set(e.target.checked); else rset(k, e.target.checked, o.scene); } }); x.checked = !!(o.get ? o.get() : rs[k]); return x; }; }
    function colour(k) { return function (id) { return el('input', { type: 'color', id: id, value: rs[k] || '#ffffff', oninput: function (e) { rset(k, e.target.value); } }); }; }
    var items = [
      { k: 'mode', label: 'Drawn as', make: function () { return el('span', { class: 'seg', role: 'group' }, [['real', 'Real'], ['tech', 'Flat'], ['xray', 'X-ray'], ['lines', 'Lines']].map(function (o) { return el('button', { type: 'button', 'aria-pressed': String(rs.mode === o[0]), text: o[1], onclick: function () { rset('mode', o[0], true, true); } }); })); } },
      { k: 'explode', label: 'Explode', make: range(null, 0, 14, 0.5, { get: function () { return ui.explode; }, set: function (v) { ui.explode = v; buildScene(); saveView(); } }) },
      { k: 'extout', label: 'Extender away', make: range(null, 0, 40, 0.5, { get: function () { return +ui.extOut || 0; }, set: function (v) { ui.extOut = v; buildScene(); saveView(); } }) },
      { k: 'opacity', label: 'Board opacity', make: range('boardOpacity', 0.1, 1, 0.05, { def: 1, scene: true }) },
      { k: 'shell', label: 'Hide the breadboard shell', short: 'Hide shell', check: true, make: chk(null, { get: function () { return ui.hideShell; }, set: function (v) { ui.hideShell = v; buildScene(); saveView(); } }) },
      { k: 'bg', label: 'Backdrop', make: sel('bg', [['console', 'Console grey'], ['deep', 'Dark'], ['studio', 'Studio fade'], ['slate', 'Slate, lit in the middle'], ['blueprint', 'Blueprint'], ['dusk', 'Dusk'], ['rainbow', 'Rainbow line'], ['paper', 'Paper'], ['white', 'White'], ['custom', 'A colour of your own'], ['clear', 'None (clear PNG)']], { redraw: true }) },
      { k: 'bgColor', label: 'Backdrop colour', short: 'Colour', when: function () { return rs.bg === 'custom'; }, make: colour('bgColor') },
      { k: 'ground', label: 'Bench', make: sel('ground', [['shadow', 'Shadow only'], ['grid', '0.1 inch grid'], ['mat', 'Cutting mat'], ['wood', 'Wooden bench'], ['steel', 'Brushed steel'], ['none', 'Nothing']]) },
      { k: 'rig', label: 'Lighting', real: true, make: sel('rig', Object.keys(Rn.RIGS).map(function (r) { return [r, Rn.RIGS[r].label]; }), { set: function (v) { var g = Rn.RIGS[v]; rs.rig = v; for (var j in g) if (j !== 'label') rs[j] = g[j]; applyRender(); saveView(); renderControls(); } }) },
      { k: 'light', label: 'Light level', make: range('light', 0.3, 2, 0.05) },
      { k: 'sun', label: 'Light from', real: true, make: range('sun', 0, 360, 5) },
      { k: 'keyColor', label: 'Main light colour', short: 'Main light', real: true, make: colour('keyColor') },
      { k: 'fillLevel', label: 'Second light', real: true, make: range('fillLevel', 0, 3, 0.05, { def: 1 }) },
      { k: 'fillColor', label: 'Second light colour', short: '2nd colour', real: true, make: colour('fillColor') },
      { k: 'rimLevel', label: 'Back light', real: true, make: range('rimLevel', 0, 3, 0.05, { def: 0 }) },
      { k: 'rimColor', label: 'Back light colour', short: 'Back colour', real: true, make: colour('rimColor') },
      { k: 'ambLevel', label: 'Sky light', real: true, make: range('ambLevel', 0, 2.5, 0.05, { def: 1 }) },
      { k: 'skyColor', label: 'Sky colour', real: true, make: colour('skyColor') },
      { k: 'texture', label: 'Board surface', real: true, make: sel('texture', [['smooth', 'Smooth'], ['fine', 'Soldermask grain'], ['weave', 'Glass weave'], ['traces', 'Tracks under the mask']], { scene: true }) },
      { k: 'shellTex', label: 'Shell surface', real: true, make: sel('shellTex', [['smooth', 'Moulded'], ['printed', 'Printed layers']], { scene: true }) },
      { k: 'shadows', label: 'Shadows', check: true, real: true, make: chk('shadows') },
      { k: 'exposure', label: 'Exposure', real: true, make: range('exposure', 0.4, 2, 0.05) },
      { k: 'decals', label: 'Part outlines printed on the boards', short: 'Outlines', check: true, real: true, make: chk('decals', { scene: true }) },
      { k: 'edges', label: 'Draw edges', short: 'Edges', check: true, real: true, make: chk('edges', { scene: true }) },
      { k: 'fov', label: 'Lens', make: sel('fov', [[12, 'Flat (12 deg)'], [30, 'Normal (30 deg)'], [50, 'Wide (50 deg)']]) },
      { k: 'wheel', label: 'Scrolling', make: sel('wheel', [['pan', 'Moves the view (pinch zooms)'], ['zoom', 'Zooms (mouse wheel)']]) },
      { k: 'rotate', label: 'Turn slowly', short: 'Turn', check: true, make: chk('rotate') },
      { k: 'clip', label: 'Section cut', make: sel(null, [['off', 'off'], ['x', 'across (x)'], ['y', 'down the board (y)'], ['z', 'by height (z)']], { get: function () { return ui.clipAxis; }, set: function (v) { ui.clipAxis = v; applyClip(); saveView(); } }) },
      { k: 'clipPos', label: 'Cut position', short: 'Cut at', make: range(null, 0, 1, 0.005, { get: function () { return ui.clipPos; }, set: function (v) { ui.clipPos = v; applyClip(); } }) },
      { k: 'env', label: 'Show pocket envelopes', short: 'Pockets', check: true, make: chk(null, { get: function () { return ui.envelopes; }, set: function (v) { ui.envelopes = v; buildScene(); saveView(); } }) }
    ];
    return items.filter(function (it) { return !(it.real && !real) && !(it.when && !it.when()); });
  }
  function inView(k) { return ui.viewbar.dock !== 'off' && ui.viewbar.items.indexOf(k) >= 0; }
  function togglePin(k, keepMenu) {
    var vb = ui.viewbar, i = vb.items.indexOf(k);
    if (vb.dock === 'off') { vb.dock = 'bottom'; if (i < 0) vb.items.push(k); }
    else if (i >= 0) vb.items.splice(i, 1); else vb.items.push(k);
    saveView(); renderControls();
    if (keepMenu) { var m = document.querySelector('#viewstrip .vs-add'); if (m) m.open = true; }
  }
  function renderViewbar() {
    var box = $('viewstrip'); if (!box) return;
    var vb = ui.viewbar, all = viewItems(), byK = {};
    all.forEach(function (it) { byK[it.k] = it; });
    box.innerHTML = ''; box.setAttribute('data-dock', vb.dock); box.classList.toggle('folded', !!vb.fold);
    box.hidden = vb.dock === 'off' || ui.tab === 'mag';
    if (box.hidden) return;
    var cells = el('div', { class: 'vs-items' });
    if (!vb.fold) vb.items.forEach(function (k) {
      var it = byK[k]; if (!it) return;
      cells.appendChild(el('div', { class: 'vcell' + (it.check ? ' chk' : ''), 'data-k': k }, [el('label', { for: 'v-' + k, text: it.short || it.label }), it.make('v-' + k)]));
    });
    var menu = el('details', { class: 'menu vs-add' }, [el('summary', { text: '+', title: 'choose what is in the view', 'aria-label': 'choose which view controls are in the 3D view' }),
      el('div', { class: 'pop' }, [el('div', { class: 'hint', text: 'In the 3D view:' })].concat(all.map(function (it) { var cb = el('input', { type: 'checkbox', id: 'vp-' + it.k, onchange: function () { togglePin(it.k, true); } }); cb.checked = vb.items.indexOf(it.k) >= 0; return el('label', { class: 'vp', for: 'vp-' + it.k }, [cb, el('span', { text: it.label })]); })))]);
    var docks = ['bottom', 'top', 'left', 'right'].map(function (d) { return el('button', { type: 'button', class: 'vdk', 'data-d': d, 'aria-pressed': String(vb.dock === d), title: 'dock at the ' + d + ' of the view', 'aria-label': 'dock the view controls at the ' + d + ' of the view', onclick: function () { vb.dock = d; saveView(); renderControls(); } }); });
    var fold = el('button', { type: 'button', class: 'vfold', id: 'vs-fold', text: vb.fold ? 'View' : '–', title: vb.fold ? 'show the view controls' : 'fold the view controls away', 'aria-label': vb.fold ? 'show the view controls' : 'fold the view controls away', onclick: function () { vb.fold = !vb.fold; saveView(); renderViewbar(); } });
    var off = el('button', { type: 'button', class: 'vfold', id: 'vs-off', text: '×', title: 'put them all back in the View section', 'aria-label': 'put the view controls back in the View section', onclick: function () { vb.dock = 'off'; saveView(); renderControls(); } });
    box.appendChild(cells);
    box.appendChild(el('div', { class: 'vs-tools' }, vb.fold ? [fold] : [menu].concat(docks, [fold, off])));
  }

  function renderControls() {
    var root = $('controls'), c = root, keepScroll = root.scrollTop, nsec = 0;
    root.innerHTML = '';
    renderViewbar();
    function sect(title) {
      var shut = !!ui.fold[title], body = el('div', { class: 'secbody' });
      var h = el('h2', {}, [el('button', { type: 'button', class: 'sech', 'aria-expanded': String(!shut), text: title, onclick: function () { ui.fold[title] = !ui.fold[title]; saveView(); renderControls(); } })]);
      var sec = el('section', { class: 'sec' + (shut ? ' shut' : ''), style: '--c: var(--r' + [2, 3, 7, 8, 10, 11, 5, 9, 12, 1][nsec++ % 10] + ')' }, [h, body]);
      root.appendChild(sec); return body;
    }
    function viewRow(label, control, forId) { return row(label, control, '', forId); }
    function vset(k, v, sceneToo) { ui.render[k] = v; applyRender(); if (sceneToo) buildScene(); saveView(); }
    if (notice) root.appendChild(el('div', { class: 'notice', role: 'status' }, [el('span', { text: notice }), el('button', { type: 'button', class: 'quiet', text: 'ok', onclick: function () { notice = null; renderControls(); } })]));
    if (ui.tab === 'mag') { magTab.controls(sect); root.scrollTop = keepScroll; return; }
    var g = P.grid, w = P.wig, f = P.frame;
    c = sect('Breadboard');
    c.appendChild(row('Wig', seg([['integrated', 'Integrated'], ['removable', 'Removable']], w.mode, function (v) { w.mode = v; })));
    if (w.mode === 'removable') c.appendChild(row('1.27 mm header pair', seg([['top', 'Top side'], ['bottom', 'Bottom side']], w.connector_side, function (v) { w.connector_side = v; })));
    c.appendChild(row('Shell height', el('span', {}, [num(w.shell.t, 0.05, function (v) { w.shell.t = v; }, { min: 1, max: 20, id: 'c-shell' }), ' ', seg([[6.75, '6.75'], [7.1, '7.1']], w.shell.t, function (v) { w.shell.t = v; })]), 'mm', 'c-shell'));
    c.appendChild(el('div', { class: 'hint', text: '6.75 is the moulding target and the older print; the Wiiig v7 print measures 7.1.' }));
    var fc = w.face = w.face || { on: false, t: 0.71, sits: 'on', header_strip: true };
    c.appendChild(check('c-faceon', 'Wig top board on the shell (countersunk holes)', fc.on, function (v) { fc.on = v; delete fc.plain; }));
    if (fc.on) {
      c.appendChild(row('Face thickness', el('span', {}, [num(fc.t, 0.01, function (v) { fc.t = v; }, { min: 0.2, max: 3, id: 'c-face' }), ' ', seg([[0.6, '0.6'], [0.71, '0.71'], [0.8, '0.8']], fc.t, function (v) { fc.t = v; })]), 'mm', 'c-face'));
      c.appendChild(row('It sits', seg([['on', 'On the shell'], ['inset', 'Let into it']], fc.sits === 'inset' ? 'inset' : 'on', function (v) { fc.sits = v; })));
      c.appendChild(el('div', { class: 'hint', text: R.wig.face && R.wig.face.real ? 'From wiigtop.3mf: 484 countersunk holes (2.03 down to 1.2) on the breadboard body\'s outline, 78.74 x 54.99. The card edge with the 2 x 35 header belongs to the wig\'s bottom board' + (w.mode === 'integrated' ? ', which here is the main board itself; Removable shows the wig\'s own.' : ', the board under the shell.') + ' Top of the breadboard is z = ' + R.z.bbTop + '.' : 'A plain rectangle of that thickness.' }));
      c.appendChild(check('c-facehs', 'Give the top board the card edge too (as in wiigtop.3mf)', fc.header_strip === true, function (v) { fc.header_strip = v; }));
    }

    c = sect('0.1 inch grid');
    // the strip is on the left as drawn, on the right after a flip (frame.side); its width moves the vertices and parts on that side
    var onR = f.side === 'right', WW = P.wig.width;
    c.appendChild(row(onR ? 'Right strip' : 'Left strip', seg([[0, 'none'], [1, '2.54'], [2, '5.08'], [3, '7.62']], g.dead_rows_left, function (v) {
      var shift = (g.dead_rows_left - v) * g.pitch * (onR ? -1 : 1); g.dead_rows_left = v;
      [P.frame.outline, P.frame.outline_drawn || []].forEach(function (list) { list.forEach(function (q) { if ((onR ? q.x > WW + 0.01 : q.x < -0.01) || q.sx) { q.sx = 1; q.x = +(q.x + shift).toFixed(3); } }); });
      P.parts.forEach(function (p) { if (onR ? p.x > WW - 5 : p.x < 5) p.x = +(p.x + shift).toFixed(3); });
      P.probe.dock.x = onR ? +(WW + v * g.pitch / 2).toFixed(3) : -v * g.pitch / 2; if (v === 0) P.probe.dock.enabled = false; })));
    c.appendChild(el('div', { class: 'hint', text: 'Unit pitch ' + R.planes.pitch + ' mm = ' + Math.round(R.planes.pitch / g.pitch) + ' rows, ' + R.checks.grid.dead_rows + ' dead row' + (R.checks.grid.dead_rows > 1 ? 's' : '') + ' between units.' }));
    // the top band: how far the frame stands above the breadboard. Moving it moves every vertex of the top edge together (the
    // step in the edge stays), and the parts in the upper half of the band, which hang on that edge.
    var og = R.checks.grid.overall;
    var drawnBand = +P.frame.band_drawn || 24.7;
    function setBand(h) {
      // measured from the outline as it is now, so a second call with the same height does nothing
      var topNow = Math.min.apply(null, P.frame.outline.map(function (q) { return q.y; }));
      h = Math.max(8, Math.min(70, +h)); var shift = +(-h - topNow).toFixed(3), half = topNow / 2;
      if (!shift) return;
      [P.frame.outline, P.frame.outline_drawn || []].forEach(function (list) { list.forEach(function (q) { if (q.sy || q.y < -2) { q.sy = 1; q.y = +(q.y + shift).toFixed(3); } }); });
      P.parts.forEach(function (p) { if (p.y < half) p.y = +(p.y + shift).toFixed(3); });
    }
    var bandBtn = function (id, text, h, title) { return el('button', { type: 'button', id: id, text: text, title: title, disabled: Math.abs(h - og.band) < 0.005 ? '' : null, onclick: function () { setBand(h); rebuild(true); } }); };
    c.appendChild(row('Top band', num(+og.band.toFixed(2), 0.1, setBand, { min: 8, max: 70, id: 'c-band' }), 'mm', 'c-band'));
    c.appendChild(el('div', { class: 'acts' }, [bandBtn('c-square', 'Make it square', og.band_square, 'top band ' + og.band_square + ': as high as the unit pitch is wide'),
      Math.abs(og.widest - og.w) > 0.05 ? bandBtn('c-square-w', 'Square to the widest point', og.band_square_widest, 'top band ' + og.band_square_widest + ': as high as the outline is wide at its widest, ' + og.widest) : null,
      bandBtn('c-band-drawn', 'As drawn', drawnBand, 'top band ' + drawnBand)]));
    c.appendChild(el('div', { class: 'hint', id: 'c-overall', text: 'Overall ' + og.w + ' wide x ' + og.h + ' high' + (og.square ? ': square' : ': ' + Math.abs(+(og.h - og.w).toFixed(2)) + (og.h < og.w ? ' short of' : ' over') + ' square (top band ' + og.band_square + ')') + '. '
      + (og.v_on_grid ? 'The height is ' + Math.round(og.rows_high) + ' rows, so a unit stood above this one keeps its holes on the 0.1 inch grid.' : 'The height is ' + og.rows_high + ' rows: a unit stood above this one is off the 0.1 inch grid.')
      + (Math.abs(og.widest - og.w) > 0.05 ? ' Widest point ' + og.widest + ' (a hump on a side stands past the grid plane; see Humps).' : '') + ' The top edge moves as one, with the parts in the upper half of the band.' }));
    c.appendChild(row('Edge coupler between units', sel([['none', 'none']].concat(Object.keys(Cat.couplers).map(function (k) { return [k, Cat.couplers[k].label]; })), g.coupler || 'none', function (v) { g.coupler = v; if (v !== 'none') P.show.coupler = true; }, 'c-cpl'), '', 'c-cpl'));
    var cq = R.checks.grid.coupler;
    if (cq) c.appendChild(el('div', { class: 'hint' + (cq.fits ? '' : ' bad'), text: 'Needs ' + cq.gap + ' mm between the two boards; the strip leaves ' + cq.have + (cq.fits ? ' (' + cq.spare + ' spare).' : '. It first fits at ' + cq.strip_needed + ' mm (' + cq.rows_needed + ' rows).') }));
    c.appendChild(check('c-nb', 'Show the next unit', P.show.neighbour, function (v) { P.show.neighbour = v; setTimeout(function () { setView('iso'); }, 0); }));
    c.appendChild(check('c-h40', 'Show a 1x40 header', P.show.header40, function (v) { P.show.header40 = v; }));
    if (P.show.header40) {
      c.appendChild(row('Header starts at column', num(P.show.header40_col, 1, function (v) { P.show.header40_col = Math.round(v); }, { min: 1, max: 30, id: 'c-h40c' }), '', 'c-h40c'));
      c.appendChild(row('Header on hole row', num(P.show.header40_row, 1, function (v) { P.show.header40_row = Math.round(v); }, { min: 0, max: R.wig.rows.length - 1, id: 'c-h40r' }), '', 'c-h40r'));
    }
    var pc = el('input', { type: 'checkbox', id: 'c-planes', onchange: function (e) { ui.planes = e.target.checked; buildScene(); } }); pc.checked = ui.planes;
    c.appendChild(el('div', { class: 'row' }, [el('label', { for: 'c-planes', text: 'Show the grid planes' }), pc]));

    // Flip left to right (rev A12): the strip and the probe's dock change sides, the extender with them. What goes with the
    // board is chosen here: each part (part.on_flip), each hump and the top corners' shapes (ui.flip), the magnetometers.
    c = sect('Flip left to right');
    c.appendChild(el('div', { class: 'hint', id: 'c-flip-now', text: 'The strip with the probe\'s dock is on the ' + (onR ? 'right' : 'left') + '; the extender stands against the ' + (onR ? 'left' : 'right') + ' side. Flipping mirrors the board about the breadboard\'s middle. Choose what goes with it:' }));
    var fl = ui.flip, modes = [['flip', 'flips'], ['corner', 'stays in its corner'], ['stay', 'stays put']];
    P.parts.forEach(function (u, i) {
      var cat = Cat.parts[u.type], id = 'c-flip-p' + i;
      c.appendChild(row(u.id + (cat && cat.label ? ' (' + String(cat.label).split(/[,(]/)[0].trim().slice(0, 26) + ')' : ''), sel(modes, Geo.ops.flipMode(u), function (v) { u.on_flip = v; }, id), '', id));
    });
    var hl = Geo.ops.humps(P);
    hl.forEach(function (h, i) {
      var id = 'c-flip-h' + i;
      c.appendChild(row('Hump: ' + h.label.split(',').slice(0, 2).join(','), sel([['flip', 'flips'], ['stay', 'stays on its side']], fl.humps[h.key] === 'stay' ? 'stay' : 'flip', function (v) { if (v === 'stay') fl.humps[h.key] = 'stay'; else delete fl.humps[h.key]; }, id), '', id));
    });
    c.appendChild(row('The two top corners\' shapes', sel([['stay', 'stay on their sides'], ['flip', 'flip']], fl.corners === 'flip' ? 'flip' : 'stay', function (v) { fl.corners = v; }, 'c-flip-corners'), '', 'c-flip-corners'));
    if (P.mag && P.mag.list && P.mag.list.length) c.appendChild(row('Magnetometers', sel([['flip', 'flip'], ['stay', 'stay put']], fl.mag === 'stay' ? 'stay' : 'flip', function (v) { fl.mag = v; }, 'c-flip-mag'), '', 'c-flip-mag'));
    c.appendChild(el('div', { class: 'acts' }, [el('button', { type: 'button', id: 'c-flip', text: 'Flip left to right', title: 'mirror the board about the breadboard\'s middle; Undo takes it back, and flipping again with the same choices does too', onclick: function () {
      var keep = {}; hl.forEach(function (h) { if (fl.humps[h.key] === 'stay') keep[h.key] = 'stay'; });
      var rep = Geo.ops.flip(P, { humps: keep, corners: fl.corners === 'flip' ? 'flip' : 'stay', mag: fl.mag !== 'stay' });
      // a hump's name belongs to the edge it is on: one that stayed is the same hump on the other end or side, one that went has a new name
      var nk = {}; Geo.ops.humps(P).forEach(function (h) { if (rep.kept[h.key]) nk[h.key] = 'stay'; }); fl.humps = nk;
      fl.said = rep.notes.join(' ');
      ui.vsel = null; rebuild(true); setTimeout(function () { setView('iso'); }, 0);
    } })]));
    c.appendChild(el('div', { class: 'hint' + (fl.said ? ' bad' : ''), id: 'c-flip-said', text: fl.said || 'Flips: the part goes to the mirror image of its place, turned to face the mirrored way (a real part cannot be mirrored). Stays in its corner: it keeps its side and its place measured from that side\'s top corner of the outline. Stays put: it is not moved. A hump that stays keeps its side; the top corners\' shapes are their chamfers. Clashes and overhangs that follow are under Checks.' }));

    // the header socket in the side and the extender that plugs into it (rev A11; a part of its own since A11c)
    c = sect('Side port and extender');
    var ex = P.extender = P.extender || clone(Cat.extender), xq = R.checks.extender, sideSkt = sidePart();
    var xside = onR ? 'left' : 'right';         // the extender stands against the side the strip is not on
    c.appendChild(row('Move it away', num(+ui.extOut || 0, 1, function (v) { ui.extOut = Math.max(0, Math.min(40, v)); saveView(); }, { min: 0, max: 40, id: 'c-ext-out' }), 'mm, in the view only', 'c-ext-out'));
    c.appendChild(row('It plugs in', seg([['side', 'sideways'], ['press', 'from the back']], ex.join === 'press' ? 'press' : 'side', function (v) { setJoin(v); })));
    var vertSkt = vertPart();
    if (ex.join === 'press' && vertSkt) {
      c.appendChild(row('Socket height', seg([[2.1, '2.1'], [4.3, '4.3']], +(vertSkt.dims && vertSkt.dims.h) || 2.1, function (v) { vertSkt.dims = vertSkt.dims || {}; vertSkt.dims.h = v; })));
      c.appendChild(row('Socket positions per row', num(Cat.ra127(vertSkt.dims && vertSkt.dims.n), 1, function (v) { vertSkt.dims = vertSkt.dims || {}; vertSkt.dims.n = Cat.ra127(v); }, { min: 2, max: 40, id: 'c-vert-n' }), 'x 2 pins', 'c-vert-n'));
      c.appendChild(el('div', { class: 'hint', text: 'An upright socket on the mid board, the top and the bottom board opened over and under it so a pin can go all the way through. A tab of the extender fills a knob-shaped cutout in the bottom board from the back, its pins going up into the socket.' }));
    }
    if (ex.join !== 'press') c.appendChild(check('c-side', 'A header socket in the ' + xside + ' side', !!sideSkt, function (v) { setSide(v); }));
    if (sideSkt) c.appendChild(row('Socket positions per row', num(Cat.ra127(sideSkt.dims && sideSkt.dims.n), 1, function (v) { sideSkt.dims = sideSkt.dims || {}; sideSkt.dims.n = Cat.ra127(v); }, { min: 2, max: 40, id: 'c-ext-n' }), 'x 2 pins', 'c-ext-n'));
    if (sideSkt) c.appendChild(row('Socket', sel(Object.keys(Cat.sideKinds).map(function (k) { return [k, Cat.sideKinds[k].label]; }), sideSkt.type, function (v) { setSideKind(v); }, 'c-side-kind'), '', 'c-side-kind'));
    c.appendChild(check('c-ext', 'Show the extender on the ' + xside, ex.on, function (v) { ex.on = v; setTimeout(function () { setView('iso'); }, 0); }));
    if (ex.on) {
      c.appendChild(row('Columns', num(ex.cols, 1, function (v) { ex.cols = Math.round(v); }, { min: 1, max: 40, id: 'c-ext-cols' }), '= ' + 2 * (xq ? xq.cols : ex.cols) + ' rows', 'c-ext-cols'));
      c.appendChild(row('Head beside the band', num(ex.head, 0.5, function (v) { ex.head = v; }, { min: 0, max: 60, id: 'c-ext-head' }), 'mm', 'c-ext-head'));
      c.appendChild(check('c-ext-cover', 'A second board over its head, level with the top board', ex.cover === true, function (v) { ex.cover = v; }));
      if (xq) c.appendChild(el('div', { class: 'hint' + (xq.overlap.overlap_mm2 || !xq.port || xq.spare < 0 ? ' bad' : ''), id: 'c-ext-hint', text: xq.w + ' mm wide, from x ' + xq.x0 + ' to ' + xq.x1 + '; its first column is ' + xq.col_gap + ' mm from column ' + (xq.side === 'left' ? 1 : g.cols) + '. '
        + (xq.port ? 'The socket has ' + xq.port.pins + ' pins for its ' + xq.rows + ' rows' + (xq.spare < 0 ? ': ' + (-xq.spare) + ' short.' : xq.spare === 0 ? ', with none left over.' : ', ' + xq.spare + ' left over.') : 'There is no socket in the ' + xside + ' side for it.')
        + ' Unit and extender together: ' + xq.pair_w + ' mm, ' + xq.pair_rows + ' rows.' }));
    }
    c.appendChild(el('div', { class: 'hint', text: 'The general expansion port is the one on the top edge (Parts, Expansion port). This socket carries routable lanes only: each row of the extender goes to one of its pins, so the extender needs no crossbar. It lies on the main board under the top board; select it under Parts to move it.' }));

    c = sect('Outline');
    var eo = el('input', { type: 'checkbox', id: 'c-eo', onchange: function (e) { ui.editOutline = e.target.checked; if (!ui.editOutline) ui.vsel = null; else setTimeout(function () { setView('top'); }, 0); rebuild(true); } }); eo.checked = ui.editOutline;
    c.appendChild(el('div', { class: 'row' }, [el('label', { for: 'c-eo', text: 'Edit the outline (drag the dots)' }), eo]));
    if (SKETCH) { var sk = el('input', { type: 'checkbox', id: 'c-sk', onchange: function (e) { ui.sketch = e.target.checked; if (ui.sketch) setView('top'); rebuild(true); } }); sk.checked = ui.sketch;
      c.appendChild(el('div', { class: 'row' }, [el('label', { for: 'c-sk', text: 'Lay the notebook sketch over it' }), sk]));
      if (ui.sketch) c.appendChild(row('Sketch opacity', el('input', { type: 'range', min: 0.15, max: 1, step: 0.05, value: ui.sketchOpacity, id: 'c-sko', oninput: function (e) { ui.sketchOpacity = parseFloat(e.target.value); buildScene(); } }), '', 'c-sko')); }
    if (R.extender) {
      c.appendChild(row('Outline of', seg([['frame', 'the unit'], ['ext', 'the extender']], ui.outlineOf === 'ext' ? 'ext' : 'frame', function (v) { ui.outlineOf = v; ui.vsel = null; })));
      if (ui.outlineOf === 'ext' && R.extender.side === 'left') c.appendChild(el('div', { class: 'hint', text: 'Flip the board back to edit the extender\'s outline; what it has is kept and mirrored.' }));
      if (P.extender.outline) c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'The extender has an outline of its own.' }), el('button', { type: 'button', text: 'Back to the one from its columns and head', onclick: function () { delete P.extender.outline; ui.vsel = null; rebuild(true); } })]));
    }
    var ov = OV(), vl = el('div', { class: 'vlist' });
    ov.forEach(function (q, i) { vl.appendChild(el('button', { type: 'button', 'aria-pressed': String(ui.vsel === i || VM().indexOf(i) >= 0), text: String(i + 1), title: q.n || '', onclick: function (e) { if (e && e.shiftKey) { var vm = VM(), at = vm.indexOf(i); if (at >= 0) vm.splice(at, 1); else vm.push(i); ui.vsel = vm.length ? i : null; } else { ui.vsel = ui.vsel === i ? null : i; ui.vmulti = ui.vsel == null ? [] : [i]; } ui.editOutline = true; rebuild(true); } })); });
    c.appendChild(vl);
    c.appendChild(row('Dot size', seg([[0.45, 'small'], [0.85, 'medium'], [1.4, 'large']], +ui.dotSize || 0.85, function (v) { ui.dotSize = v; saveView(); })));
    c.appendChild(check('c-snaphv', 'Snap to vertical and horizontal while dragging', ui.snapHV !== false, function (v) { ui.snapHV = v; saveView(); }));
    c.appendChild(el('div', { class: 'hint', text: 'Shift-click dots, or the numbers, to select several: ' + (VM().length > 1 ? VM().map(function (i) { return i + 1; }).sort(function (a, b) { return a - b; }).join(', ') + ' are selected. ' : '') + 'Drag one of them and they all move together. The snap pulls a dot onto a neighbour\'s x or y within 0.6 mm; hold Alt to drag without it.' }));
    var q = ui.vsel != null ? ov[ui.vsel] : null;
    if (q) {
      var kind = q.c === 'wig' ? 'wig' : q.c === 'meet' ? 'meet' : Array.isArray(q.c) && !(q.r > 0) ? (q.c[0] === q.c[1] ? 'chamfer45' : 'chamferplain') : q.c ? 'chamfer' : q.r > 0 ? 'round' : 'sharp';
      c.appendChild(row('Vertex ' + (ui.vsel + 1) + '  x', num(q.x, 0.1, function (v) { q.x = v; }, { id: 'c-vx' }), 'mm', 'c-vx'));
      c.appendChild(row('y', num(q.y, 0.1, function (v) { q.y = v; }, { id: 'c-vy' }), 'mm', 'c-vy'));
      c.appendChild(row('Corner', sel([['sharp', 'sharp'], ['round', 'round'], ['chamfer45', '45° chamfer'], ['chamferplain', 'chamfer, two lengths'], ['chamfer', 'rounded chamfer'], ['wig', 'WigLEDmag corner'], ['meet', 'meets the breadboard\'s chamfer square']], kind, function (v) {
        if (v === 'sharp') { delete q.c; delete q.r; } else if (v === 'round') { delete q.c; q.r = q.r || 1; } else if (v === 'chamfer') { q.c = Array.isArray(q.c) ? q.c : [2.2, 1.6]; q.r = q.r || 1; }
        else if (v === 'chamfer45') { var d45 = Array.isArray(q.c) ? Math.min(+q.c[0], +q.c[1]) : (q.r > 0 ? +q.r : 2); q.c = [d45, d45]; delete q.r; }      // a straight cut, the same along both edges
        else if (v === 'chamferplain') { q.c = Array.isArray(q.c) && q.c[0] !== q.c[1] ? q.c : [2.2, 1.6]; delete q.r; }
        else if (v === 'meet') {            // the vertex goes onto the breadboard's nearest corner, where the joint is made
          q.c = 'meet'; delete q.r; q.x = Math.abs(q.x) <= Math.abs(q.x - P.wig.width) ? 0 : P.wig.width; q.y = Math.abs(q.y) <= Math.abs(q.y - P.wig.height) ? 0 : P.wig.height;
        } else { q.c = 'wig'; delete q.r; }
      }, 'c-vk'), '', 'c-vk'));
      if (kind === 'meet') c.appendChild(el('div', { class: 'hint', text: 'The vertex sits on the breadboard\'s corner. The frame\'s edge turns in to meet the breadboard\'s chamfer at right angles, at the middle of its flat; the rest of the chamfer is left open. Keep the vertex on the corner, and take out any vertices added to shape this by hand.' }));
      if (kind === 'chamfer') c.appendChild(row('Chamfer along / up', el('span', {}, [num(q.c[0], 0.1, function (v) { q.c[0] = v; }, { min: 0, max: 40, label: 'chamfer leg along the more horizontal edge' }), ' ', num(q.c[1], 0.1, function (v) { q.c[1] = v; }, { min: 0, max: 40, label: 'chamfer leg along the more vertical edge' })]), 'mm'));
      if (kind === 'chamfer' || kind === 'round') c.appendChild(row(kind === 'round' ? 'Radius' : 'Blend radius', num(q.r || 0, 0.1, function (v) { q.r = v; }, { min: 0, max: 30, id: 'c-vr' }), 'mm', 'c-vr'));
      if (q.n) c.appendChild(el('div', { class: 'hint', text: q.n }));
      c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'Arrow keys nudge 0.1 mm, Shift 1.27.' }), el('span', {}, [
        el('button', { type: 'button', text: 'Add after', onclick: function () { var nx = ov[(ui.vsel + 1) % ov.length]; ov.splice(ui.vsel + 1, 0, { x: +((q.x + nx.x) / 2).toFixed(2), y: +((q.y + nx.y) / 2).toFixed(2) }); ui.vsel++; rebuild(true); } }), ' ',
        el('button', { type: 'button', text: 'Delete', onclick: function () { if (ov.length < 4) return; ov.splice(ui.vsel, 1); ui.vsel = null; rebuild(true); } })])]));
    } else c.appendChild(el('div', { class: 'hint', text: ov.length + ' vertices, clockwise from the top-left corner. Pick one to edit it. The strip edge belongs on x = ' + (onR ? R.planes.xr : R.planes.xl) + '.' }));
    if (P.frame.outline_drawn) c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'The strip\'s side has been made straight. The outline as drawn is kept.' }), el('button', { type: 'button', id: 'c-unstraight', text: 'Put it back as drawn', title: 'bring back the outline from before the left side was made straight', onclick: function () {
      P.frame.outline = P.frame.outline_drawn; delete P.frame.outline_drawn; ui.vsel = null; rebuild(true); } })]));
    else if (ov.some(function (q) { return onR ? q.x > R.planes.xr + 0.01 : q.x < R.planes.xl - 0.01; })) c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'The block at the top of the strip stands ' + (+(onR ? R.planes.x1 - R.planes.xr : R.planes.xl - R.planes.x0).toFixed(2)) + ' mm past the strip.' }), el('button', { type: 'button', id: 'c-straight', text: 'Make the ' + (onR ? 'right' : 'left') + ' side straight', title: 'pull the block in to the strip edge and drop the vertices that no longer turn a corner; the outline as drawn is kept and can be put back', onclick: function () {
      P.frame.outline_drawn = clone(ov);
      var xl = R.planes.xl, xr = R.planes.xr; ov.forEach(function (q) { if (onR) { if (q.x > xr) q.x = xr; } else if (q.x < xl) q.x = xl; });
      for (var pass = 0; pass < 3; pass++) for (var i = ov.length - 1; i >= 0 && ov.length > 4; i--) { var a = ov[(i + ov.length - 1) % ov.length], b = ov[i], n2 = ov[(i + 1) % ov.length]; if (Math.abs((b.x - a.x) * (n2.y - b.y) - (b.y - a.y) * (n2.x - b.x)) < 1e-6) ov.splice(i, 1); }
      ui.vsel = null; rebuild(true); } })]));
    if (w.mode === 'integrated') c.appendChild(row('Fill notches in the one board', num(f.fill_notches || 0, 0.25, function (v) { f.fill_notches = v; }, { min: 0, max: 6, id: 'c-fn' }), 'mm', 'c-fn'));
    if (P.stack.some(function (L) { return L.kind === 'ring'; })) c.appendChild(row('Spacer ring wall', num(f.ring_wall || 2, 0.25, function (v) { f.ring_wall = v; }, { min: 0.5, max: 12, id: 'c-ring' }), 'mm', 'c-ring'));

    // Humps (rev A12): the stretches of the outline that stand out of an edge's own line. Each can be moved along its edge,
    // made longer, shorter, higher or lower, sent to the other end of its edge or to the other side, or taken out.
    c = sect('Humps');
    if (R.extender) c.appendChild(row('Humps of', seg([['frame', 'the unit'], ['ext', 'the extender']], ui.outlineOf === 'ext' ? 'ext' : 'frame', function (v) { ui.outlineOf = v; ui.vsel = null; })));
    var hxP = ui.outlineOf === 'ext' ? extHumpP() : null, hx = !!hxP, hs = hx ? Geo.ops.humps(hxP.P) : Geo.ops.humps(P);
    function HP(name) { var args = [].slice.call(arguments, 1); return hx ? extHumpDo(function (Q) { return Geo.ops[name].apply(null, [Q].concat(args)); }) : Geo.ops[name].apply(null, [P].concat(args)); }
    if (ui.outlineOf === 'ext' && !hx) c.appendChild(el('div', { class: 'hint', text: 'Show the extender, and flip the board back, to work on its humps.' }));
    function humpDo(res) { ui.humpSaid = res && !res.ok ? 'Not done: ' + res.why + '.' : ''; ui.vsel = null; }
    if (!hs.length) c.appendChild(el('div', { class: 'hint', text: 'The outline has no humps: every outer edge is one straight line.' }));
    hs.forEach(function (h, i) {
      var ax = h.axis, box = el('div', { class: 'hump', id: 'c-hump' + i });
      box.appendChild(el('div', { class: 'hint', text: h.label }));
      var from = h.end0 ? el('span', { class: 'u', text: 'the ' + (ax === 'x' ? 'top-left' : 'top') + ' corner' }) : num(+h.a0.toFixed(2), 0.5, function (v) { humpDo(HP('humpSet', h.key, { a0: v })); }, { id: 'c-hump' + i + '-a0' });
      var to = h.end1 ? el('span', { class: 'u', text: 'the ' + (ax === 'x' ? 'top-right' : 'bottom') + ' corner' }) : num(+h.a1.toFixed(2), 0.5, function (v) { humpDo(HP('humpSet', h.key, { a1: v })); }, { id: 'c-hump' + i + '-a1' });
      box.appendChild(row('From ' + ax, from, h.end0 ? '' : 'mm', 'c-hump' + i + '-a0'));
      box.appendChild(row('To ' + ax, to, h.end1 ? '' : 'mm', 'c-hump' + i + '-a1'));
      box.appendChild(row(h.side === 'top' ? 'Up' : 'Out', num(+h.out.toFixed(2), 0.1, function (v) { humpDo(HP('humpSet', h.key, { out: v })); }, { min: -30, max: 30, id: 'c-hump' + i + '-out' }), 'mm', 'c-hump' + i + '-out'));
      var btn = function (id, text, title, fn) { return el('button', { type: 'button', id: 'c-hump' + i + '-' + id, text: text, title: title, onclick: function () { humpDo(fn()); rebuild(true); } }); };
      var acts = [];
      if (!(h.end0 && h.end1)) acts.push(btn('back', ax === 'x' ? '◀' : '▲', 'move it 1.27 mm ' + (ax === 'x' ? 'left' : 'up') + (h.end0 || h.end1 ? ' (its step; the other end is the corner)' : ''), function () { return HP('humpSet', h.key, { slide: -1.27 }); }),
        btn('fwd', ax === 'x' ? '▶' : '▼', 'move it 1.27 mm ' + (ax === 'x' ? 'right' : 'down') + (h.end0 || h.end1 ? ' (its step; the other end is the corner)' : ''), function () { return HP('humpSet', h.key, { slide: 1.27 }); }));
      acts.push(btn('end', ax === 'x' ? 'To the other end' : 'To the other end', 'the same hump mirrored along its edge: ' + (ax === 'x' ? 'left end for right end' : 'top for bottom') + '. The edge\'s own corners stay as they are.', function () { return HP('humpOtherEnd', h.key); }));
      if (ax === 'y' && !hx) acts.push(btn('side', 'To the ' + (h.side === 'left' ? 'right' : 'left') + ' side', 'the same hump at the same height on the other side; where that side is shorter its lower end is pulled up', function () { return HP('humpOtherSide', h.key); }));
      if (!(h.end0 && h.end1)) acts.push(btn('45', '45°', 'both flanks at 45 degrees: each foot as far along the edge from the flat as the hump is high', function () { return HP('hump45', h.key); }));
      acts.push(btn('del', 'Remove', 'take this hump out: its edge runs straight there', function () { return HP('humpRemove', h.key); }));
      box.appendChild(el('div', { class: 'acts' }, acts));
      c.appendChild(box);
    });
    c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'Add a hump on' }), el('span', {}, [['top', 'the top edge'], ['left', 'the left side'], ['right', 'the right side']].map(function (o) {
      return el('button', { type: 'button', id: 'c-hump-add-' + o[0], text: o[1], title: 'a 1.5 mm hump in the middle of the longest clear stretch of that edge', onclick: function () { humpDo(HP('humpAdd', o[0])); rebuild(true); } }); }))]));
    c.appendChild(el('div', { class: 'hint' + (ui.humpSaid ? ' bad' : ''), id: 'c-hump-said', text: ui.humpSaid || 'A negative Out on a side hump cuts it into the board instead. A hump is found in the outline, not kept beside it: drag its vertices under Outline and it is still listed here. Parts do not move with a hump.' }));

    c = sect('Stack, bottom to top');
    c.appendChild(check('c-stack-top', 'Top board level with the breadboard\'s face (the spaces move the mid board only)', P.stack_top === 'face', function (v) { if (v) P.stack_top = 'face'; else delete P.stack_top; }));
    c.appendChild(row('Boards top / mid / bottom', seg([['1.6/1.6', '1.6 1.6 1.6'], ['0.8/0.8', '0.8 1.6 0.8'], ['0.8/1', '0.8 1.6 1.0'], ['0.8/1.2', '0.8 1.6 1.2']], stackKey(), function (v) { setStack(v); })));
    var tb = el('table', { class: 'stack' }, [el('tr', {}, [el('th', { text: '' }), el('th', { text: 'Name' }), el('th', { text: 'Kind' }), el('th', { class: 'n', text: 't' }), el('th', { class: 'n', text: 'gap' })])]);
    P.stack.forEach(function (L, i) {
      var eye = el('input', { type: 'checkbox', 'aria-label': 'show ' + L.id, onchange: function (e) { ui.hidden[L.id] = !e.target.checked; buildScene(); } }); eye.checked = !ui.hidden[L.id];
      var kind = i === 0 ? el('span', { text: 'bottom' }) : sel([['board', 'board'], ['ring', 'ring']], L.kind === 'ring' ? 'ring' : 'board', function (v) { L.kind = v; });
      tb.appendChild(el('tr', {}, [
        el('td', {}, [eye, el('span', { class: 'sw', style: 'background:' + Exp.LAYER_COLORS[i % Exp.LAYER_COLORS.length] + ';margin-left:4px' }), L.id]),
        el('td', {}, [el('input', { type: 'text', value: L.name, 'aria-label': L.id + ' name', onchange: function (e) { L.name = e.target.value || L.id; rebuild(true); } })]),
        el('td', {}, [kind]),
        el('td', { class: 'n' }, [num(L.t, 0.2, function (v) { L.t = v; }, { min: 0.2, max: 4, label: L.id + ' thickness' })]),
        el('td', { class: 'n' }, [i === 0 ? el('span', { text: '' }) : num(L.gap || 0, 0.05, function (v) { L.gap = v; }, { min: 0, max: 12, label: L.id + ' gap below' })])
      ]));
    });
    c.appendChild(tb);
    c.appendChild(el('div', { class: 'hint', text: 'gap = space under that board, where parts live. A board is opened only where a part passes through it.' }));
    function level(target) { var n = P.stack.length - 1; if (n < 1) return; var tt = 0; P.stack.slice(1).forEach(function (L) { tt += L.t; }); var each = (target - tt) / n; if (each < 0) return; P.stack.slice(1).forEach(function (L) { L.gap = +each.toFixed(3); }); rebuild(true); }
    c.appendChild(el('div', { class: 'row' }, [el('span', {}, [el('button', { type: 'button', text: R.wig.face ? 'Level with the shell' : 'Level with the breadboard', title: 'share the space out so the top board is flush with the top of the shell', onclick: function () { level(R.z.shellTop); } }),
      R.wig.face && !R.wig.face.inset ? ' ' : null, R.wig.face && !R.wig.face.inset ? el('button', { type: 'button', text: 'with the face', title: 'flush with the top of the wig top board instead', onclick: function () { level(R.z.bbTop); } }) : null]), el('span', {}, [
      el('button', { type: 'button', text: '+ board', onclick: function () { var n = P.stack.length, id = 'L' + n; while (P.stack.some(function (s) { return s.id === id; })) id = 'L' + (++n); P.stack.push({ id: id, name: 'Board ' + n, t: 1.6, gap: 1.0, kind: 'board' }); rebuild(true); } }),
      ' ',
      el('button', { type: 'button', text: '- top', onclick: function () { if (P.stack.length < 2) return; var gone = P.stack.pop().id, top = P.stack[P.stack.length - 1].id; P.parts.forEach(function (p) { if (p.mount && p.mount.on === gone) p.mount.on = top; }); rebuild(true); } })
    ])]));

    c = sect('Parts');
    var dsp = userPart('display');
    c.appendChild(row('Display', sel([['none', 'none']].concat(Cat.displays.map(function (k) { return [k, Cat.parts[k].label]; })), dsp ? dsp.type : 'none', function (v) {
      if (v === 'none') { P.parts = P.parts.filter(function (q) { return q.id !== 'display'; }); if (ui.sel === 'display') ui.sel = null; }
      else if (dsp) {      // another display in the same place: the picture stays centred where it was, the module stays seated on the same edge
        var was = displaySeat(dsp.type, dsp.rot), now = displaySeat(v, dsp.rot);
        if (was && now) { dsp.x = +(dsp.x + was.sx - now.sx).toFixed(3); dsp.y = +(dsp.y + was.ymax - now.ymax).toFixed(3); }
        dsp.type = v;
      } else {             // a display where there was none: where the built-in design has its own, or centred on the breadboard just above it
        var dd = (DEFAULTS.parts || []).filter(function (q) { return q.id === 'display'; })[0], rot = dd ? dd.rot || 0 : 90, ref0 = dd && displaySeat(dd.type, rot), seat = displaySeat(v, rot);
        var cx = ref0 ? dd.x + ref0.sx : P.wig.width / 2, yb = ref0 ? dd.y + ref0.ymax : -1.1;
        P.parts.unshift({ id: 'display', type: v, x: +(cx - (seat ? seat.sx : 0)).toFixed(3), y: +(yb - (seat ? seat.ymax : 8.8)).toFixed(3), rot: rot, mount: { flush: 'top', offset: 0 } });
      }
    }, 'c-dsp'), '', 'c-dsp'));
    var dinfo = dsp && Cat.parts[dsp.type] && Cat.parts[dsp.type].info;
    if (dinfo) c.appendChild(el('div', { class: 'hint', id: 'c-dsp-info' }, [dinfo.px[0] + ' x ' + dinfo.px[1] + ', ' + dinfo.ic + ', ' + dinfo.bus + '. ' + dinfo.price + '. ' + dinfo.fps + '. '].concat(dinfo.links.map(function (l, i) { return el('span', {}, [i ? ' · ' : '', el('a', { href: l[1], target: '_blank', rel: 'noopener', text: l[0] })]); }))));
    c.appendChild(row('Expansion port', sel(Object.keys(Cat.portTypes).map(function (k) { return [k, Cat.portTypes[k].label]; }), currentPort(), function (v) { setPort(v); }, 'c-port'), '', 'c-port'));
    c.appendChild(check('c-plug', 'Show what is plugged into the sockets', P.show.plugged !== false, function (v) { P.show.plugged = v; }));
    c.appendChild(check('c-press', 'Show the buttons pressed (those with a travel)', !!P.show.pressed, function (v) { if (v) P.show.pressed = true; else delete P.show.pressed; }));
    (Cat.controls || []).forEach(function (ctl) {
      c.appendChild(row(ctl.label, sel(ctl.options, controlValue(ctl), function (v) { setControl(ctl, v); }, 'c-ctl-' + ctl.key), '', 'c-ctl-' + ctl.key));
    });
    var list = el('div', { class: 'partlist' });
    R.parts.forEach(function (p) {
      if (p.system) return;
      list.appendChild(el('button', { type: 'button', 'aria-pressed': String(ui.sel === p.id), text: p.id + '  ·  ' + p.label, onclick: function () { ui.sel = ui.sel === p.id ? null : p.id; rebuild(true); } }));
    });
    c.appendChild(list);
    var u = ui.sel && userPart(ui.sel);
    if (u) {
      c.appendChild(row('x', num(u.x, 0.1, function (v) { u.x = v; }, { id: 'c-px' }), 'mm', 'c-px'));
      c.appendChild(row('y', num(u.y, 0.1, function (v) { u.y = v; }, { id: 'c-py' }), 'mm', 'c-py'));
      c.appendChild(row('Rotation', num(u.rot || 0, 5, function (v) { u.rot = ((v % 360) + 360) % 360; }, { id: 'c-pr' }), 'deg', 'c-pr'));
      c.appendChild(row('Mount', sel(mountOptions(), mountValue(u.mount), function (v) { var a = v.split(':'); u.mount = a[0] === 'flush' ? { flush: a[1], offset: 0 } : { on: a[0], side: a[1] }; }, 'c-pm'), '', 'c-pm'));
      if (u.mount.flush) c.appendChild(row('Offset from flush', num(u.mount.offset || 0, 0.1, function (v) { u.mount.offset = v; }, { id: 'c-po' }), 'mm', 'c-po'));
      var ucat = Cat.parts[u.type];
      if (ucat && ucat.dims) {
        c.appendChild(row('Name', el('input', { type: 'text', value: u.name || '', id: 'c-pname', placeholder: 'what it is', onchange: function (e) { if (e.target.value) u.name = e.target.value; else delete u.name; rebuild(true); } }), '', 'c-pname'));
        Object.keys(ucat.dims).forEach(function (k) {
          var cur = u.dims && u.dims[k] != null ? u.dims[k] : ucat.dims[k];
          c.appendChild(row(ucat.dimLabels[k], num(cur, (ucat.dimStep && ucat.dimStep[k]) || 0.1, function (v) { u.dims = u.dims || clone(ucat.dims); u.dims[k] = v; }, { min: 0, max: 60, id: 'c-dim-' + k }), ucat.dimUnits && ucat.dimUnits[k] != null ? ucat.dimUnits[k] : 'mm', 'c-dim-' + k));
        });
      }
      if (ucat && ucat.group === 'display' && ucat.screen) {
        var wOn = !!u.window, wv = function (k) { return u.window && u.window[k] != null ? u.window[k] : Cat.window[k]; };
        c.appendChild(check('c-win', 'Behind a window: under the top board, only the active area shows', wOn, function (v) { if (v) u.window = {}; else delete u.window; }));
        if (wOn) {
          c.appendChild(row('Cut inside the active area by', num(wv('crop'), 0.05, function (v) { u.window.crop = v; }, { min: 0, max: 3, id: 'c-win-crop' }), 'mm', 'c-win-crop'));
          c.appendChild(row('Corner chamfer', num(wv('chamfer'), 0.1, function (v) { u.window.chamfer = v; }, { min: 0, max: 8, id: 'c-win-ch' }), 'mm', 'c-win-ch'));
          c.appendChild(check('c-win-glass', 'Glass let into the cut, flush with the top', !!wv('glass'), function (v) { u.window.glass = v ? 1 : 0; }));
          if (wv('glass')) c.appendChild(row('Gap round the glass', num(wv('gap'), 0.01, function (v) { u.window.gap = v; }, { min: 0, max: 0.5, id: 'c-win-gap' }), 'mm', 'c-win-gap'));
        }
      }
      if (ucat && ucat.group === 'button') {
        var tOn = u.tongue !== false && !!(u.tongue || ucat.tongue), tv = function (k) { return u.tongue && u.tongue[k] != null ? u.tongue[k] : (ucat.tongue && ucat.tongue[k] != null ? ucat.tongue[k] : Cat.tongue[k]); };
        c.appendChild(check('c-tongue', 'Cantilevered: a tongue cut in the top board', tOn, function (v) { if (v) { if (ucat.tongue) delete u.tongue; else u.tongue = clone(Cat.tongue); } else { if (ucat.tongue) u.tongue = false; else delete u.tongue; } }));
        if (tOn) {
          [['len', 'Tongue length', 4, 40, 0.5], ['w', 'Tongue width', 1.5, 12, 0.1], ['slot', 'Slot width', 0.4, 3, 0.1], ['tip', 'Tongue past the switch', 0, 10, 0.5], ['nub', 'Bump under the tongue', 0, 1, 0.05]].forEach(function (d) {
            c.appendChild(row(d[1], num(tv(d[0]), d[4], function (v) { if (!u.tongue) u.tongue = {}; u.tongue[d[0]] = v; }, { min: d[2], max: d[3], id: 'c-tg-' + d[0] }), 'mm', 'c-tg-' + d[0]));
          });
          c.appendChild(row('Tongue runs', sel([['0', 'towards +y of the part'], ['90', 'towards +x'], ['180', 'towards -y'], ['270', 'towards -x']], String(tv('dir') || 0), function (v) { if (!u.tongue) u.tongue = {}; u.tongue.dir = +v; }, 'c-tg-dir'), '', 'c-tg-dir'));
        }
      }
      var rp = resolved(u.id);
      if (rp) {
        c.appendChild(el('div', { class: 'hint', text: 'Boards opened for it (tick to open, untick to keep whole):' }));
        R.layers.slice().reverse().forEach(function (L) {
          var st = rp.boards[L.id] || { state: 'whole', auto: 'whole', set: null }, open = st.state === 'through' || st.state === 'access';
          var cb = el('input', { type: 'checkbox', id: 'c-open-' + L.id, onchange: function (e) {
            var want = e.target.checked, autoOpen = st.auto !== 'whole';
            u.open = u.open || {};
            if (want === autoOpen) delete u.open[L.id]; else u.open[L.id] = want;
            if (!Object.keys(u.open).length) delete u.open;
            rebuild(true);
          } }); cb.checked = open;
          c.appendChild(el('div', { class: 'row boardrow' + (st.state === 'blocked' ? ' bad' : '') }, [el('label', { for: 'c-open-' + L.id, text: L.id + ' ' + L.name + ': ' + boardText(st) }), cb]));
        });
        if (u.open) c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'Some of these are set by hand.' }), el('button', { type: 'button', text: 'Back to automatic', onclick: function () { delete u.open; rebuild(true); } })]));
      }
      var act = function (id, text, title, fn) { return el('button', { type: 'button', id: id, text: text, title: title, onclick: function () { fn(); rebuild(true); } }); };
      c.appendChild(el('div', { class: 'acts' }, [act('c-turn', 'Turn 90', 'R', function () { turnPart(u, 90); }), act('c-turn45', 'Turn 45', 'Shift + R', function () { turnPart(u, 45); }),
        u.mount.on ? act('c-flip', 'Other side', 'F: the other face of the same board', function () { u.mount.side = u.mount.side === 'bottom' ? 'top' : 'bottom'; }) : null,
        act('c-dup', 'Duplicate', 'D', function () { duplicatePart(u); }), act('c-del', 'Remove', 'Delete', function () { removePart(u); })]));
      var uc2 = Cat.parts[u.type];
      if (uc2 && uc2.travel) {
        if (P.show.pressed) c.appendChild(el('div', { class: 'hint', id: 'c-pressed-all', text: 'Drawn pressed, ' + uc2.travel + ' mm down, because all buttons are shown pressed (the tick under the expansion port).' }));
        else c.appendChild(check('c-pressed', 'Pressed: actuator down ' + uc2.travel + ' mm (P)', !!u.pressed, function (v) { if (v) u.pressed = true; else delete u.pressed; }));
        if (uc2.variants && uc2.variants.length) c.appendChild(el('div', { class: 'hint', id: 'c-variants', text: 'Part numbers: ' + uc2.variants.map(function (v) { return v.mpn + ' ' + v.force + (v.lcsc ? ' (LCSC ' + v.lcsc + ')' : ''); }).join(', ') + '.' }));
      }
      if (uc2 && uc2.source) c.appendChild(el('div', { class: 'hint', text: uc2.source }));
      c.appendChild(el('div', { class: 'hint', text: 'Drag it in the view. Arrow keys nudge 0.1 mm, with Shift 1.27 mm. R turns, D duplicates, Delete removes' + (uc2 && uc2.travel ? ', P presses it.' : '.') }));
    }
    c.appendChild(el('h3', { text: 'Add a part' }));
    var B = ui.browse;
    var GROUPS = [['all', 'All'], ['button', 'Buttons'], ['nav', 'Directional'], ['joy', 'Joysticks'], ['wheel', 'Wheels'], ['port', 'Ports'], ['display', 'Displays'], ['chip', 'Chips'], ['other', 'Other']];
    var known = { button: 1, nav: 1, joy: 1, wheel: 1, port: 1, display: 1, chip: 1 };
    var res = el('div', { class: 'browse', id: 'c-browse', role: 'list' }), count = el('span', { class: 'hint', id: 'c-count' });
    function fill() {
      var words = B.q.toLowerCase().split(/\s+/).filter(Boolean), n = 0; res.innerHTML = '';
      Object.keys(Cat.parts).sort(function (a, b) { var x = Cat.parts[a], y = Cat.parts[b]; return (y.fp ? 1 : 0) - (x.fp ? 1 : 0) || (y.have || 0) - (x.have || 0); }).forEach(function (k) {
        var q = Cat.parts[k], g = known[q.group] ? q.group : 'other';
        if (B.group !== 'all' && g !== B.group) return;
        if (B.mine && !q.have) return;
        var sz = partSize(k), text = (q.label + ' ' + k + ' ' + (q.lcsc || '') + ' ' + (q.fp || '') + ' ' + g).toLowerCase();
        if (!words.every(function (w) { return text.indexOf(w) >= 0; })) return;
        n++;
        res.appendChild(el('div', { class: 'brow', role: 'listitem' }, [el('div', { class: 'bt' }, [el('span', { text: q.label }),
          el('span', { class: 'bd', text: (sz ? sz.w + ' x ' + sz.d + ' x ' + sz.h + ' mm' : '') + (q.have ? '  ·  have ' + q.have : '') + (q.fp ? '  ·  footprint' : '') + (q.model ? '  ·  3D' : '') + (q.travel ? '  ·  travel ' + q.travel : '') })]),
          el('button', { type: 'button', text: 'Add', 'aria-label': 'add ' + q.label, 'data-type': k, onclick: function () { addPartOfType(k); rebuild(true); } })]));
      });
      count.textContent = n + ' of ' + Object.keys(Cat.parts).length + ' parts';
      if (!n) res.appendChild(el('div', { class: 'hint', text: 'Nothing matches. The custom part under Other takes any size.' }));
    }
    c.appendChild(el('input', { type: 'search', id: 'c-find', placeholder: 'find: tact, joystick, M.2, C318884 ...', value: B.q, 'aria-label': 'find a part', oninput: function (e) { B.q = e.target.value; fill(); saveView(); } }));
    c.appendChild(el('div', { class: 'chips' }, GROUPS.map(function (g) { return el('button', { type: 'button', text: g[1], 'aria-pressed': String(B.group === g[0]), onclick: function (e) { B.group = g[0]; Array.prototype.forEach.call(e.target.parentNode.children, function (x) { x.setAttribute('aria-pressed', String(x === e.target)); }); fill(); saveView(); } }); })));
    var mine = el('input', { type: 'checkbox', id: 'c-mine', onchange: function (e) { B.mine = e.target.checked; fill(); saveView(); } }); mine.checked = !!B.mine;
    c.appendChild(el('div', { class: 'row' }, [el('label', { for: 'c-mine', text: 'Only what is in my parts inventory' }), mine]));
    c.appendChild(res); c.appendChild(count); fill();
    c.appendChild(el('div', { class: 'hint', text: 'A new part lands in the middle of the view, selected: drag it into place. Library parts carry the EasyEDA footprint for their LCSC number, which the KiCad export places with them.' }));
    c = sect('Probe dock');
    var pd = P.probe.dock;
    c.appendChild(check('c-dock', 'Dock in the ' + (P.frame.side === 'right' ? 'right' : 'left') + ' strip, between the boards', pd.enabled, function (v) { pd.enabled = v; }));
    if (pd.enabled) {
      c.appendChild(row('Probe diameter', num(P.probe.dia, 0.1, function (v) { P.probe.dia = v; }, { min: 1, max: 12, id: 'c-pdia' }), 'mm', 'c-pdia'));
      c.appendChild(row('Probe length', num(P.probe.len, 1, function (v) { P.probe.len = v; }, { min: 10, max: 200, id: 'c-plen' }), 'mm', 'c-plen'));
      c.appendChild(row('Tip end at y', num(pd.y_tip, 0.5, function (v) { pd.y_tip = v; }, { id: 'c-ptip' }), 'mm', 'c-ptip'));
      c.appendChild(row('Centre line x', num(pd.x, 0.1, function (v) { pd.x = v; }, { id: 'c-pcx' }), 'mm', 'c-pcx'));
      c.appendChild(check('c-pzauto', 'Centred between bottom and top board', pd.z == null, function (v) { pd.z = v ? null : R.probe.zc; }));
      if (pd.z != null) c.appendChild(row('Axis height z', num(pd.z, 0.1, function (v) { pd.z = v; }, { id: 'c-pz' }), 'mm', 'c-pz'));
      c.appendChild(row('Magnet dia x length', el('span', {}, [num(P.probe.magnet.dia, 0.5, function (v) { P.probe.magnet.dia = v; }, { min: 0.5, max: 10, label: 'magnet diameter' }), ' ', num(P.probe.magnet.len, 0.5, function (v) { P.probe.magnet.len = v; }, { min: 0.5, max: 10, label: 'magnet length' })]), 'mm'));
    }

    c = sect('View');
    var vdock = el('select', { id: 'c-vdock', onchange: function (e) { ui.viewbar.dock = e.target.value; saveView(); renderControls(); } }, [['bottom', 'along the bottom'], ['top', 'along the top'], ['left', 'down the left'], ['right', 'down the right'], ['off', 'nowhere: all of them here']].map(function (o) { return el('option', { value: o[0], text: o[1] }); })); vdock.value = ui.viewbar.dock;
    c.appendChild(row('Controls in the 3D view', vdock, '', 'c-vdock'));
    viewItems().forEach(function (it) {
      var id = VIEW_ID[it.k] || 'c-' + it.k, there = inView(it.k);
      var pin = el('button', { type: 'button', class: 'pin', 'data-k': it.k, 'aria-pressed': String(there), text: there ? 'in view' : 'pin', title: there ? 'bring it back here' : 'put it in the 3D view', 'aria-label': there ? 'bring ' + it.label + ' back to this list' : 'put ' + it.label + ' in the 3D view', onclick: function () { togglePin(it.k); } });
      if (there) c.appendChild(el('div', { class: 'row pinned' }, [el('span', { class: 'hint', text: it.label }), pin]));
      else c.appendChild(el('div', { class: 'row' }, [el('label', { for: id, text: it.label }), el('span', { class: 'ctl' }, [it.make(id), pin])]));
    });
    c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'Save the picture as a PNG:' }), el('span', {}, [el('button', { type: 'button', text: 'As shown', onclick: function () { savePng(1); } }), ' ', el('button', { type: 'button', text: '2x', onclick: function () { savePng(2); } })])]));
    c.appendChild(check('c-sens', 'Show the magnetometers', P.show.sensors, function (v) { P.show.sensors = v; }));
    c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: R.wig.sensors.list.length + ' of them. Where they sit and how well that places the probe:' }), el('button', { type: 'button', text: 'Magnetometers tab', onclick: function () { setTab('mag'); } })]));
    c = sect('Look');
    var lk = P.look = P.look || {};
    function lsel(id, k, opts) { return sel(opts, lk[k] || opts[0][0], function (v) { lk[k] = v; }, id); }
    var colours = [['black', 'black'], ['white', 'white'], ['green', 'green'], ['purple', 'purple'], ['blue', 'blue'], ['red', 'red']];
    c.appendChild(row('Board soldermask', lsel('c-mask', 'mask', colours), '', 'c-mask'));
    c.appendChild(row('Face board soldermask', lsel('c-fmask', 'face_mask', colours), '', 'c-fmask'));
    c.appendChild(row('Silkscreen', lsel('c-silk', 'silk', [['white', 'white'], ['black', 'black'], ['yellow', 'yellow']]), '', 'c-silk'));
    c.appendChild(row('Copper finish', seg([['enig', 'ENIG gold'], ['hasl', 'HASL']], lk.finish || 'enig', function (v) { lk.finish = v; })));
    c.appendChild(row('Shell', seg([['black', 'Black'], ['white', 'White'], ['clear', 'Clear']], lk.shell || 'black', function (v) { lk.shell = v; })));
    c.appendChild(row('LEDs under the holes', lsel('c-leds', 'leds', [['off', 'off'], ['rainbow', 'rainbow'], ['rails', 'rails lit'], ['probe', 'probe cursor']]), '', 'c-leds'));
    c.appendChild(check('c-scr', 'Light the display', lk.screen !== false, function (v) { lk.screen = v; }));
    c.appendChild(el('div', { class: 'hint', text: 'How the Real view paints things. None of it changes the geometry or the files.' }));

    c = sect('Saved designs');
    c.appendChild(el('div', { class: 'hint', text: State.available() ? 'The design, the view settings and the camera are kept in this browser and come back when the page is reloaded. Nothing is sent anywhere.' : 'This browser is not letting the page keep anything. Use Copy code or Export to keep a design.' }));
    var nameIn = el('input', { type: 'text', id: 'c-savename', placeholder: 'name this design', 'aria-label': 'name for a saved copy', value: ui.saveName || '' });
    c.appendChild(el('div', { class: 'row' }, [nameIn, el('button', { type: 'button', text: 'Save a copy', onclick: function () { var n = (nameIn.value || '').trim() || ('design ' + new Date().toISOString().slice(0, 16).replace('T', ' ')); ui.saveName = n; notice = State.putSave(n, P) ? null : 'The copy could not be kept (the browser refused the storage).'; saveView(); renderControls(); } })]));
    var sv = State.saves();
    if (sv.length) { var sl = el('div', { class: 'savelist' }); sv.forEach(function (e) {
      sl.appendChild(el('div', { class: 'row' }, [el('span', { class: 'savename', text: e.name, title: (e.rev || '') + '  ' + new Date(e.t).toLocaleString() }), el('span', {}, [
        el('button', { type: 'button', text: 'Open', onclick: function () { var q = State.getSave(e.name, DEFAULTS); if (q) { ui.saveName = e.name; adopt(q); } } }), ' ',
        el('button', { type: 'button', class: 'quiet', text: 'Delete', 'aria-label': 'delete ' + e.name, onclick: function () { State.delSave(e.name); renderControls(); } })])]));
    }); c.appendChild(sl); }
    var canLink = /^https?:$/.test(location.protocol) && (function () { try { return window.top === window; } catch (e) { return false; } })();
    var codeIn = el('input', { type: 'text', id: 'c-code', placeholder: 'paste a link, a code or the JSON', 'aria-label': 'a link, a code or JSON to open' });
    function copy(text, what) { var done = function () { notice = what + ' copied.'; renderControls(); }; try { navigator.clipboard.writeText(text).then(done, function () { codeIn.value = text; codeIn.select(); }); } catch (e2) { codeIn.value = text; codeIn.select(); } }
    c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'Hand it to someone, or to another browser:' }), el('span', {}, [
      canLink ? el('button', { type: 'button', text: 'Copy link', onclick: function () { copy(location.href.split('#')[0] + '#p=' + State.encode(P, DEFAULTS), 'Link'); } }) : null, canLink ? ' ' : null,
      el('button', { type: 'button', text: 'Copy code', onclick: function () { copy(State.encode(P, DEFAULTS), 'Code'); } })])]));
    c.appendChild(el('div', { class: 'row' }, [codeIn, el('button', { type: 'button', text: 'Open', onclick: function () { try { var q = State.decode(codeIn.value, DEFAULTS); notice = null; adopt(q); } catch (e3) { notice = 'That could not be read: ' + e3.message + '.'; renderControls(); } } })]));
    c.appendChild(el('div', { class: 'row' }, [el('span', {}, [el('button', { type: 'button', text: 'Undo', onclick: undo }), ' ', el('button', { type: 'button', text: 'Redo', onclick: redo })]), el('button', { type: 'button', text: 'Back to the built-in design', onclick: function () { adopt(clone(DEFAULTS)); } })]));
    root.scrollTop = keepScroll;
  }

  // ---------- checks ----------
  function pill(kind, text) { return el('span', { class: 'pill ' + kind, text: text }); }
  function line(kind, label, title, detail) { return el('div', { class: 'check' }, [pill(kind, label), el('span', { class: 't', text: title }), detail ? el('span', { class: 'd', text: detail }) : null]); }
  function renderChecks() {
    var c = R.checks, box = $('checks'); box.innerHTML = '';
    var g = c.grid, nb = {}; c.neighbours.forEach(function (n) { nb[n.id] = n; });
    var wigsFit = !nb.wig_left.overlap_mm2 && !nb.wig_right.overlap_mm2, unitsFit = !nb.unit_left.overlap_mm2;
    $('rev').textContent = (P.meta.rev || '') + '  ·  ' + (R.removable ? 'removable wig' : 'integrated');
    var hl = $('headline'); hl.innerHTML = '';
    if (ui.tab === 'mag') { magTab.checks(box, hl); return; }
    hl.appendChild(pill(g.on_grid && wigsFit && unitsFit ? 'ok' : g.on_grid && wigsFit ? 'warn' : 'bad', unitsFit ? g.dead_rows + ' dead row' + (g.dead_rows > 1 ? 's' : '') + ', pitch ' + g.pitch : wigsFit ? 'breadboards fit beside it, a second unit does not' : 'a neighbour overlaps'));
    hl.appendChild(document.createTextNode(' '));
    var nClash = c.clashes.length + c.blocked.length;
    hl.appendChild(pill(nClash ? 'bad' : 'ok', nClash ? nClash + ' clash' + (nClash > 1 ? 'es' : '') : 'no clashes'));
    hl.appendChild(document.createTextNode(' '));
    if (c.area.fill != null) hl.appendChild(pill(c.area.fill > 0.6 ? 'bad' : c.area.fill > 0.45 ? 'warn' : 'ok', Math.round(c.area.fill * 100) + ' % of component room used'));

    box.appendChild(el('h2', { text: '0.1 inch stacking' }));
    box.appendChild(line(g.on_grid ? 'ok' : 'bad', g.on_grid ? 'on grid' : 'off grid', 'Unit pitch ' + g.pitch + ' mm = ' + Math.round(g.pitch / P.grid.pitch) + ' x 2.54', 'Grid planes at x = ' + g.left_plane + ' and ' + g.right_plane + '. Dead-row pins land at x = ' + g.dead_x.join(', ') + '.'));
    c.neighbours.forEach(function (n) {
      if (!n.overlap_mm2) { box.appendChild(line('ok', 'fits', n.label, 'One unit pitch away, edges meeting on the plane.')); return; }
      box.appendChild(line('bad', n.overlap_mm2 + ' mm²', n.label, 'Overlaps up to ' + n.depth + ' mm between y ' + n.y0 + ' and ' + n.y1 + ': ' + n.items.map(function (i) { return i.what; }).join(', ') + '.'));
    });
    if (!unitsFit && g.units_clear_at) box.appendChild(line('warn', g.units_clear_at.dead_rows + ' rows', 'Two whole units clear each other at pitch ' + g.units_clear_at.pitch, 'That is ' + g.units_clear_at.extra_rows + ' more dead row' + (g.units_clear_at.extra_rows > 1 ? 's' : '') + ' than the strip gives. Plan view only; heights are not considered.'));

    var cq = g.coupler;
    if (cq) box.appendChild(line(cq.fits ? 'ok' : 'bad', cq.fits ? 'fits' : 'short', cq.label + ' between two units', 'Needs ' + cq.gap + ' mm between the two boards (housing ' + cq.across + ' x ' + cq.len + ' x ' + cq.thick + '). The strip leaves ' + cq.have + ' mm' + (cq.fits ? ', ' + cq.spare + ' spare. ' : '; it first fits with a ' + cq.strip_needed + ' mm strip. ') + (cq.tip_gap != null ? 'Its ' + cq.tongue + ' mm tongues meet about ' + cq.tip_gap + ' apart inside it. ' : 'Tongue ' + cq.tongue + ' long. ') + 'The tongue is not part of the outline yet, and the strip is board where the coupler would sit.'));

    var xq = c.extender;
    if (xq) {
      box.appendChild(el('h2', { text: 'Side port and extender' }));
      box.appendChild(line(xq.on_grid ? 'ok' : 'bad', xq.rows + ' rows', 'Extender: ' + xq.cols + ' columns, ' + xq.w + ' mm wide, ' + (xq.dead ? xq.dead + ' dead row' + (xq.dead > 1 ? 's' : '') : 'no dead row') + ' at the seam', 'Its first column is ' + xq.col_gap + ' mm from column ' + (xq.side === 'left' ? 1 : P.grid.cols) + ', on the same 0.1 inch grid. Unit and extender together are ' + xq.pair_w + ' mm = ' + xq.pair_rows + ' rows, so a next unit beside them keeps the grid too.'));
      var sc = xq.seam_col;
      if (sc) box.appendChild(sc.fits ? line('ok', sc.wall + ' mm wall', 'Its first column is on the grid plane, in the edge that bows into the waist', 'The waist in the breadboard\'s side is ' + sc.has + ' mm deep (the WigLEDmag\'s own is ' + sc.own + '), which leaves the breadboard a ' + sc.wall + ' mm wall beside column ' + (xq.side === 'left' ? 1 : P.grid.cols) + '. The extender\'s first channel is open on that side and that wall closes it: the ' + sc.clip + ' mm clip clears it by ' + sc.clip_clear + ' mm, and its solder tab has ' + sc.land + ' mm of board to the edge.' + (sc.face_land ? ' The two top boards meet on the half-pitch line: ' + sc.face_land.ext + ' mm of land outside the ' + sc.face_land.countersink + ' mm countersinks on the extender, ' + sc.face_land.unit + ' on the breadboard.' : '') + ' The rails start ' + xq.rail_skip + ' hole' + (xq.rail_skip > 1 ? 's' : '') + ' in, where the breadboard\'s corners are.')
        : line('bad', 'no room', 'Its first column does not fit on the grid plane', !sc.bowed ? 'Its edge has to fill the waist for a column there (Side port and extender).' : 'A column there needs the waist ' + sc.need + ' mm deep and it is ' + sc.has + ': the ' + sc.clip + ' mm clip would be ' + (-sc.clip_clear) + ' mm into the breadboard\'s side, and the board ' + (sc.land < 0 ? (-sc.land) + ' mm short under its solder tab.' : 'has ' + sc.land + ' mm under its solder tab.')));
      var xp = xq.port;
      if (xp && xp.press) { var pr = xp.press; box.appendChild(line(pr.mags && pr.mags.length ? 'warn' : 'ok', '2 x ' + xp.n, 'Pressed in from the back: a tab of the extender in a knob-shaped cutout of the bottom board', 'Socket: ' + xp.kind_label + ', its top ' + (xp.room >= 0 ? xp.room + ' mm below' : (-xp.room) + ' mm ABOVE') + ' the top face, the top and the bottom board opened over and under it so a pin can go all the way through. The cutout is ' + (pr.knob[2] - pr.knob[0]).toFixed(1) + ' x ' + (pr.knob[3] - pr.knob[1]).toFixed(1) + ' mm with a ' + pr.neck + ' mm neck to the edge: ' + pr.under + ' mm of undercut each side holds the tab in the plane, cut ' + pr.gap + ' mm clear. Pins from the tab reach the socket\'s top at z ' + pr.pin_tip + ': ' + pr.pin_len + ' mm above a 1.0 mm base (the usual 1.27 mm header has 3.0).' + (pr.mags && pr.mags.length ? ' Magnetometer ' + pr.mags.join(', ') + ' is in the cutout and has to move.' : '') + (xp.price ? ' ' + xp.price + ' (read 2026-11-28).' : ''))); }
      if (!xp) box.appendChild(line('bad', 'no socket', 'Nothing in the ' + (xq.side || 'right') + ' side for it to plug into', 'Side port and extender: tick the header socket in the ' + (xq.side || 'right') + ' side.'));
      else {
        if (!xp.press) box.appendChild(line(!xp.faces || xp.open_seam || !xp.pin_ok ? 'bad' : xp.inset > 0.005 || (xp.room != null && xp.room < 0) ? 'warn' : 'ok', '2 x ' + xp.n, 'Side socket: ' + xp.kind_label + ', ' + xp.pins + ' pins, ' + xp.len + ' mm long', !xp.faces ? 'It has to be on top of the main board and turned 180 for its mouth to face the extender.' : 'Mouth at x ' + xp.mouth_x + (Math.abs(xp.inset) < 0.005 ? ', on the edge: the header\'s ' + xp.pin + ' mm pins go all the way in.' : xp.inset > 0 ? ', ' + xp.inset + ' mm inside the edge: the ' + xp.pin + ' mm pins go ' + xp.engage + ' in.' : ', ' + xp.open_seam + ' mm past the edge: the seam stands open by that.') + ' It runs from y ' + xp.y0 + ' to ' + xp.y1 + '.' + (xp.takes ? ' Its maker gives ' + xp.takes[0] + ' to ' + xp.takes[1] + ' mm of insertion' + (xp.pin_ok ? ', which a ' + xp.pin + ' mm pin meets' + (xp.pin < 4 ? ' (a short-pin header, not the usual 4.0).' : '.') : ': ' + xp.engage + ' mm is outside that.') : '') + (xp.room != null && xp.room < 0 ? ' It is ' + xp.high + ' mm high, ' + (-xp.room) + ' more than there is under the top board, so the top board is opened over it.' : '') + (xp.price ? ' ' + xp.price + ' (read 2026-11-28).' : '')));
        box.appendChild(line(xq.spare < 0 ? 'bad' : xq.spare === 0 ? 'warn' : 'ok', xq.spare < 0 ? (-xq.spare) + ' short' : xq.spare + ' spare', xq.need + ' rows take ' + xq.need + ' of its ' + xp.pins + ' pins', xq.spare < 0 ? 'Fewer columns, or a longer socket.' : xq.spare === 0 ? 'None left on this side for 5 V, ground or LED data. Those are on the top port, which a board on this side does not reach, so the extender\'s rows would be dark.' : 'Left over for power or LED data on this side.'));
      }
      box.appendChild(line(xq.header.covered ? 'ok' : 'warn', xq.header.covered ? 'on its head' : 'off its head', 'Its header, 2 x ' + xq.header.n + ', from y ' + xq.header.y0 + ' to ' + xq.header.y1, 'The head stands ' + xq.head + ' mm above the breadboard\'s top edge' + (xq.cover ? ', with a second board over it.' : ' and is the one board, the header on it in the open.') + ' Plastic face on the extender\'s edge, pins ' + (xq.port ? xq.port.pin : 4) + ' mm into the unit.'));
      box.appendChild(xq.overlap.overlap_mm2 ? line('bad', xq.overlap.overlap_mm2 + ' mm²', 'The extender overlaps this unit', 'Up to ' + xq.overlap.depth + ' mm between y ' + xq.overlap.y0 + ' and ' + xq.overlap.y1 + ': ' + xq.overlap.items.map(function (i) { return i.what; }).join(', ') + '. Plan view only.')
        : line('ok', 'clear', 'The extender shares no plan area with this unit', xq.keyed ? 'Its edge fills the waist in the breadboard\'s side (' + xq.keyed + ' mm² of key), so the two cannot slide along the seam.' : 'Its edge is straight; the waist in the breadboard\'s side is left open.'));
      box.appendChild(xq.tied ? line('ok', xq.ties.n + ' ties', 'Seam ' + xq.seam + ' mm, tied by wire staples at y ' + xq.ties.at.map(function (q) { return q[1]; }).join(' and '), xq.ties.wire + ' mm wire, ' + xq.ties.span + ' mm span, in the holes beside the rails (' + xq.ties.hole + ' mm, ' + xq.ties.room + ' mm from the next hole).')
        : line('warn', xq.play ? xq.play.corner + ' mm' : 'loose', 'Seam ' + xq.seam + ' mm, held by ' + (xq.port && xq.port.press ? 'the tab in its cutout' : 'the header pair') + (xq.keyed ? ' and the key' : '') + ' alone', (xq.play ? 'The pair is ' + xq.play.joint + ' mm of joint at the top of the seam: 0.1 mm of side play in it is ' + xq.play.corner + ' mm at the bottom corner, ' + xq.play.arm + ' mm away. ' : '') + (xq.keyed ? 'The key stops the two sliding along the seam, not the seam opening.' : '') + ' Nothing pulls the seam shut below the header.'));
      if (xq.jumpers) box.appendChild(line('ok', xq.jumpers + ' jumpers', 'The rails cross the seam on ' + xq.jumper_span + ' mm jumpers', 'From the rail holes of column ' + P.grid.cols + ' to the extender\'s first column.'));
      if (xq.near) box.appendChild(line(xq.near.d < 10 ? 'warn' : 'ok', xq.near.d + ' mm', 'Nearest magnetometer (' + xq.near.ref + ') to ' + xq.near.what, 'No magnets on this seam, and brass or A2 stainless for anything screwed there.'));
    }

    box.appendChild(el('h2', { text: 'Stack height' }));
    var hasFace = !!R.wig.face, d = hasFace ? c.flush.delta_shell : c.flush.delta, fk = Math.abs(d) <= 0.1 ? 'ok' : Math.abs(d) <= 0.5 ? 'warn' : 'bad';
    box.appendChild(line(fk, (d >= 0 ? '+' : '') + d + ' mm', 'Top board at ' + c.flush.frame_top + (hasFace ? ', shell top ' + c.flush.shell_top + ', wig top board ' + c.flush.bb_top : ', breadboard top ' + c.flush.bb_top), 'Total ' + (+(Math.max(c.flush.frame_top, c.flush.bb_top) - R.z.bottom).toFixed(2)) + ' mm from the main board underside' + (hasFace ? ' to the top of the ' + c.flush.face_t + ' mm wig top board' : '') + '. Gaps: ' + c.flush.gaps.map(function (q) { return q.gap + ' under ' + q.below; }).join(', ') + '.'));
    R.layers.forEach(function (L) { if (L.cutBy.length) box.appendChild(line(L.index === 0 || L.index === R.layers.length - 1 ? 'warn' : 'ok', L.id, L.name + ' is opened for ' + L.cutBy.join(', '), L.pocketArea + ' mm² removed' + (L.islands !== 1 ? ', which leaves it in ' + L.islands + ' pieces' : '') + '.')); else box.appendChild(line('ok', L.id, L.name + ' is whole')); });

    box.appendChild(el('h2', { text: 'Clashes' }));
    if (!c.clashes.length && !c.blocked.length) box.appendChild(line('ok', 'none', 'No two parts share space'));
    c.blocked.forEach(function (k) { box.appendChild(line('bad', k.mm2 + ' mm²', k.label + ' runs into ' + k.layer + ' ' + k.name, 'That board is set to stay whole for this part.')); });
    c.clashes.forEach(function (k) { box.appendChild(line('bad', k.overlap_z + ' mm', k.labels[0] + ' and ' + k.labels[1], k.overlap_mm2 + ' mm² of overlap in plan (' + k.bodies.join(' against ') + ').')); });
    c.overhang.forEach(function (o) { box.appendChild(line('warn', o.mm2 + ' mm²', o.label + ' reaches past the edge of ' + o.layer, 'x ' + o.x[0] + ' .. ' + o.x[1] + ', y ' + o.y[0] + ' .. ' + o.y[1] + '.')); });

    if (c.proud.length) {
      box.appendChild(el('h2', { text: 'Standing out' }));
      c.proud.forEach(function (k) { box.appendChild(line('info', '+' + k.by + ' mm', k.label, k.side === 'top' ? 'Above the top face.' : 'Below the underside of the main board.')); });
    }

    if (c.windows && c.windows.length) {
      box.appendChild(el('h2', { text: 'Display window' }));
      c.windows.forEach(function (k) {
        box.appendChild(line('ok', k.w + ' x ' + k.h, k.id + ': the cut in ' + k.board + ' (' + k.t + ' mm), corners chamfered ' + k.chamfer,
          k.shown_pct + ' % of the ' + k.aa[0] + ' x ' + k.aa[1] + ' active area shows; the cut is ' + k.crop + ' mm inside it all round, so the dead border is covered. ' + (k.glass ? 'A pane ' + k.glass.w + ' x ' + k.glass.h + ' x ' + k.glass.t + ' with ' + k.glass.gap + ' mm round it ends flush with the top face.' : 'No glass: the panel is ' + k.t + ' mm down the cut.') + ' A routed cut has a 0.4 to 0.5 mm radius in each corner; the pane needs the same.'));
        if (k.below) box.appendChild(line(k.under < 0.5 ? 'warn' : 'info', k.under + ' mm', k.id + ': room under the module, above ' + k.below,
          'The module is from z ' + k.z_module[0] + ' to ' + k.z_module[1] + '. Switches under the display need about 0.5 mm for a metal dome and 1.9 for a 1.7 mm tact; with less, they stand on the board below and come up through ' + k.below + '.'));
      });
    }
    if (c.cantilevers && c.cantilevers.length) {
      box.appendChild(el('h2', { text: 'Cantilevered buttons' }));
      c.cantilevers.forEach(function (k) {
        var where = k.id + ': tongue ' + (k.arm != null ? k.arm + ' x ' + k.w + ' ' : '') + 'in ' + k.board + ' (' + k.t + ' mm)';
        if (k.none) { box.appendChild(line('warn', 'no tongue', k.id + ': no tongue in ' + k.board, k.why === 'through' ? 'The switch itself comes up through the top board, so there is nothing to cut a tongue in.' : k.why === 'kept' ? 'The top board is set to stay whole for it: tick ' + k.board + ' in the key\'s list of boards.' : 'The top board is not opened for it.')); return; }
        if (k.broken) box.appendChild(line('bad', 'breaks out', k.id + ': the slot is less than 0.8 mm from an edge or another opening', k.broken + ' mm² of the ring round the slot is not board. Move it, shorten the tongue or narrow the slot.'));
        if (k.away) { box.appendChild(line('bad', 'cannot press', where, 'The switch is on ' + k.switch_on + (k.underside ? ', on its underside, facing away from the top board' : ', on top of the board the tongue is cut in') + '. The tongue cannot work it there. Put it on the top face of the board under ' + k.board + ', or on the underside of ' + k.board + ' (Mount, or Other side).')); return; }
        if (k.under && k.lands == null) { box.appendChild(line('bad', 'nothing under', where, 'The switch rides under the tongue but there is no board below it to press on.')); return; }
        if (k.far) { box.appendChild(line('bad', k.gap + ' mm off', where, 'The switch on ' + k.switch_on + ' stops ' + k.gap + ' mm short of the tongue, so the tongue will not reach it. Put the switch on the board just under ' + k.board + ', or under the tongue itself.')); return; }
        box.appendChild(line(k.force <= 4 ? 'ok' : k.force <= 10 ? 'warn' : 'bad', '~' + k.force + ' N', where + (k.under ? ', switch under the tongue, pressing on ' + k.lands : ', switch on ' + k.switch_on),
          'The board alone takes ' + k.board_force + ' N to bend the ' + k.travel + ' mm to the click (' + k.gap + ' gap' + (k.nub ? ' less the ' + k.nub + ' bump' : '') + ' + 0.25 travel), plus about 1.6 N for the switch; ' + k.k + ' N/mm, ' + k.stress + ' MPa at the root. In a 0.8 mm board the same tongue is about ' + k.thin.force + ' N' + (k.nub ? '' : '; a 0.2 mm bump ' + (k.under ? 'on the board below' : 'under the tongue') + ' makes it about ' + k.with_nub + ' N') + '. An estimate: plain cantilever, E = 22 GPa.'));
      });
    }
    box.appendChild(el('h2', { text: 'Component room' }));
    var a = c.area;
    box.appendChild(el('div', {}, [el('span', { class: 'big', text: a.placeable + '' }), el('span', { class: 'u', text: ' mm² free' }), el('span', { class: 'hint', text: '  for ' + a.budget + ' mm² of parts' })]));
    box.appendChild(el('div', { class: 'bar' }, [el('i', { style: 'width:' + Math.min(100, Math.round((a.fill || 0) * 100)) + '%;background:var(--' + (a.fill > 0.6 ? 'bad' : a.fill > 0.45 ? 'warn' : 'ok') + ')' })]));
    box.appendChild(el('div', { class: 'hint', text: 'Parts would fill ' + Math.round((a.fill || 0) * 100) + ' % of it. Boards like this stop routing near 45 %.' }));
    var tb = el('table', {}, [el('tr', {}, [el('th', { text: 'Face' }), el('th', { class: 'n', text: 'free mm²' }), el('th', { class: 'n', text: 'headroom' })])]);
    var underBB = 0;
    c.faces.forEach(function (f) { if (!f.counts) return; if (f.under_bb) underBB += f.under_bb; tb.appendChild(el('tr', {}, [el('td', { text: f.layer + ' ' + f.side }), el('td', { class: 'n', text: String(f.free + (f.free_open || 0)) }), el('td', { class: 'n', text: f.open ? 'open' : f.height + ' mm' })])); });
    box.appendChild(tb);
    box.appendChild(el('div', { class: 'hint', text: 'A face counts where nothing stands in front of it and the gap is at least ' + a.min_gap + ' mm. Two faces across one gap share its height. One frame face is ' + a.frame_face + ' mm².' + (underBB ? ' ' + underBB + ' mm² of this is under the breadboard, which also has to carry the breadboard\'s own LEDs, pads and sensors.' : '') }));

    box.appendChild(el('h2', { text: 'Boards' }));
    var lt = el('table', {}, [el('tr', {}, [el('th', { text: 'Board' }), el('th', { class: 'n', text: 'z' }), el('th', { class: 'n', text: 'net mm²' })])]);
    R.layers.slice().reverse().forEach(function (L) { lt.appendChild(el('tr', {}, [el('td', {}, [el('span', { class: 'sw', style: 'background:' + Exp.LAYER_COLORS[L.index % Exp.LAYER_COLORS.length] }), L.id + ' ' + L.name]), el('td', { class: 'n', text: L.z0 + ' .. ' + L.z1 }), el('td', { class: 'n', text: String(L.area) })])); });
    box.appendChild(lt);

    if (c.probe) {
      var pr = c.probe;
      box.appendChild(el('h2', { text: 'Probe dock' }));
      box.appendChild(line(pr.cuts_outer.length ? 'bad' : 'ok', pr.cuts_outer.length ? pr.cuts_outer.join(', ') : 'inside', pr.cuts_outer.length ? 'The channel reaches into the bottom or top board' : 'The probe lies between the bottom and top boards', 'Axis at z ' + pr.zc + ' in a ' + pr.room_z + ' mm space; channel ' + pr.channel_w + ' mm. Opened: ' + (pr.cuts.length ? pr.cuts.join(', ') : 'nothing') + '.'));
      var wmin = Math.min(pr.wall_left, pr.wall_right);
      if (pr.cuts.length) box.appendChild(line(wmin >= 0.8 ? 'ok' : wmin >= 0.4 ? 'warn' : 'bad', wmin + ' mm', 'Thinnest wall left in ' + pr.cuts.join(', ') + ' beside the channel', 'Channel ' + pr.channel_w + ' mm wide in a ' + g.strip_w + ' mm strip.'));
      if (pr.sticks_out > 0) box.appendChild(line('warn', pr.sticks_out + ' mm', 'The probe sticks out past the bottom edge'));
      if (pr.nearest) box.appendChild(line(pr.nearest.frac > 0.8 ? 'bad' : 'ok', pr.nearest.B_mT + ' mT', 'Docked magnet at the nearest ' + pr.nearest.kind, pr.nearest.ref + ' is ' + pr.nearest.r + ' mm away; its range is ±' + pr.nearest.range_mT + ' mT.'));
      if (pr.dead_row_in_channel.length) box.appendChild(line('warn', 'shared', 'A dead-row pin line runs down the channel', 'x = ' + pr.dead_row_in_channel.join(', ') + '. A header bridging two units and a docked probe cannot both be there.'));
    }
    var sp = ui.sel && resolved(ui.sel);
    if (sp) {
      box.appendChild(el('h2', { text: 'Selected: ' + sp.id }));
      box.appendChild(el('div', { class: 'hint', text: sp.label + '. z ' + sp.z0 + ' .. ' + sp.z1 + ' mm, x ' + sp.xmin + ' .. ' + sp.xmax + ' mm.' + (sp.proud != null ? (sp.proud > 0.05 ? ' Its top is ' + sp.proud + ' mm above the top face.' : ' Its top is ' + (-sp.proud) + ' mm below the top face.') : '') }));
      if (sp.source) box.appendChild(el('div', { class: 'hint', text: sp.source }));
    }
    c.notes.forEach(function (t) { box.appendChild(line('warn', 'note', t)); });
  }

  // ---------- export ----------
  function exportItems() {
    var items = [['report', 'Check report (.txt)', 'v6_checks.txt', function () { R.checks.mag = Mag.report(R, P); return Exp.report(R); }],
      ['params', 'Parameters (v6_outline.json)', 'v6_outline.json', function () { return JSON.stringify(P, null, 2) + '\n'; }],
      ['svg', 'Plan of all layers (.svg)', 'v6_plan.svg', function () { return Exp.svg(R); }]];
    R.layers.forEach(function (L) {
      items.push(['dxf:' + L.id, L.id + ' ' + L.name + ' outline (.dxf)', Exp.slug(L) + '.dxf', function () { return Exp.dxf(R, L); }]);
      var nf = Exp.footprintsOn(R, L), nr = nf.filter(function (f) { return f.real; }).length;
      items.push(['kicad:' + L.id, L.id + ' ' + L.name + ' for KiCad: outline as lines and arcs, ' + (nf.length ? nr + ' footprint' + (nr === 1 ? '' : 's') + (nf.length > nr ? ' + ' + (nf.length - nr) + ' outline' + (nf.length - nr === 1 ? '' : 's') : '') : 'no parts') + ' (.kicad_pcb)', Exp.slug(L) + '.kicad_pcb', function () { return Exp.kicad(R, L); }]);
    });
    if (R.wig.face && R.wig.face.holes) items.push(['kicad:WT', 'Wig top board for KiCad: outline and ' + R.wig.face.holes.length + ' holes (.kicad_pcb)', 'WT_wig_top_board.kicad_pcb', function () { return Exp.kicadFace(R); }]);
    if (R.extender) {
      items.push(['kicad:EX', 'Extender bottom board for KiCad: outline as lines and arcs, its header as an outline (.kicad_pcb)', 'EX_Extender_board.kicad_pcb', function () { return Exp.kicadExt(R); }]);
      items.push(['dxf:EX', 'Extender bottom board outline (.dxf)', 'EX_Extender_board.dxf', function () { return Exp.dxfExt(R); }]);
    }
    var mods = Exp.kicadMods(R);
    Object.keys(mods).forEach(function (k) { items.push(['mod:' + k, 'Footprint ' + k + ' (.kicad_mod)', k + '.kicad_mod', function () { return mods[k]; }]); });
    items.push(['resolved', 'Resolved geometry for the STEP script (.json)', 'resolved.json', function () { R.checks.mag = Mag.report(R, P); return JSON.stringify(Geo.plain(R)) + '\n'; }]);
    return items;
  }
  function bindExport() {
    var dlg = $('dlg'), what = $('exp-what'), text = $('exp-text'), note = $('exp-note'), items = [];
    function fill() { var it = items.filter(function (i) { return i[0] === what.value; })[0] || items[0]; text.value = it[3](); note.textContent = 'File name: ' + it[2] + '. Download works when this page is opened from disk; inside Claude use Copy.'; }
    $('btn-export').addEventListener('click', function () {
      items = exportItems(); what.innerHTML = ''; items.forEach(function (i) { what.appendChild(el('option', { value: i[0], text: i[1] })); });
      fill(); if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
    });
    what.addEventListener('change', fill);
    $('exp-close').addEventListener('click', function () { dlg.close ? dlg.close() : dlg.removeAttribute('open'); });
    $('exp-copy').addEventListener('click', function () {
      var done = function () { note.textContent = 'Copied.'; };
      try { navigator.clipboard.writeText(text.value).then(done, function () { text.select(); note.textContent = 'Copy was refused. The text is selected; press Ctrl or Cmd + C.'; }); } catch (e) { text.select(); note.textContent = 'The text is selected; press Ctrl or Cmd + C.'; }
    });
    $('exp-save').addEventListener('click', function () {
      var it = items.filter(function (i) { return i[0] === what.value; })[0];
      try { var a = el('a', { href: URL.createObjectURL(new Blob([text.value], { type: 'text/plain' })), download: it[2] }); document.body.appendChild(a); a.click(); a.remove(); } catch (e) { note.textContent = 'Download is not available here. Use Copy.'; }
    });
    $('btn-load').addEventListener('click', function () { $('file').click(); });
    $('file').addEventListener('change', function (e) {
      var f = e.target.files[0]; if (!f) return;
      var rd = new FileReader();
      rd.onload = function () { try { ui.sel = null; ui.vsel = null; adopt(State.decode(rd.result, DEFAULTS)); } catch (err) { $('rev').textContent = 'Could not load that file: ' + err.message; } };
      rd.readAsText(f); e.target.value = '';
    });
    $('btn-reset').addEventListener('click', function () { ui.hidden = {}; adopt(clone(DEFAULTS)); });
    $('btn-undo').addEventListener('click', undo); $('btn-redo').addEventListener('click', redo);
  }

  // ---------- go ----------
  function rebuild(full, sceneOnly) {
    if (!P.frame.outline || P.frame.outline.length < 3) P.frame.outline = Geo.legacyOutline(P);      // a rev A1 file: turn its band and chamfers into vertices
    if (P.probe && P.probe.dock && P.probe.dock.z === undefined) P.probe.dock.z = null;
    R = Geo.resolve(P, REF);
    if (ui.mag.sel != null && ui.mag.sel >= R.wig.sensors.list.length) ui.mag.sel = null;
    if (ui.tab === 'mag') { sceneStale = true; magTab.refresh(); } else buildScene();       // the tab that is not showing is brought up to date when it is next opened
    renderChecks();
    if (full && !sceneOnly) renderControls();
    save();
  }
  function savePng(scale) {
    if (!renderer) return;
    try { var url = Rn.png(renderer, scene, camera, scale), a = el('a', { href: url, download: 'jumperless_v6_' + ui.render.mode + '.png' }); document.body.appendChild(a); a.click(); a.remove(); }
    catch (e) { notice = 'The picture could not be saved here (' + e.message + ').'; renderControls(); }
  }
  // ---------- the two tabs: the outline in 3D, or the magnetometer map. The same design, panels and undo serve both. ----------
  var TABS = { outline: { design: ['Design', 'what the unit is made of'], view: 'View', checks: ['Checks', 'what the numbers say'], hud: null },
    mag: { design: ['Sensors', 'where they sit'], view: 'Map', checks: ['Accuracy', 'hole by hole'], hud: 'drag a sensor: move it \u00a0 shift: on the 1.27 grid \u00a0 double-click: add one \u00a0 delete: remove it \u00a0 arrows: nudge \u00a0 hover a hole: its error' } };
  var hud0 = null;
  function setTab(name, quiet) {
    name = name === 'mag' ? 'mag' : 'outline';
    var was = ui.tab, t = TABS[name]; ui.tab = name;
    if (magTab && was === 'mag' && name !== 'mag') magTab.stop();
    document.body.classList.toggle('tab-mag', name === 'mag');
    $('tab-outline').setAttribute('aria-selected', String(name === 'outline')); $('tab-mag').setAttribute('aria-selected', String(name === 'mag'));
    $('magview').hidden = name !== 'mag';
    if (renderer) renderer.domElement.style.visibility = name === 'mag' ? 'hidden' : '';     // hidden, not removed: taking a WebGL canvas out of the layout can cost its drawing buffer
    $('fallback').style.display = !renderer && name !== 'mag' ? 'block' : 'none';
    $('tip').style.display = 'none';
    if (hud0 == null) hud0 = $('hud').innerHTML;
    if (t.hud) $('hud').textContent = t.hud; else $('hud').innerHTML = hud0;
    function plate(id, words) { var pn = $(id), pl = pn.querySelector('.plate'), bn = pn.querySelector('.bar-note'); pl.lastChild.nodeValue = words[0]; if (bn && words[1] != null) bn.textContent = words[1]; pn.setAttribute('aria-label', words[0]); }
    plate('panel-design', t.design); plate('centre', [t.view, null]); plate('panel-checks', t.checks);
    if (name === 'mag') magTab.enter(); else if (sceneStale) { sceneStale = false; buildScene(); resize(); }
    renderControls(); renderChecks();
    if (!quiet) { saveView(); try { history.replaceState(null, '', name === 'mag' ? '#magnetometers' : location.pathname + location.search); } catch (e) { /* a file:// page may refuse */ } }
  }
  function tabs() {
    magTab = window.V6MagTab.create({ P: function () { return P; }, R: function () { return R; }, ui: ui, ref: REF, el: el, $: $, row: row, num: num, sel: sel, seg: seg, check: check, pill: pill, line: line,
      rebuild: rebuild, saveView: saveView, panels: function () { renderControls(); renderChecks(); }, checksOnly: renderChecks });
    $('tab-outline').addEventListener('click', function () { setTab('outline'); }); $('tab-mag').addEventListener('click', function () { setTab('mag'); });
    window.addEventListener('hashchange', function () { var want = location.hash === '#magnetometers' ? 'mag' : 'outline'; if (want !== ui.tab && (location.hash === '' || location.hash === '#magnetometers')) setTab(want, true); });
  }
  function viewbar() {
    var vb = $('viewbar');
    [['iso', 'Iso'], ['top', 'Top'], ['under', 'Underside'], ['topedge', 'Top edge'], ['left', 'Left edge']].forEach(function (v) { vb.appendChild(el('button', { type: 'button', text: v[1], onclick: function () { setView(v[0]); } })); });
  }
  // ---------- layout: which dock each panel is in, how big the docks are, what is folded. All of it is kept. ----------
  var DOCKS = ['left', 'right', 'bottom'], PANELS = ['panel-design', 'panel-checks'], WIDE = { left: 348, right: 338 }, phone = window.matchMedia ? window.matchMedia('(max-width: 700px)') : { matches: false };
  if (ui.layout.auto === undefined) ui.layout.auto = ui.layout.dock['panel-design'] === 'left' && ui.layout.dock['panel-checks'] === 'right';      // untouched so far: the page picks by the window's width
  function applyLayout() {
    var L = ui.layout, mw = $('main').clientWidth || 1400, mh = $('main').clientHeight || 800, narrow = !!phone.matches;
    // until the panels have been moved by hand, a window too narrow for three columns gets the checks under the view
    if (L.auto) L.dock = { 'panel-design': 'left', 'panel-checks': mw >= 1180 ? 'right' : 'bottom' };
    PANELS.forEach(function (id) { if (DOCKS.indexOf(L.dock[id]) < 0) L.dock[id] = id === 'panel-design' ? 'left' : 'right'; });
    DOCKS.forEach(function (d) {
      var dock = $('dock-' + d), sp = $('split-' + d), mine = PANELS.filter(function (id) { return L.dock[id] === d; }), row = d === 'bottom';
      Array.prototype.slice.call(dock.querySelectorAll('.isplit')).forEach(function (n) { n.remove(); });
      var all = mine.length > 0 && mine.every(function (id) { return ui.panels[id]; });
      mine.forEach(function (id, i) {
        var pn = $(id), shut = !!ui.panels[id]; dock.appendChild(pn);
        pn.classList.toggle('shut', shut);
        pn.classList.toggle('stand', shut && !narrow && (row ? !all : all));
        // in a narrow window the panels are simply stacked under the view at their own height: no shares, or they collapse onto each other
        pn.style.flex = shut || narrow ? '' : ((mine.length === 2 ? (i === 0 ? L.ratio[d] : 1 - L.ratio[d]) : 1) * 100).toFixed(1) + ' 1 0';
        pn.querySelector('.fold').setAttribute('aria-expanded', String(!shut));
        Array.prototype.forEach.call(pn.querySelectorAll('.dk'), function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-dock') === d)); });
      });
      if (!narrow && mine.length === 2 && !ui.panels[mine[0]] && !ui.panels[mine[1]]) {        // two open panels share the dock: a line between them to drag
        var is = el('div', { class: 'isplit', role: 'separator', title: 'drag to share the space out' });
        is.addEventListener('pointerdown', function (ev) {
          ev.preventDefault(); is.setPointerCapture(ev.pointerId); is.classList.add('drag'); document.body.classList.add('resizing');
          function mv(e) { var r = dock.getBoundingClientRect(), f = row ? (e.clientX - r.left) / r.width : (e.clientY - r.top) / r.height; L.ratio[d] = Math.max(0.15, Math.min(0.85, f)); $(mine[0]).style.flex = (L.ratio[d] * 100).toFixed(1) + ' 1 0'; $(mine[1]).style.flex = ((1 - L.ratio[d]) * 100).toFixed(1) + ' 1 0'; }
          function up() { is.classList.remove('drag'); document.body.classList.remove('resizing'); is.removeEventListener('pointermove', mv); is.removeEventListener('pointerup', up); is.removeEventListener('pointercancel', up); saveView(); }
          is.addEventListener('pointermove', mv); is.addEventListener('pointerup', up); is.addEventListener('pointercancel', up);
        });
        dock.insertBefore(is, $(mine[1]));
      }
      var size = row ? Math.max(120, Math.min(Math.max(120, mh - 170), L.h)) : Math.max(220, Math.min(Math.max(220, mw - 360), L.w[d]));
      dock.hidden = !mine.length || (!!L.solo && !narrow); dock.classList.toggle('allshut', all && !narrow); dock.style.setProperty('--size', size + 'px');
      sp.hidden = dock.hidden; sp.classList.toggle('off', all); sp.setAttribute('aria-valuenow', String(size));
    });
    document.documentElement.style.setProperty('--ui-zoom', String(({ s: 0.9, m: 1, l: 1.14 })[L.text] || 1));       // text size: the panels and the top rail are scaled whole
    var so = $('btn-solo'); so.setAttribute('aria-pressed', String(!!L.solo)); so.textContent = L.solo ? 'Show panels' : 'Hide panels';
    resize();
  }
  function setLayout(change, auto) { ui.layout.auto = !!auto; change(ui.layout); applyLayout(); saveView(); layoutMenu(); }
  function layoutMenu() {
    var pop = $('layout-pop'), L = ui.layout; pop.innerHTML = '';
    function preset(label, design, checks) { var on = L.dock['panel-design'] === design && L.dock['panel-checks'] === checks && !L.solo; return el('button', { type: 'button', 'aria-pressed': String(on), text: label, onclick: function () { setLayout(function (q) { q.dock = { 'panel-design': design, 'panel-checks': checks }; q.solo = false; ui.panels = {}; }); } }); }
    pop.appendChild(el('h2', { text: 'Panels', style: '--c: var(--r2)' }));
    pop.appendChild(el('div', { class: 'seg' }, [preset('Either side', 'left', 'right'), preset('Both left', 'left', 'left'), preset('Both right', 'right', 'right'), preset('Checks below', 'left', 'bottom'), preset('Both below', 'bottom', 'bottom')]));
    pop.appendChild(el('div', { class: 'hint', text: 'Drag the lines between panels to resize them; double-click a line for its usual size. Each panel\'s bar has three small pictures to dock it left, under the view or right, and a fold mark; clicking its name folds it too.' }));
    pop.appendChild(el('div', { class: 'row' }, [el('span', {}, [el('button', { type: 'button', 'aria-pressed': String(!!L.solo), text: 'View only', title: 'the \\ key', onclick: function () { setLayout(function (q) { q.solo = !q.solo; }, ui.layout.auto); } })]), el('button', { type: 'button', text: 'Usual layout', onclick: function () { setLayout(function (q) { q.dock = { 'panel-design': 'left', 'panel-checks': 'right' }; q.w = { left: WIDE.left, right: WIDE.right }; q.h = 300; q.ratio = { left: 0.55, right: 0.5, bottom: 0.5 }; q.solo = false; q.text = 'm'; ui.panels = {}; }, true); } })]));
    pop.appendChild(el('h2', { text: 'Text size', style: '--c: var(--r7)' }));
    pop.appendChild(el('div', { class: 'seg' }, [['s', 'Small'], ['m', 'Usual'], ['l', 'Large']].map(function (o) { return el('button', { type: 'button', 'aria-pressed': String((L.text || 'm') === o[0]), text: o[1], onclick: function () { setLayout(function (q) { q.text = o[0]; }, ui.layout.auto); } }); })));
    pop.appendChild(el('h2', { text: 'Design sections', style: '--c: var(--r10)' }));
    function foldAll(v) { Array.prototype.forEach.call(document.querySelectorAll('#controls .sech'), function (b) { ui.fold[b.textContent] = v; }); saveView(); renderControls(); }
    pop.appendChild(el('div', { class: 'seg' }, [el('button', { type: 'button', text: 'Fold all', onclick: function () { foldAll(true); } }), el('button', { type: 'button', text: 'Unfold all', onclick: function () { foldAll(false); } })]));
  }
  function panels() {
    PANELS.forEach(function (id) {
      var pn = $(id);
      function fold() { ui.panels[id] = !ui.panels[id]; applyLayout(); saveView(); }
      pn.querySelector('.fold').addEventListener('click', fold);
      pn.querySelector('.plate').addEventListener('click', fold);
      Array.prototype.forEach.call(pn.querySelectorAll('.dk'), function (b) { b.addEventListener('click', function () { setLayout(function (q) { q.dock[id] = b.getAttribute('data-dock'); ui.panels[id] = false; }); }); });
    });
    DOCKS.forEach(function (d) {
      var sp = $('split-' + d), row = d === 'bottom';
      function set(v) { if (row) ui.layout.h = Math.round(v); else ui.layout.w[d] = Math.round(v); applyLayout(); }
      sp.addEventListener('pointerdown', function (ev) {
        if (sp.classList.contains('off')) return;
        ev.preventDefault(); sp.setPointerCapture(ev.pointerId); sp.classList.add('drag'); document.body.classList.add('resizing');
        function mv(e) { var m = $('main').getBoundingClientRect(), mid = $('mid').getBoundingClientRect(); set(d === 'left' ? e.clientX - m.left : d === 'right' ? m.right - e.clientX : mid.bottom - e.clientY); }
        function up() { sp.classList.remove('drag'); document.body.classList.remove('resizing'); sp.removeEventListener('pointermove', mv); sp.removeEventListener('pointerup', up); sp.removeEventListener('pointercancel', up); saveView(); }
        sp.addEventListener('pointermove', mv); sp.addEventListener('pointerup', up); sp.addEventListener('pointercancel', up);
      });
      sp.addEventListener('dblclick', function () { set(row ? 300 : WIDE[d]); saveView(); });
      sp.addEventListener('keydown', function (ev) {
        var cur = row ? ui.layout.h : ui.layout.w[d], step = ev.shiftKey ? 64 : 16, grow = { left: 'ArrowRight', right: 'ArrowLeft', bottom: 'ArrowUp' }[d], shrink = { left: 'ArrowLeft', right: 'ArrowRight', bottom: 'ArrowDown' }[d];
        if (ev.key === grow) set(cur + step); else if (ev.key === shrink) set(cur - step); else return;
        ev.preventDefault(); saveView();
      });
    });
    $('btn-solo').addEventListener('click', function () { setLayout(function (q) { q.solo = !q.solo; }, ui.layout.auto); });
    var menu = $('layout-menu');
    document.addEventListener('pointerdown', function (ev) { if (menu.open && !menu.contains(ev.target)) menu.open = false; });
    window.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && menu.open) { menu.open = false; return; }
      if (ev.key === '\\' && !/INPUT|SELECT|TEXTAREA/.test(ev.target.tagName || '')) setLayout(function (q) { q.solo = !q.solo; }, ui.layout.auto);
    });
    window.addEventListener('resize', applyLayout);
    if (phone.addEventListener) phone.addEventListener('change', applyLayout);
    layoutMenu(); applyLayout();
  }
  var bootTab = ui.tab; ui.tab = 'outline';      // the scene is built once, then the tab the page was left on (or the link names) is opened
  initThree();
  viewbar();
  tabs();
  panels();
  bindExport();
  rebuild(true);
  resize();
  if (bootTab === 'mag') setTab('mag', true);
  if (boot.cam && !boot.upgraded && camera && boot.cam.p && boot.cam.t) { camera.position.fromArray(boot.cam.p); controls.target.fromArray(boot.cam.t); controls.update(); } else setView('iso');
  clearTimeout(histT); hist.push(P); syncUndo();
  function flush() { clearTimeout(saveT); State.save(P, ui, camState()); }       // whatever is still waiting to be written goes out when the page is left
  window.addEventListener('pagehide', flush); document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') flush(); });
  window.V6App = { get params() { return P; }, get model() { return R; }, get camera() { return camera; }, target: function () { return controls.target; }, get unit() { return unit; }, get scene() { return scene; }, rebuild: rebuild, setView: setView, ui: ui, undo: undo, redo: redo, state: State, boot: boot, savePng: savePng, setTab: setTab, get mag() { return magTab; } };
})();
