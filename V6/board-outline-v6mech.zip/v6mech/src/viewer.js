// Jumperless V6 outline tool - the viewer. Everything it draws comes from V6Geo.resolve(params); it holds no geometry of its own.
(function () {
  'use strict';
  var Geo = window.V6Geo, Cat = window.V6Catalog, Exp = window.V6Export, T = window.THREE;
  var MODELS = window.V6_MODELS || {}, REF = window.V6_REF || {}, DEFAULTS = window.V6_DEFAULTS, SKETCH = window.V6_SKETCH || null;
  var KEY = 'v6mech.params';
  var $ = function (id) { return document.getElementById(id); };
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function el(tag, attrs, kids) {
    var e = document.createElement(tag);
    if (attrs) for (var k in attrs) { if (k === 'text') e.textContent = attrs[k]; else if (k === 'html') e.innerHTML = attrs[k]; else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), attrs[k]); else if (attrs[k] != null) e.setAttribute(k, attrs[k]); }
    (kids || []).forEach(function (c) { if (c != null) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }

  // ---------- state ----------
  var P = (function () {
    try { var s = localStorage.getItem(KEY); if (s) { var o = JSON.parse(s); if (o && o.stack && o.grid && o.meta && o.meta.rev === DEFAULTS.meta.rev) return o; } } catch (e) { /* storage may be unavailable */ }
    return clone(DEFAULTS);
  })();
  var R = null;
  var ui = { sel: null, vsel: null, editOutline: false, sketch: false, sketchOpacity: 0.6, explode: 0, clipAxis: 'off', clipPos: 0.5, envelopes: false, planes: true, hidden: {}, hideShell: false };
  function save() { try { localStorage.setItem(KEY, JSON.stringify(P)); } catch (e) { /* ignore */ } }

  // ---------- three ----------
  var view = $('view'), renderer = null, scene, camera, controls, unit, ghost, deco, handles, sketchTex = null;
  var raycaster = T ? new T.Raycaster() : null, pointer = T ? new T.Vector2() : null;
  var clipPlane = T ? new T.Plane(new T.Vector3(-1, 0, 0), 0) : null;
  function cssVar(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
  function initThree() {
    if (!T) return false;
    try { renderer = new T.WebGLRenderer({ antialias: true }); } catch (e) { renderer = null; }
    if (!renderer) { $('fallback').style.display = 'block'; return false; }
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    renderer.localClippingEnabled = true;
    view.insertBefore(renderer.domElement, view.firstChild);
    scene = new T.Scene();
    camera = new T.PerspectiveCamera(30, 1, 1, 3000);
    controls = new T.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true; controls.dampingFactor = 0.12; controls.screenSpacePanning = true;
    scene.add(new T.HemisphereLight(0xffffff, 0x8c9299, 0.95));
    var d1 = new T.DirectionalLight(0xffffff, 0.75); d1.position.set(-80, 200, 120); scene.add(d1);
    var d2 = new T.DirectionalLight(0xffffff, 0.3); d2.position.set(160, 60, -120); scene.add(d2);
    unit = new T.Group(); ghost = new T.Group(); deco = new T.Group(); handles = new T.Group();
    scene.add(unit); scene.add(ghost); scene.add(deco); scene.add(handles);
    theme();
    window.addEventListener('resize', resize);
    if (window.ResizeObserver) new ResizeObserver(resize).observe(view);
    if (window.matchMedia) { var mq = window.matchMedia('(prefers-color-scheme: dark)'); if (mq.addEventListener) mq.addEventListener('change', theme); }
    if (window.MutationObserver) new MutationObserver(theme).observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
    resize();
    bindPointer();
    (function loop() { requestAnimationFrame(loop); controls.update(); renderer.render(scene, camera); })();
    return true;
  }
  function theme() { if (scene) scene.background = new T.Color(cssVar('--viewport') || '#dce1e5'); }
  function resize() {
    if (!renderer) return;
    var w = Math.max(1, view.clientWidth), h = Math.max(1, view.clientHeight);
    renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
  }
  function setView(name) {
    if (!camera) return;
    // look along a fixed direction and back off until the whole unit fits the viewport
    var pl = R ? R.planes : { x0: -8.3, x1: 78.74, yt: -24.7, yb: 55 }, wide = P.show.neighbour ? pl.pitch : 0;
    var t = [(pl.x0 + pl.x1 + wide) / 2, 2.5, (pl.yt + pl.yb) / 2];
    var dir = { iso: [-0.42, 0.72, 0.62], top: [0, 1, 0.001], under: [-0.25, -0.85, 0.45], left: [-1, 0.22, 0.05], topedge: [0.05, 0.3, -1], bottomedge: [0, 0.3, 1] }[name] || [-0.42, 0.72, 0.62];
    var len = Math.sqrt(dir[0] * dir[0] + dir[1] * dir[1] + dir[2] * dir[2]);
    var rad = 0.5 * Math.sqrt(Math.pow(pl.x1 - pl.x0 + wide, 2) + Math.pow(pl.yb - pl.yt, 2)) + 6;
    var half = camera.fov * Math.PI / 360, fit = Math.min(half, Math.atan(Math.tan(half) * camera.aspect));
    var dist = rad / Math.sin(fit) * 1.02;
    camera.position.set(t[0] + dir[0] / len * dist, t[1] + dir[1] / len * dist, t[2] + dir[2] / len * dist);
    controls.target.set(t[0], t[1], t[2]); controls.update();
  }

  // materials
  var mats = {};
  function mat(color, o) {
    o = o || {};
    var key = color + ':' + (o.opacity || 1) + ':' + (o.metal || 0) + ':' + (o.side || 0);
    if (!mats[key]) mats[key] = new T.MeshStandardMaterial({ color: color, roughness: o.rough != null ? o.rough : 0.7, metalness: o.metal || 0.05, transparent: (o.opacity || 1) < 1, opacity: o.opacity || 1, depthWrite: (o.opacity || 1) >= 1, side: o.side ? T.DoubleSide : T.FrontSide });
    return mats[key];
  }
  var lineMat = T ? new T.LineBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.35 }) : null;
  var ghostMat = T ? new T.MeshStandardMaterial({ color: 0x7f8891, transparent: true, opacity: 0.22, depthWrite: false, roughness: 1 }) : null;

  function extrude(polys, z0, z1, material, edges) {
    var shapes = polys.map(function (e) {
      var s = new T.Shape(e.outer.map(function (q) { return new T.Vector2(q[0], -q[1]); }));
      (e.holes || []).forEach(function (h) { s.holes.push(new T.Path(h.map(function (q) { return new T.Vector2(q[0], -q[1]); }))); });
      return s;
    });
    var g = new T.ExtrudeGeometry(shapes, { depth: Math.max(0.001, z1 - z0), bevelEnabled: false, curveSegments: 1 });
    g.rotateX(-Math.PI / 2); g.translate(0, z0, 0);          // world: X = x, Y = z (up), Z = plan y
    var m = new T.Mesh(g, material);
    if (edges !== false) m.add(new T.LineSegments(new T.EdgesGeometry(g, 30), lineMat));
    return m;
  }
  function b64(s) { var bin = atob(s), n = bin.length, u = new Uint8Array(n); for (var i = 0; i < n; i++) u[i] = bin.charCodeAt(i); return u.buffer; }
  var geoCache = {};
  function model(name) {
    var m = MODELS[name]; if (!m) return null;
    if (!geoCache[name]) geoCache[name] = m.groups.map(function (gr) {
      var src = new Float32Array(b64(gr.pos)), out = new Float32Array(src.length);
      for (var i = 0; i < src.length; i += 3) { out[i] = src[i]; out[i + 1] = src[i + 2]; out[i + 2] = -src[i + 1]; }   // model (x, y, z up) -> (x, z, plan y = -y)
      var g = new T.BufferGeometry();
      g.setAttribute('position', new T.BufferAttribute(out, 3));
      g.setIndex(new T.BufferAttribute(gr.i32 ? new Uint32Array(b64(gr.idx)) : new Uint16Array(b64(gr.idx)), 1));
      g.computeVertexNormals(); g.userData.keep = true;
      var c = gr.color, lum = Math.max(c[0], c[1], c[2]);
      var col = new T.Color(Math.max(c[0], 0.045), Math.max(c[1], 0.045), Math.max(c[2], 0.05));
      return { geo: g, mat: new T.MeshStandardMaterial({ color: col, roughness: lum > 0.5 ? 0.35 : 0.6, metalness: (c[0] > c[2] * 1.5 && lum > 0.4) || lum > 0.7 ? 0.7 : 0.1 }) };
    });
    var grp = new T.Group();
    geoCache[name].forEach(function (e) { grp.add(new T.Mesh(e.geo, e.mat)); });
    return grp;
  }

  function holesMesh(x0, y0, z, color) {
    var w = R.wig, pos = [], idx = [], h = 0.95, n = 0;
    w.cols.forEach(function (cx) { w.rows.forEach(function (cy) {
      pos.push(cx - h, z, cy - h, cx + h, z, cy - h, cx + h, z, cy + h, cx - h, z, cy + h);
      idx.push(n, n + 2, n + 1, n, n + 3, n + 2); n += 4;
    }); });
    var g = new T.BufferGeometry();
    g.setAttribute('position', new T.BufferAttribute(new Float32Array(pos), 3)); g.setIndex(idx); g.computeVertexNormals();
    return new T.Mesh(g, new T.MeshBasicMaterial({ color: color }));
  }

  function partObject(p) {
    var grp = new T.Group(); grp.userData.partId = p.id;
    var selected = ui.sel === p.id;
    function bodies(material, list) { (list || p.bodies).forEach(function (b) { if (!b.slot) grp.add(extrude([{ outer: b.pts, holes: [] }], b.z0, b.z1, material)); }); }
    if (p.type === 'bb_shell') {
      if (!ui.hideShell) { bodies(mat(0x26282c, { rough: 0.9 })); grp.add(holesMesh(0, 0, p.z1 + 0.02, R.wig.face_t > 0 ? 0x26282c : 0xa67c2e)); }
    } else if (p.type === 'bb_face') {
      if (!ui.hideShell) { bodies(mat(0xc9a43a, { metal: 0.6, rough: 0.4 })); grp.add(holesMesh(0, 0, p.z1 + 0.02, 0x1a1a1a)); }
    } else if (p.type === 'wig_pcb') {
      bodies(mat(0x15201a, { rough: 0.6 }));
    } else if (p.type === 'probe') {
      var pr = R.probe, len = pr.y1 - pr.y0;
      var c = new T.Mesh(new T.CylinderGeometry(pr.dia / 2, pr.dia / 2, len - 3, 24), mat(0xd9dcdf, { metal: 0.5, rough: 0.35 }));
      c.rotation.x = Math.PI / 2; c.position.set(pr.x, pr.zc, pr.y0 + 3 + (len - 3) / 2); grp.add(c);
      var tip = new T.Mesh(new T.CylinderGeometry(pr.dia / 2, 0.4, 3, 24), mat(0x2b2b2b));
      tip.rotation.x = Math.PI / 2; tip.position.set(pr.x, pr.zc, pr.y0 + 1.5); grp.add(tip);
      var mg = new T.Mesh(new T.CylinderGeometry(pr.magnet.dia / 2 + 0.05, pr.magnet.dia / 2 + 0.05, pr.magnet.len, 16), mat(0xd43c2f));
      mg.rotation.x = Math.PI / 2; mg.position.set(pr.magnet.x, pr.magnet.z, pr.magnet.y); grp.add(mg);
    } else {
      var hasModel = p.model && MODELS[p.model.name];
      if (hasModel) {
        var outer = new T.Group(), inner = new T.Group();
        outer.position.set(p.x, p.zPlane, p.y); outer.rotation.y = p.rot * Math.PI / 180;
        if (p.bottom) inner.rotation.z = Math.PI;
        inner.add(model(p.model.name));
        (p.extra || []).forEach(function (n) { var m = model(n); if (m) inner.add(m); });
        outer.add(inner); grp.add(outer);
        if (ui.envelopes || selected) bodies(new T.MeshBasicMaterial({ color: selected ? 0xffb300 : 0x2277dd, wireframe: true, transparent: true, opacity: 0.5 }));
      } else {
        bodies(mat(p.color != null ? p.color : 0x888888, { metal: 0.3, rough: 0.5 }));
        if (selected) bodies(new T.MeshBasicMaterial({ color: 0xffb300, wireframe: true, transparent: true, opacity: 0.6 }));
      }
      bodies(mat(0x2d7fd0, { opacity: 0.28, side: 1 }), p.ghosts);
    }
    return grp;
  }

  function header40() {
    var grp = new T.Group(), s = P.show, pitch = P.grid.pitch, rows = R.wig.rows;
    var cy = rows[Math.max(0, Math.min(rows.length - 1, s.header40_row | 0))], c0 = Math.max(1, s.header40_col | 0);
    var z = R.z.bbTop, x0 = c0 * pitch, x1 = (c0 + 39) * pitch;
    var body = new T.Mesh(new T.BoxGeometry(x1 - x0 + pitch, 2.5, pitch), mat(0x101010)); body.position.set((x0 + x1) / 2, z + 1.25, cy); grp.add(body);
    for (var k = 0; k < 40; k++) {
      var x = (c0 + k) * pitch, st = pinState(x);
      var pin = new T.Mesh(new T.BoxGeometry(0.64, 11.5, 0.64), mat(st === 'hole' ? 0xd9b441 : st === 'next' ? 0x35a56a : 0xd43c2f, { metal: 0.6, rough: 0.3 }));
      pin.position.set(x, z + 2.75, cy); grp.add(pin);          // 3 mm into the hole, 2.5 mm of plastic, 6 mm above
    }
    return grp;
  }
  function pinState(x) {            // where a 0.1" pin at x lands: this unit's hole, the neighbour's hole, or a dead row
    var pitch = P.grid.pitch, n = P.grid.cols, k = x / pitch;
    if (Math.abs(k - Math.round(k)) < 1e-6 && Math.round(k) >= 1 && Math.round(k) <= n) return 'hole';
    var kn = (x - R.planes.pitch) / pitch;
    if (Math.abs(kn - Math.round(kn)) < 1e-6 && Math.round(kn) >= 1 && Math.round(kn) <= n) return 'next';
    return 'dead';
  }

  function buildScene() {
    if (!renderer) return;
    [unit, ghost, deco, handles].forEach(function (g) { while (g.children.length) { var c = g.children.pop(); c.traverse(function (o) { if (o.geometry && !o.geometry.userData.keep) o.geometry.dispose(); }); } });
    var idx = {}; R.layers.forEach(function (L, i) { idx[L.id] = i; });
    R.layers.forEach(function (L, i) {
      if (ui.hidden[L.id] || !L.shape.length) return;
      var m = extrude(L.shape, L.z0, L.z1, mat(parseInt(Exp.LAYER_COLORS[i % Exp.LAYER_COLORS.length].slice(1), 16), { rough: 0.75 }));
      m.position.y = i * ui.explode; m.userData.layerId = L.id; unit.add(m);
    });
    R.parts.forEach(function (p) {
      var o = partObject(p), li = p.mountLayer != null && idx[p.mountLayer] != null ? idx[p.mountLayer] : 0;
      if (p.mountLayer && ui.hidden[p.mountLayer] && !p.system) return;
      o.position.y = li * ui.explode; unit.add(o);
    });
    if (P.show.sensors) {
      var s = R.wig.sensors, zt = R.removable ? 0 : 0;
      s.mmc.forEach(function (q) { var b = new T.Mesh(new T.BoxGeometry(0.9, 0.5, 0.9), mat(0x18b7c9)); b.position.set(q.x, q.side === 'F' ? zt + 0.25 : -R.wig.pcb_t - 0.25, q.y); unit.add(b); });
      s.tmag.forEach(function (q) { var b = new T.Mesh(new T.BoxGeometry(2.9, 1.1, 1.6), mat(0xc0399f)); b.position.set(q.x, q.side === 'F' ? zt + 0.55 : -R.wig.pcb_t - 0.55, q.y); unit.add(b); });
    }
    if (P.show.neighbour) {
      var g = unit.clone(true);
      g.traverse(function (o) { if (o.isMesh) o.material = ghostMat; if (o.isLineSegments) o.visible = false; });
      g.position.x = R.planes.pitch; ghost.add(g);
    }
    if (P.show.header40) deco.add(header40());
    if (ui.planes) {
      [R.planes.xl, R.planes.xr].forEach(function (x) {
        var pl = new T.Mesh(new T.PlaneGeometry(R.planes.yb - R.planes.yt + 10, 18), new T.MeshBasicMaterial({ color: 0xd43c2f, transparent: true, opacity: 0.1, side: T.DoubleSide, depthWrite: false }));
        pl.rotation.y = Math.PI / 2; pl.position.set(x, 3, (R.planes.yt + R.planes.yb) / 2); deco.add(pl);
      });
    }
    if (P.show.neighbour || P.show.header40) {       // mark where dead-row pins would land
      var zs = R.z.top + 0.04, mk = new T.MeshBasicMaterial({ color: 0xd43c2f });
      R.checks.grid.dead_x.forEach(function (dx) { [0, R.planes.pitch].forEach(function (off) { R.wig.rows.forEach(function (cy) {
        var q = new T.Mesh(new T.PlaneGeometry(1.1, 1.1), mk); q.rotation.x = -Math.PI / 2; q.position.set(dx + off, Math.max(zs, R.z.bbTop + 0.04), cy); deco.add(q);
      }); }); });
    }
    if (ui.sketch && SKETCH) {                         // Kevin's notebook page, rectified, lying just above the top face
      if (!sketchTex) { sketchTex = new T.TextureLoader().load(SKETCH.src); sketchTex.minFilter = T.LinearFilter; }
      var sw = SKETCH.x1 - SKETCH.x0, sh = SKETCH.y1 - SKETCH.y0, sg = new T.PlaneGeometry(sw, sh);
      sg.rotateX(-Math.PI / 2);
      var sm = new T.Mesh(sg, new T.MeshBasicMaterial({ map: sketchTex, transparent: true, opacity: ui.sketchOpacity, depthWrite: false, depthTest: false }));
      sm.position.set((SKETCH.x0 + SKETCH.x1) / 2, Math.max(R.z.top, R.z.bbTop) + 0.3, (SKETCH.y0 + SKETCH.y1) / 2); sm.renderOrder = 5; deco.add(sm);
    }
    if (ui.editOutline || ui.sketch) {                 // the outline as a line, and its vertices as dots to drag
      var hy = Math.max(R.z.top, R.z.bbTop) + 0.45, lp = [];
      R.outline.pts.concat([R.outline.pts[0]]).forEach(function (q) { lp.push(new T.Vector3(q[0], hy, q[1])); });
      var ol = new T.Line(new T.BufferGeometry().setFromPoints(lp), new T.LineBasicMaterial({ color: 0xe0245e, depthTest: false })); ol.renderOrder = 6; handles.add(ol);
    }
    if (ui.editOutline) {
      var hy2 = Math.max(R.z.top, R.z.bbTop) + 0.5, cp = [];
      R.outline.verts.concat([R.outline.verts[0]]).forEach(function (q) { cp.push(new T.Vector3(q.x, hy2, q.y)); });
      var cl = new T.Line(new T.BufferGeometry().setFromPoints(cp), new T.LineBasicMaterial({ color: 0x1f6fd0, transparent: true, opacity: 0.45, depthTest: false })); cl.renderOrder = 6; handles.add(cl);
      R.outline.verts.forEach(function (q, i) {
        var on = ui.vsel === i, hm = new T.Mesh(new T.SphereGeometry(on ? 1.15 : 0.85, 16, 12), new T.MeshBasicMaterial({ color: on ? 0xffb300 : 0x1f6fd0, depthTest: false }));
        hm.position.set(q.x, hy2, q.y); hm.renderOrder = 7; hm.userData.vertex = i; handles.add(hm);
      });
    }
    applyClip();
  }
  function applyClip() {
    if (!renderer) return;
    if (ui.clipAxis === 'off') { renderer.clippingPlanes = []; return; }
    var pl = R.planes, t = ui.clipPos;
    if (ui.clipAxis === 'x') { clipPlane.normal.set(-1, 0, 0); clipPlane.constant = pl.x0 - 1 + t * (pl.x1 - pl.x0 + 2); }
    else if (ui.clipAxis === 'y') { clipPlane.normal.set(0, 0, -1); clipPlane.constant = pl.yt - 1 + t * (pl.yb - pl.yt + 2); }
    else { clipPlane.normal.set(0, -1, 0); clipPlane.constant = R.z.bottom - 6 + t * (R.z.top - R.z.bottom + 9 + R.layers.length * ui.explode); }
    renderer.clippingPlanes = [clipPlane];
  }

  // ---------- pointer: hover, select, drag parts in plan ----------
  var drag = null, pending = false;
  function pickPart(ev) {
    var r = renderer.domElement.getBoundingClientRect();
    pointer.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
    raycaster.setFromCamera(pointer, camera);
    var hits = raycaster.intersectObjects(unit.children, true);
    for (var i = 0; i < hits.length; i++) {
      if (hits[i].object.isLineSegments) continue;
      if (renderer.clippingPlanes.length && clipPlane.distanceToPoint(hits[i].point) < 0) continue;
      var o = hits[i].object;
      while (o && !o.userData.partId && !o.userData.layerId) o = o.parent;
      if (o && o.userData.partId) return { id: o.userData.partId, point: hits[i].point };
      if (o && o.userData.layerId) return { layer: o.userData.layerId, point: hits[i].point };
    }
    return null;
  }
  function pickVertex(ev) {
    if (!ui.editOutline) return null;
    var r = renderer.domElement.getBoundingClientRect();
    pointer.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
    raycaster.setFromCamera(pointer, camera);
    var hits = raycaster.intersectObjects(handles.children, false);
    for (var i = 0; i < hits.length; i++) if (hits[i].object.userData.vertex != null) return { vertex: hits[i].object.userData.vertex, point: hits[i].object.position.clone() };
    return null;
  }
  function userPart(id) { for (var i = 0; i < P.parts.length; i++) if (P.parts[i].id === id) return P.parts[i]; return null; }
  function resolved(id) { for (var i = 0; i < R.parts.length; i++) if (R.parts[i].id === id) return R.parts[i]; return null; }
  function bindPointer() {
    var dom = renderer.domElement, tip = $('tip');
    dom.addEventListener('pointerdown', function (ev) {
      if (ev.button !== 0) return;
      var hv = pickVertex(ev);
      if (hv) {
        var q0 = P.frame.outline[hv.vertex]; ui.vsel = hv.vertex; ui.sel = null;
        drag = { vertex: hv.vertex, plane: new T.Plane(new T.Vector3(0, 1, 0), -hv.point.y), dx: q0.x - hv.point.x, dy: q0.y - hv.point.z, moved: false }; controls.enabled = false; dom.setPointerCapture(ev.pointerId);
        rebuild(true); return;
      }
      var h = pickPart(ev);
      if (h && h.id) {
        var changed = ui.sel !== h.id; ui.sel = h.id;
        var u = userPart(h.id);
        if (u) { drag = { id: h.id, plane: new T.Plane(new T.Vector3(0, 1, 0), -h.point.y), dx: u.x - h.point.x, dy: u.y - h.point.z, moved: false }; controls.enabled = false; dom.setPointerCapture(ev.pointerId); }
        if (changed) { rebuild(true); }
      }
    });
    dom.addEventListener('pointermove', function (ev) {
      if (drag) {
        var r = dom.getBoundingClientRect();
        pointer.set(((ev.clientX - r.left) / r.width) * 2 - 1, -((ev.clientY - r.top) / r.height) * 2 + 1);
        raycaster.setFromCamera(pointer, camera);
        var pt = new T.Vector3();
        if (!raycaster.ray.intersectPlane(drag.plane, pt)) return;
        var u = drag.vertex != null ? P.frame.outline[drag.vertex] : userPart(drag.id), step = ev.shiftKey ? 1.27 : 0.05;
        u.x = Math.round((pt.x + drag.dx) / step) * step; u.y = Math.round((pt.z + drag.dy) / step) * step;
        u.x = +u.x.toFixed(3); u.y = +u.y.toFixed(3); drag.moved = true;
        if (!pending) { pending = true; requestAnimationFrame(function () { pending = false; rebuild(false, true); }); }
        return;
      }
      var hv2 = pickVertex(ev);
      if (hv2) { tip.textContent = 'outline vertex ' + (hv2.vertex + 1) + ' (drag to move)'; tip.style.display = 'block'; var vr0 = view.getBoundingClientRect(); tip.style.left = (ev.clientX - vr0.left + 14) + 'px'; tip.style.top = (ev.clientY - vr0.top + 12) + 'px'; return; }
      var h = pickPart(ev);
      if (h && h.id) { var p = resolved(h.id); tip.textContent = p.label + (userPart(h.id) ? ' (drag to move)' : ''); tip.style.display = 'block'; }
      else if (h && h.layer) { var L = R.layers.filter(function (x) { return x.id === h.layer; })[0]; tip.textContent = L.id + ' ' + L.name + ', ' + L.t + ' mm'; tip.style.display = 'block'; }
      else tip.style.display = 'none';
      var vr = view.getBoundingClientRect(); tip.style.left = (ev.clientX - vr.left + 14) + 'px'; tip.style.top = (ev.clientY - vr.top + 12) + 'px';
    });
    function end(ev) { if (!drag) return; var m = drag.moved; drag = null; controls.enabled = true; try { dom.releasePointerCapture(ev.pointerId); } catch (e) { /* not captured */ } if (m) rebuild(true); }
    dom.addEventListener('pointerup', end); dom.addEventListener('pointercancel', end);
    dom.addEventListener('pointerleave', function () { tip.style.display = 'none'; });
    dom.addEventListener('dblclick', function (ev) { if (!pickPart(ev)) setView('iso'); });
    window.addEventListener('keydown', function (ev) {
      if (/INPUT|SELECT|TEXTAREA/.test((ev.target.tagName || ''))) return;
      var u = ui.editOutline && ui.vsel != null ? P.frame.outline[ui.vsel] : (ui.sel ? userPart(ui.sel) : null); if (!u) return;
      var s = ev.shiftKey ? 1.27 : 0.1, d = { ArrowLeft: [-s, 0], ArrowRight: [s, 0], ArrowUp: [0, -s], ArrowDown: [0, s] }[ev.key];
      if (!d) return;
      u.x = +(u.x + d[0]).toFixed(3); u.y = +(u.y + d[1]).toFixed(3); ev.preventDefault(); rebuild(true);
    });
  }

  // ---------- controls ----------
  function num(v, step, set, o) {
    o = o || {};
    return el('input', { type: 'number', value: v, step: step, min: o.min, max: o.max, id: o.id, 'aria-label': o.label, onchange: function (e) { var x = parseFloat(e.target.value); if (isNaN(x)) return; if (o.min != null) x = Math.max(o.min, x); if (o.max != null) x = Math.min(o.max, x); set(x); rebuild(true); } });
  }
  function seg(options, value, set) {
    return el('span', { class: 'seg', role: 'group' }, options.map(function (o) { return el('button', { type: 'button', 'aria-pressed': String(o[0] === value), text: o[1], onclick: function () { set(o[0]); rebuild(true); } }); }));
  }
  function chk(value, set, id) { return el('input', { type: 'checkbox', id: id, onchange: function (e) { set(e.target.checked); rebuild(true); } }, []); }
  function row(label, control, unitTxt, forId) { return el('div', { class: 'row' }, [el('label', { text: label, for: forId }), el('span', {}, [control, unitTxt ? el('span', { class: 'u', text: unitTxt }) : null])]); }
  function sel(options, value, set, id) {
    var s = el('select', { id: id, onchange: function (e) { set(e.target.value); rebuild(true); } }, options.map(function (o) { return el('option', { value: o[0], text: o[1] }); }));
    s.value = value; return s;
  }
  function check(id, label, value, set) { var c = chk(value, set, id); c.checked = !!value; return el('div', { class: 'row' }, [el('label', { for: id, text: label }), c]); }

  function mountValue(m) { if (m.flush) return 'flush:' + m.flush; if (m.on) return m.on + ':' + (m.side || 'top'); return 'z'; }
  function mountOptions() {
    var o = [];
    R.layers.forEach(function (L) { o.push([L.id + ':top', 'on ' + L.id + ' top']); o.push([L.id + ':bottom', 'on ' + L.id + ' bottom']); });
    o.push(['flush:top', 'flush with the top board']); o.push(['flush:bb', 'flush with breadboard top']);
    return o;
  }
  function currentPort() {
    var ids = P.parts.filter(function (p) { return /^port/.test(p.id); }).map(function (p) { return p.type; });
    if (!ids.length) return 'none';
    for (var k in Cat.portTypes) if (JSON.stringify(Cat.portTypes[k].parts) === JSON.stringify(ids)) return k;
    return 'none';
  }
  function setPort(kind) {
    var old = P.parts.filter(function (p) { return /^port/.test(p.id); })[0];
    var x = old ? old.x : 56, mount = old ? clone(old.mount) : { on: R.layers[0].id, side: 'top' };
    P.parts = P.parts.filter(function (p) { return !/^port/.test(p.id); });
    var yt = R.planes.yt, types = Cat.portTypes[kind].parts;
    var back = { m2_socket: 8.35, pcie_x1_ra: 11, sfp_cage: 0 };
    types.forEach(function (t, i) {
      P.parts.push({ id: i ? 'port' + (i + 1) : 'port', type: t, x: +(x + (types.length > 1 ? (i - (types.length - 1) / 2) * 15.5 : 0)).toFixed(2), y: +(yt + 1.15 + back[t]).toFixed(2), rot: 0, mount: clone(mount) });
    });
    if (ui.sel && /^port/.test(ui.sel)) ui.sel = null;
  }

  function boardFor(where) { var st = P.stack; return where === 'top' ? st[st.length - 1].id : (where === 'mid' && st.length > 2 ? st[1].id : st[0].id); }
  function controlValue(ctl) { var u = userPart(ctl.ids[0]); return u ? u.type : 'none'; }
  function setControl(ctl, type) {
    ctl.ids.forEach(function (id, i) {
      var u = userPart(id);
      if (type === 'none') { P.parts = P.parts.filter(function (q) { return q.id !== id; }); if (ui.sel === id) ui.sel = null; return; }
      var on = boardFor(Cat.parts[type].on);
      if (u) { u.type = type; u.mount = { on: on, side: 'top' }; delete u.open; delete u.dims; }
      else P.parts.push({ id: id, type: type, x: ctl.at[i][0], y: ctl.at[i][1], rot: ctl.at[i][2], mount: { on: on, side: 'top' } });
    });
    if (type !== 'none') ui.sel = ctl.ids[0];
  }
  function boardText(st) {
    if (st.state === 'through') return 'it passes through';
    if (st.state === 'access') return st.set === true ? 'opened (your choice)' : 'opened to reach it';
    if (st.state === 'blocked') return 'kept whole, and it runs into this board';
    return st.set === false ? 'kept whole (your choice)' : 'whole';
  }

  function renderControls() {
    var c = $('controls'), keepScroll = c.scrollTop;
    c.innerHTML = '';
    var g = P.grid, w = P.wig, f = P.frame;
    c.appendChild(el('h2', { text: 'Breadboard' }));
    c.appendChild(row('Wig', seg([['integrated', 'Integrated'], ['removable', 'Removable']], w.mode, function (v) { w.mode = v; })));
    if (w.mode === 'removable') c.appendChild(row('1.27 mm header pair', seg([['top', 'Top side'], ['bottom', 'Bottom side']], w.connector_side, function (v) { w.connector_side = v; })));
    c.appendChild(row('Shell height', num(w.shell.t, 0.05, function (v) { w.shell.t = v; }, { min: 1, max: 20, id: 'c-shell' }), 'mm', 'c-shell'));
    c.appendChild(row('Face PCB on the shell', num(w.face_pcb_t, 0.2, function (v) { w.face_pcb_t = v; }, { min: 0, max: 3, id: 'c-face' }), 'mm', 'c-face'));

    c.appendChild(el('h2', { text: '0.1 inch grid' }));
    c.appendChild(row('Left strip', seg([[0, 'none'], [1, '2.54'], [2, '5.08']], g.dead_rows_left, function (v) { var shift = (g.dead_rows_left - v) * g.pitch; g.dead_rows_left = v; P.frame.outline.forEach(function (q) { if (q.x < -0.01 || q.sx) { q.sx = 1; q.x = +(q.x + shift).toFixed(3); } }); P.parts.forEach(function (p) { if (p.x < 5) p.x = +(p.x + shift).toFixed(3); }); P.probe.dock.x = -v * g.pitch / 2; if (v === 0) P.probe.dock.enabled = false; })));
    c.appendChild(el('div', { class: 'hint', text: 'Unit pitch ' + R.planes.pitch + ' mm = ' + Math.round(R.planes.pitch / g.pitch) + ' rows, ' + R.checks.grid.dead_rows + ' dead row' + (R.checks.grid.dead_rows > 1 ? 's' : '') + ' between units.' }));
    c.appendChild(check('c-nb', 'Show the next unit', P.show.neighbour, function (v) { P.show.neighbour = v; setTimeout(function () { setView('iso'); }, 0); }));
    c.appendChild(check('c-h40', 'Show a 1x40 header', P.show.header40, function (v) { P.show.header40 = v; }));
    if (P.show.header40) {
      c.appendChild(row('Header starts at column', num(P.show.header40_col, 1, function (v) { P.show.header40_col = Math.round(v); }, { min: 1, max: 30, id: 'c-h40c' }), '', 'c-h40c'));
      c.appendChild(row('Header on hole row', num(P.show.header40_row, 1, function (v) { P.show.header40_row = Math.round(v); }, { min: 0, max: R.wig.rows.length - 1, id: 'c-h40r' }), '', 'c-h40r'));
    }
    var pc = el('input', { type: 'checkbox', id: 'c-planes', onchange: function (e) { ui.planes = e.target.checked; buildScene(); } }); pc.checked = ui.planes;
    c.appendChild(el('div', { class: 'row' }, [el('label', { for: 'c-planes', text: 'Show the grid planes' }), pc]));

    c.appendChild(el('h2', { text: 'Outline' }));
    var eo = el('input', { type: 'checkbox', id: 'c-eo', onchange: function (e) { ui.editOutline = e.target.checked; if (!ui.editOutline) ui.vsel = null; else setTimeout(function () { setView('top'); }, 0); rebuild(true); } }); eo.checked = ui.editOutline;
    c.appendChild(el('div', { class: 'row' }, [el('label', { for: 'c-eo', text: 'Edit the outline (drag the dots)' }), eo]));
    if (SKETCH) { var sk = el('input', { type: 'checkbox', id: 'c-sk', onchange: function (e) { ui.sketch = e.target.checked; if (ui.sketch) setView('top'); rebuild(true); } }); sk.checked = ui.sketch;
      c.appendChild(el('div', { class: 'row' }, [el('label', { for: 'c-sk', text: 'Lay the notebook sketch over it' }), sk]));
      if (ui.sketch) c.appendChild(row('Sketch opacity', el('input', { type: 'range', min: 0.15, max: 1, step: 0.05, value: ui.sketchOpacity, id: 'c-sko', oninput: function (e) { ui.sketchOpacity = parseFloat(e.target.value); buildScene(); } }), '', 'c-sko')); }
    var ov = f.outline, vl = el('div', { class: 'vlist' });
    ov.forEach(function (q, i) { vl.appendChild(el('button', { type: 'button', 'aria-pressed': String(ui.vsel === i), text: String(i + 1), title: q.n || '', onclick: function () { ui.vsel = ui.vsel === i ? null : i; ui.editOutline = true; rebuild(true); } })); });
    c.appendChild(vl);
    var q = ui.vsel != null ? ov[ui.vsel] : null;
    if (q) {
      var kind = q.c === 'wig' ? 'wig' : q.c ? 'chamfer' : q.r > 0 ? 'round' : 'sharp';
      c.appendChild(row('Vertex ' + (ui.vsel + 1) + '  x', num(q.x, 0.1, function (v) { q.x = v; }, { id: 'c-vx' }), 'mm', 'c-vx'));
      c.appendChild(row('y', num(q.y, 0.1, function (v) { q.y = v; }, { id: 'c-vy' }), 'mm', 'c-vy'));
      c.appendChild(row('Corner', sel([['sharp', 'sharp'], ['round', 'round'], ['chamfer', 'rounded chamfer'], ['wig', 'WigLEDmag corner']], kind, function (v) {
        if (v === 'sharp') { delete q.c; delete q.r; } else if (v === 'round') { delete q.c; q.r = q.r || 1; } else if (v === 'chamfer') { q.c = q.c && q.c !== 'wig' ? q.c : [2.2, 1.6]; q.r = q.r || 1; } else { q.c = 'wig'; delete q.r; }
      }, 'c-vk'), '', 'c-vk'));
      if (kind === 'chamfer') c.appendChild(row('Chamfer along / up', el('span', {}, [num(q.c[0], 0.1, function (v) { q.c[0] = v; }, { min: 0, max: 40, label: 'chamfer leg along the more horizontal edge' }), ' ', num(q.c[1], 0.1, function (v) { q.c[1] = v; }, { min: 0, max: 40, label: 'chamfer leg along the more vertical edge' })]), 'mm'));
      if (kind === 'chamfer' || kind === 'round') c.appendChild(row(kind === 'round' ? 'Radius' : 'Blend radius', num(q.r || 0, 0.1, function (v) { q.r = v; }, { min: 0, max: 30, id: 'c-vr' }), 'mm', 'c-vr'));
      if (q.n) c.appendChild(el('div', { class: 'hint', text: q.n }));
      c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'Arrow keys nudge 0.1 mm, Shift 1.27.' }), el('span', {}, [
        el('button', { type: 'button', text: 'Add after', onclick: function () { var nx = ov[(ui.vsel + 1) % ov.length]; ov.splice(ui.vsel + 1, 0, { x: +((q.x + nx.x) / 2).toFixed(2), y: +((q.y + nx.y) / 2).toFixed(2) }); ui.vsel++; rebuild(true); } }), ' ',
        el('button', { type: 'button', text: 'Delete', onclick: function () { if (ov.length < 4) return; ov.splice(ui.vsel, 1); ui.vsel = null; rebuild(true); } })])]));
    } else c.appendChild(el('div', { class: 'hint', text: ov.length + ' vertices, clockwise from the top-left corner. Pick one to edit it. The strip edge belongs on x = ' + R.planes.xl + '.' }));
    if (w.mode === 'integrated') c.appendChild(row('Fill notches in the one board', num(f.fill_notches || 0, 0.25, function (v) { f.fill_notches = v; }, { min: 0, max: 6, id: 'c-fn' }), 'mm', 'c-fn'));
    if (P.stack.some(function (L) { return L.kind === 'ring'; })) c.appendChild(row('Spacer ring wall', num(f.ring_wall || 2, 0.25, function (v) { f.ring_wall = v; }, { min: 0.5, max: 12, id: 'c-ring' }), 'mm', 'c-ring'));

    c.appendChild(el('h2', { text: 'Stack, bottom to top' }));
    var tb = el('table', { class: 'stack' }, [el('tr', {}, [el('th', { text: '' }), el('th', { text: 'Name' }), el('th', { text: 'Kind' }), el('th', { class: 'n', text: 't' }), el('th', { class: 'n', text: 'gap' })])]);
    P.stack.forEach(function (L, i) {
      var eye = el('input', { type: 'checkbox', 'aria-label': 'show ' + L.id, onchange: function (e) { ui.hidden[L.id] = !e.target.checked; buildScene(); } }); eye.checked = !ui.hidden[L.id];
      var kind = i === 0 ? el('span', { text: 'bottom' }) : sel([['board', 'board'], ['ring', 'ring']], L.kind === 'ring' ? 'ring' : 'board', function (v) { L.kind = v; });
      tb.appendChild(el('tr', {}, [
        el('td', {}, [eye, el('span', { class: 'sw', style: 'background:' + Exp.LAYER_COLORS[i % Exp.LAYER_COLORS.length] + ';margin-left:4px' }), L.id]),
        el('td', {}, [el('input', { type: 'text', value: L.name, 'aria-label': L.id + ' name', onchange: function (e) { L.name = e.target.value || L.id; rebuild(true); } })]),
        el('td', {}, [kind]),
        el('td', { class: 'n' }, [num(L.t, 0.2, function (v) { L.t = v; }, { min: 0.2, max: 4, label: L.id + ' thickness' })]),
        el('td', { class: 'n' }, [i === 0 ? el('span', { text: '' }) : num(L.gap || 0, 0.05, function (v) { L.gap = v; }, { min: 0, max: 12, label: L.id + ' gap below' })])
      ]));
    });
    c.appendChild(tb);
    c.appendChild(el('div', { class: 'hint', text: 'gap = space under that board, where parts live. A board is opened only where a part passes through it.' }));
    c.appendChild(el('div', { class: 'row' }, [el('button', { type: 'button', text: 'Level with the breadboard', title: 'share the space out so the top board is flush with the breadboard top', onclick: function () {
      var n = P.stack.length - 1; if (n < 1) return; var tt = 0; P.stack.slice(1).forEach(function (L) { tt += L.t; }); var each = (R.z.bbTop - tt) / n; if (each < 0) return; P.stack.slice(1).forEach(function (L) { L.gap = +each.toFixed(3); }); rebuild(true); } }), el('span', {}, [
      el('button', { type: 'button', text: '+ board', onclick: function () { var n = P.stack.length, id = 'L' + n; while (P.stack.some(function (s) { return s.id === id; })) id = 'L' + (++n); P.stack.push({ id: id, name: 'Board ' + n, t: 1.6, gap: 1.0, kind: 'board' }); rebuild(true); } }),
      ' ',
      el('button', { type: 'button', text: '- top', onclick: function () { if (P.stack.length < 2) return; var gone = P.stack.pop().id, top = P.stack[P.stack.length - 1].id; P.parts.forEach(function (p) { if (p.mount && p.mount.on === gone) p.mount.on = top; }); rebuild(true); } })
    ])]));

    c.appendChild(el('h2', { text: 'Parts' }));
    var dsp = userPart('display');
    if (dsp) c.appendChild(row('Display', sel([['display_amoled147', '1.47" AMOLED'], ['display_tft147', '1.47" TFT']], dsp.type, function (v) { dsp.type = v; }, 'c-dsp'), '', 'c-dsp'));
    c.appendChild(row('Expansion port', sel(Object.keys(Cat.portTypes).map(function (k) { return [k, Cat.portTypes[k].label]; }), currentPort(), function (v) { setPort(v); }, 'c-port'), '', 'c-port'));
    (Cat.controls || []).forEach(function (ctl) {
      c.appendChild(row(ctl.label, sel(ctl.options, controlValue(ctl), function (v) { setControl(ctl, v); }, 'c-ctl-' + ctl.key), '', 'c-ctl-' + ctl.key));
    });
    var list = el('div', { class: 'partlist' });
    R.parts.forEach(function (p) {
      if (p.system) return;
      list.appendChild(el('button', { type: 'button', 'aria-pressed': String(ui.sel === p.id), text: p.id + '  ·  ' + p.label, onclick: function () { ui.sel = ui.sel === p.id ? null : p.id; rebuild(true); } }));
    });
    c.appendChild(list);
    var u = ui.sel && userPart(ui.sel);
    if (u) {
      c.appendChild(row('x', num(u.x, 0.1, function (v) { u.x = v; }, { id: 'c-px' }), 'mm', 'c-px'));
      c.appendChild(row('y', num(u.y, 0.1, function (v) { u.y = v; }, { id: 'c-py' }), 'mm', 'c-py'));
      c.appendChild(row('Rotation', num(u.rot || 0, 5, function (v) { u.rot = ((v % 360) + 360) % 360; }, { id: 'c-pr' }), 'deg', 'c-pr'));
      c.appendChild(row('Mount', sel(mountOptions(), mountValue(u.mount), function (v) { var a = v.split(':'); u.mount = a[0] === 'flush' ? { flush: a[1], offset: 0 } : { on: a[0], side: a[1] }; }, 'c-pm'), '', 'c-pm'));
      if (u.mount.flush) c.appendChild(row('Offset from flush', num(u.mount.offset || 0, 0.1, function (v) { u.mount.offset = v; }, { id: 'c-po' }), 'mm', 'c-po'));
      var ucat = Cat.parts[u.type];
      if (ucat && ucat.dims) {
        c.appendChild(row('Name', el('input', { type: 'text', value: u.name || '', id: 'c-pname', placeholder: 'what it is', onchange: function (e) { if (e.target.value) u.name = e.target.value; else delete u.name; rebuild(true); } }), '', 'c-pname'));
        Object.keys(ucat.dims).forEach(function (k) {
          var cur = u.dims && u.dims[k] != null ? u.dims[k] : ucat.dims[k];
          c.appendChild(row(ucat.dimLabels[k], num(cur, 0.1, function (v) { u.dims = u.dims || clone(ucat.dims); u.dims[k] = v; }, { min: 0, max: 60, id: 'c-dim-' + k }), 'mm', 'c-dim-' + k));
        });
      }
      var rp = resolved(u.id);
      if (rp) {
        c.appendChild(el('div', { class: 'hint', text: 'Boards opened for it (tick to open, untick to keep whole):' }));
        R.layers.slice().reverse().forEach(function (L) {
          var st = rp.boards[L.id] || { state: 'whole', auto: 'whole', set: null }, open = st.state === 'through' || st.state === 'access';
          var cb = el('input', { type: 'checkbox', id: 'c-open-' + L.id, onchange: function (e) {
            var want = e.target.checked, autoOpen = st.auto !== 'whole';
            u.open = u.open || {};
            if (want === autoOpen) delete u.open[L.id]; else u.open[L.id] = want;
            if (!Object.keys(u.open).length) delete u.open;
            rebuild(true);
          } }); cb.checked = open;
          c.appendChild(el('div', { class: 'row boardrow' + (st.state === 'blocked' ? ' bad' : '') }, [el('label', { for: 'c-open-' + L.id, text: L.id + ' ' + L.name + ': ' + boardText(st) }), cb]));
        });
        if (u.open) c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'Some of these are set by hand.' }), el('button', { type: 'button', text: 'Back to automatic', onclick: function () { delete u.open; rebuild(true); } })]));
      }
      c.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'Arrow keys nudge 0.1 mm, with Shift 1.27 mm.' }), el('button', { type: 'button', text: 'Remove', onclick: function () { P.parts = P.parts.filter(function (p) { return p.id !== u.id; }); ui.sel = null; rebuild(true); } })]));
    }
    var addSel = el('select', { id: 'c-add', 'aria-label': 'part type to add' }, Object.keys(Cat.parts).map(function (k) { return el('option', { value: k, text: Cat.parts[k].label }); }));
    c.appendChild(el('div', { class: 'row' }, [addSel, el('button', { type: 'button', text: 'Add', onclick: function () { var t = addSel.value, n = 1, id; do { id = t.split('_')[0] + (n++); } while (P.parts.some(function (p) { return p.id === id; })); P.parts.push({ id: id, type: t, x: 60, y: +(R.planes.yt / 2).toFixed(1), rot: 0, mount: { on: boardFor(Cat.parts[t].on), side: 'top' } }); ui.sel = id; rebuild(true); } })]));

    c.appendChild(el('h2', { text: 'Probe dock' }));
    var pd = P.probe.dock;
    c.appendChild(check('c-dock', 'Dock in the left strip, between the boards', pd.enabled, function (v) { pd.enabled = v; }));
    if (pd.enabled) {
      c.appendChild(row('Probe diameter', num(P.probe.dia, 0.1, function (v) { P.probe.dia = v; }, { min: 1, max: 12, id: 'c-pdia' }), 'mm', 'c-pdia'));
      c.appendChild(row('Probe length', num(P.probe.len, 1, function (v) { P.probe.len = v; }, { min: 10, max: 200, id: 'c-plen' }), 'mm', 'c-plen'));
      c.appendChild(row('Tip end at y', num(pd.y_tip, 0.5, function (v) { pd.y_tip = v; }, { id: 'c-ptip' }), 'mm', 'c-ptip'));
      c.appendChild(row('Centre line x', num(pd.x, 0.1, function (v) { pd.x = v; }, { id: 'c-pcx' }), 'mm', 'c-pcx'));
      c.appendChild(check('c-pzauto', 'Centred between bottom and top board', pd.z == null, function (v) { pd.z = v ? null : R.probe.zc; }));
      if (pd.z != null) c.appendChild(row('Axis height z', num(pd.z, 0.1, function (v) { pd.z = v; }, { id: 'c-pz' }), 'mm', 'c-pz'));
      c.appendChild(row('Magnet dia x length', el('span', {}, [num(P.probe.magnet.dia, 0.5, function (v) { P.probe.magnet.dia = v; }, { min: 0.5, max: 10, label: 'magnet diameter' }), ' ', num(P.probe.magnet.len, 0.5, function (v) { P.probe.magnet.len = v; }, { min: 0.5, max: 10, label: 'magnet length' })]), 'mm'));
    }

    c.appendChild(el('h2', { text: 'View' }));
    var ex = el('input', { type: 'range', min: 0, max: 14, step: 0.5, value: ui.explode, id: 'c-ex', oninput: function (e) { ui.explode = parseFloat(e.target.value); buildScene(); } });
    c.appendChild(row('Explode', ex, '', 'c-ex'));
    var cs = el('select', { id: 'c-clip', onchange: function (e) { ui.clipAxis = e.target.value; applyClip(); } }, [['off', 'off'], ['x', 'across (x)'], ['y', 'down the board (y)'], ['z', 'by height (z)']].map(function (o) { return el('option', { value: o[0], text: o[1] }); })); cs.value = ui.clipAxis;
    c.appendChild(row('Section cut', cs, '', 'c-clip'));
    c.appendChild(row('Cut position', el('input', { type: 'range', min: 0, max: 1, step: 0.005, value: ui.clipPos, id: 'c-clipp', oninput: function (e) { ui.clipPos = parseFloat(e.target.value); applyClip(); } }), '', 'c-clipp'));
    var hs = el('input', { type: 'checkbox', id: 'c-hs', onchange: function (e) { ui.hideShell = e.target.checked; buildScene(); } }); hs.checked = ui.hideShell;
    c.appendChild(el('div', { class: 'row' }, [el('label', { for: 'c-hs', text: 'Hide the breadboard shell' }), hs]));
    var en = el('input', { type: 'checkbox', id: 'c-env', onchange: function (e) { ui.envelopes = e.target.checked; buildScene(); } }); en.checked = ui.envelopes;
    c.appendChild(el('div', { class: 'row' }, [el('label', { for: 'c-env', text: 'Show pocket envelopes' }), en]));
    c.appendChild(check('c-sens', 'Show the magnetometers', P.show.sensors, function (v) { P.show.sensors = v; }));
    c.scrollTop = keepScroll;
  }

  // ---------- checks ----------
  function pill(kind, text) { return el('span', { class: 'pill ' + kind, text: text }); }
  function line(kind, label, title, detail) { return el('div', { class: 'check' }, [pill(kind, label), el('span', { class: 't', text: title }), detail ? el('span', { class: 'd', text: detail }) : null]); }
  function renderChecks() {
    var c = R.checks, box = $('checks'); box.innerHTML = '';
    var g = c.grid, nb = {}; c.neighbours.forEach(function (n) { nb[n.id] = n; });
    var wigsFit = !nb.wig_left.overlap_mm2 && !nb.wig_right.overlap_mm2, unitsFit = !nb.unit_left.overlap_mm2;
    $('rev').textContent = (P.meta.rev || '') + '  ·  ' + (R.removable ? 'removable wig' : 'integrated');
    var hl = $('headline'); hl.innerHTML = '';
    hl.appendChild(pill(g.on_grid && wigsFit && unitsFit ? 'ok' : g.on_grid && wigsFit ? 'warn' : 'bad', unitsFit ? g.dead_rows + ' dead row' + (g.dead_rows > 1 ? 's' : '') + ', pitch ' + g.pitch : wigsFit ? 'breadboards fit beside it, a second unit does not' : 'a neighbour overlaps'));
    hl.appendChild(document.createTextNode(' '));
    var nClash = c.clashes.length + c.blocked.length;
    hl.appendChild(pill(nClash ? 'bad' : 'ok', nClash ? nClash + ' clash' + (nClash > 1 ? 'es' : '') : 'no clashes'));
    hl.appendChild(document.createTextNode(' '));
    if (c.area.fill != null) hl.appendChild(pill(c.area.fill > 0.6 ? 'bad' : c.area.fill > 0.45 ? 'warn' : 'ok', Math.round(c.area.fill * 100) + ' % of component room used'));

    box.appendChild(el('h2', { text: '0.1 inch stacking' }));
    box.appendChild(line(g.on_grid ? 'ok' : 'bad', g.on_grid ? 'on grid' : 'off grid', 'Unit pitch ' + g.pitch + ' mm = ' + Math.round(g.pitch / P.grid.pitch) + ' x 2.54', 'Grid planes at x = ' + g.left_plane + ' and ' + g.right_plane + '. Dead-row pins land at x = ' + g.dead_x.join(', ') + '.'));
    c.neighbours.forEach(function (n) {
      if (!n.overlap_mm2) { box.appendChild(line('ok', 'fits', n.label, 'One unit pitch away, edges meeting on the plane.')); return; }
      box.appendChild(line('bad', n.overlap_mm2 + ' mm²', n.label, 'Overlaps up to ' + n.depth + ' mm between y ' + n.y0 + ' and ' + n.y1 + ': ' + n.items.map(function (i) { return i.what; }).join(', ') + '.'));
    });
    if (!unitsFit && g.units_clear_at) box.appendChild(line('warn', g.units_clear_at.dead_rows + ' rows', 'Two whole units clear each other at pitch ' + g.units_clear_at.pitch, 'That is ' + g.units_clear_at.extra_rows + ' more dead row' + (g.units_clear_at.extra_rows > 1 ? 's' : '') + ' than the strip gives. Plan view only; heights are not considered.'));

    box.appendChild(el('h2', { text: 'Stack height' }));
    var d = c.flush.delta, fk = Math.abs(d) <= 0.1 ? 'ok' : Math.abs(d) <= 0.5 ? 'warn' : 'bad';
    box.appendChild(line(fk, (d >= 0 ? '+' : '') + d + ' mm', 'Top board at ' + c.flush.frame_top + ', breadboard top ' + c.flush.bb_top, 'Total ' + c.flush.total + ' mm from the main board underside. Gaps: ' + c.flush.gaps.map(function (q) { return q.gap + ' under ' + q.below; }).join(', ') + '.'));
    R.layers.forEach(function (L) { if (L.cutBy.length) box.appendChild(line(L.index === 0 || L.index === R.layers.length - 1 ? 'warn' : 'ok', L.id, L.name + ' is opened for ' + L.cutBy.join(', '), L.pocketArea + ' mm² removed' + (L.islands !== 1 ? ', which leaves it in ' + L.islands + ' pieces' : '') + '.')); else box.appendChild(line('ok', L.id, L.name + ' is whole')); });

    box.appendChild(el('h2', { text: 'Clashes' }));
    if (!c.clashes.length && !c.blocked.length) box.appendChild(line('ok', 'none', 'No two parts share space'));
    c.blocked.forEach(function (k) { box.appendChild(line('bad', k.mm2 + ' mm²', k.label + ' runs into ' + k.layer + ' ' + k.name, 'That board is set to stay whole for this part.')); });
    c.clashes.forEach(function (k) { box.appendChild(line('bad', k.overlap_z + ' mm', k.labels[0] + ' and ' + k.labels[1], k.overlap_mm2 + ' mm² of overlap in plan (' + k.bodies.join(' against ') + ').')); });
    c.overhang.forEach(function (o) { box.appendChild(line('warn', o.mm2 + ' mm²', o.label + ' reaches past the edge of ' + o.layer, 'x ' + o.x[0] + ' .. ' + o.x[1] + ', y ' + o.y[0] + ' .. ' + o.y[1] + '.')); });

    if (c.proud.length) {
      box.appendChild(el('h2', { text: 'Standing out' }));
      c.proud.forEach(function (k) { box.appendChild(line('info', '+' + k.by + ' mm', k.label, k.side === 'top' ? 'Above the top face.' : 'Below the underside of the main board.')); });
    }

    box.appendChild(el('h2', { text: 'Component room' }));
    var a = c.area;
    box.appendChild(el('div', {}, [el('span', { class: 'big', text: a.placeable + '' }), el('span', { class: 'u', text: ' mm² free' }), el('span', { class: 'hint', text: '  for ' + a.budget + ' mm² of parts' })]));
    box.appendChild(el('div', { class: 'bar' }, [el('i', { style: 'width:' + Math.min(100, Math.round((a.fill || 0) * 100)) + '%;background:var(--' + (a.fill > 0.6 ? 'bad' : a.fill > 0.45 ? 'warn' : 'ok') + ')' })]));
    box.appendChild(el('div', { class: 'hint', text: 'Parts would fill ' + Math.round((a.fill || 0) * 100) + ' % of it. Boards like this stop routing near 45 %.' }));
    var tb = el('table', {}, [el('tr', {}, [el('th', { text: 'Face' }), el('th', { class: 'n', text: 'free mm²' }), el('th', { class: 'n', text: 'headroom' })])]);
    var underBB = 0;
    c.faces.forEach(function (f) { if (!f.counts) return; if (f.under_bb) underBB += f.under_bb; tb.appendChild(el('tr', {}, [el('td', { text: f.layer + ' ' + f.side }), el('td', { class: 'n', text: String(f.free + (f.free_open || 0)) }), el('td', { class: 'n', text: f.open ? 'open' : f.height + ' mm' })])); });
    box.appendChild(tb);
    box.appendChild(el('div', { class: 'hint', text: 'A face counts where nothing stands in front of it and the gap is at least ' + a.min_gap + ' mm. Two faces across one gap share its height. One frame face is ' + a.frame_face + ' mm².' + (underBB ? ' ' + underBB + ' mm² of this is under the breadboard, which also has to carry the breadboard\'s own LEDs, pads and sensors.' : '') }));

    box.appendChild(el('h2', { text: 'Boards' }));
    var lt = el('table', {}, [el('tr', {}, [el('th', { text: 'Board' }), el('th', { class: 'n', text: 'z' }), el('th', { class: 'n', text: 'net mm²' })])]);
    R.layers.slice().reverse().forEach(function (L) { lt.appendChild(el('tr', {}, [el('td', {}, [el('span', { class: 'sw', style: 'background:' + Exp.LAYER_COLORS[L.index % Exp.LAYER_COLORS.length] }), L.id + ' ' + L.name]), el('td', { class: 'n', text: L.z0 + ' .. ' + L.z1 }), el('td', { class: 'n', text: String(L.area) })])); });
    box.appendChild(lt);

    if (c.probe) {
      var pr = c.probe;
      box.appendChild(el('h2', { text: 'Probe dock' }));
      box.appendChild(line(pr.cuts_outer.length ? 'bad' : 'ok', pr.cuts_outer.length ? pr.cuts_outer.join(', ') : 'inside', pr.cuts_outer.length ? 'The channel reaches into the bottom or top board' : 'The probe lies between the bottom and top boards', 'Axis at z ' + pr.zc + ' in a ' + pr.room_z + ' mm space; channel ' + pr.channel_w + ' mm. Opened: ' + (pr.cuts.length ? pr.cuts.join(', ') : 'nothing') + '.'));
      var wmin = Math.min(pr.wall_left, pr.wall_right);
      if (pr.cuts.length) box.appendChild(line(wmin >= 0.8 ? 'ok' : wmin >= 0.4 ? 'warn' : 'bad', wmin + ' mm', 'Thinnest wall left in ' + pr.cuts.join(', ') + ' beside the channel', 'Channel ' + pr.channel_w + ' mm wide in a ' + g.strip_w + ' mm strip.'));
      if (pr.sticks_out > 0) box.appendChild(line('warn', pr.sticks_out + ' mm', 'The probe sticks out past the bottom edge'));
      if (pr.nearest) box.appendChild(line(pr.nearest.frac > 0.8 ? 'bad' : 'ok', pr.nearest.B_mT + ' mT', 'Docked magnet at the nearest ' + pr.nearest.kind, pr.nearest.ref + ' is ' + pr.nearest.r + ' mm away; its range is ±' + pr.nearest.range_mT + ' mT.'));
      if (pr.dead_row_in_channel.length) box.appendChild(line('warn', 'shared', 'A dead-row pin line runs down the channel', 'x = ' + pr.dead_row_in_channel.join(', ') + '. A header bridging two units and a docked probe cannot both be there.'));
    }
    var sp = ui.sel && resolved(ui.sel);
    if (sp) {
      box.appendChild(el('h2', { text: 'Selected: ' + sp.id }));
      box.appendChild(el('div', { class: 'hint', text: sp.label + '. z ' + sp.z0 + ' .. ' + sp.z1 + ' mm, x ' + sp.xmin + ' .. ' + sp.xmax + ' mm.' + (sp.proud != null ? (sp.proud > 0.05 ? ' Its top is ' + sp.proud + ' mm above the top face.' : ' Its top is ' + (-sp.proud) + ' mm below the top face.') : '') }));
      if (sp.source) box.appendChild(el('div', { class: 'hint', text: sp.source }));
    }
    c.notes.forEach(function (t) { box.appendChild(line('warn', 'note', t)); });
  }

  // ---------- export ----------
  function exportItems() {
    var items = [['report', 'Check report (.txt)', 'v6_checks.txt', function () { return Exp.report(R); }],
      ['params', 'Parameters (v6_outline.json)', 'v6_outline.json', function () { return JSON.stringify(P, null, 2) + '\n'; }],
      ['svg', 'Plan of all layers (.svg)', 'v6_plan.svg', function () { return Exp.svg(R); }]];
    R.layers.forEach(function (L) {
      items.push(['dxf:' + L.id, L.id + ' ' + L.name + ' outline (.dxf)', Exp.slug(L) + '.dxf', function () { return Exp.dxf(R, L); }]);
      items.push(['kicad:' + L.id, L.id + ' ' + L.name + ' board (.kicad_pcb)', Exp.slug(L) + '.kicad_pcb', function () { return Exp.kicad(R, L); }]);
    });
    items.push(['resolved', 'Resolved geometry for the STEP script (.json)', 'resolved.json', function () { return JSON.stringify(Geo.plain(R)) + '\n'; }]);
    return items;
  }
  function bindExport() {
    var dlg = $('dlg'), what = $('exp-what'), text = $('exp-text'), note = $('exp-note'), items = [];
    function fill() { var it = items.filter(function (i) { return i[0] === what.value; })[0] || items[0]; text.value = it[3](); note.textContent = 'File name: ' + it[2] + '. Download works when this page is opened from disk; inside Claude use Copy.'; }
    $('btn-export').addEventListener('click', function () {
      items = exportItems(); what.innerHTML = ''; items.forEach(function (i) { what.appendChild(el('option', { value: i[0], text: i[1] })); });
      fill(); if (dlg.showModal) dlg.showModal(); else dlg.setAttribute('open', '');
    });
    what.addEventListener('change', fill);
    $('exp-close').addEventListener('click', function () { dlg.close ? dlg.close() : dlg.removeAttribute('open'); });
    $('exp-copy').addEventListener('click', function () {
      var done = function () { note.textContent = 'Copied.'; };
      try { navigator.clipboard.writeText(text.value).then(done, function () { text.select(); note.textContent = 'Copy was refused. The text is selected; press Ctrl or Cmd + C.'; }); } catch (e) { text.select(); note.textContent = 'The text is selected; press Ctrl or Cmd + C.'; }
    });
    $('exp-save').addEventListener('click', function () {
      var it = items.filter(function (i) { return i[0] === what.value; })[0];
      try { var a = el('a', { href: URL.createObjectURL(new Blob([text.value], { type: 'text/plain' })), download: it[2] }); document.body.appendChild(a); a.click(); a.remove(); } catch (e) { note.textContent = 'Download is not available here. Use Copy.'; }
    });
    $('btn-load').addEventListener('click', function () { $('file').click(); });
    $('file').addEventListener('change', function (e) {
      var f = e.target.files[0]; if (!f) return;
      var rd = new FileReader();
      rd.onload = function () { try { var o = JSON.parse(rd.result); if (!o.stack || !o.grid || !o.wig) throw new Error('not a v6_outline.json'); P = o; ui.sel = null; ui.vsel = null; rebuild(true); } catch (err) { $('rev').textContent = 'Could not load that file: ' + err.message; } };
      rd.readAsText(f); e.target.value = '';
    });
    $('btn-reset').addEventListener('click', function () { P = clone(DEFAULTS); ui.sel = null; ui.vsel = null; ui.hidden = {}; rebuild(true); });
  }

  // ---------- go ----------
  function rebuild(full, sceneOnly) {
    if (!P.frame.outline || P.frame.outline.length < 3) P.frame.outline = Geo.legacyOutline(P);      // a rev A1 file: turn its band and chamfers into vertices
    if (P.probe && P.probe.dock && P.probe.dock.z === undefined) P.probe.dock.z = null;
    R = Geo.resolve(P, REF);
    buildScene();
    renderChecks();
    if (full && !sceneOnly) renderControls();
    save();
  }
  function viewbar() {
    var vb = $('viewbar');
    [['iso', 'Iso'], ['top', 'Top'], ['under', 'Underside'], ['topedge', 'Top edge'], ['left', 'Left edge']].forEach(function (v) { vb.appendChild(el('button', { type: 'button', text: v[1], onclick: function () { setView(v[0]); } })); });
  }
  initThree();
  viewbar();
  bindExport();
  rebuild(true);
  resize(); setView('iso');
  window.V6App = { get params() { return P; }, get model() { return R; }, get camera() { return camera; }, get unit() { return unit; }, rebuild: rebuild, setView: setView, ui: ui };
})();
