// Jumperless V6 outline tool - part catalogue.
// Every part is a set of "bodies": plan shapes in the part's own frame (x right, y DOWN, origin = part origin)
// with a z range measured away from the mounting plane. Bodies cut pockets in the layers they pass through
// and are what the clash check uses. "model" names a real 3D mesh (see models/SOURCES.md).
// Dimensions marked ASSUMPTION have not been checked against a drawing.
// Bodies read from a 3D model were taken as its plan silhouette per height band (tools/silhouette.py).
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./partlib.js'));
  else root.V6Catalog = factory(root.V6_PARTLIB);
})(typeof self !== 'undefined' ? self : this, function (LIB) {
  'use strict';
  var R = function (x0, y0, x1, y1) { return { rect: [x0, y0, x1, y1] }; };
  var C = function (cx, cy, r) { return { circle: [cx, cy, r] }; };
  function body(shape, z0, z1, o) { var b = { shape: shape, z0: z0, z1: z1 }; if (o) for (var k in o) b[k] = o[k]; return b; }

  var catalog = {
    display_amoled147: {
      label: '1.47" AMOLED 194x368 + touch',
      color: 0x0a0a0c, height: 3.05, clearance: 0.2,
      bodies: [
        body(R(-9.68, -18.08, 9.68, 18.08), 0, 0.96, { name: 'panel' }),
        body(R(-11.0, -20.605, 11.0, 20.055), 0.96, 3.05, { name: 'cover glass' })
      ],
      model: { name: 'amoled147' },
      source: 'JumperlessV6/Displays (GLO147-D-M2002): cover glass 22.00 x 40.66, 3.05 thick. The 61.8 mm FPC tail is not drawn.'
    },
    display_tft147: {
      label: '1.47" TFT 172x320 + touch',
      color: 0x0a0a0c, height: 3.15, clearance: 0.2,
      bodies: [
        body(R(-9.88, -18.43, 9.88, 18.43), 0, 1.88, { name: 'LCM + folded FPC' }),
        body(R(-11.95, -20.07, 11.95, 19.83), 1.88, 3.15, { name: 'cover glass' })
      ],
      model: { name: 'tft147' },
      source: 'JumperlessV6/Displays (QHS147TP): cover glass 23.90 x 39.90, model 3.15 thick with the FPC folded under.'
    },
    // ---- inputs. "access" is the opening a board above the part gets so a finger or a cap can reach it;
    //      open: true = boards above are opened for it unless told otherwise, false = it stays covered unless asked.
    //      "on" is where the part goes when first added: base, mid or top board.
    encoder_siq02: {
      label: 'Click wheel SIQ-02FVS3 (no cap)', group: 'wheel', on: 'base',
      color: 0x222222, height: 4.0, clearance: 0.4,
      bodies: [
        body(R(-5.17, -3.85, 5.17, 7.26), 0, 2.0, { name: 'base', clearance: 0.25 }),
        body(C(0, 0, 7.25), 2.0, 4.0, { name: 'wheel' })
      ],
      access: { shape: C(0, 0, 7.25), open: false },
      model: { name: 'encoder' },
      source: 'STEP model embedded in the V5 board file (SIQ-02FVS3-1.step): base 10.3 x 11.1 up to 2.0, wheel dia 14.5 from 2.0 to 4.0. LCSC C29780879. Covered by the board above unless that board is opened for it.'
    },
    encoder_siq02_cap: {
      label: 'Click wheel SIQ-02FVS3 with the V5 cap', group: 'wheel', on: 'base',
      color: 0x222222, height: 5.75, clearance: 0.4,
      bodies: [
        body(R(-5.17, -3.85, 5.17, 7.26), 0, 2.0, { name: 'base', clearance: 0.25 }),
        body(C(0, 0, 7.25), 2.0, 4.0, { name: 'wheel' }),
        body(C(0, 0, 6.96), 4.0, 5.75, { name: 'cap' })
      ],
      access: { shape: C(0, 0, 7.25), open: true },
      model: { name: 'encoder', extra: ['cap'] },
      source: 'As above, with ClickwheelcapColor.step from the V5 board: cap top at 5.75.'
    },
    nav_rkjxm: {
      label: 'Nav stick ALPS RKJXM1015004 (through-hole)', group: 'nav', on: 'base',
      color: 0x2a2a2a, height: 15.0, clearance: 0.3,
      bodies: [
        body(R(-5.5, -5.5, 5.5, 5.5), 0, 6.6, { name: 'body' }),
        body(C(0, 0, 1.1), 6.6, 15.0, { name: 'lever', clearance: 1.6 })
      ],
      access: { shape: C(0, 0, 2.7), open: true },
      source: 'ALPSALPINE catalogue (Testolomew/docs/rkjxm1015004-catalog.png): 11.0 x 11.0 x 6.6, lever dia 2.2 with its tip 15 +-0.4 above the board, terminals 3.2 below it, 10 to 12 degrees of tilt, push travel 0.3. LCSC C97432; the stick on the bench. Drawn as its 11 x 11 square.'
    },
    nav_skrh: {
      label: 'Nav switch ALPS SKRHADE010 (SMD 7.45 x 7.5)', group: 'nav', on: 'mid',
      color: 0x2a2a2a, height: 5.0, clearance: 0.3,
      bodies: [
        body(R(-3.725, -3.75, 3.725, 3.75), 0, 1.85, { name: 'body' }),
        body(R(-1.17, -1.17, 1.17, 1.17), 1.85, 5.0, { name: 'stem', clearance: 1.2 })
      ],
      access: { shape: C(0, 0, 2.9), open: true },
      source: 'ALPS SKRH catalogue: SKRHAC / AD body 7.45 x 7.5 x 1.85, 5 overall, travel 0.25 (direction) and 0.15 (push). Its footprint is already in JumperlessFootprints. ASSUMPTION: the 2.34 square stem is from SparkFun\'s model of a same-size switch (SF303GJ26), not from the ALPS drawing.'
    },
    nav_k1_1210: {
      label: 'Nav pad Hroparts K1-1210UN-01 (SMD 9.9 x 9.9, flat)', group: 'nav', on: 'mid',
      color: 0x2a2a2a, height: 1.7, clearance: 0.3,
      bodies: [
        body(R(-5.25, -5.25, 5.25, 5.25), 0, 1.0, { name: 'body' }),
        body(C(0, 0, 3.46), 1.0, 1.45, { name: 'plate', clearance: 0.5 }),
        body(C(0, 0, 1.0), 1.45, 1.7, { name: 'nub', clearance: 0.5 })
      ],
      access: { shape: C(0, 0, 3.96), open: true },
      model: { name: 'nav_k1' },
      source: 'SparkFun KiCad library, Navigation_SMD_9.9x9.9mm.step (its footprint cites the K1-1210UN-01 datasheet): 9.9 x 9.9 body, 10.5 over the terminals, 1.7 overall. LCSC C128927. Its footprint is already in JumperlessFootprints. The Hroparts drawing itself was not read.'
    },
    tact_ts1187: {
      label: 'Tact switch 5.1 x 5.1, 1.7 high (TS-1187A-C-C-B)', group: 'button', on: 'mid',
      color: 0x8a8a8a, height: 1.7, clearance: 0.25,
      bodies: [
        body(R(-3.2, -2.5, 3.2, 2.5), 0, 0.28, { name: 'terminals' }),
        body(R(-2.55, -2.55, 2.55, 2.55), 0, 1.38, { name: 'body' }),
        body(C(0, 0, 1.0), 1.38, 1.7, { name: 'button', clearance: 0.5 })
      ],
      access: { shape: C(0, 0, 1.75), open: true },
      model: { name: 'tact' },
      source: 'XKB TS-1187A-C-C-B per LCSC: 5.1 x 5.1, 1.7 high, 260 gf (the TL3342 class of the V5 BOOT switch, MPN TS1187A26017 in B25). Shape and the dia 2.0 button from KiCad\'s SW_SPST_TL3342 model, stretched from 1.54 to 1.7.'
    },
    joy_joycon: {
      label: 'Thumbstick, Joy-Con type (Adafruit 5628)', group: 'joy', on: 'base',
      color: 0x303030, height: 13.68, clearance: 0.3,
      bodies: [
        body(R(-7.71, -9.71, 12.90, 9.30), 0, 1.0, { name: 'base and FPC' }),
        body(R(-11.05, -12.95, 9.25, 9.31), 1.25, 2.5, { name: 'mounting ears' }),
        body(R(-8.63, -10.63, 9.25, 9.31), 0, 5.25, { name: 'can' }),
        body(C(0, 0, 4.62), 5.25, 10.0, { name: 'stem', clearance: 1.5 }),
        body(C(0, 0, 7.5), 10.0, 13.68, { name: 'cap', clearance: 2.0 })
      ],
      access: { shape: C(0, 0, 9.5), open: true },
      model: { name: 'joycon' },
      source: 'Adafruit CAD model of product 5628 (Mini Joycon Thumbstick): can 17.9 x 19.9 x 5.25, ears to 20.3 x 22.3, cap dia 15 with its top 13.7 above the seat. FPC-connected. Not a part Kevin has named: the bench joystick is unidentified.'
    },
    custom_control: {
      label: 'Custom control (your numbers)', group: 'custom', on: 'base',
      color: 0x5b6470, clearance: 0.3,
      dims: { w: 8, d: 8, h: 3, stem: 3, top: 6 },
      dimLabels: { w: 'Body width', d: 'Body depth', h: 'Body height', stem: 'Actuator diameter', top: 'Actuator top height' },
      make: function (d) {
        var w = Math.max(0.5, d.w), dp = Math.max(0.5, d.d), h = Math.max(0.1, d.h), st = Math.max(0, d.stem), top = Math.max(h, d.top);
        var b = [body(R(-w / 2, -dp / 2, w / 2, dp / 2), 0, h, { name: 'body' })];
        if (st > 0 && top > h + 0.01) b.push(body(C(0, 0, st / 2), h, top, { name: 'actuator', clearance: 0.75 }));
        return { bodies: b, height: top, access: { shape: C(0, 0, Math.max(st, 1) / 2 + 0.75), open: true } };
      },
      source: 'Dimensions typed in by hand: measure the part.'
    },
    usbc_16p: {
      label: 'USB-C receptacle (16P, top mount)',
      color: 0xb8b8b8, height: 3.26, clearance: 0.25,
      bodies: [body(R(-4.47, -3.675, 4.47, 3.675), 0, 3.26, { name: 'shell' })],
      mouth: [0, -1],
      source: 'ASSUMPTION: 8.94 x 7.35 x 3.26 envelope for an HRO TYPE-C-31-M-12 class part; no model fetched.'
    },
    m2_socket: {
      label: 'M.2 socket, 4.2 high (TE 2199230 class)',
      color: 0x1c1c1c, height: 4.1, clearance: 0.3,
      bodies: [body(R(-10.95, -8.35, 10.95, 0.35), 0, 4.1, { name: 'socket' })],
      ghosts: [body(R(-11, -34.4, 11, -4.4), 1.7, 2.5, { name: '22x30 card' })],
      model: { name: 'm2' },
      mouth: [0, -1],
      source: 'SparkFun KiCad library M.2-E.step (Key E; the Key M body differs only in the key). 21.9 x 8.7 x 4.1 above the board.'
    },
    pcie_x1_ra: {
      label: 'PCIe x1 right-angle socket',
      color: 0x1c1c1c, height: 9.4, clearance: 0.3,
      bodies: [body(R(-12.5, -11, 12.5, 0), 0, 9.4, { name: 'socket' })],
      mouth: [0, -1],
      source: 'TE 1-1761465-1 product page: right angle, 36 position, 9.4 high. 25 long from the x1 family; 11 deep is an ASSUMPTION.'
    },
    sfp_cage: {
      label: 'SFP cage + 20-pin connector',
      color: 0xa8a8a8, height: 9.7, clearance: 0.3,
      bodies: [body(R(-7.25, 0, 7.25, 48.7), 0, 9.7, { name: 'cage' })],
      mouth: [0, -1],
      source: 'TE 2227316-1 drawing: single cage 48.7 x 14.5 x 9.7, port opening 14 x 8.95. Origin is the port mouth.'
    },
    hdr_ra_2x35: {
      label: '2x35 1.27 mm right-angle pin header',
      color: 0x111111, height: 3.4, clearance: 0.25,
      bodies: [body(R(-0.2, -0.635, 6.77, 43.815), 0, 3.4, { name: 'header' })],
      model: { name: 'hdr_ra' },
      source: 'KiCad PinHeader_2x35_P1.27mm_Horizontal: plastic 3.4 high, pins 4.0 long.'
    },
    skt_ra_2x35: {
      label: '2x35 1.27 mm right-angle socket',
      color: 0x111111, height: 3.1, clearance: 0.25,
      bodies: [body(R(-5.82, -0.81, 0.075, 43.99), 0, 3.1, { name: 'socket' })],
      model: { name: 'skt_ra' },
      source: 'KiCad PinSocket_2x35_P1.27mm_Horizontal (GCT BD091): body 4.4 deep, 3.1 high.'
    }
  };

  // What the "port" selector in the viewer swaps between.

  // ---- the candidate displays from Kevin's library (V6pile/display/Jumperless_V6_Displays/src/displays_data.py, read from the
  //      vendor drawings there). Each is its module outline and thickness, plus the cover glass where the drawing has one.
  //      [key, label, module w, h, thickness, corner r, active area w, h, AA top margin, cover glass [w, h, t, y offset] or 0]
  //      The FPC tails are not drawn. The two long IPS bars (7.84 and 10.11 inch, 206 and 266 mm) are left out: longer than the unit.
  var DISPLAY_LIB = [
    ['oled147b2b', '1.47" AMOLED 194x368, QSPI, B2B (library drawing)', 19.36, 36.17, 0.96, 3.5, 17.46, 33.12, 0.75, [22.0, 40.66, 2.09, 0.275]],
    ['tft147t16', '1.47" TFT 172x320 + touch, 16P (library drawing)', 19.75, 36.86, 1.56, 2.5, 17.65, 32.83, 1.1, [23.9, 39.9, 1.27, 0.12]],
    ['ips165bar', '1.65" IPS bar 142x428, 13P (ER-TFT1.65-2)', 16.3, 44.96, 2.23, 0, 13.16, 39.68, 1.5, 0],
    ['tft169t', '1.69" TFT 240x280 + touch, B2B', 30.07, 37.43, 2.1, 2.5, 27.97, 32.63, 0.8, [33.9, 42.7, 1.1, 0.505]],
    ['tft190', '1.9" TFT 170x320, 30P', 25.8, 49.72, 2.03, 0, 22.695, 42.72, 1.5, 0],
    ['tft201', '2.01" TFT 240x296, 8P', 34.04, 43.32, 1.56, 9.0, 32.04, 39.51, 1.1, 0],
    ['tft213r', '2.13" reflective TFT 122x250, 24P', 27.07, 56.2, 1.1, 0, 23.67, 48.5, 1.7, 0],
    ['tft220bar', '2.2" bar TFT 116x420, 8P (LTN220TF-PF09)', 17.6, 60.11, 1.62, 0, 14.964, 54.36, 1.5, 0],
    ['ips220m', '2.2" IPS 200x480, 20P MIPI', 23.72, 57.79, 2.0, 0, 21.72, 52.42, 1.4, 0],
    ['ips223m', '2.23" IPS 200x480, 24P MIPI', 23.82, 57.39, 1.56, 0, 21.72, 52.42, 1.2, 0],
    ['ips223t', '2.23" IPS 200x480 + touch glass, 24P MIPI', 23.82, 57.39, 1.56, 0, 21.72, 52.42, 1.2, [28.82, 62.39, 1.35, 0.5]],
    ['tft225bar', '2.25" bar TFT 76x284, 8P', 17.9, 62.5, 2.36, 0, 14.797, 55.295, 1.61, 0],
    ['ips279bar', '2.79" IPS bar 142x428, 12P (ER-TFT2.79-2)', 24.38, 69.43, 2.1, 0, 21.2787, 64.1358, 1.4, 0],
    ['tft290r', '2.9" reflective TFT 210x480, 24P', 31.1, 70.95, 0.8, 0, 29.1, 66.85, 1.0, 0],
    ['tft300', '3.0" TFT 268x800, 40P RGB (ST7701S)', 26.96, 80.08, 1.76, 0, 24.12, 72.0, 1.38, 0]
  ];
  catalog.display_amoled147.group = 'display'; catalog.display_amoled147.screen = { w: 17.46, h: 33.12, cy: -0.775 };
  catalog.display_tft147.group = 'display'; catalog.display_tft147.screen = { w: 17.65, h: 32.83, cy: -0.915 };
  DISPLAY_LIB.forEach(function (d) {
    var w = d[2], h = d[3], t = d[4], cg = d[9], bodies = [body(R(-w / 2, -h / 2, w / 2, h / 2), 0, t, { name: 'module' })];
    if (cg) bodies.push(body(R(-cg[0] / 2, -cg[1] / 2 - cg[3], cg[0] / 2, cg[1] / 2 - cg[3]), t, t + cg[2], { name: 'cover glass' }));
    catalog['display_' + d[0]] = { label: d[1], group: 'display', color: 0x0a0a0c, height: +(t + (cg ? cg[2] : 0)).toFixed(2), clearance: 0.2, bodies: bodies,
      screen: { w: d[6], h: d[7], cy: -(h / 2 - d[8] - d[7] / 2) },
      source: 'displays_data.py (vendor drawing): module ' + w + ' x ' + h + ' x ' + t + (cg ? ', cover glass ' + cg[0] + ' x ' + cg[1] + ' x ' + cg[2] : '') + '. FPC tail not drawn.' };
  });

  // ---- what drives each display and where it can be had (the bar-display survey of 2026-11-24,
  //      V6pile/notes/README_v6BarDisplay.md). bus = what the stock FPC brings out. price = list or quoted prices on that day.
  //      fps = whole frames a second in RGB565 on 50 MHz SPI, scaled by pixel count from Testolomew's 33 to 40 on its 240 x 240.
  var DISPLAY_INFO = {
    tft220bar: { px: [116, 420], ic: 'NV3006B', bus: '4-wire SPI on 8 pins (the chip also has 2-lane SPI, QSPI and 8-bit 8080)', price: '$2.39 one (AliExpress), $3.07 at 100 (EastRising); no 1k quote yet', fps: 'About 39 to 47 whole frames a second in RGB565 on 50 MHz SPI',
      links: [['EastRising ER-TFT022-3', 'https://www.buydisplay.com/2-2-inch-ips-tft-bar-display-116x420-spi-nv3006b-with-soldering-type-fpc'], ['on a breakout', 'https://www.buydisplay.com/2-2-inch-116x420-ips-tft-lcd-display-module-for-stm32-esp32-and-arduino'], ['AliExpress, EC-Buying', 'https://www.aliexpress.us/item/3256812438743306.html'], ['NV3006B datasheet', 'https://www.buydisplay.com/download/ic/ER-NV3006B.pdf']] },
    ips279bar: { px: [142, 428], ic: 'NV3007', bus: '4-wire SPI; the 12-pin part also has TE and SDO', price: '$3.20 at 100 (ER-TFT2.79-2, 400 nit), $3.48 at 100 (ER-TFT2.79-1, 600 nit)', fps: 'About 31 to 38 whole frames a second in RGB565 on 50 MHz SPI',
      links: [['EastRising ER-TFT2.79-2', 'https://www.buydisplay.com/2-79-inch-142x428-resolution-ips-tft-lcd-display-nv3007-4-wire-spi'], ['ER-TFT2.79-1', 'https://www.buydisplay.com/wide-angle-2-79-inch-142x428-color-ips-tft-display-nv3007-controller'], ['on a breakout', 'https://www.buydisplay.com/2-79-inch-142x428-ips-display-with-breakout-board-for-stm32-esp32-and-arduino'], ['NV3007 datasheet', 'https://buydisplay.com/download/ic/NV3007.pdf']] },
    ips165bar: { px: [142, 428], ic: 'NV3007', bus: '4-wire SPI', price: '$2.23 at 100 (ER-TFT1.65-3, rounded corners, 8 pins)', fps: 'About 31 to 38 whole frames a second in RGB565 on 50 MHz SPI',
      links: [['EastRising ER-TFT1.65-2', 'https://buydisplay.com/wide-angle-1-65-inch-142x428-color-ips-tft-display-nv3007-controller'], ['ER-TFT1.65-3', 'https://www.buydisplay.com/bar-type-1-65-inch-142x428-tft-lcd-display-4-wire-spi-nv3007-connector-type-fpc'], ['NV3007 datasheet', 'https://buydisplay.com/download/ic/NV3007.pdf']] },
    tft225bar: { px: [76, 284], ic: 'ST7789P3', bus: '4-wire SPI on 8 pins, the same pin order as the 2.2 inch', price: '$2.37 at 100 (EastRising); Shineworld quoted $4.09 at 1000', fps: 'The wire allows 145 frames a second at 50 MHz, so it runs at the panel\'s own 60',
      links: [['EastRising ER-TFT2.25-1', 'https://www.buydisplay.com/2-25-inch-tft-serial-spi-76x284-lcd-display-module-w-st7789p3'], ['on a breakout', 'https://www.buydisplay.com/spi-tft-2-25-lcd-76x284-display-module-st7789-breakout-board-for-arduino-raspberry-pi']] },
    tft190: { px: [170, 320], ic: 'ST7789', bus: 'SPI or 8-bit 8080', price: 'Shineworld quoted $2.90 at 1000; $5.71 at 100 (EastRising)', fps: 'About 35 to 42 whole frames a second in RGB565 on 50 MHz SPI',
      links: [['EastRising ER-TFT019-1', 'https://www.buydisplay.com/full-viewing-angle-spi-1-9-inch-ips-tft-lcd-display-panel-170x320-st7789'], ['Tailor Pixels TTH019BVS', 'https://tailorpixels.com/?p=21275']] },
    tft300: { px: [268, 800], ic: 'ST7701S', bus: 'RGB dot clock (about 16 MHz, 18 data pins) with SPI for setup only', price: 'Shineworld quoted $4.87 at 1000; $10.52 at 100 (EastRising)', fps: 'Always 60, streamed from a 419 kB frame buffer of your own; over SPI it would be 15',
      links: [['EastRising 2.99 inch', 'https://www.buydisplay.com/bar-type-2-99-inch-268x800-ips-tft-lcd-display-spi-rgb-interface']] }
  };
  Object.keys(DISPLAY_INFO).forEach(function (k) { if (catalog['display_' + k]) catalog['display_' + k].info = DISPLAY_INFO[k]; });

  // ---- a display behind a window: the module under the top board, the board cut to the active area with chamfered corners,
  //      and (glass: 1) a pane the thickness of that board let into the cut. crop = how far inside the active area the cut is,
  //      all round; chamfer = the leg of each corner cut; gap = the space round the pane. A real routed cut has a radius of
  //      half the bit (0.4 to 0.5) at each of the eight corners, which is not drawn.
  var WINDOW = { crop: 0.3, chamfer: 2.0, glass: 1, gap: 0.1 };
  function windowShape(cat, wn, inset) {
    var s = cat.screen, g = inset || 0, hw = s.w / 2 - wn.crop - g, hh = s.h / 2 - wn.crop - g;
    var c = Math.max(0, Math.min(wn.chamfer - g * 0.5858, hw - 0.2, hh - 0.2)), cy = s.cy;
    return [[-hw + c, cy - hh], [hw - c, cy - hh], [hw, cy - hh + c], [hw, cy + hh - c], [hw - c, cy + hh], [-hw + c, cy + hh], [-hw, cy + hh - c], [-hw, cy - hh + c]].map(function (q) { return [+q[0].toFixed(4), +q[1].toFixed(4)]; });
  }

  // ---- expansion-port families from the port survey (V6_expansion_port_and_current_sense.md, section 5)
  catalog.minipcie = {
    label: 'mini PCIe socket, 52 pads (SOFNG PCIE-52P52H class)', group: 'port', color: 0x1c1c1c, height: 5.2, clearance: 0.3,
    bodies: [body(R(-15.75, -6.0, 15.75, 0), 0, 5.2, { name: 'socket' })], ghosts: [body(R(-15, -32.5, 15, -2.5), 2.2, 3.2, { name: '30 x 30 half card' })], mouth: [0, -1],
    source: 'Port survey: 31.5 x 6 mm host footprint + 2 latch posts, 1.0 mm card 30 wide. ASSUMPTION: 5.2 high, read off the part number (52H), no drawing opened; latch posts not drawn.' };
  catalog.sodimm_ddr4 = {
    label: 'DDR4 SO-DIMM socket, 260 pads, 4.0 high (Lotes ADDR0205)', group: 'port', color: 0x1c1c1c, height: 4.0, clearance: 0.3,
    bodies: [body(R(-36.5, -23.5, 36.5, 0), 0, 4.0, { name: 'socket + latches' })], ghosts: [body(R(-34.8, -30, 34.8, -1), 1.4, 2.6, { name: '69.6 x 30 module' })], mouth: [0, -1],
    source: 'Port survey: 73 x 23.5 mm with latches, 4.0 high, 1.2 mm card 69.6 wide. The envelope is the whole 73 x 23.5 block; the real part is a socket bar and two latch arms.' };

  // ---- chips and other tall or large parts, to try where they fit. Bodies are the package outlines over the leads.
  function chip(label, w, d, h, src) { return { label: label, group: 'chip', on: 'base', color: 0x18181b, height: h, clearance: 0.25, cut: true, bodies: [body(R(-w / 2, -d / 2, w / 2, d / 2), 0, h, { name: 'package' })], source: src }; }
  catalog.ic_ch446q = chip('CH446Q crossbar, LQFP-44 (12 x 12 over leads)', 12.0, 12.0, 1.6, 'LQFP-44 10 x 10 body, 12 x 12 over the leads, 1.6 max high (JEDEC MS-026). V6 has 12 + 5 lane + 1 port. Courtyard in V6_area.json: 13.4 x 13.4.');
  catalog.ic_ch32h417 = chip('CH32H417QEU6, QFN-128 12.3 x 12.3', 12.3, 12.3, 0.9, 'Footprint QFN-128-1EP_12.3x12.3mm_P0.35mm (V6_area.json). ASSUMPTION: 0.9 high, typical for the package; not from the datasheet.');
  catalog.ic_rp2350b = chip('RP2350B, QFN-80 10 x 10', 10.0, 10.0, 0.9, 'Footprint RP2350-QFN-80-1EP_10x10 (V6_area.json). ASSUMPTION: 0.9 high.');
  catalog.ic_tssop16 = chip('74HC595 / 74HC238, TSSOP-16 (6.4 over leads)', 5.0, 6.4, 1.2, 'TSSOP-16 4.4 x 5 body, 6.4 over the leads, 1.2 max high. V6 has 25 x 74HC595 and 4 x 74HC238.');
  catalog.ind_6x6 = chip('Inductor 6.3 x 6.3, 3 high (TPS65131 rails)', 6.3, 6.3, 3.0, 'Footprint L_6.3x6.3_H3 (V6_area.json, 2 fitted). The tallest part of the power block.');
  catalog.usb_fpc20 = chip('FPC connector 20P (FC05-S20FCT class)', 15.4, 4.7, 2.0, 'Footprint courtyard 15.4 x 4.7 (V6_area.json). ASSUMPTION: 2.0 high.');
  // a screw through the whole stack with a spacer in every gap: what could hold the boards apart
  catalog.standoff_m2 = {
    label: 'M2 screw + spacers through the stack', group: 'mech', on: 'base', color: 0xb9bcc2, height: 0, clearance: 0.1,
    dims: { screw: 2.0, spacer: 3.5, head: 3.8 }, dimLabels: { screw: 'Screw diameter', spacer: 'Spacer diameter', head: 'Head diameter' },
    make: function (d, ctx) {
      var L = (ctx && ctx.layers) || [{ z0: -1.6, z1: 0 }], zb = L[0].z0, zt = L[L.length - 1].z1, b = [body(C(0, 0, d.screw / 2), zb, zt, { name: 'screw', clearance: 0.1 })];
      for (var i = 1; i < L.length; i++) if (L[i].z0 - L[i - 1].z1 > 0.05) b.push(body(C(0, 0, d.spacer / 2), L[i - 1].z1, L[i].z0, { name: 'spacer', cut: false }));
      b.push(body(C(0, 0, d.head / 2), zt, zt + 1.3, { name: 'head', cut: false }));
      return { bodies: b, height: zt + 1.3 };
    },
    source: 'ASSUMPTION: a plain M2 pan-head screw (head 3.8 x 1.3) with a 3.5 mm round spacer in each gap. What holds the boards apart is not decided.' };


  // ---- parts from the library file (src/partlib.js, built by tools/prep_parts.py): the footprint and 3D model that EasyEDA
  //      holds for an LCSC number. A part's frame here is its footprint's frame, so the KiCad export places the footprint
  //      at the part's own x, y and rotation. "have" is the quantity in Kevin's parts inventory.
  LIB = LIB || { parts: {}, footprints: {} };
  var TONE = { button: 0x8a8a8a, nav: 0x7d8288, joy: 0x2b2b2e, wheel: 0x3a3a3a, port: 0xa9adb3 };
  Object.keys(LIB.parts).forEach(function (k) {
    var q = LIB.parts[k], sh = function (b) { return b.r ? R(b.r[0], b.r[1], b.r[2], b.r[3]) : C(b.c[0], b.c[1], b.c[2]); };
    var act = q.bodies[q.bodies.length - 1];
    var mo = /^model centre (-?[\d.]+), (-?[\d.]+)/.exec(q.note || ''), off = mo && (Math.abs(+mo[1]) > 0.5 || Math.abs(+mo[2]) > 0.5);
    catalog[k] = { label: q.label, group: q.group, on: q.on, color: TONE[q.group] || 0x8a8a8a, height: q.height, clearance: 0.25, lcsc: q.lcsc, fp: q.fp, have: q.have, lib: true, size: q.size, model: q.model ? { name: 'lib_' + k } : undefined,
      bodies: q.bodies.map(function (b) { return body(sh(b), b.z0, b.z1, { name: b.name }); }),
      access: q.access ? { shape: sh(act), open: true } : undefined,
      source: 'LCSC ' + q.lcsc + ': EasyEDA footprint ' + q.fp + '; body ' + q.size[0] + ' x ' + q.size[1] + ' x ' + q.height + (q.model ? ' from its 3D model' : '') + (off ? ' (' + q.note + ': check which is right)' : !q.model && q.note ? ' (' + q.note + ')' : '') + '. Not checked against the maker\'s drawing.' };
  });
  // metal domes straight on the board: the lowest switch there is, and the usual partner of a cantilevered button
  function dome(dia, h, lcsc, have) { return { label: 'Metal dome ' + dia + ' mm (BONSDA, LCSC ' + lcsc + ')', group: 'button', on: 'mid', color: 0xc9cdd2, height: h, clearance: 0.3, have: have, lcsc: lcsc,
    bodies: [body(C(0, 0, dia / 2), 0, h, { name: 'dome' })], access: { shape: C(0, 0, dia / 2 - 1), open: true },
    source: 'In the parts inventory (' + have + '). ASSUMPTION: ' + h + ' mm high and round, from the usual shape of a dome that size; no drawing or footprint found. Exported as an outline only.' }; }
  catalog.dome_5 = dome(5, 0.4, 'C41419087', 50);
  catalog.dome_7 = dome(7, 0.5, 'C49260603', 50);
  // A cantilevered button: a tongue cut in the top board over a low switch, so the board itself is the key top. The tongue
  // belongs to the top board whatever board or face the switch is on (geometry.js). Any button can be
  // given a tongue (the part's "tongue" numbers); this entry is the TS-1187A with one already on it. The tongue runs from just
  // past the switch to its root, in the direction "dir" (degrees, counter-clockwise from the part's +y).
  var TONGUE = { len: 19, w: 3, slot: 0.8, tip: 2.5, dir: 0, nub: 0 };
  function tongueShape(t) {
    var hw = t.w / 2, s = t.slot, y0 = -t.tip, y1 = t.len - t.tip, a = (t.dir || 0) * Math.PI / 180, c = Math.cos(a), n = Math.sin(a);
    return [[-hw - s, y1], [-hw - s, y0 - s], [hw + s, y0 - s], [hw + s, y1], [hw, y1], [hw, y0], [-hw, y0], [-hw, y1]].map(function (q) { return [+(q[0] * c + q[1] * n).toFixed(4), +(-q[0] * n + q[1] * c).toFixed(4)]; });
  }
  (function () {
    var base = catalog.btn_ts1187a; if (!base) return;
    var o = {}; for (var k in base) o[k] = base[k];
    o.label = 'Cantilevered button: TS-1187A under a tongue cut in the top board'; o.tongue = TONGUE; o.have = 0;
    o.source = base.source + ' The tongue is the top board, cut round on three sides; the force in the checks is a plain cantilever with E = 22 GPa for FR4: an estimate.';
    catalog.btn_cantilever = o;
  })();

  // ---- edge couplers between two units (claude_V6_edge_coupler_connector_design.md and ..._v2_kiss_slot.md)
  //      gap = distance between the two boards' shoulders when mated; across = the housing in that direction; thick = across the board faces
  var couplers = {
    wingtat: { label: 'WingTAT HEE70LP03BK (today)', len: 50.55, across: 18.3, thick: 8.88, gap: 6.4, tongue: 7.62, tip_gap: null, source: 'Housing 50.55 x 8.88 x 14.0 + 4.3 of tails = 18.3 end to end; boards about 6.4 apart; 45.47 x 7.62 tongue.' },
    kiss: { label: 'Kiss slot V2 (custom, 9.2)', len: 50.55, across: 9.2, thick: 5.0, gap: 9.2, tongue: 4.5, tip_gap: 0.2, source: 'Housing 50.55 x 5.0 x 9.2, one through slot; 4.5 mm tongues meet in the middle about 0.2 apart; shoulders seat on the faces.' },
    kiss_short: { label: 'Kiss slot V3 short (7.8)', len: 50.55, across: 7.8, thick: 5.0, gap: 7.8, tongue: 3.8, tip_gap: 0.2, source: 'Housing 50.55 x 5.0 x 7.8, 3.8 mm tongues; needs tight tolerances (card +-0.10, gap +-0.03).' }
  };

  var portTypes = {
    none: { label: 'none', parts: [] },
    m2: { label: 'M.2 socket', parts: ['m2_socket'] },
    pcie: { label: 'PCIe x1 right-angle', parts: ['pcie_x1_ra'] },
    sfp2: { label: '2 x SFP cage', parts: ['sfp_cage', 'sfp_cage'] },
    minipcie: { label: 'mini PCIe socket', parts: ['minipcie'] },
    sodimm: { label: 'DDR4 SO-DIMM socket', parts: ['sodimm_ddr4'] }
  };

  // The "Controls" selectors in the viewer: one slot each, swapped in place. at = [x, y, rot] for a part added fresh.
  var controls = [
    { key: 'wheel', label: 'Click wheel', ids: ['encoder'], at: [[-2.47, -17.17, 45]],
      options: [['none', 'none'], ['encoder_siq02', 'SIQ-02FVS3, no cap'], ['encoder_siq02_cap', 'SIQ-02FVS3 with the V5 cap']] },
    { key: 'nav', label: 'Directional switch', ids: ['nav'], at: [[54, -7.5, 0]],
      options: [['none', 'none'], ['nav_rkjxm', 'ALPS RKJXM stick (through-hole)'], ['nav_skrh', 'ALPS SKRHADE010 (SMD)'], ['nav_k1_1210', 'Hroparts K1-1210UN (flat SMD)']] },
    { key: 'joy', label: 'Joystick', ids: ['joy'], at: [[58, -10.5, 0]],
      options: [['none', 'none'], ['joy_joycon', 'Joy-Con type thumbstick'], ['custom_control', 'custom (your numbers)']] },
    { key: 'buttons', label: 'Buttons A and B', ids: ['btn_a', 'btn_b'], at: [[66.5, -6, 0], [73.5, -6, 0]],
      options: [['none', 'none'], ['tact_ts1187', 'tact 5.1 x 5.1, 1.7 high']] }
  ];

  // every part of a kind is offered in that kind's selector, the ones in the parts inventory marked
  controls.forEach(function (c) {
    var g = { wheel: 'wheel', nav: 'nav', joy: 'joy', buttons: 'button' }[c.key];
    Object.keys(catalog).forEach(function (k) { if (catalog[k].group === g && !c.options.some(function (o) { return o[0] === k; })) c.options.push([k, catalog[k].label + (catalog[k].have ? ' (have ' + catalog[k].have + ')' : '')]); });
  });
  ['port_m2_48', 'port_minipcie_40', 'port_hee70'].forEach(function (k) { if (catalog[k]) portTypes[k] = { label: catalog[k].label + ' (have ' + catalog[k].have + ')', parts: [k], lib: true }; });

  // a user part -> its catalogue entry, with the bodies of a parametric part made from the part's own numbers
  function get(u, ctx) {
    var c = catalog[u.type];
    if (!c) return null;
    if (!c.make) return c;
    var d = {}, k; for (k in c.dims) d[k] = u.dims && u.dims[k] != null ? +u.dims[k] : c.dims[k];
    var m = c.make(d, ctx), o = {}; for (k in c) o[k] = c[k]; for (k in m) o[k] = m[k];
    return o;
  }

  return { parts: catalog, footprints: LIB.footprints, tongue: TONGUE, tongueShape: tongueShape, window: WINDOW, windowShape: windowShape, portTypes: portTypes, controls: controls, couplers: couplers, displays: Object.keys(catalog).filter(function (k) { return catalog[k].group === 'display'; }), get: get };
});
