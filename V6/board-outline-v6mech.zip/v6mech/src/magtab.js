// Jumperless V6 outline tool - the Magnetometers tab.
// A plan of the unit with the probe tracker's sensors as dots to drag, every breadboard hole coloured by how well the
// layout places the probe there (src/magmodel.js), the sensor list and the probe's settings in the Design panel and the
// numbers in the Checks panel. The sensors are the design's own mag.list, so the 3D view, the docked-probe check, undo,
// the saved state and the exported files all follow.
(function () {
  'use strict';
  var Mag = window.V6Mag;
  var EDGES = [0.3, 0.6, 1.0, 1.6, 3, 6];
  var COLS = ['#185fa5', '#378add', '#85b7eb', '#6a6a74', '#f09595', '#e24b4a', '#a32d2d'];           // blue: finds the hole; grey: about half a hole; red: does not
  var BIN_LABELS = ['under 0.3 mm', '0.3 to 0.6', '0.6 to 1.0', '1.0 to 1.6, about half a hole', '1.6 to 3', '3 to 6', 'over 6'];
  var DROP = ['#2b4563', '#3f77b8', '#6ea9ea', '#b7d6f8'];                                             // sensors past full scale at that hole: none, 1, 2, 3 or more
  function bin(v) { for (var i = 0; i < EDGES.length; i++) if (v < EDGES[i]) return i; return 6; }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function mm(v, d) { return isFinite(v) ? v.toFixed(d == null ? 2 : d) : 'no fix'; }

  function create(c) {
    var el = c.el, $ = c.$, canvas = $('magcanvas'), legend = $('maglegend'), tip = $('tip'), view = $('view');
    var S = null, tf = null, drag = null, raf = false, legendFor = null, improving = null, cmp = { key: null, rows: null, timer: null };
    var st = c.ui.mag;

    function list() { return c.R().wig.sensors.list || []; }
    // the list being edited is the design's own; an older file's fixed layout becomes a list at the first change
    function own() {
      var P = c.P(), R = c.R();
      if (P.show.sensor_layout !== 'custom' || !P.mag || !P.mag.list) { P.mag = P.mag || {}; P.mag.list = clone(R.wig.sensors.list || []); P.show.sensor_layout = 'custom'; R.wig.sensors.list = P.mag.list; }
      return P.mag.list;
    }
    function mag() { var P = c.P(); P.mag = P.mag || {}; P.mag.magnet = P.mag.magnet || { use: 'bench', strength: 1900 }; return P.mag; }
    function compute(quick) { var R = c.R(), P = c.P(); S = Mag.summary(R, list(), P, quick ? { quick: true } : null); S.docked = Mag.docked(R, S.placed, S.st.strength); S.quick = !!quick; return S; }
    function mode() { var m = (c.P().mag || {}).map; return m === 'shift' || m === 'used' ? m : 'error'; }

    // ---------- the map ----------
    function fit() {
      var R = c.R(), w = Math.max(50, canvas.clientWidth), h = Math.max(50, canvas.clientHeight), pl = R.planes, pad = 22, top = 46, bot = 26;
      var x0 = pl.x0 - 1.5, x1 = pl.x1 + 1.5, y0 = pl.yt - 1.5, y1 = pl.yb + 1.5;
      var k = Math.max(0.5, Math.min((w - 2 * pad) / (x1 - x0), (h - top - bot) / (y1 - y0)));
      tf = { k: k, ox: (w - k * (x1 - x0)) / 2 - k * x0, oy: top + ((h - top - bot) - k * (y1 - y0)) / 2 - k * y0, w: w, h: h };
    }
    function sx(x) { return tf.ox + tf.k * x; }
    function sy(y) { return tf.oy + tf.k * y; }
    function css(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim(); }
    function trace(g, pts) { g.beginPath(); pts.forEach(function (q, i) { if (i) g.lineTo(sx(q[0]), sy(q[1])); else g.moveTo(sx(q[0]), sy(q[1])); }); g.closePath(); }
    function setLegend() {
      var m = mode(), key = m + '|' + (S && S.st.uniform);
      if (legendFor === key) return;
      legendFor = key; legend.innerHTML = '';
      function sw(col, text, cls) { legend.appendChild(el('span', {}, [el('i', { style: col ? 'background:' + col : null, class: cls || null }), text])); }
      if (m === 'used') { sw(DROP[0], 'every sensor in range'); sw(DROP[1], '1 past full scale'); sw(DROP[2], '2'); sw(DROP[3], '3 or more'); sw(null, 'too few left for a fix', 'nofix'); }
      else { BIN_LABELS.forEach(function (t, i) { sw(COLS[i], i === 0 && m === 'shift' ? 'moves under 0.3 mm' : t); }); sw(null, 'no fix', 'nofix'); }
      sw(null, 'sensor on the top face', 'dot'); sw(null, 'on the underside', 'ring');
    }
    function draw() {
      if (!S || canvas.clientWidth < 2) return;
      var R = c.R(); fit();
      var dpr = Math.min(2, window.devicePixelRatio || 1), W = Math.round(tf.w * dpr), H = Math.round(tf.h * dpr);
      if (canvas.width !== W || canvas.height !== H) { canvas.width = W; canvas.height = H; }
      var g = canvas.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, tf.w, tf.h);
      var ink = css('--ink') || '#f3f3f5', dim = css('--dim') || '#aaaab5', line = css('--line') || '#4b4b54', panel = css('--panel') || '#323238', panel2 = css('--panel-2') || '#3d3d44', bg = css('--bg') || '#27272b', accent = css('--accent') || '#fc0289', bad = css('--problem') || '#ff4d3d';
      var k = tf.k, m = mode(), ev = S.ev, cols = R.wig.cols, rows = R.wig.rows;
      // the frame, then the breadboard's own outline on it
      g.save(); g.beginPath(); g.rect(0, 0, tf.w, sy(R.planes.yb + 1.5) + 1); g.clip();         // the docked probe sticks out past the bottom edge: the plan stops there
      trace(g, R.outline.pts); g.fillStyle = panel2; g.fill();
      trace(g, R.wig.outline); g.fillStyle = bg; g.fill(); g.lineWidth = 1; g.strokeStyle = dim; g.globalAlpha = 0.7; g.stroke();
      trace(g, R.outline.pts); g.stroke(); g.globalAlpha = 1;
      if (st.parts !== false) {
        g.font = '10px ' + (css('--mono') || 'monospace'); g.textAlign = 'center'; g.textBaseline = 'middle';
        R.parts.forEach(function (p) {
          if (p.id === 'shell' || p.id === 'face' || p.id === 'wig_pcb') return;
          g.globalAlpha = 0.55; g.strokeStyle = dim; g.lineWidth = 1; g.setLineDash(p.id === 'probe' ? [4, 3] : []);
          p.bodies.forEach(function (b) { trace(g, b.pts); g.stroke(); });
          var b0 = p.bodies[0].pts, cx = 0, cy = 0; b0.forEach(function (q) { cx += q[0]; cy += q[1]; });
          g.setLineDash([]); g.fillStyle = dim; g.fillText(p.id === 'wig_hdr' ? 'header' : p.id === 'wig_skt' ? 'socket' : p.id, sx(cx / b0.length), sy(cy / b0.length)); g.globalAlpha = 1;
        });
        if (R.probe && R.probe.magnet) { var pm = R.probe.magnet; g.fillStyle = accent; g.fillRect(sx(pm.x) - 3, sy(pm.y) - 3, 6, 6); }
      }
      g.restore();
      // the holes
      var cs = k * 2.24, hx = cs / 2;
      for (var iy = 0; iy < rows.length; iy++) for (var ix = 0; ix < cols.length; ix++) {
        var h = iy * ev.nx + ix, v = m === 'shift' ? ev.shift[h] : ev.err[h], x = sx(cols[ix]) - hx, y = sy(rows[iy]) - hx, nofix = !isFinite(ev.err[h]);
        if (v !== v) continue;
        if (m === 'used') g.fillStyle = nofix ? COLS[6] : DROP[Math.min(3, S.n - ev.used[h])];
        else g.fillStyle = nofix ? COLS[6] : COLS[bin(v)];
        g.fillRect(x, y, cs, cs);
        if (nofix) { g.strokeStyle = bg; g.lineWidth = 1.2; g.beginPath(); g.moveTo(x + 1, y + cs - 1); g.lineTo(x + cs - 1, y + 1); g.stroke(); }
      }
      if (m === 'error' && S.stats.at >= 0 && isFinite(S.stats.worst)) { var wa = S.stats.at; g.strokeStyle = ink; g.lineWidth = 1.5; g.strokeRect(sx(cols[wa % ev.nx]) - hx - 1.5, sy(rows[Math.floor(wa / ev.nx)]) - hx - 1.5, cs + 3, cs + 3); }
      // the sensors
      g.font = '600 10px ' + (css('--label') || 'sans-serif'); g.textAlign = 'left'; g.textBaseline = 'middle';
      S.placed.forEach(function (p, i) {
        var X = sx(p.x), Y = sy(p.y), r = p.kind === 'tmag' ? 5.5 : 4.5, wrong = p.off || p.under, col = wrong ? bad : ink, top = p.side !== 'bottom';
        if (st.sel === i) { g.beginPath(); g.arc(X, Y, r + 5, 0, 6.2832); g.strokeStyle = accent; g.lineWidth = 2; g.stroke(); }
        g.beginPath(); if (p.kind === 'tmag') g.rect(X - r, Y - r, 2 * r, 2 * r); else g.arc(X, Y, r, 0, 6.2832);
        g.fillStyle = top ? col : bg; g.fill(); g.lineWidth = top ? 1.5 : 2.2; g.strokeStyle = top ? bg : col; g.stroke();
        if (!top) { g.beginPath(); if (p.kind === 'tmag') g.rect(X - r - 1.6, Y - r - 1.6, 2 * r + 3.2, 2 * r + 3.2); else g.arc(X, Y, r + 1.6, 0, 6.2832); g.lineWidth = 1; g.strokeStyle = bg; g.stroke(); }
        if (k >= 5 || st.sel === i) { g.lineWidth = 3; g.strokeStyle = bg; g.strokeText(p.ref, X + r + 4, Y - r - 1); g.fillStyle = st.sel === i ? accent : ink; g.fillText(p.ref, X + r + 4, Y - r - 1); }
      });
      setLegend();
    }
    function redraw() { if (raf) return; raf = true; requestAnimationFrame(function () { raf = false; draw(); }); }

    // ---------- pointer and keys ----------
    function at(ev) { var b = canvas.getBoundingClientRect(); return { px: ev.clientX - b.left, py: ev.clientY - b.top, x: (ev.clientX - b.left - tf.ox) / tf.k, y: (ev.clientY - b.top - tf.oy) / tf.k }; }
    function hitSensor(q) { var best = -1, bd = 11; if (S) S.placed.forEach(function (p, i) { var d = Math.hypot(sx(p.x) - q.px, sy(p.y) - q.py); if (d < bd) { bd = d; best = i; } }); return best; }
    function hitHole(q) { var R = c.R(), bx = -1, by = -1; R.wig.cols.forEach(function (x, i) { if (Math.abs(x - q.x) <= 1.27) bx = i; }); R.wig.rows.forEach(function (y, i) { if (Math.abs(y - q.y) <= 1.27) by = i; }); return bx < 0 || by < 0 ? -1 : by * R.wig.cols.length + bx; }
    function landed(s) {                     // under the breadboard it rides the breadboard's board; off it, the bottom board (or the frame board it was on)
      var R = c.R(), inside = Mag.inWig(R, s.x, s.y);
      if (inside && s.on !== 'wig') s.on = 'wig';
      else if (!inside && s.on === 'wig') s.on = R.layers[0].id;
    }
    function moveTo(i, x, y, snap) {
      var s = own()[i], step = snap ? 1.27 : 0.1;
      s.x = +(Math.round(x / step) * step).toFixed(2); s.y = +(Math.round(y / step) * step).toFixed(2); landed(s);
    }
    function showTip(ev, text) { if (!text) { tip.style.display = 'none'; return; } var vr = view.getBoundingClientRect(); tip.textContent = text; tip.style.display = 'block'; tip.style.left = Math.min(vr.width - 250, ev.clientX - vr.left + 14) + 'px'; tip.style.top = (ev.clientY - vr.top + 14) + 'px'; }
    function describe(p) { return p.ref + ': ' + Mag.KINDS[p.kind].name + ' on ' + p.board + ', ' + (p.side === 'bottom' ? 'underside' : 'top face') + ', x ' + p.x + ', y ' + p.y + (p.off ? '. Not on that board here.' : '') + (p.under ? '. Under: ' + p.under + '.' : ''); }
    function bind() {
      canvas.addEventListener('pointerdown', function (ev) {
        if (ev.button !== 0 || !S) return;
        stopImprove(); canvas.focus();
        var q = at(ev), i = hitSensor(q);
        if (i >= 0) { var s = own()[i]; st.sel = i; drag = { i: i, dx: s.x - q.x, dy: s.y - q.y, moved: false }; try { canvas.setPointerCapture(ev.pointerId); } catch (e) { /* synthetic */ } canvas.classList.add('grabbing'); }
        else st.sel = null;
        tip.style.display = 'none'; c.panels(); draw();
      });
      canvas.addEventListener('pointermove', function (ev) {
        if (!S || !tf) return;
        var q = at(ev);
        if (drag) { moveTo(drag.i, q.x + drag.dx, q.y + drag.dy, ev.shiftKey); drag.moved = true; compute(true); redraw(); c.checksOnly(); return; }
        var i = hitSensor(q); canvas.classList.toggle('grab', i >= 0);
        if (i >= 0) { showTip(ev, describe(S.placed[i]) + ' Drag to move.'); return; }
        var h = hitHole(q);
        if (h < 0) { showTip(ev, null); return; }
        var e = S.ev.err[h], nx = S.ev.nx;
        showTip(ev, 'column ' + (h % nx + 1) + ', hole row ' + (Math.floor(h / nx) + 1) + ' of ' + S.ev.ny + ': ' + (isFinite(e) ? e.toFixed(2) + ' mm' : 'no fix') + (S.shift && isFinite(S.ev.shift[h]) ? '; a 10 µT ambient change moves it ' + S.ev.shift[h].toFixed(2) + ' mm' : '') + '; ' + S.ev.used[h] + ' of ' + S.n + ' sensors in range');
      });
      function end(ev) { if (!drag) return; var m = drag.moved; drag = null; canvas.classList.remove('grabbing'); try { canvas.releasePointerCapture(ev.pointerId); } catch (e) { /* not captured */ } if (m) c.rebuild(true); }
      canvas.addEventListener('pointerup', end); canvas.addEventListener('pointercancel', end);
      canvas.addEventListener('pointerleave', function () { tip.style.display = 'none'; });
      canvas.addEventListener('dblclick', function (ev) {
        var q = at(ev); if (hitSensor(q) >= 0) return;
        var R = c.R(), s = { x: +q.x.toFixed(1), y: +q.y.toFixed(1), on: Mag.inWig(R, q.x, q.y) ? 'wig' : R.layers[0].id, side: 'bottom', kind: 'mmc' };
        var l = own(); l.push(s); st.sel = l.length - 1; c.rebuild(true);
      });
      if (window.ResizeObserver) new ResizeObserver(function () { if (c.ui.tab === 'mag') redraw(); }).observe(view);
    }
    function key(ev) {
      if (ev.key === 'Escape') { stopImprove(); if (st.sel != null) { st.sel = null; c.panels(); draw(); } return; }
      if (st.sel == null || !list()[st.sel]) return;
      if (ev.key === 'Delete' || ev.key === 'Backspace') { ev.preventDefault(); remove(st.sel); return; }
      var s = ev.shiftKey ? 2.54 : 0.5, d = { ArrowLeft: [-s, 0], ArrowRight: [s, 0], ArrowUp: [0, -s], ArrowDown: [0, s] }[ev.key];
      if (!d) return;
      ev.preventDefault(); var q = own()[st.sel]; q.x = +(q.x + d[0]).toFixed(2); q.y = +(q.y + d[1]).toFixed(2); landed(q); c.rebuild(true);
    }
    function remove(i) { own().splice(i, 1); st.sel = null; c.rebuild(true); }
    function load(a) { stopImprove(); var P = c.P(); P.mag = P.mag || {}; P.mag.list = clone(a.list); P.show.sensor_layout = 'custom'; st.sel = null; c.rebuild(true); }

    // ---------- improve: a few passes of magmodel's nudging, one pass per turn of the event loop so it can be watched and stopped ----------
    function stopImprove() { if (improving) { clearTimeout(improving.t); improving = null; c.rebuild(true); } }
    function improve() {
      if (improving) { stopImprove(); return; }
      own(); st.sel = null;
      var steps = [6, 6, 3, 3, 1.5, 1.5, 0.75], n = 0, P = c.P(), R = c.R(), sc = Mag.score(R, P.mag.list, P), first = sc;
      improving = { t: null, note: 'starting' };
      function pass() {
        if (!improving) return;
        var r = Mag.improvePass(c.R(), c.P().mag.list, c.P(), steps[n], sc);
        c.P().mag.list = r.list; c.R().wig.sensors.list = r.list; sc = r.score; n++;
        if (!r.moved && n < steps.length && steps[n] === steps[n - 1]) n++;
        improving.note = 'pass ' + n + ' of ' + steps.length + ': score ' + first.toFixed(3) + ' → ' + sc.toFixed(3);
        compute(true); draw(); c.panels();
        if (n >= steps.length) { improving = null; c.rebuild(true); return; }
        improving.t = setTimeout(pass, 30);
      }
      c.panels(); improving.t = setTimeout(pass, 30);
    }

    // ---------- the Design panel on this tab ----------
    function same(a, b) { if (a.length !== b.length) return false; for (var i = 0; i < a.length; i++) if (Math.abs(a[i].x - b[i].x) > 0.005 || Math.abs(a[i].y - b[i].y) > 0.005 || a[i].on !== b[i].on || (a[i].side || 'top') !== (b[i].side || 'top') || (a[i].kind || 'mmc') !== (b[i].kind || 'mmc')) return false; return true; }
    function controls(sect) {
      var P = c.P(), R = c.R(), g = mag(), l = list(), b;
      b = sect('Arrangement');
      var arr = Mag.arrangements(R, c.ref), pl = el('div', { class: 'partlist' });
      arr.forEach(function (a) { pl.appendChild(el('button', { type: 'button', 'aria-pressed': String(same(a.list, l)), text: a.label, onclick: function () { load(a); } })); });
      b.appendChild(pl);
      b.appendChild(el('div', { class: 'hint', text: 'Each one replaces the sensors on the map; Undo brings yours back. Then drag them.' }));
      b.appendChild(el('div', { class: 'row' }, [el('span', {}, [el('button', { type: 'button', class: improving ? 'on' : null, text: improving ? 'Stop' : 'Improve', title: 'nudge every sensor toward a lower error, each kept on its own board and off the parts', onclick: improve }), ' ',
        el('button', { type: 'button', text: st.ref ? 'Hold this one instead' : 'Hold for comparison', title: 'keep this layout\'s numbers beside the next one\'s', onclick: function () { st.ref = { n: S.n, on_bb: S.on_bb, median: S.stats.median, p90: S.stats.p90, worst: S.stats.worst, ok: S.stats.ok, shift: S.shift ? S.shift.median : null }; c.saveView(); c.panels(); } })]),
        st.ref ? el('button', { type: 'button', class: 'quiet', text: 'let go', onclick: function () { st.ref = null; c.saveView(); c.panels(); } }) : null]));
      if (improving) b.appendChild(el('div', { class: 'hint', role: 'status', text: 'Improving, ' + improving.note + '. It moves each sensor a little at a time and keeps a move only if the error over the holes drops (their rms, plus a quarter of the worst).' }));

      b = sect('Sensors');
      var nb = 0; if (S) S.placed.forEach(function (p) { if (p.bb) nb++; });
      b.appendChild(el('div', { class: 'hint', text: l.length + ' in all: ' + nb + ' under the breadboard, ' + (l.length - nb) + ' on the frame.' + (P.show.sensor_layout !== 'custom' ? ' This is a fixed layout from an older file; it becomes a list of its own at the first change.' : '') }));
      var sl = el('div', { class: 'vlist' });
      (S ? S.placed : []).forEach(function (p, i) { sl.appendChild(el('button', { type: 'button', 'aria-pressed': String(st.sel === i), text: p.ref, title: describe(p), style: p.off || p.under ? 'color: var(--problem)' : null, onclick: function () { st.sel = st.sel === i ? null : i; c.panels(); draw(); } })); });
      b.appendChild(sl);
      var s = st.sel != null ? l[st.sel] : null, p = s && S ? S.placed[st.sel] : null;
      if (s && p) {
        var boards = [['wig', R.removable ? 'Wig PCB' : 'Under the breadboard']].concat(R.layers.map(function (L) { return [L.id, L.id + ' ' + L.name]; }));
        b.appendChild(c.row('x', c.num(s.x, 0.5, function (v) { own()[st.sel].x = v; landed(own()[st.sel]); }, { id: 'm-x' }), 'mm', 'm-x'));
        b.appendChild(c.row('y', c.num(s.y, 0.5, function (v) { own()[st.sel].y = v; landed(own()[st.sel]); }, { id: 'm-y' }), 'mm', 'm-y'));
        b.appendChild(c.row('Board', c.sel(boards, s.on, function (v) { own()[st.sel].on = v; }, 'm-on'), '', 'm-on'));
        b.appendChild(c.row('Face', c.seg([['top', 'Top'], ['bottom', 'Underside']], s.side === 'bottom' ? 'bottom' : 'top', function (v) { own()[st.sel].side = v; })));
        b.appendChild(c.row('Part', c.seg([['mmc', 'MMC5603'], ['tmag', 'TMAG5273']], s.kind === 'tmag' ? 'tmag' : 'mmc', function (v) { own()[st.sel].kind = v; })));
        var dk = S.docked && S.docked[st.sel];
        b.appendChild(el('div', { class: 'hint' + (p.off || p.under ? ' bad' : ''), text: (p.off ? 'It is not on that board here. ' : '') + (p.under ? 'It is under the ' + p.under + '. ' : '') + 'Sensing point at z ' + p.z + ' mm.' + (dk ? ' Reads ' + (dk.B >= 1 ? dk.B.toFixed(1) : dk.B.toFixed(3)) + ' mT while the probe is docked' + (dk.sat ? ', past its range.' : '.') : '') }));
        b.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'Arrow keys nudge 0.5 mm, with Shift 2.54.' }), el('button', { type: 'button', text: 'Remove', onclick: function () { remove(st.sel); } })]));
      }
      b.appendChild(el('div', { class: 'row' }, [el('span', { class: 'hint', text: 'Double-click the map to add one there.' }), el('button', { type: 'button', text: 'Add one', onclick: function () {
        var q = S && S.worst_hole ? { x: R.wig.cols[S.worst_hole.col - 1], y: R.wig.rows[S.worst_hole.row - 1] } : { x: R.wig.w / 2, y: R.wig.h / 2 }, ls = own();
        while (ls.some(function (o) { return Math.abs(o.x - q.x) < 2 && Math.abs(o.y - q.y) < 2; })) q.x = +(q.x - 3).toFixed(2);
        ls.push({ x: q.x, y: q.y, on: Mag.inWig(R, q.x, q.y) ? 'wig' : R.layers[0].id, side: 'bottom', kind: 'mmc' }); st.sel = ls.length - 1; c.rebuild(true);
      } })]));

      b = sect('Probe');
      var pm = P.probe.magnet, opts = Mag.MAGNETS.map(function (m) { return [m.id, m.label + (m.strength ? ', ' + m.strength : m.id === 'probe' ? ', ' + pm.dia + ' x ' + pm.len + ' mm' : '')]; });
      b.appendChild(c.row('Magnet', c.sel(opts, g.magnet.use || 'bench', function (v) { g.magnet.use = v; if (v === 'other' && !g.magnet.strength) g.magnet.strength = 1900; }, 'm-mag'), '', 'm-mag'));
      if (g.magnet.use === 'probe') {
        b.appendChild(c.row('Diameter', c.num(pm.dia, 0.5, function (v) { pm.dia = v; }, { min: 0.5, max: 12, id: 'm-md' }), 'mm', 'm-md'));
        b.appendChild(c.row('Length', c.num(pm.len, 0.5, function (v) { pm.len = v; }, { min: 0.5, max: 20, id: 'm-ml' }), 'mm', 'm-ml'));
      }
      if (g.magnet.use === 'other') b.appendChild(c.row('Strength', c.num(g.magnet.strength || 1900, 100, function (v) { g.magnet.strength = v; }, { min: 10, max: 100000, id: 'm-ms' }), 'mT·mm³', 'm-ms'));
      b.appendChild(el('div', { class: 'hint', text: Math.round(Mag.strengthOf(P)) + ' mT·mm³ (the moment as Testolomew counts it). The cylinder drawn in the dock is taken as N52; the bench tracker was solid from about 3000 up.' }));
      b.appendChild(c.row('Above the surface', el('span', {}, [c.num(g.height != null ? g.height : 2, 0.5, function (v) { g.height = v; }, { min: 0.5, max: 100, id: 'm-h' }), ' ', c.seg([[2, '2'], [20, '20'], [40, '40']], g.height, function (v) { g.height = v; })]), 'mm', 'm-h'));
      b.appendChild(el('div', { class: 'hint', text: 'The magnet\'s centre above the breadboard\'s top: about 2 with the point on a hole.' }));
      b.appendChild(c.row('Lean', c.num(g.lean != null ? g.lean : 25, 5, function (v) { g.lean = v; }, { min: 0, max: 70, id: 'm-lean' }), 'deg', 'm-lean'));

      b = sect('Readings');
      b.appendChild(c.row('Noise a reading', c.num(g.noise_uT != null ? g.noise_uT : 0.4, 0.05, function (v) { g.noise_uT = v; }, { min: 0, max: 100, id: 'm-n' }), 'µT', 'm-n'));
      b.appendChild(c.row('Zero known to', c.num(g.zero_uT != null ? g.zero_uT : 1, 0.5, function (v) { g.zero_uT = v; }, { min: 0, max: 100, id: 'm-z' }), 'µT', 'm-z'));
      b.appendChild(c.row('Gain error', c.num(g.gain_pct != null ? g.gain_pct : 1, 0.5, function (v) { g.gain_pct = v; }, { min: 0, max: 20, id: 'm-g' }), '%', 'm-g'));
      b.appendChild(el('div', { class: 'hint', text: '0.4, 1 and 1 are the MMC5603 on the 2026-11-01 bench. Set the zero to 5 for a desk that changed since it was taken.' }));
      b.appendChild(c.row('Ambient field', c.seg([['zeroed', 'Zeroed out'], ['fitted', 'Fitted']], g.ambient === 'fitted' ? 'fitted' : 'zeroed', function (v) { g.ambient = v; })));
      b.appendChild(c.check('m-hold', 'The fit holds the magnet\'s strength', g.hold_strength !== false, function (v) { g.hold_strength = v; }));

      b = sect('Map');
      b.appendChild(c.row('Colour by', c.seg([['error', 'Error'], ['shift', 'Ambient shift'], ['used', 'In range']], mode(), function (v) { g.map = v; })));
      b.appendChild(el('div', { class: 'hint', text: mode() === 'shift' ? (S && S.st.uniform ? 'With the ambient field fitted a uniform change moves nothing: this map is empty of colour by design.' : 'How far the fix moves when the ambient field changes by 10 µT and the zero is not taken again (the board turned on the desk).') : mode() === 'used' ? 'How many sensors are past full scale with the probe at that hole, and so left out of the fit.' : 'The 1-sigma error of the fix across the board, per frame, as the firmware\'s fit would at best do.' }));
      var pc = el('input', { type: 'checkbox', id: 'm-parts', onchange: function (e) { st.parts = e.target.checked; c.saveView(); draw(); } }); pc.checked = st.parts !== false;
      b.appendChild(el('div', { class: 'row' }, [el('label', { for: 'm-parts', text: 'Show the parts and the dock' }), pc]));
    }

    // ---------- the Checks panel on this tab ----------
    function cmpKey() { var P = c.P(), g = clone(P.mag || {}); delete g.list; delete g.map; return JSON.stringify([g, P.wig, P.stack, P.frame.outline, P.grid, P.probe, P.parts]); }
    function compare() {                     // every arrangement under the same settings; worked out a moment later so the page stays quick
      var keyNow = cmpKey();
      if (cmp.key === keyNow && cmp.rows) return cmp.rows;
      if (!cmp.timer) {
        var arr = Mag.arrangements(c.R(), c.ref), rows = [], k2 = keyNow;
        var step = function () {
          cmp.timer = null;
          if (cmpKey() !== k2 || drag || improving) { cmp.timer = setTimeout(function () { cmp.timer = null; if (c.ui.tab === 'mag') c.checksOnly(); }, 250); return; }      // the settings moved on, or the page is busy: start over later
          var a = arr[rows.length], s = Mag.summary(c.R(), a.list, c.P());
          rows.push({ a: a, n: s.n, on_bb: s.on_bb, stats: s.stats });
          if (rows.length < arr.length) { cmp.timer = setTimeout(step, 0); return; }
          cmp.rows = rows; cmp.key = k2; if (c.ui.tab === 'mag') c.checksOnly();
        };
        cmp.timer = setTimeout(step, 80);
      }
      return cmp.rows && cmp.key ? cmp.rows.map(function (r) { return { a: r.a, n: r.n, on_bb: r.on_bb, stats: r.stats, old: true }; }) : null;
    }
    function delta(now, ref, lowerIsBetter) {
      if (ref == null || !isFinite(now) || !isFinite(ref) || Math.abs(now - ref) < 0.005) return null;
      var better = lowerIsBetter ? now < ref : now > ref;
      return el('span', { class: 'delta ' + (better ? 'down' : 'up'), text: (now > ref ? '+' : '−') + Math.abs(now - ref).toFixed(lowerIsBetter ? 2 : 0) });
    }
    function checks(box, hl) {
      if (!S) return;
      var s = S.stats, R = c.R(), P = c.P(), l = list(), ref = st.ref, all = s.ok === s.count;
      hl.appendChild(c.pill('info', S.on_bb + ' under + ' + S.on_frame + ' on the frame')); hl.appendChild(document.createTextNode(' '));
      hl.appendChild(c.pill(all ? 'ok' : s.ok >= 0.95 * s.count ? 'warn' : 'bad', s.ok + ' of ' + s.count + ' holes'));

      box.appendChild(el('h2', { text: 'This layout' }));
      box.appendChild(c.line(all ? 'ok' : s.ok >= 0.95 * s.count ? 'warn' : 'bad', s.ok + ' / ' + s.count, 'Holes placed within half a pitch (1.27 mm)', s.nofix ? 'No fix at ' + s.nofix + ' of them: too few sensors in range, or the fit is not determined.' : null));
      var t = el('table', {}, [el('tr', {}, [el('th', { text: 'Error of the fix' }), el('th', { class: 'n', text: 'mm' }), ref ? el('th', { class: 'n', text: 'held' }) : null])]);
      [['Median', s.median, ref && ref.median], ['90th percentile', s.p90, ref && ref.p90], ['Worst hole', s.worst, ref && ref.worst]].forEach(function (r) {
        t.appendChild(el('tr', {}, [el('td', { text: r[0] }), el('td', { class: 'n' }, [el('span', { class: 'mono', text: mm(r[1]) }), ref ? delta(r[1], r[2], true) : null]), ref ? el('td', { class: 'n', text: mm(r[2]) }) : null]));
      });
      box.appendChild(t);
      if (S.worst_hole) box.appendChild(el('div', { class: 'hint', text: 'Worst at column ' + S.worst_hole.col + ', hole row ' + S.worst_hole.row + ' of ' + S.ev.ny + ' (outlined on the map). Magnet ' + Math.round(S.st.strength) + ' mT·mm³, ' + S.st.height + ' mm above the surface.' + (ref ? ' Held: ' + ref.n + ' sensors, ' + ref.on_bb + ' under the breadboard, ' + ref.ok + ' holes within half a pitch.' : '') }));
      if (S.shift) box.appendChild(c.line(S.shift.worst < 1.27 ? 'ok' : S.shift.median < 1.27 ? 'warn' : 'bad', mm(S.shift.median) + ' mm', 'A 10 µT ambient change moves the fix', 'Median; ' + mm(S.shift.worst) + ' mm at the worst hole. That is the board turned on the desk with the zero not taken again. Fitted, it moves nothing and the error above grows a little.'));
      else box.appendChild(c.line('info', 'fitted', 'The ambient field is solved with the magnet', 'A uniform change moves nothing; the error above pays for the three extra unknowns.'));
      var off = S.placed.filter(function (p) { return p.off; }), under = S.placed.filter(function (p) { return p.under; }), dk = (S.docked || []).filter(function (d) { return d.sat; });
      if (off.length) box.appendChild(c.line('bad', String(off.length), 'Not on their board', off.map(function (p) { return p.ref + ' (' + p.board + ')'; }).join(', ') + '. Wig set to ' + (R.removable ? 'Removable: the main board stops at the breadboard, and the wig\'s card edge is cut out of it.' : 'Integrated.')));
      if (under.length) box.appendChild(c.line('warn', String(under.length), 'Under a part on the same face', under.map(function (p) { return p.ref + ': ' + p.under; }).join('; ') + '.'));
      if (dk.length) box.appendChild(c.line('warn', String(dk.length), 'Past full scale while the probe is docked', dk.map(function (d) { return d.ref + ' ' + (d.B >= 10 ? d.B.toFixed(0) : d.B.toFixed(1)) + ' mT'; }).join(', ') + '. They read again once it is lifted; the MMC5603 needs its SET pulse after a field that large.'));
      if (!off.length && !under.length) box.appendChild(c.line('ok', 'clear', 'Every sensor is on its board and clear of the parts'));

      box.appendChild(el('h2', { text: 'Arrangements compared' }));
      var rows = compare(), ct = el('table', { class: 'cmp' }, [el('tr', {}, [el('th', { text: 'With this probe' }), el('th', { class: 'n', text: 'median' }), el('th', { class: 'n', text: '90 %' }), el('th', { class: 'n', text: 'worst' }), el('th', { class: 'n', text: 'holes' })])]);
      if (!rows) ct.appendChild(el('tr', {}, [el('td', { colspan: 5, class: 'hint', text: 'working it out…' })]));
      else rows.forEach(function (r) {
        if (r.old) ct.style.opacity = '0.55';             // the last answer, shown until the new one is ready
        ct.appendChild(el('tr', { class: same(r.a.list, l) ? 'cur' : null }, [el('td', {}, [el('button', { type: 'button', class: 'quiet', text: r.a.label, title: 'put this one on the map', onclick: function () { load(r.a); } })]),
          el('td', { class: 'n', text: mm(r.stats.median) }), el('td', { class: 'n', text: mm(r.stats.p90) }), el('td', { class: 'n', text: mm(r.stats.worst) }), el('td', { class: 'n', text: String(r.stats.ok) })]));
      });
      box.appendChild(ct);
      box.appendChild(el('div', { class: 'hint', text: 'Each as it is first loaded, with the probe and readings set on the left. Click one to put it on the map.' }));

      box.appendChild(el('h2', { text: 'What the numbers are' }));
      box.appendChild(el('div', { class: 'hint', text: 'The error bound of a dipole fit to the sensors\' readings, in the plane of the board, 1 sigma, for one frame: rms over the probe upright and leaning ' + S.st.lean + '° four ways' + (S.quick ? ' (two ways while dragging)' : '') + '. Each reading is given its noise, the doubt in its zero and its gain error; a sensor past 95 % of full scale is left out.' }));
      box.appendChild(el('div', { class: 'hint', text: 'It is a floor. Testolomew\'s own fit, run on these arrangements, comes out 1.3 to 1.5 times it at the median hole and two to three times at the worst with the bench magnet, and about twice it everywhere with the 2 x 1 mm one. Fields from the frame\'s own parts and from the circuit on the breadboard are not in it, and nothing here has run on a board.' }));
    }

    function enter() { compute(false); legendFor = null; draw(); }
    function refresh() { if (!drag) compute(false); draw(); }
    bind();
    return { enter: enter, refresh: refresh, draw: draw, controls: controls, checks: checks, key: key, stop: stopImprove, get summary() { return S; }, load: load, improve: improve };
  }
  window.V6MagTab = { create: create };
})();
