#!/usr/bin/env node
// Jumperless V6 outline tool - the left-to-right flip and the humps (rev A12).
//   node tools/flipcheck.mjs      exits 1 if any case below is wrong
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const here = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const Geo = require(here + '/src/geometry.js'), U = Geo.util, O = Geo.ops;
const base = JSON.parse(fs.readFileSync(here + '/v6_outline.json', 'utf8'));
const ref = JSON.parse(fs.readFileSync(here + '/ref/wig_ref.json', 'utf8'));
const W = base.wig.width, H = base.wig.height;
let bad = 0;
const ok = (name, cond, extra) => { if (!cond) bad++; console.log((cond ? 'ok   ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); };
const clone = (o) => JSON.parse(JSON.stringify(o));
const near = (a, b, t) => Math.abs(a - b) <= (t == null ? 1e-3 : t);
const mirror = (pts) => pts.map((q) => [W - q[0], q[1]]);
const reg = (shape) => shape.reduce((a, e) => U.diff(U.union(a, U.region([e.outer])), U.region(e.holes)), []);
const xor = (a, b) => U.area(U.diff(a, b)) + U.area(U.diff(b, a));
const mreg = (shape) => reg(shape.map((e) => ({ outer: mirror(e.outer), holes: e.holes.map(mirror) })));
// Two plans are the same when what they do not share is hairlines only. The WigLEDmag's own outline is 0.002 mm2 off its mirror
// image and rounded offsets are cut into slightly different chords from the other end, so a mirrored board differs from the
// flipped one by slivers a few um wide: none of them may be a real piece (0.03 mm2), nor all of them together much (0.25 mm2).
const slivers = (a, b) => { const ps = U.expolys(U.diff(a, b)).concat(U.expolys(U.diff(b, a))).map((e) => U.area(U.region([e.outer]))); return { all: ps.reduce((x, y) => x + y, 0), big: Math.max(0, ...ps) }; };
const alike = (a, b) => { const d = slivers(a, b); return d.all < 0.25 && d.big < 0.03; };
const all = { corners: 'flip', parts: {}, humps: {} };

for (const mode of ['integrated', 'removable']) {
  const P0 = clone(base); P0.wig.mode = mode;
  const allFlip = (P) => { const o = clone(all); P.parts.forEach((u) => { o.parts[u.id] = 'flip'; }); return o; };
  // 1. everything flipped: the resolved design is the mirror image of the original, board by board
  const P1 = clone(P0); O.flip(P1, allFlip(P1));
  const R0 = Geo.resolve(P0, ref), R1 = Geo.resolve(P1, ref);
  ok(mode + ': the strip is on the right and the pitch is the same', P1.frame.side === 'right' && R1.planes.xl === 0 && near(R1.planes.xr, W + 5.08) && R1.checks.grid.pitch === R0.checks.grid.pitch && R1.checks.grid.on_grid);
  R0.layers.forEach((L, i) => { const d = slivers(mreg(L.shape), reg(R1.layers[i].shape)); ok(mode + ': ' + L.id + ' is the mirror image of the original', alike(mreg(L.shape), reg(R1.layers[i].shape)) && R1.layers[i].islands === L.islands, 'hairlines only: ' + d.all.toFixed(3) + ' mm2 in all, the largest ' + d.big.toFixed(4) + '; ' + R1.layers[i].area + ' against ' + L.area + ' mm2'); });
  const E0 = R0.extender, E1 = R1.extender;
  ok(mode + ': the extender is on the left, the mirror image of the one on the right', E1 && E1.side === 'left' && E1.x1 === 0 && near(E1.x0, -E0.w) && alike(mreg(E0.shapes.board), reg(E1.shapes.board)) && alike(mreg(E0.shapes.shell), reg(E1.shapes.shell)),
    E1 ? 'x ' + E1.x0 + ' to ' + E1.x1 + ', board differs by ' + xor(mreg(E0.shapes.board), reg(E1.shapes.board)).toFixed(3) : '');
  const x0 = R0.checks.extender, x1 = R1.checks.extender;
  ok(mode + ': it meets its socket as before (faces it, same engagement, no overlap, on the grid, same key)', x1.port && x1.port.faces && x1.port.engage === x0.port.engage && x1.overlap.overlap_mm2 === 0 && x1.on_grid && x1.pair_w === x0.pair_w && x1.keyed === x0.keyed && x1.header.covered === x0.header.covered,
    JSON.stringify({ faces: x1.port && x1.port.faces, engage: x1.port && x1.port.engage, overlap: x1.overlap.overlap_mm2, pair: x1.pair_w, keyed: [x0.keyed, x1.keyed] }));
  const hb0 = R0.extender.parts[0].bodies, hb1 = R1.extender.parts[0].bodies;
  ok(mode + ': its header lies in the mirror image of its place', hb0.every((b, i) => xor(U.region([mirror(b.pts)]), U.region([hb1[i].pts])) < 0.01));
  ok(mode + ': the probe is in the strip, with the same walls the other way round', R1.probe && near(R1.probe.x, W + 2.54) && R1.checks.probe.wall_left === R0.checks.probe.wall_right && R1.checks.probe.wall_right === R0.checks.probe.wall_left,
    JSON.stringify([R0.checks.probe.wall_left, R0.checks.probe.wall_right, R1.checks.probe.wall_left, R1.checks.probe.wall_right]));
  ok(mode + ': the joint with the breadboard\'s chamfer is at the bottom-right corner', R1.checks.joints.length === 1 && near(R1.checks.joints[0].at[0], W - R0.checks.joints[0].at[0], 0.01) && near(R1.checks.joints[0].at[1], R0.checks.joints[0].at[1], 0.01), JSON.stringify(R1.checks.joints));
  ok(mode + ': the same clashes, room and overall size', R1.checks.clashes.length === R0.checks.clashes.length && R1.checks.area.placeable === R0.checks.area.placeable && R1.checks.grid.overall.widest === R0.checks.grid.overall.widest && R1.checks.grid.overall.square === R0.checks.grid.overall.square,
    R0.checks.clashes.length + ' / ' + R1.checks.clashes.length + ' clashes, room ' + R0.checks.area.placeable + ' / ' + R1.checks.area.placeable);
  R0.parts.filter((p) => !p.system).forEach((p) => { const q = R1.parts.filter((x) => x.id === p.id)[0]; const d = xor(U.region(p.bodies.map((b) => mirror(b.pts))), U.region(q.bodies.map((b) => b.pts))); ok(mode + ': ' + p.id + ' lies in the mirror image of its place', d < 0.05, 'differs by ' + d.toFixed(3) + ' mm2, now at ' + q.x + ', ' + q.y + ' turned ' + q.rot); });
  // 2. flipped twice with the same choices: the design itself comes back
  const P2 = clone(P1); O.flip(P2, allFlip(P2));
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  ok(mode + ': flipped twice, the outline is the original', P2.frame.side === 'left' && same(P2.frame.outline.map((v) => [v.x, v.y, v.c, v.r]), P0.frame.outline.map((v) => [v.x, v.y, v.c, v.r])) && same(P2.frame.outline.map((v) => v.n), P0.frame.outline.map((v) => v.n)));
  ok(mode + ': and so are the parts, the probe and the magnetometers', same(P2.parts.map((u) => [u.id, u.x, u.y, u.rot]), P0.parts.map((u) => [u.id, u.x, u.y, u.rot])) && P2.probe.dock.x === P0.probe.dock.x && same(P2.mag.list, P0.mag.list),
    JSON.stringify(P2.parts.map((u) => [u.id, u.x, u.y, u.rot])));
}

// 2b. What rev A11d and A11e put on the extender's side goes with it: the deeper waist the extender's first column bows into,
//     and the press-in joint (an upright socket on the mid board, a knob-shaped cutout in the bottom board at the edge).
for (const mode of ['integrated', 'removable']) {
  const flipAll = (P) => { const o = clone(all); P.parts.forEach((u) => { o.parts[u.id] = 'flip'; }); O.flip(P, o); return P; };
  const P0 = clone(base); P0.wig.mode = mode;
  const R0 = Geo.resolve(P0, ref), R1 = Geo.resolve(flipAll(clone(P0)), ref);
  ok(mode + ': the breadboard itself is mirrored where the extender needs it (its deeper waist is on the left)', alike(U.region([mirror(R0.wig.outline)]), U.region([R1.wig.outline])) && (!R0.wig.waist || !R0.wig.waist.deepened || xor(U.region([R0.wig.outline]), U.region([R1.wig.outline])) > 1),
    R0.wig.waist ? 'waist ' + R0.wig.waist.depth + ' against the traced ' + R0.wig.waist.own + '; outline against its mirror image ' + xor(U.region([R0.wig.outline]), U.region([R1.wig.outline])).toFixed(2) + ' mm2' : 'no waist setting in this design');
  const s0 = R0.checks.extender.seam_col, s1 = R1.checks.extender.seam_col;
  if (s0) ok(mode + ': the column on the seam fits as before (same wall, clip clearance and lands)', s1 && s1.fits === s0.fits && s1.wall === s0.wall && s1.clip_clear === s0.clip_clear && s1.land === s0.land && near(s1.x, W - s0.x) && JSON.stringify(s1.face_land) === JSON.stringify(s0.face_land), JSON.stringify([s0.wall, s0.clip_clear, s0.land, s1.wall, s1.clip_clear, s1.land, s1.x]));
  // pressed in from the back
  const Pp = clone(P0); Pp.extender.join = 'press'; Pp.parts = Pp.parts.filter((u) => !/^skt_(ra|h)_/.test(u.type));
  Pp.parts.push({ id: 'vert', type: 'skt_v_127', x: +(W - 5.6).toFixed(2), y: -15.9, rot: 0, mount: { on: Pp.stack[1].id, side: 'top' }, dims: { n: 11, h: 2.1 }, open: { [Pp.stack[0].id]: true, [Pp.stack[Pp.stack.length - 1].id]: true } });
  const Rp0 = Geo.resolve(Pp, ref);
  if (Rp0.checks.extender && Rp0.checks.extender.port && Rp0.checks.extender.port.press) {
    const Rp1 = Geo.resolve(flipAll(clone(Pp)), ref), p0 = Rp0.checks.extender.port, p1 = Rp1.checks.extender.port;
    Rp0.layers.forEach((L, i) => { const d = slivers(mreg(L.shape), reg(Rp1.layers[i].shape)); ok(mode + ', pressed in: ' + L.id + ' is the mirror image of the original, cutout and openings included', alike(mreg(L.shape), reg(Rp1.layers[i].shape)) && Rp1.layers[i].islands === L.islands, 'hairlines ' + d.all.toFixed(3) + ' mm2, the largest ' + d.big.toFixed(4)); });
    ok(mode + ', pressed in: the extender with its tab, and its upright header, are the mirror image', alike(mreg(Rp0.extender.shapes.board), reg(Rp1.extender.shapes.board)) && Rp0.extender.parts[0].bodies.every((b, i) => xor(U.region([mirror(b.pts)]), U.region([Rp1.extender.parts[0].bodies[i].pts])) < 0.01));
    ok(mode + ', pressed in: the same joint in numbers, its knob on the left edge', p1.press && p1.engage === p0.engage && p1.room === p0.room && near(p1.press.knob[0], W - p0.press.knob[2]) && near(p1.press.knob[2], W - p0.press.knob[0]) && near(p1.mouth_x, 0) && Rp1.checks.extender.overlap.overlap_mm2 === Rp0.checks.extender.overlap.overlap_mm2 && (p1.press.mags || []).length === (p0.press.mags || []).length,
      JSON.stringify([p0.press.knob, p1.press.knob, p1.mouth_x]));
  } else ok(mode + ', pressed in: this design has no press-in joint to try', true, '(extender.join is not known to this revision)');
}

// 3. The choices the page starts with: the USB socket and the click wheel stay on their sides in their corners, the top corners
//    keep their shapes, everything else goes with the board.
{
  const P0 = clone(base), P1 = clone(base), rep = O.flip(P1, { corners: 'stay' });
  const tl = (P) => O.edges(P).top.list[0], tr = (P) => { const l = O.edges(P).top.list; return l[l.length - 1]; };
  const part = (P, id) => P.parts.filter((u) => u.id === id)[0];
  const off = (P, id, c) => [+(part(P, id).x - c.x).toFixed(3), +(part(P, id).y - c.y).toFixed(3)];
  ok('default choices: the USB socket keeps its place from the top-right corner, and its turn', JSON.stringify(off(P1, 'usbc', tr(P1))) === JSON.stringify(off(P0, 'usbc', tr(P0))) && part(P1, 'usbc').rot === 315, JSON.stringify(off(P1, 'usbc', tr(P1))) + ' at ' + part(P1, 'usbc').x + ', ' + part(P1, 'usbc').y);
  ok('default choices: the click wheel keeps its place from the top-left corner', JSON.stringify(off(P1, 'encoder', tl(P1))) === JSON.stringify(off(P0, 'encoder', tl(P0))) && part(P1, 'encoder').rot === 45, JSON.stringify(off(P1, 'encoder', tl(P1))) + ' at ' + part(P1, 'encoder').x + ', ' + part(P1, 'encoder').y);
  ok('default choices: each top corner keeps its own shape', JSON.stringify(tl(P1).c) === JSON.stringify(tl(P0).c) && JSON.stringify(tr(P1).c) === JSON.stringify(tr(P0).c), JSON.stringify([tl(P1).c, tr(P1).c]));
  ok('default choices: the port, the side socket and the display went with the board', near(part(P1, 'port').x, W - 56) && part(P1, 'side').rot === 0 && near(part(P1, 'side').x, 5.82) && part(P1, 'display').rot === 270, JSON.stringify(rep.parts));
  const R1 = Geo.resolve(P1, ref), x = R1.checks.extender;
  ok('default choices: strip right, extender left, plugged in, sharing no plan with the unit', R1.planes.side === 'right' && x.side === 'left' && x.port.faces && x.port.engage === 4 && x.overlap.overlap_mm2 === 0);
  ok('default choices: the USB socket is still on the outline\'s edge (its mouth overhangs the corner as before)', R1.checks.overhang.some((o) => o.id === 'usbc') === Geo.resolve(P0, ref).checks.overhang.some((o) => o.id === 'usbc'));
  const P2 = clone(P1); O.flip(P2, { corners: 'stay' });
  ok('default choices: flipped twice, the design is the original', JSON.stringify(P2.frame.outline.map((v) => [v.x, v.y, v.c, v.r])) === JSON.stringify(P0.frame.outline.map((v) => [v.x, v.y, v.c, v.r])) && JSON.stringify(P2.parts.map((u) => [u.x, u.y, u.rot])) === JSON.stringify(P0.parts.map((u) => [u.x, u.y, u.rot])) && P2.frame.side === 'left');
  // a part told to stay is not touched; one told to flip is
  const P3 = clone(base); O.flip(P3, { corners: 'stay', parts: { usbc: 'stay', encoder: 'flip' } });
  ok('a part set to stay is where it was; the click wheel set to flip is mirrored', part(P3, 'usbc').x === 72.9 && part(P3, 'usbc').y === -22.989 && near(part(P3, 'encoder').x, W + 2.47) && part(P3, 'encoder').rot === 315);
  const P4 = clone(base); part(P4, 'port').on_flip = 'stay'; O.flip(P4, { corners: 'stay' });
  ok('on_flip on the part itself is honoured', part(P4, 'port').x === 56);
  const P5 = clone(base); O.flip(P5, { corners: 'stay', mag: false });
  ok('magnetometers left where they are when asked', JSON.stringify(P5.mag.list) === JSON.stringify(base.mag.list) && JSON.stringify(P1.mag.list.map((q) => q.x)) === JSON.stringify(base.mag.list.map((q) => +(W - q.x).toFixed(4))));
}

// 4. The humps
{
  const hs = O.humps(base);
  ok('the default outline has three humps: the raised top right, the block at the top of the strip, the bump on the strip', hs.length === 3 && hs[0].side === 'top' && hs[0].end1 && near(hs[0].out, 1.7) && near(hs[0].a0, 44.2) && hs[1].side === 'left' && hs[1].end0 && near(hs[1].out, 3.22) && near(hs[1].a1, 1.583) && hs[2].side === 'left' && near(hs[2].out, 0.5) && near(hs[2].a0, 28) && near(hs[2].a1, 44.29), hs.map((h) => h.label).join(' / '));
  const whole = (P) => { const R = Geo.resolve(P, ref); return R.layers[0].islands === 1 && R.layers[R.layers.length - 1].islands === 1 && !R.checks.notes.some((t) => /scaled/.test(t)); };
  let P = clone(base), r = O.humpSet(P, 'top:0', { out: 3 });
  ok('higher: the raised stretch and its corner stand 3 mm up', r.ok && near(O.humps(P)[0].out, 3) && near(Math.min(...P.frame.outline.map((v) => v.y)), -27.129 - 3) && whole(P));
  P = clone(base); r = O.humpSet(P, 'top:0', { a0: 30 });
  ok('longer: its step moved to x 30, the corner not moved', r.ok && near(O.humps(P)[0].a0, 30) && near(O.humps(P)[0].flat0, 32.6) && O.humps(P)[0].end1 && whole(P), JSON.stringify(O.humps(P)[0]));
  P = clone(base); r = O.humpSet(P, 'left:1', { slide: -10 });
  ok('moved along: the strip\'s bump 10 mm up, same size', r.ok && near(O.humps(P)[2].a0, 18) && near(O.humps(P)[2].a1, 34.29) && near(O.humps(P)[2].out, 0.5) && whole(P));
  P = clone(base); r = O.humpSet(P, 'left:1', { slide: -40 });
  ok('moved onto another, so merged: the strip\'s bump slid up into the block is one hump with it, down to where the bump now ends', r.ok && r.merged === 1 && O.humps(P).filter((h) => h.side === 'left').length === 1 && O.humps(P)[1].end0 && near(O.humps(P)[1].out, 3.22) && near(O.humps(P)[1].a1, 4.29) && whole(P), O.humps(P).map((h) => h.label).join(' / '));
  P = clone(base); r = O.humpSet(P, 'left:1', { slide: 40 });
  ok('moved off the end of its edge: refused, and nothing changed', !r.ok && JSON.stringify(P.frame.outline) === JSON.stringify(base.frame.outline), r.why);
  P = clone(base); r = O.humpSet(P, 'left:1', { slide: 9 });
  ok('moved into the bottom corner\'s own shape: refused, and nothing changed', !r.ok && JSON.stringify(P.frame.outline) === JSON.stringify(base.frame.outline), r.why);
  // merging on the top edge: a new hump slid into the raised stretch
  {
    const profile = (P, side) => { const e = O.edges(P)[side]; return e.list.map((v) => [+e.a(v).toFixed(3), +e.out(v).toFixed(3)]); };
    const heightAt = (P, side, a) => { const pts = profile(P, side); for (let i = 0; i < pts.length - 1; i++) { const [a0, o0] = pts[i], [a1, o1] = pts[i + 1]; if (a >= a0 && a <= a1 && a1 > a0) return o0 + (o1 - o0) * (a - a0) / (a1 - a0); } return null; };
    P = clone(base); O.humpAdd(P, 'top');
    const nh = O.humps(P).filter((h) => h.side === 'top')[0];
    ok('a hump added on the top edge stands clear of the raised stretch: two humps there', O.humps(P).filter((h) => h.side === 'top').length === 2 && nh.a1 < 44.2, nh.label);
    const Pm = clone(P); r = O.humpSet(Pm, 'top:0', { slide: 44.2 - nh.a1 + 6 });
    const one = O.humps(Pm).filter((h) => h.side === 'top');
    ok('slid 6 mm into the raised stretch: one hump, 1.5 up where the new one stands alone and 1.7 up from there to the corner', r.ok && r.merged === 1 && one.length === 1 && one[0].end1 && near(one[0].a0, nh.a0 + 44.2 - nh.a1 + 6) && near(one[0].out, 1.7) && near(heightAt(Pm, 'top', one[0].a0 + 4), 1.5, 0.01) && near(heightAt(Pm, 'top', 60), 1.7, 0.01) && whole(Pm), one.map((h) => h.label).join(' / ') + '  ' + JSON.stringify(profile(Pm, 'top')));
    ok('the outline there has no vertex under the merged hump and one new rounded one where the flank crosses', profile(Pm, 'top').every((q) => q[1] > -0.001) && O.edges(Pm).top.list.filter((v) => v.r > 0).length >= 3 && Geo.resolve(Pm, ref).checks.notes.length === 0, JSON.stringify(O.edges(Pm).top.list.map((v) => [v.x, v.y, v.r || 0])));
    const Pe = clone(P); O.humpSet(Pe, 'top:0', { out: 1.7 }); r = O.humpSet(Pe, 'top:0', { slide: 44.2 - nh.a1 + 6 });
    ok('the same at the same height: one flat top, the step between them gone', r.ok && r.merged === 1 && O.humps(Pe).filter((h) => h.side === 'top').length === 1 && near(heightAt(Pe, 'top', 44.2), 1.7, 0.01) && near(heightAt(Pe, 'top', 40), 1.7, 0.01) && O.edges(Pe).top.list.length < O.edges(Pm).top.list.length && whole(Pe), JSON.stringify(profile(Pe, 'top')));
    const Pt = clone(P); r = O.humpSet(Pt, 'top:0', { a1: 50 });
    ok('made longer until it overlaps (its To field): merged too', r.ok && r.merged === 1 && O.humps(Pt).filter((h) => h.side === 'top').length === 1 && near(O.humps(Pt)[0].a0, nh.a0) && whole(Pt), O.humps(Pt).filter((h) => h.side === 'top').map((h) => h.label).join(' / '));
    const Pc = clone(P); r = O.humpSet(Pc, 'top:0', { slide: 3 }); const two = O.humps(Pc).filter((h) => h.side === 'top');
    ok('moved without reaching the other: still two humps, nothing else on the edge changed', r.ok && !r.merged && two.length === 2 && near(two[0].a0, nh.a0 + 3) && near(two[0].a1, nh.a1 + 3) && near(two[1].a0, 44.2));
    const Ph = clone(P); r = O.humpSet(Ph, 'top:0', { slide: 44.2 - nh.a1 }); const tch = O.humps(Ph).filter((h) => h.side === 'top');
    ok('moved until they just touch: they share the one vertex on the edge\'s line and are still two', r.ok && tch.length === 2 && near(tch[0].a1, 44.2) && whole(Ph), tch.map((h) => h.label).join(' / '));
    const Po = clone(P); r = O.humpOtherEnd(Po, 'top:1'); const oe = O.humps(Po).filter((h) => h.side === 'top');
    ok('To the other end onto a hump standing there: merged instead of refused', r.ok && oe.length >= 1 && oe[0].end0 && whole(Po), oe.map((h) => h.label).join(' / '));
  }
  P = clone(base); r = O.humpOtherEnd(P, 'top:0');
  const h1 = O.humps(P).filter((h) => h.side === 'top')[0];
  ok('to the other end: the raised stretch is at the top left, the same length, the corners\' shapes not swapped', r.ok && h1.end0 && !h1.end1 && near(h1.a1, -8.3 + 78.74 - 44.2) && near(h1.out, 1.7) && JSON.stringify(O.edges(P).top.list[0].c) === '[8.8,7.7]' && whole(P), h1.label);
  r = O.humpOtherEnd(P, 'top:0');
  ok('and back: the outline is the original', r.ok && JSON.stringify(P.frame.outline.map((v) => [v.x, v.y, v.c, v.r])) === JSON.stringify(base.frame.outline.map((v) => [v.x, v.y, v.c, v.r])));
  P = clone(base); r = O.humpOtherSide(P, 'left:0');
  const hr = O.humps(P).filter((h) => h.side === 'right')[0];
  ok('to the other side: the block is at the top of the right side, 3.22 out, its lower end pulled up above the breadboard\'s corner', r.ok && hr && hr.end0 && near(hr.out, 3.22) && hr.a1 < -2.3 && O.humps(P).filter((h) => h.side === 'left').length === 1 && whole(P), hr && hr.label);
  P = clone(base); r = O.humpRemove(P, 'top:0');
  ok('removed: the top edge is one line, two vertices fewer', r.ok && O.humps(P).length === 2 && P.frame.outline.length === base.frame.outline.length - 2 && new Set(O.edges(P).top.list.map((v) => v.y)).size === 1 && whole(P));
  P = clone(base); r = O.humpRemove(P, 'left:0');
  ok('removed: the block is gone and the strip\'s side runs straight to the top corner, which keeps its chamfer', r.ok && O.humps(P).length === 2 && near(Math.min(...P.frame.outline.map((v) => v.x)), -5.58) && JSON.stringify(O.edges(P).top.list[0].c) === '[8.8,7.7]' && whole(P));
  P = clone(base); O.humpRemove(P, 'top:0'); r = O.humpAdd(P, 'top');
  ok('added: a new hump in the middle of the top edge', r.ok && O.humps(P).filter((h) => h.side === 'top').length === 1 && !O.humps(P)[0].end0 && !O.humps(P)[0].end1 && whole(P), O.humps(P)[0].label);
  r = O.humpSet(P, 'top:0', { out: 0 });
  ok('a hump set to no height is taken out', r.ok && O.humps(P).filter((h) => h.side === 'top').length === 0);
  // humps that stay when the board is flipped
  P = clone(base); const rp = O.flip(P, { corners: 'stay', humps: { 'top:0': 'stay', 'left:0': 'stay' } });
  const ht = O.humps(P).filter((h) => h.side === 'top')[0], hl = O.humps(P).filter((h) => h.side === 'left')[0];
  ok('flipped with both humps staying: the raised stretch still starts at x 44.2 and runs to the top-right corner, the block is still on the left', !rp.notes.length && ht.end1 && near(ht.a0, 44.2) && near(ht.flat0, 46.8) && hl && hl.end0 && near(hl.out, 3.22) && P.frame.side === 'right' && rp.kept['top:0'] && rp.kept['left:0'] && whole(P), ht.label + ' / ' + (hl && hl.label) + ' ' + JSON.stringify(rp.notes));
  const Pb = clone(P); O.flip(Pb, { corners: 'stay', humps: { 'top:0': 'stay', 'left:0': 'stay' } });
  ok('and flipped back the same way: the top edge and the parts are the original (the block\'s lower end stays pulled up)', Pb.frame.side === 'left' && JSON.stringify(O.edges(Pb).top.list.map((v) => [v.x, v.y, v.c])) === JSON.stringify(O.edges(base).top.list.map((v) => [v.x, v.y, v.c])) && JSON.stringify(Pb.parts.map((u) => [u.x, u.y, u.rot])) === JSON.stringify(base.parts.map((u) => [u.x, u.y, u.rot])), O.humps(Pb).map((h) => h.label).join(' / '));
  // a design somebody has reshaped: a vertex added on the top edge, the block's edge dragged
  P = clone(base); P.frame.outline.splice(1, 0, { x: 20, y: -27.129 }); P.frame.outline[P.frame.outline.length - 1].y = -6;
  ok('humps are still found in a reshaped outline', O.humps(P).length === 3 && near(O.humps(P)[1].a1, 1.583) && O.humpSet(P, 'top:0', { a0: 50 }).ok && near(O.humps(P)[0].a0, 50));
  P.frame.outline.reverse();
  ok('and in one whose vertices run the other way round', O.humps(P).length === 3 && O.flip(P, {}).side === 'right' && O.humps(P).length === 3);
}
console.log(bad ? bad + ' case(s) wrong' : 'ALL OK'); process.exit(bad ? 1 : 0);
