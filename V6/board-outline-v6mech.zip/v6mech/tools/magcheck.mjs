#!/usr/bin/env node
// Jumperless V6 outline tool - the magnetometer model from the command line.
//   node tools/magcheck.mjs              the arrangements' numbers for v6_outline.json as it stands, both wig variants
//   node tools/magcheck.mjs --check      also fails (exit 1) if the model has drifted from the reference values below
// The reference values are from the Python study of 2026-11-24 (V6pile/maglayout/bound.py, the same model written
// independently): error bound in mm, magnet 2 mm above the breadboard's top, upright and leaning 25 degrees four ways.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const here = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const require = createRequire(import.meta.url);
const Geo = require('../src/geometry.js'), Mag = require('../src/magmodel.js');
const params = JSON.parse(fs.readFileSync(path.join(here, 'v6_outline.json'), 'utf8')), ref = JSON.parse(fs.readFileSync(path.join(here, 'ref/wig_ref.json'), 'utf8'));
const f = (v) => (isFinite(v) ? v.toFixed(2) : 'no fix').padStart(6);
const lin = (a, b, n) => Array.from({ length: n }, (_, i) => a + (b - a) * i / (n - 1));

for (const mode of ['integrated', 'removable']) {
  const P = JSON.parse(JSON.stringify(params)); P.wig.mode = mode;
  const R = Geo.resolve(P, ref), st = Mag.settings(P);
  console.log(`\n${mode}: magnet ${Math.round(st.strength)} mT*mm^3, ${st.height} mm above the surface, ambient ${st.uniform ? 'fitted' : 'zeroed'}`);
  console.log('  ' + 'arrangement'.padEnd(40) + 'median    90 %   worst  holes   10 uT shift: median, worst   flags');
  const rows = [{ label: 'the design as it stands', list: R.wig.sensors.list }].concat(Mag.arrangements(R, ref));
  for (const a of rows) {
    const s = Mag.summary(R, a.list, P), bad = s.placed.filter((p) => p.off || p.under).map((p) => p.ref + (p.off ? ' off its board' : ' under ' + p.under));
    console.log('  ' + a.label.padEnd(38) + f(s.stats.median) + '  ' + f(s.stats.p90) + '  ' + f(s.stats.worst) + '  ' + String(s.stats.ok).padStart(5) + '   ' + (s.shift ? f(s.shift.median) + ' ' + f(s.shift.worst) : '   fitted   ') + '              ' + (bad.join(', ') || 'none'));
  }
}

if (process.argv.includes('--check')) {
  // [layout, strength, median, p90, worst] as bound.py gave them
  const P = JSON.parse(JSON.stringify(params)); P.wig.mode = 'removable';
  const R = Geo.resolve(P, ref), L0 = R.layers[0].id;
  const two = lin(1, 77.5, 12).map((x) => ({ x, y: -3, on: L0, side: 'bottom' })).concat(lin(5, 51, 6).map((y) => ({ x: -2.54, y, on: L0, side: 'bottom' })));
  const cases = [['18 under', Mag.gridList(R, 3, 6), 1900, 0.07, 0.10, 0.16], ['18 under', Mag.gridList(R, 3, 6), 363, 0.12, 0.22, 0.38], ['18 on two sides', two, 1900, 0.20, 0.94, 2.99], ['18 on two sides', two, 4200, 0.13, 0.44, 1.37]];
  let ok = true;
  console.log('\nagainst the Python study (the two-sided layout is placed as it was there, whether or not the board reaches):');
  for (const [name, list, strength, med, p90, worst] of cases) {
    P.mag = { magnet: { use: 'other', strength }, height: 2, lean: 25, noise_uT: 0.4, zero_uT: 1, gain_pct: 1, ambient: 'zeroed', hold_strength: true };
    const s = Mag.summary(R, list, P).stats, near = (a, b) => Math.abs(a - b) <= Math.max(0.011, 0.03 * b), good = near(s.median, med) && near(s.p90, p90) && near(s.worst, worst);
    ok = ok && good;
    console.log(`  ${good ? 'ok ' : '!! '} ${name}, ${strength}: ${s.median.toFixed(2)} / ${s.p90.toFixed(2)} / ${s.worst.toFixed(2)}  (reference ${med} / ${p90} / ${worst})`);
  }
  if (!ok) { console.error('CHECK FAILED: the model no longer matches the reference'); process.exit(1); }
}
