#!/usr/bin/env python3
# Dev step: plan silhouette of a STEP model per height band (connected pieces with bbox, area and how full the bbox is).
# This is where the input parts' bodies in src/catalog.js come from.   pip install cadquery shapely ; python3 tools/silhouette.py [models dir]
import sys, json
import cadquery as cq
from shapely.geometry import Polygon
from shapely.ops import unary_union
def clip(pts, zc, above):
    out = []
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        ina = (a[2] >= zc) if above else (a[2] <= zc); inb = (b[2] >= zc) if above else (b[2] <= zc)
        if ina: out.append(a)
        if ina != inb and abs(b[2] - a[2]) > 1e-12:
            t = (zc - a[2]) / (b[2] - a[2]); out.append((a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]), zc))
    return out
def run(path, fmap, bands):
    s = cq.importers.importStep(path); sh = s.val() if s.size() == 1 else cq.Compound.makeCompound(s.vals())
    verts, tris = sh.tessellate(0.03)
    V = [fmap(v.x, v.y, v.z) for v in verts]
    for (z0, z1) in bands:
        polys = []
        for t in tris:
            pts = [V[i] for i in t]
            if max(p[2] for p in pts) < z0 + 0.02 or min(p[2] for p in pts) > z1 - 0.02: continue
            pts = clip(pts, z0 + 0.02, True)
            if len(pts) >= 3: pts = clip(pts, z1 - 0.02, False)
            if len(pts) >= 3:
                pg = Polygon([(p[0], p[1]) for p in pts])
                if pg.is_valid and pg.area > 1e-7: polys.append(pg)
                else:
                    # edge-on triangles (vertical walls) still mark the outline: give them a hair of width
                    from shapely.geometry import LineString
                    polys.append(LineString([(p[0], p[1]) for p in pts]).buffer(0.005))
        u = unary_union(polys).buffer(0.02).buffer(-0.02)
        geoms = list(u.geoms) if hasattr(u, 'geoms') else [u]
        print('  band %.2f..%.2f' % (z0, z1))
        for g in sorted(geoms, key=lambda g: -g.area):
            if g.area < 0.05: continue
            h = Polygon(g.exterior)                     # filled outline
            b = h.bounds; box = (b[2] - b[0]) * (b[3] - b[1])
            import math
            r = max(b[2] - b[0], b[3] - b[1]) / 2; circ = math.pi * r * r
            print('    piece x %.2f..%.2f  y %.2f..%.2f  (%.2f x %.2f)  area %.1f  = %.0f%% of its box, %.0f%% of a circle dia %.2f centre (%.2f, %.2f)' % (b[0], b[2], b[1], b[3], b[2] - b[0], b[3] - b[1], h.area, 100 * h.area / box, 100 * h.area / circ, 2 * r, (b[0] + b[2]) / 2, (b[1] + b[3]) / 2))
D = sys.argv[1].rstrip("/") + "/" if len(sys.argv) > 1 else "models/"
print('SIQ-02FVS3 (frame as modelled: x, y plan-up, z up)'); run(D + 'SIQ-02FVS3-1.step', lambda x, y, z: (x, y, z), [(0, 2.0), (2.0, 4.0)])
print('K1-1210UN-01 (SparkFun): up = model y + 1.0, plan = (x, -z)'); run(D + 'Navigation_SMD_9.9x9.9mm.step', lambda x, y, z: (x, -z, y + 1.0), [(0, 1.0), (1.0, 1.45), (1.45, 1.7)])
print('TL3342 (KiCad)'); run(D + 'SW_SPST_TL3342.step', lambda x, y, z: (x, y, z), [(0, 0.25), (0.25, 1.0), (1.0, 1.25), (1.25, 1.54)])
print('Joy-Con stick (Adafruit 5628): origin moved to the stick axis, z = 0 the underside of the can'); run(D + '5628_Mini_Joycon_Thumbstick.step', lambda x, y, z: (x - 9.15, y - 7.0, z), [(0, 1.0), (1.25, 2.5), (2.5, 5.25), (5.25, 10.0), (10.0, 13.68)])
