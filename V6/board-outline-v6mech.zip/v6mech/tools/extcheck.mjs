#!/usr/bin/env node
// Jumperless V6 outline tool - the header socket in the unit's right side and the extender that plugs into it (rev A11 to A11d).
//   node tools/extcheck.mjs      exits 1 if any case below is wrong
// What it holds the model to: the general expansion port is on the top edge and the side socket is a part of its own; the
// extender's holes are on the unit's 0.1 inch grid whatever its columns and dead rows; its header meets the socket pin for
// pin; it shares no plan area with the unit and changes nothing in the unit's own numbers; a socket moved in, out or round is
// reported for what it is; nothing ties the seam unless a design asks; no hole position is skipped at the seam, its first
// column standing in the edge that bows into the breadboard's waist (rev A11d), with the wall, the clip and the solder tab
// each given room; its outer edge is the unit's own side profile, or the mirror image of its seam edge (rev A12e); and a
// design saved by an older page is brought up without losing what was put in it.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const here = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const Geo = require(here + '/src/geometry.js'), Exp = require(here + '/src/exporters.js'), S = require(here + '/src/state.js'), Cat = require(here + '/src/catalog.js');
const defaults = JSON.parse(fs.readFileSync(here + '/v6_outline.json', 'utf8')), ref = JSON.parse(fs.readFileSync(here + '/ref/wig_ref.json', 'utf8'));
let bad = 0; const ok = (name, cond, extra) => { if (!cond) bad++; console.log((cond ? 'ok   ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); };
const make = (edit, mode) => { const p = JSON.parse(JSON.stringify(defaults)); p.wig.mode = mode || 'integrated'; if (edit) edit(p); return p; };
const run = (edit, mode) => Geo.resolve(make(edit, mode), ref);
const side = (p) => p.parts.find((q) => q.type === 'skt_ra_127');      // the socket in the right side
const port = (p) => p.parts.find((q) => q.id === 'port');              // the general expansion port, on the top edge
const sorted = (parts) => JSON.stringify(parts.slice().sort((a, b) => (a.id < b.id ? -1 : 1)));
const near = (a, b, tol) => Math.abs(a - b) <= (tol || 1e-6);
const P = 2.54;

for (const mode of ['integrated', 'removable']) {
  const R = run(null, mode), x = R.checks.extender, E = R.extender, xr = R.planes.xr;
  ok(mode + ': two ports: the M.2 socket on the top edge, and a 1.27 mm socket in the right side as a part of its own', port(R.params).type === 'm2_socket' && side(R.params).id === 'side' && !!x && !!x.port && x.port.faces && x.port.id === 'side');
  ok(mode + ': the two sockets and the USB-C clear each other', R.checks.clashes.length === 0, R.checks.clashes.map((k) => k.a + ' x ' + k.b).join(', '));
  ok(mode + ': 11 columns, 22 rows, no dead row: first column 2.54 from column 30, on the unit\'s right grid plane', x.cols === 11 && x.rows === 22 && x.dead === 0 && near(E.cols[0] - R.wig.cols[R.wig.cols.length - 1], P, 1e-3) && near(E.cols[0], xr) && near(x.col_gap, P), 'x ' + x.x0 + ' .. ' + x.x1);
  const sc = x.seam_col, edgeAt = (shape, y) => Math.min(...shape[0].outer.filter((q) => Math.abs(q[1] - y) < 3).map((q) => q[0]));
  ok(mode + ': the waist is 1.02 deep (the WigLEDmag\'s 0.635 made deeper), which leaves the breadboard a 0.5 wall beside column 30', R.wig.waist.deepened && near(R.wig.waist.depth, 1.02) && near(R.wig.waist.own, 0.635, 0.002) && !!sc && near(sc.wall, 0.5, 0.002) && near(sc.need, 1.02, 0.002), JSON.stringify(R.wig.waist));
  ok(mode + ': that column fits: the 1.86 clip clears the wall, its solder tab has board under it, and the breadboard\'s shell has the cut', sc.fits && sc.clip_clear > 0.05 && sc.land > 0.2 && near(Math.min(...R.parts.find((q) => q.id === 'shell').bodies[0].pts.filter((q) => q[0] > 77 && q[1] > 11 && q[1] < 44.5).map((q) => q[0])), xr - 1.02, 0.01), 'clip clear ' + sc.clip_clear + ', land ' + sc.land);
  ok(mode + ': the two top boards meet on the half-pitch line, so the countersinks either side of the seam keep the same land', near(R.wig.waist.face, 1.32, 0.001) && near(Math.min(...R.parts.find((q) => q.id === 'face').bodies[0].pts.filter((q) => q[0] > 77 && q[1] > 11 && q[1] < 44.5).map((q) => q[0])), xr - 1.32, 0.01) && sc.face_land.ext > 0.15 && near(sc.face_land.ext, sc.face_land.unit, 0.01), JSON.stringify(sc.face_land));
  ok(mode + ': the rails start one hole in; every other row has a hole in every column', x.rail_skip === 1 && E.holes.filter((h) => near(h[0], xr, 1e-3)).length === R.wig.rows.length - 4 && [0, 1, R.wig.rows.length - 2, R.wig.rows.length - 1].every((i) => !E.holes.some((h) => near(h[0], xr, 1e-3) && near(h[1], R.wig.rows[i], 0.05)) && E.holes.some((h) => near(h[0], xr + P, 1e-3) && near(h[1], R.wig.rows[i], 0.05))));
  ok(mode + ': every countersink of its top board is inside that board, 0.15 or more from its edge', (() => { const o = E.shapes.face[0].outer; const inside = (x0, y0) => { let c = false; for (let i = 0, j = o.length - 1; i < o.length; j = i++) { if ((o[i][1] > y0) !== (o[j][1] > y0) && x0 < (o[j][0] - o[i][0]) * (y0 - o[i][1]) / (o[j][1] - o[i][1]) + o[i][0]) c = !c; } return c; }; return E.holes.every((h) => inside(h[0] - h[2] / 2 - 0.15, h[1]) && inside(h[0] + h[2] / 2 + 0.15, h[1]) && inside(h[0], h[1] - h[2] / 2 - 0.15) && inside(h[0], h[1] + h[2] / 2 + 0.15)); })());
  ok(mode + ': every column of it is on the unit\'s 0.1 inch grid, and so is its far edge', E.cols.every((c) => near(c / P, Math.round(c / P), 1e-6)) && near(E.x1 / P, Math.round(E.x1 / P), 1e-6) && x.on_grid, 'pair ' + x.pair_w + ' = ' + x.pair_rows + ' rows');
  ok(mode + ': its rows are the breadboard\'s own', JSON.stringify(E.rows) === JSON.stringify(R.wig.rows));
  ok(mode + ': socket mouth on the edge, header pin 1 level with socket pin 1, pins all the way in', near(x.port.mouth_x, xr) && x.port.inset === 0 && x.port.engage === 4 && near(x.header.y, side(R.params).y) && x.header.n === x.port.n, 'mouth x ' + x.port.mouth_x + ', pin 1 at y ' + x.header.y);
  const hp = E.parts[0], plastic = hp.bodies.find((b) => b.name === 'plastic'), pins = hp.bodies.find((b) => b.name === 'pins');
  ok(mode + ': the header\'s plastic stops on the extender\'s edge and its pins reach 4.0 into the unit', near(Math.min(...plastic.pts.map((q) => q[0])), xr) && near(Math.min(...pins.pts.map((q) => q[0])), xr - 4));
  ok(mode + ': the header is on the head, which is the one board with nothing over it', x.header.covered && E.z.cover === null && E.shapes.cover.length === 0 && x.cover === false, 'header top ' + hp.z1);
  const Rc = run((p) => { p.extender.cover = true; }, mode);
  ok(mode + ': a second board over the head, when asked for, is level with the top board and clear of the header', !!Rc.extender.z.cover && Rc.extender.z.cover[1] === Rc.z.top && Rc.extender.z.cover[0] >= hp.z1 && Rc.checks.extender.cover === true && Rc.checks.extender.overlap.overlap_mm2 === 0, 'from z ' + (Rc.extender.z.cover && Rc.extender.z.cover[0]));
  ok(mode + ': 22 rows take all 22 pins', x.need === 22 && x.spare === 0);
  ok(mode + ': it shares no plan area with the unit', x.overlap.overlap_mm2 === 0);
  ok(mode + ': the top board is whole over the side socket; the mid board is opened for it', R.layers[2].cutBy.indexOf('side') < 0 && R.layers[1].cutBy.indexOf('side') >= 0 && R.layers[0].cutBy.indexOf('side') < 0);
  ok(mode + ': nothing ties the seam: no staples, no rail jumpers; the play at the bottom corner is given', !x.tied && x.ties.n === 0 && x.jumpers === 0 && E.ties.list.length === 0 && E.jumpers.length === 0 && x.play.corner > 0.3 && x.play.corner < 0.6, '0.1 mm in the pair is ' + x.play.corner + ' at the corner');
  ok(mode + ': its edge bows into the waist (a key too), 0.2 clear of the breadboard\'s PCB', x.keyed > 20 && near(Math.min(...E.shapes.board[0].outer.map((q) => q[0])), xr - 1.02 + 0.2, 0.01), x.keyed + ' mm2');
  ok(mode + ': its top board has a hole for every row of every column but the four rail holes at the seam, and one beside each rail pair at both ends', E.holes.length === 11 * R.wig.rows.length - 4 + 4);
  // nothing of the extender is in the unit's own numbers
  const R0 = run((p) => { p.extender.on = false; }, mode);
  ok(mode + ': turned off, there is none, and the unit\'s boards and checks are the same either way', R0.extender === null && R0.checks.extender === null
    && JSON.stringify(R0.layers.map((L) => [L.area, L.pocketArea, L.islands, L.cutBy])) === JSON.stringify(R.layers.map((L) => [L.area, L.pocketArea, L.islands, L.cutBy]))
    && JSON.stringify(R0.checks.clashes) === JSON.stringify(R.checks.clashes) && JSON.stringify(R0.checks.neighbours) === JSON.stringify(R.checks.neighbours) && JSON.stringify(R0.checks.area) === JSON.stringify(R.checks.area));
  ok(mode + ': the extender\'s board comes out as a KiCad file and a DXF', /Extender board/.test(Exp.kicadExt(R)) && /gr_arc/.test(Exp.kicadExt(R)) && /POLYLINE/.test(Exp.dxfExt(R)) && Exp.kicadExt(R0) === '');
  JSON.stringify(Geo.plain(R));
}

// columns and dead rows
for (const d of [0, 1, 2, 3]) for (const n of [1, 5, 11, 20]) {
  const R = run((p) => { p.extender.cols = n; p.extender.dead_rows = d; }), x = R.checks.extender, E = R.extender;
  ok(n + ' columns, ' + d + ' dead: width ' + x.w + ', first column ' + x.col_gap + ' from column 30', near(x.w, (d + n) * P) && near(x.col_gap, (d + 1) * P) && x.on_grid && x.rows === 2 * n && x.spare === 22 - 2 * n && x.overlap.overlap_mm2 === 0 && E.shapes.board.length === 1 && E.shapes.shell.length === 1 && (d === 0) === !!x.seam_col && (d > 0 || x.seam_col.fits) && x.rail_skip === (d === 0 ? 1 : 0));
}

// the side socket where it should not be
let x = run((p) => { side(p).x -= 1; }).checks.extender;
ok('socket 1.0 inside the edge: reported, the pins go 3.0 in', near(x.port.inset, 1) && near(x.port.engage, 3) && x.port.open_seam === 0);
x = run((p) => { side(p).x += 0.5; }).checks.extender;
ok('socket 0.5 past the edge: the seam is open by that and the two overlap', near(x.port.open_seam, 0.5) && x.overlap.overlap_mm2 > 0, x.overlap.overlap_mm2 + ' mm2');
let R = run((p) => { side(p).rot = 90; });
ok('socket turned: it does not face the extender, and a note says so', R.checks.extender.port.faces === false && R.checks.notes.some((t) => /side socket/.test(t)));
R = run((p) => { side(p).mount = { on: 'L0', side: 'bottom' }; });
ok('socket under the main board: not facing either', R.checks.extender.port.faces === false);
R = run((p) => { p.parts = p.parts.filter((q) => q.type !== 'skt_ra_127'); });
ok('no side socket: the extender is drawn, with nothing to meet; the top port is not taken for one', !!R.extender && R.checks.extender.port === null && R.checks.extender.spare === null && port(R.params).type === 'm2_socket');
R = run((p) => { p.parts = p.parts.filter((q) => q.id !== 'port'); });
ok('no top port: the side socket and the extender do not need it', R.checks.extender.port.faces && R.checks.extender.overlap.overlap_mm2 === 0);
R = run((p) => { p.wig.waist_r = 0; });
ok('the waist setting left out: it just matches, as deep as the column on the seam needs', R.wig.waist.deepened === true && near(R.wig.waist.depth, 1.02, 0.001) && R.checks.extender.seam_col.fits);
R = run((p) => { p.extender.key = false; });
ok('no dead row with the edge left straight: no room for the column either', R.checks.extender.seam_col.fits === false && R.checks.extender.seam_col.bowed === false);
R = run((p) => { p.extender.rail_skip = 2; });
ok('rails starting two holes in: eight rail holes fewer than a full field', R.checks.extender.rail_skip === 2 && R.extender.holes.length === 11 * R.wig.rows.length - 8 + 4);
R = run((p) => { p.extender.dead_rows = 1; });
ok('one dead row, as rev A11 to A11c drew it: first column 5.08 from column 30, a hole in every row of every column, no column on the seam', near(R.checks.extender.col_gap, 2 * P) && R.checks.extender.seam_col === null && R.extender.holes.length === 11 * R.wig.rows.length + 4 && R.checks.extender.overlap.overlap_mm2 === 0);
const unitOf = (R1) => JSON.stringify([R1.layers.map((L) => [L.area, L.pocketArea, L.islands, L.cutBy]), R1.checks.clashes, R1.checks.area]);
ok('the deeper waist takes 0.385 x about 31 mm off the breadboard and nothing else of the unit changes with the extender\'s dead rows', unitOf(run((p) => { p.extender.dead_rows = 1; })) === unitOf(run(null)) && run(null).wig.waist.depth > run((p) => { p.wig.waist_r = 0; p.extender.on = false; }).wig.waist.depth);
R = run((p) => { p.extender.dead_rows = 1; p.extender.ties = 'staple'; p.extender.jumpers = true; });
ok('a design that asks for them still gets two staples at the holes beside the rails and four rail jumpers', R.checks.extender.tied && R.checks.extender.ties.n === 2 && near(R.checks.extender.ties.span, 2 * P) && R.checks.extender.ties.from_ref && near(R.checks.extender.ties.at[0][1], 8.636, 0.002) && near(R.checks.extender.ties.at[1][1], 46.736, 0.002) && R.checks.extender.jumpers === 4);
R = run((p) => { p.extender.key = false; p.extender.dead_rows = 1; });
ok('key off: a straight edge on the grid plane', R.checks.extender.keyed === 0 && near(Math.min(...R.extender.shapes.board[0].outer.map((q) => q[0])), R.planes.xr, 0.001) && R.checks.extender.overlap.overlap_mm2 === 0);
R = run((p) => { p.extender.head = 6; });
ok('a head too short for the header: said', R.checks.extender.header.covered === false);
R = run((p) => { p.wig.face.on = false; });
ok('no top board on the breadboard: none on the extender, and no holes list', R.extender.z.face === null && R.extender.holes.length === 0 && R.extender.shapes.face.length === 0);
R = run((p) => { p.stack = p.stack.slice(0, 1); p.parts = p.parts.filter((q) => q.id !== 'display'); p.extender.cover = true; });
ok('a one-board stack, the second board asked for: there is no top board to be level with, so none', R.extender.z.cover === null);

// the other sockets for the side (rev A11d): Kevin's horizontal surface-mount ones
const bySide = (p) => p.parts.find((q) => q.id === 'side');
R = run((p) => { const s = bySide(p); s.type = 'skt_h_clp127'; s.x = +(78.74 - 4.57).toFixed(2); });
ok('Samtec CLP-DH in the side: mouth on the edge, 3.43 high under the top board, a 2.5 mm pin inside the 2.31 to 2.67 it takes', R.checks.extender.port.kind === 'skt_h_clp127' && near(R.checks.extender.port.mouth_x, 78.74) && R.checks.extender.port.pin_ok && near(R.checks.extender.port.engage, 2.5) && near(R.checks.extender.port.room, 1.72, 0.01) && near(Math.min(...R.extender.parts[0].bodies.find((b) => b.name === 'pins').pts.map((q) => q[0])), 78.74 - 2.5) && R.layers[2].cutBy.indexOf('side') < 0 && R.checks.extender.overlap.overlap_mm2 === 0 && R.checks.clashes.length === 0, 'len ' + R.checks.extender.port.len);
R = run((p) => { const s = bySide(p); s.type = 'skt_h_clp127'; s.x = +(78.74 - 4.57 - 1).toFixed(2); });
ok('  ... 1.0 inside the edge its 2.5 mm pin goes 1.5 in, which is outside what it takes, and it says so', R.checks.extender.port.pin_ok === false && near(R.checks.extender.port.engage, 1.5));
R = run((p) => { const s = bySide(p); s.type = 'skt_h_254'; s.x = +(78.74 - 8.4).toFixed(2); s.dims = { n: 5 }; });
ok('the 2.54 mm horizontal socket in the side: 2 x 5 = 10 pins for 22 rows, 6.0 high so the top board is opened over it, a 2.54 mm header with 6.0 mm pins on the extender', R.checks.extender.port.kind === 'skt_h_254' && R.checks.extender.port.pins === 10 && R.checks.extender.spare === -12 && R.checks.extender.port.room < 0 && R.layers[2].cutBy.indexOf('side') >= 0 && R.extender.parts[0].type === 'hdr_ra_254' && near(R.checks.extender.port.pin, 6) && near(R.checks.extender.port.len, 12.62), 'room ' + R.checks.extender.port.room + ', clashes ' + R.checks.clashes.map((k) => k.a + ' x ' + k.b).join(', '));
R = run((p) => { const s = bySide(p); s.type = 'skt_h_254'; s.x = +(78.74 - 8.4 - 1.25).toFixed(2); s.dims = { n: 5 }; });
ok('  ... with its mouth 1.25 inside the edge for the leads it has at that end, a 6.0 mm pin goes 4.75 in, inside the 3.6 to 7.5 the Dubox drawing gives', near(R.checks.extender.port.inset, 1.25) && near(R.checks.extender.port.engage, 4.75) && R.checks.extender.port.pin_ok && near(R.checks.extender.port.room, -0.85, 0.01));
ok('the three sockets offered for the side each say what they are, what mates and what they cost', Object.keys(Cat.sideKinds).length === 3 && Object.keys(Cat.sideKinds).every((k) => { const K = Cat.sideKinds[k]; return !!Cat.parts[k] && !!Cat.parts[K.hdr] && K.depth > 0 && K.high > 0 && /\$/.test(K.price); }));

// the press-in joint (rev A11e): an upright socket on the mid board, cutouts through the top and the bottom board, a tab in a knob
const toPress = (p, h, st) => { p.extender.join = 'press'; p.parts = p.parts.filter((q) => q.id !== 'side'); p.parts.push({ id: 'vert', type: 'skt_v_127', x: 73.14, y: -15.9, rot: 0, mount: { on: 'L1', side: 'top' }, dims: { n: 11, h: h || 2.1 }, open: { L0: true, L2: true } }); if (st) { p.stack[2].t = st[0]; p.stack[0].t = st[1]; const g = +((6.75 - st[0] - 1.6) / 2).toFixed(3); p.stack[1].gap = g; p.stack[2].gap = g; } };
for (const mode of ['integrated', 'removable']) {
  R = run((p) => toPress(p), mode); const xp = R.checks.extender.port, pr = xp.press;
  ok(mode + ': pressed in from the back: the bottom board is cut for the socket and for the tab, the top board for the socket, the mid board for neither, and all stay in one piece each as before', R.layers[0].cutBy.indexOf('tab') >= 0 && R.layers[0].cutBy.indexOf('vert') >= 0 && R.layers[2].cutBy.indexOf('vert') >= 0 && R.layers[1].cutBy.indexOf('vert') < 0 && R.layers[0].islands === 1 && R.layers[2].islands === 1);
  ok(mode + ': the tab is wider than its neck by 0.8 a side and is cut 0.05 clear; the extender is one board with it and shares no plan area with the unit\'s boards otherwise', near(pr.under, 0.8) && near(pr.gap, 0.05) && pr.knob[3] - pr.knob[1] - pr.neck > 1.5 && R.extender.shapes.board.length === 1 && Math.min(...R.extender.shapes.board[0].outer.map((q) => q[0])) < 72 && R.checks.extender.overlap.overlap_mm2 === 0 && R.checks.clashes.length === 0, 'knob ' + pr.knob.join(' '));
  ok(mode + ': 22 pins for 22 rows; the socket stands on the mid board and stops below the top face; the pins reach its top, longer than the usual 3.0; M10 is in the cutout', xp.pins === 22 && R.checks.extender.spare === 0 && near(pr.socket_z[0], R.layers[1].z1) && xp.room > 0 && near(pr.pin_tip, R.layers[1].z1 + 2.1, 0.01) && pr.pin_len > 3 && pr.mags.indexOf('M10') >= 0 && R.extender.parts[0].type === 'hdr_v_127');
}
R = run((p) => toPress(p, 2.1, [0.8, 0.8]));
ok('top and bottom boards 0.8 thick: the mid board from 2.175 to 3.775, the 2.1 mm socket to 5.875 under a top board that starts at 5.95, the extender\'s board 0.8 thick too', near(R.layers[0].z0, -0.8) && near(R.layers[1].z0, 2.175) && near(R.layers[2].z0, 5.95) && near(R.checks.extender.port.press.socket_z[1], 5.875) && near(R.extender.z.board[0], -0.8) && R.checks.extender.seam_col.fits);
R = run((p) => toPress(p, 4.3));
ok('the 4.3 mm socket there stands above the top face, and it says so', R.checks.extender.port.room < 0);
R = run((p) => { p.extender.join = 'press'; });
ok('asked to press in with no upright socket placed: nothing is cut, and the side socket is still what it plugs into', R.layers[0].cutBy.indexOf('tab') < 0 && R.checks.extender.port.kind === 'skt_ra_127');
R = run((p) => { p.extender.outline = [{ x: 78.74, y: -18.5, r: 1 }, { x: 110, y: -18.5, r: 2 }, { x: 110, y: 20 }, { x: 106.68, y: 54.991, c: 'wig' }, { x: 78.74, y: 54.991, c: 'wig' }]; });
ok('an outline of its own (extender.outline): the board follows its vertices, keeps its breadboard part, and still clears the unit', R.extender.outline.own && R.extender.outline.verts.length === 5 && Math.max(...R.extender.shapes.board[0].outer.map((q) => q[0])) > 109.9 && R.extender.shapes.board.length === 1 && R.checks.extender.overlap.overlap_mm2 === 0);
ok('without one, its outline is the four vertices from its columns and head, and the page can take them over', run(null).extender.outline.own === false && run(null).extender.outline.src.length === 4);
ok('the catalogue\'s own joint is sideways', Cat.extender.join === 'side' && !!Cat.parts.skt_v_127 && !!Cat.vertKinds['2.1']);

// how long the side socket can be where it is: the USB-C stands above it (the finding of 2026-11-27)
const clashAt = (n) => run((p) => { side(p).dims = { n: n }; }).checks.clashes.filter((k) => k.a === 'side' || k.b === 'side').map((k) => (k.a === 'side' ? k.b : k.a) + ' ' + k.overlap_mm2);
ok('2 x 11 clears the USB-C; 2 x 14 does not', clashAt(11).length === 0 && clashAt(14).some((t) => /^usbc/.test(t)), '2 x 12: ' + (clashAt(12).join(', ') || 'clear') + '; 2 x 13: ' + (clashAt(13).join(', ') || 'clear') + '; 2 x 14: ' + clashAt(14).join(', '));

// designs saved by the pages before
const M2 = { id: 'port', type: 'm2_socket', x: 56.0, y: -19.329, rot: 0, mount: { on: 'L0', side: 'top' } };
const SKT = { id: 'port', type: 'skt_ra_127', x: 72.92, y: -3.2, rot: 180, mount: { on: 'L0', side: 'top' }, dims: { n: 11 } };
const base = (rev, portPart, ext, edit) => { const p = JSON.parse(JSON.stringify(defaults)); p.meta.rev = rev; p.parts = p.parts.filter((q) => q.id !== 'port' && q.id !== 'side'); if (portPart) p.parts.push(JSON.parse(JSON.stringify(portPart))); if (ext) p.extender = JSON.parse(JSON.stringify(ext)); else delete p.extender; if (edit) edit(p); return p; };
const a10d = (edit) => base('A10d 2026-11-27', M2, null, edit);
const a11b = (edit) => base('A11b 2026-11-27', SKT, { on: true, cols: 11, dead_rows: 1, head: 18.5, cover: false, key: true, ties: 'staple', wire: 1.0, jumpers: true }, edit);
let m = S.migrate(a10d(), defaults);
ok('an A10d design (the M.2 socket on the top edge, no extender): it keeps its port, is given the side socket and the extender, and says so', port(m.params).type === 'm2_socket' && side(m.params).id === 'side' && m.params.extender.on === true && m.changes.length === 1);
ok('  ... and it is then the built-in design', sorted(m.params.parts) === sorted(defaults.parts) && JSON.stringify(m.params.extender) === JSON.stringify(defaults.extender));
m = S.migrate(a10d((p) => { port(p).x = 50; }), defaults);
ok('an M.2 socket that was moved stays where it was put, and the side socket is added', port(m.params).x === 50 && !!side(m.params));
m = S.migrate(a10d((p) => { port(p).type = 'minipcie'; }), defaults);
ok('another kind of port stays', port(m.params).type === 'minipcie' && !!side(m.params));
m = S.migrate(a10d((p) => { p.parts = p.parts.filter((q) => q.id !== 'port'); }), defaults);
ok('a design with no port keeps none on the top edge', !port(m.params) && !!side(m.params));
m = S.migrate(a11b(), defaults);
ok('an A11b design (the side socket in the port\'s place, staples, jumpers): the socket becomes "side", the M.2 socket is back on the top edge, the staples and jumpers go', side(m.params).id === 'side' && port(m.params).type === 'm2_socket' && m.params.extender.ties === 'none' && m.params.extender.jumpers === false && m.params.extender.dead_rows === 0 && m.params.wig.waist_r === defaults.wig.waist_r && m.changes.length === 3, m.changes.join(' | '));
ok('  ... and it is then the built-in design', sorted(m.params.parts) === sorted(defaults.parts) && Geo.resolve(m.params, ref).extender.ties.list.length === 0 && Geo.resolve(m.params, ref).checks.clashes.length === 0);
m = S.migrate(a11b((p) => { port(p).x = 71.92; port(p).dims.n = 9; p.extender.cols = 7; }), defaults);
ok('  ... a side socket that was moved or resized keeps its place and size, and the extender its columns', near(side(m.params).x, 71.92) && side(m.params).dims.n === 9 && m.params.extender.cols === 7);
m = S.migrate(a11b((p) => { p.meta.rev = 'A11 2026-11-27'; p.extender.cover = true; }), defaults);
ok('an A11 design: the same, and the board over the head that A11 drew is off', side(m.params).id === 'side' && port(m.params).type === 'm2_socket' && m.params.extender.cover === false && m.params.extender.ties === 'none');
m = S.migrate(a11b((p) => { p.extender.cover = true; }), defaults);
ok('an A11b design with the second board turned on by hand keeps it', m.params.extender.cover === true);
m = S.migrate(base('A11b 2026-11-27', Object.assign({}, M2, { x: 50 }), { on: true, cols: 11, dead_rows: 1, head: 18.5, cover: false, key: true, ties: 'staple', wire: 1.0, jumpers: true }), defaults);
ok('an A11b design that had kept a moved M.2 socket (so had no side socket): it keeps it and is given the side socket', port(m.params).x === 50 && !!side(m.params) && side(m.params).id === 'side');
const a11c = (edit) => { const p = JSON.parse(JSON.stringify(defaults)); p.meta.rev = 'A11c 2026-11-28'; p.extender = { on: true, cols: 11, dead_rows: 1, head: 18.5, cover: false, key: true }; delete p.wig.waist_r; delete p.wig._waist_r; if (edit) edit(p); return p; };
m = S.migrate(a11c(), defaults);
ok('an A11c design (one dead row, the waist as traced): no dead row, the waist deep enough for the column, and it says so; it is then the built-in design', m.params.extender.dead_rows === 0 && m.params.wig.waist_r === defaults.wig.waist_r && m.changes.length === 1 && Geo.resolve(m.params, ref).checks.extender.seam_col.fits && sorted(m.params.parts) === sorted(defaults.parts), m.changes.join(' | '));
m = S.migrate(a11c((p) => { p.extender.dead_rows = 2; p.extender.cols = 7; }), defaults);
ok('  ... two dead rows that were chosen are kept, and so are its columns', m.params.extender.dead_rows === 2 && m.params.extender.cols === 7 && m.changes.length === 0);
m = S.migrate(make((p) => { p.extender.ties = 'staple'; }), defaults);
ok('a design of this revision is left alone, staples asked for by hand included', m.from_rev === null && m.changes.length === 0 && m.params.extender.ties === 'staple');
ok('the catalogue\'s own extender is off until a design turns it on, has no ties and no dead row', Cat.extender.on === false && Cat.extender.ties === 'none' && Cat.extender.jumpers === false && Cat.extender.dead_rows === 0 && run((p) => { delete p.extender; }).extender === null);
ok('the side socket is not offered as the expansion port on the top edge', !Object.keys(Cat.portTypes).some((k) => Cat.portTypes[k].parts.indexOf('skt_ra_127') >= 0) && Cat.side.type === 'skt_ra_127');

// rev A12e: the extender's outer edge. An innie has the unit's own side profile (so a second extender stands against the first
// as the first stands against the unit); an outie is the mirror image of the extender's seam edge, one row out.
{
  const U = Geo.util, xor = (a, b) => U.area(U.union(U.diff(a, b), U.diff(b, a)));
  const reg = (sh) => U.region(sh.map((e) => e.outer)), moved = (pts, dx) => pts.map((q) => [q[0] + dx, q[1]]), mirrored = (pts, c) => pts.map((q) => [c - q[0], q[1]]).reverse();
  const band = (x0, x1, y0, y1) => U.region([U.rectPts(x0, y0, x1, y1)]);
  const flipped = (p) => { const o = { corners: 'flip', parts: {}, humps: {} }; p.parts.forEach((u) => { o.parts[u.id] = 'flip'; }); Geo.ops.flip(p, o); return p; };
  for (const mode of ['integrated', 'removable']) {
    const R = run(null, mode), E = R.extender, x = R.checks.extender, o = x.outer, xr = R.planes.xr, dx = E.x1 - xr, H = R.wig.h;
    const shellU = R.parts.find((q) => q.id === 'shell').bodies[0].pts, faceU = R.parts.find((q) => q.id === 'face').bodies[0].pts;
    const st = band(E.x1 - 3, E.x1 + 2, -1, H + 1), stB = band(E.x1 - 3, E.x1 + 2, 4, H + 1), stF = band(E.x1 - 3, E.x1 + 2, 8, 46);
    ok(mode + ': the outer edge is an innie unless a design says otherwise: 1.02 in, a 0.5 wall beside the last column, the columns and the width as they were', o && o.kind === 'in' && near(o.depth, 1.02, 0.001) && near(o.wall, 0.5, 0.001) && o.fits && x.cols === 11 && near(x.w, 11 * P) && near(o.col_x, E.x1 - P, 1e-6), JSON.stringify(o));
    ok(mode + ': its shell there is the unit\'s own shell edge, corners and waist', xor(U.inter(U.region([moved(shellU, dx)]), st), U.inter(reg(E.shapes.shell), st)) < 0.02);
    ok(mode + ': its board there is the breadboard\'s own board edge, and its top board is cut to the half-pitch line as the unit\'s is', xor(U.inter(U.region([moved(R.wig.outline, dx)]), stB), U.inter(reg(E.shapes.board), stB)) < 0.05 && xor(U.inter(U.region([moved(faceU, dx)]), stF), U.inter(reg(E.shapes.face), stF)) < 0.03 && near(o.face_land, x.seam_col.face_land.unit, 0.002));
    ok(mode + ': a second extender stands against the first as the first does against the unit: no overlap in the shell, the board or the top board, its edge in the waist', ['shell', 'board', 'face'].every((k) => { const a = reg(E.shapes[k]), b = U.region(E.shapes[k].map((e) => moved(e.outer, E.x1 - E.x0))); return U.area(U.inter(a, b)) < 0.001 && U.area(U.inter(b, band(E.x1 - 3, E.x1, 6, 48))) > 20; }));
    const R2 = run((p) => { p.extender.outer = 'out'; }, mode), E2 = R2.extender, x2 = R2.checks.extender, o2 = x2.outer, c = E2.x0 + E2.x1, bm = band(E2.x0 - 2, E2.x1 + 2, 6, 48);
    ok(mode + ': an outie: the same 11 columns, the last on the outer grid plane, the body one row narrower, the pair still on the grid', o2.kind === 'out' && x2.cols === 11 && E2.cols.length === 11 && near(E2.cols[10], E2.x1, 1e-6) && near(o2.col_x, E2.x1, 1e-6) && near(x2.w, 10 * P) && x2.on_grid && near(x2.pair_w, x.pair_w - P, 1e-3) && x2.overlap.overlap_mm2 === 0 && x2.seam_col.fits, JSON.stringify(o2));
    ok(mode + ': its outer edge is the mirror image of its seam edge, in the shell, the board and the top board', ['shell', 'board', 'face'].every((k) => xor(U.inter(reg(E2.shapes[k]), bm), U.inter(U.region(E2.shapes[k].map((e) => mirrored(e.outer, c))), bm)) < 0.02) && near(o2.bow, 1.02 - R2.params.wig.fit_gap, 0.002) && near(o2.land, x2.seam_col.land, 0.002) && near(o2.face_land, x2.seam_col.face_land.ext, 0.002) && o2.fits);
    ok(mode + ': the rails stop one hole short of that edge too, and the hole beside each rail pair moves in with them', E2.holes.length === 11 * R2.wig.rows.length - 8 + 4 && E2.holes.filter((h) => near(h[0], E2.x1, 1e-3)).length === R2.wig.rows.length - 4 && E2.holes.filter((h) => near(h[0], E2.x1 - P, 1e-3)).length === R2.wig.rows.length + 2);
    ok(mode + ': every countersink of the outie\'s top board is inside that board', (() => { const ob = reg(E2.shapes.face); return E2.holes.every((h) => U.area(U.diff(U.region([U.rectPts(h[0] - h[2] / 2 + 0.2, h[1] - 0.2, h[0] + h[2] / 2 - 0.2, h[1] + 0.2)]), ob)) < 1e-4); })());
    for (const kind of ['in', 'out']) {
      const A = run((p) => { p.extender.outer = kind; }, mode), B = Geo.resolve(flipped(make((p) => { p.extender.outer = kind; }, mode)), ref), EA = A.extender, EB = B.extender, W0 = A.planes.xr;
      ok(mode + ': flipped, an ' + (kind === 'in' ? 'innie' : 'outie') + ' is the mirror image of itself', EB.side === 'left' && near(B.checks.extender.outer.x, W0 - A.checks.extender.outer.x, 1e-6) && near(B.checks.extender.outer.col_x, W0 - A.checks.extender.outer.col_x, 1e-6)
        && ['shell', 'board', 'face'].every((k) => xor(U.region(EA.shapes[k].map((e) => mirrored(e.outer, W0))), reg(EB.shapes[k])) < 0.25) && EA.holes.length === EB.holes.length);
    }
  }
  let Ro = run((p) => { p.extender.outer = 'out'; p.extender.cols = 1; });
  ok('one column cannot be an outie: its edge goes in, and the page says so', Ro.checks.extender.outer.kind === 'in' && Ro.checks.extender.outer.asked === 'out' && near(Ro.checks.extender.w, P) && Ro.checks.notes.some((t) => /two columns or more/.test(t)));
  Ro = run((p) => { p.extender.outer = 'out'; p.extender.cols = 2; });
  ok('two columns as an outie: one row wide between the planes, a column on each', near(Ro.checks.extender.w, P) && near(Ro.extender.cols[0], Ro.extender.x0, 1e-6) && near(Ro.extender.cols[1], Ro.extender.x1, 1e-6) && Ro.checks.extender.outer.fits);
  const base0 = run(null), src0 = base0.extender.outline.src;
  Ro = run((p) => { p.extender.outline = JSON.parse(JSON.stringify(src0)).map((v) => { if (Math.abs(v.x - base0.extender.x1) < 1e-6) v.x = base0.extender.x1 + 6; return v; }); });
  ok('an outline drawn out past an innie\'s edge keeps its board whole there; the shell still has the waist', Ro.checks.extender.outer.board_whole === true && Ro.checks.extender.outer.kind === 'in' && near(Ro.checks.extender.outer.depth, 1.02, 0.001) && Math.max(...Ro.extender.shapes.board[0].outer.map((q) => q[0])) > base0.extender.x1 + 5.9 && Ro.extender.shapes.board.length === 1);
  ok('the report says which the outer edge is', /its outer edge is an innie/.test(Exp.report(base0)) && /its outer edge is an outie/.test(Exp.report(run((p) => { p.extender.outer = 'out'; }))));
  ok('the catalogue\'s own extender has an innie', Cat.extender.outer === 'in');
}

console.log(bad ? bad + ' wrong' : 'ALL OK'); process.exit(bad ? 1 : 0);
