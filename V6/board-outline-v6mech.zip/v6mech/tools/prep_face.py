#!/usr/bin/env python3
"""Read Kevin's Wiiig face board (V6pile/Wig/Wiig/wiigtop.3mf, a Fusion export) and put its outline and hole pattern
into ref/wig_ref.json under "face", in the tool's frame (x right from the wig left edge, y DOWN from the wig body top edge).

    python3 -I tools/prep_face.py /path/to/wiigtop.3mf

The mesh is 78.74 x 58.42 x 0.71: 480 countersunk holes (2.032 at the top face, 1.2 at the bottom), four more of the
same at the ends of the row next to each rail pair, and 2 x 35 holes of 0.65 at 1.27 mm for the wig's card header.
It is lined up with the WigLEDmag by its header rows (y = -0.254 there), which also lands its 16 hole rows on the
WigLEDmag's and its bottom edge on the WigLEDmag's (54.99).
"""
import zipfile, re, sys, json, collections, os
src = sys.argv[1]
here = os.path.dirname(os.path.abspath(__file__))
refp = os.path.join(here, '..', 'ref', 'wig_ref.json')
z = zipfile.ZipFile(src)
s = [z.read(n).decode('utf8', 'replace') for n in z.namelist() if n.endswith('.model')][0]
V = [(float(a), float(b), float(c)) for a, b, c in re.findall(r'<vertex x="([-\d.eE+]+)" y="([-\d.eE+]+)" z="([-\d.eE+]+)"', s)]
T = [(int(a), int(b), int(c)) for a, b, c in re.findall(r'<triangle v1="(\d+)" v2="(\d+)" v3="(\d+)"', s)]
zs = sorted(set(round(v[2], 3) for v in V))

def loops_at(zt):
    key = lambda i: (round(V[i][0], 3), round(V[i][1], 3))
    edges = collections.Counter()
    for t in T:
        if all(abs(V[i][2] - zt) < 1e-3 for i in t):
            k = [key(i) for i in t]
            for a, b in ((k[0], k[1]), (k[1], k[2]), (k[2], k[0])):
                if a != b: edges[tuple(sorted((a, b)))] += 1
    adj = collections.defaultdict(list)
    for (a, b), n in edges.items():
        if n == 1: adj[a].append(b); adj[b].append(a)
    seen, out = set(), []
    for st in list(adj):
        if st in seen: continue
        loop, cur = [st], st; seen.add(st)
        while True:
            nx = [p for p in adj[cur] if p not in seen]
            if not nx: break
            cur = nx[0]; seen.add(cur); loop.append(cur)
        out.append(loop)
    return out

def box(L):
    xs = [p[0] for p in L]; ys = [p[1] for p in L]
    return (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, max(xs) - min(xs), max(ys) - min(ys)

top, bot = loops_at(zs[-1]), loops_at(zs[0])
outline = max(top, key=lambda L: box(L)[2] * box(L)[3])
ob = box(outline)
bot_b = [box(L) for L in bot]
def bottom_dia(cx, cy, w):          # the same hole's loop on the bottom face (nearest centre), else the top diameter
    best = min(bot_b, key=lambda b: abs(b[0] - cx) + abs(b[1] - cy))
    return round(best[2], 3) if abs(best[0] - cx) + abs(best[1] - cy) < 0.05 else round(w, 3)
ref = json.load(open(refp))
hdr = [f for f in ref['footprints'] if f['name'] == 'PinHeader_2x35_P1.27_wiig_card'][0]
small = sorted(set(round(box(L)[1], 3) for L in top if L is not outline and box(L)[2] < 1.0))
# mesh frame: centred, y up. tool frame: x from the left edge, y down, the header row nearer the holes on hdr.y
fx = lambda x: round(x + ob[2] / 2, 3)
fy = lambda y: round(hdr['y'] + (small[0] - y), 3)
holes = []
for L in top:
    if L is outline: continue
    cx, cy, w, h = box(L)
    holes.append([fx(cx), fy(cy), round(w, 3), bottom_dia(cx, cy, w)])
holes.sort(key=lambda q: (q[1], q[0]))
if len(holes) != 554: sys.exit('expected 554 holes in the face board, found %d' % len(holes))
# walk the outline clockwise on screen (y down), starting near the top-left
pts = [[fx(p[0]), fy(p[1])] for p in outline]
area = sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1] for i in range(len(pts)))
if area < 0: pts.reverse()
i0 = min(range(len(pts)), key=lambda i: pts[i][0] + pts[i][1]); pts = pts[i0:] + pts[:i0]
rows = sorted(set(q[1] for q in holes if q[2] > 1.5))
ref['face'] = dict(source='V6pile/Wig/Wiig/wiigtop.3mf (Fusion export, 2026-08-19)', w=round(ob[2], 3), h=round(ob[3], 3), t=round(zs[-1] - zs[0], 3),
                   csk_depth=round(zs[-1] - zs[1], 3), y0=round(min(p[1] for p in pts), 3), y1=round(max(p[1] for p in pts), 3), outline=pts, holes=holes)
json.dump(ref, open(refp, 'w'), separators=(',', ':'))
big = [q for q in holes if q[2] > 1.5]
print('face %.2f x %.2f x %.2f, y %.3f..%.3f, %d holes (%d countersunk %.3f->%.3f, %d of %.2f), outline %d points' % (ob[2], ob[3], zs[-1] - zs[0], ref['face']['y0'], ref['face']['y1'], len(holes), len(big), big[0][2], big[0][3], len(holes) - len(big), holes[0][2], len(pts)))
main = [r for r in rows if sum(1 for q in big if q[1] == r) == 30]
print('rows of 30:', main)
print('through diameters:', sorted(collections.Counter(q[3] for q in holes).items()))
print('wig rows   :', [round(r, 3) for r in ref['rows']])
print('worst row mismatch %.3f mm' % max(abs(a - b) for a, b in zip(main, ref['rows'])))
print('cols', sorted(set(q[0] for q in big))[:3], '...', 'wig cols', ref['cols'][:3])
