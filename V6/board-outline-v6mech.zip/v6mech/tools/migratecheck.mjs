#!/usr/bin/env node
// Jumperless V6 outline tool - what a saved design keeps and what it takes from a newer revision (rev A10c: the strip's end).
//   node tools/migratecheck.mjs      exits 1 if any case below is wrong
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const here = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const S = require(here + '/src/state.js');
const defaults = JSON.parse(fs.readFileSync(here + '/v6_outline.json', 'utf8'));
let bad = 0; const ok = (name, cond, extra) => { if (!cond) bad++; console.log((cond ? 'ok   ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); };
const old = (rev, edit) => { const p = JSON.parse(JSON.stringify(defaults)); p.meta.rev = rev; const v = p.frame.outline[6]; delete v.c; v.n = "strip ends level with the breadboard's bottom edge"; if (edit) edit(p); return p; };
const v7 = (p) => p.frame.outline[6];
ok('an untouched A10b design: its strip-end vertex takes the new joint', v7(S.migrate(old('A10b 2026-11-27'), defaults).params).c === 'meet');
ok('an untouched A9 design: the same', v7(S.migrate(old('A9 2026-11-25'), defaults).params).c === 'meet');
ok("Kevin's 08:38 design (vertex raised to 53.35, rounded chamfer) is left as it is", JSON.stringify(v7(S.migrate(old('A10b 2026-11-27', (p) => { const v = v7(p); v.y = 53.35; v.c = [2.2, 1.6]; v.r = 1; }), defaults).params).c) === '[2.2,1.6]');
ok('a strip-end vertex somebody rounded is left as it is', v7(S.migrate(old('A10b 2026-11-27', (p) => { v7(p).r = 1; }), defaults).params).c === undefined);
ok('an A10c design with the vertex set back to sharp is left sharp', v7(S.migrate(old('A10c 2026-11-27'), defaults).params).c === undefined);
const added = S.migrate(old('A10b 2026-11-27', (p) => { p.frame.outline.splice(7, 0, { x: -0.7, y: 54.55 }); }), defaults).params;
ok('a design with a vertex added next to it: the corner vertex still takes the joint, the added one is kept', v7(added).c === 'meet' && added.frame.outline.length === defaults.frame.outline.length + 1);
console.log(bad ? bad + ' wrong' : 'ALL OK'); process.exit(bad ? 1 : 0);
