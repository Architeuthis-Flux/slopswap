#!/usr/bin/env node
// Jumperless V6 outline tool - what a saved design keeps and what it takes from a newer revision (rev A10c: the strip's end;
// rev A10d: the two keys beside the display taken out and the display centred).
//   node tools/migratecheck.mjs      exits 1 if any case below is wrong
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const here = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const S = require(here + '/src/state.js');
const defaults = JSON.parse(fs.readFileSync(here + '/v6_outline.json', 'utf8'));
let bad = 0; const ok = (name, cond, extra) => { if (!cond) bad++; console.log((cond ? 'ok   ' : 'FAIL ') + name + (extra ? '  ' + extra : '')); };
const old = (rev, edit) => { const p = JSON.parse(JSON.stringify(defaults)); p.meta.rev = rev; const v = p.frame.outline[6]; delete v.c; v.n = "strip ends level with the breadboard's bottom edge"; if (edit) edit(p); return p; };
const v7 = (p) => p.frame.outline[6];
ok('an untouched A10b design: its strip-end vertex takes the new joint', v7(S.migrate(old('A10b 2026-11-27'), defaults).params).c === 'meet');
ok('an untouched A9 design: the same', v7(S.migrate(old('A9 2026-11-25'), defaults).params).c === 'meet');
ok("Kevin's 08:38 design (vertex raised to 53.35, rounded chamfer) is left as it is", JSON.stringify(v7(S.migrate(old('A10b 2026-11-27', (p) => { const v = v7(p); v.y = 53.35; v.c = [2.2, 1.6]; v.r = 1; }), defaults).params).c) === '[2.2,1.6]');
ok('a strip-end vertex somebody rounded is left as it is', v7(S.migrate(old('A10b 2026-11-27', (p) => { v7(p).r = 1; }), defaults).params).c === undefined);
ok('an A10c design with the vertex set back to sharp is left sharp', v7(S.migrate(old('A10c 2026-11-27'), defaults).params).c === undefined);
const added = S.migrate(old('A10b 2026-11-27', (p) => { p.frame.outline.splice(7, 0, { x: -0.7, y: 54.55 }); }), defaults).params;
ok('a design with a vertex added next to it: the corner vertex still takes the joint, the added one is kept', v7(added).c === 'meet' && added.frame.outline.length === defaults.frame.outline.length + 1);

// rev A10d. The built-in design before it: the display at x 30 with key1 and key2 to its right.
const KEYS = [{ id: 'key1', type: 'btn_cantilever', x: 64.5, y: -5.0, rot: 90, tongue: { dir: 90 }, mount: { on: 'L1', side: 'top' } },
              { id: 'key2', type: 'btn_cantilever', x: 70.5, y: -5.0, rot: 90, tongue: { dir: 90 }, mount: { on: 'L1', side: 'top' } }];
const a10c = (edit) => { const p = JSON.parse(JSON.stringify(defaults)); p.meta.rev = 'A10c 2026-11-27'; p.parts = p.parts.concat(JSON.parse(JSON.stringify(KEYS))); part(p, 'display').x = 30.0; if (edit) edit(p); return p; };
const part = (p, id) => p.parts.find((q) => q.id === id);
const dflt = part(defaults, 'display');
let m = S.migrate(a10c(), defaults).params;
ok('an untouched A10c design: both keys go and the display takes the new place', !part(m, 'key1') && !part(m, 'key2') && part(m, 'display').x === dflt.x && part(m, 'display').y === dflt.y, 'display x ' + part(m, 'display').x);
ok('  ... and it is then the built-in design', JSON.stringify(m.parts) === JSON.stringify(defaults.parts));
m = S.migrate(a10c((p) => { part(p, 'key2').x = 72.0; }), defaults).params;
ok('a key that was moved stays; the other goes', !part(m, 'key1') && part(m, 'key2') && part(m, 'key2').x === 72.0);
m = S.migrate(a10c((p) => { part(p, 'key1').mount = { on: 'L0', side: 'top' }; part(p, 'key2').type = 'tact_ts1187'; }), defaults).params;
ok('a key that was remounted or changed for another part stays', !!part(m, 'key1') && !!part(m, 'key2'));
m = S.migrate(a10c((p) => { part(p, 'display').x = 28.0; }), defaults).params;
ok('a display that was moved stays where it was put; the keys still go', part(m, 'display').x === 28.0 && !part(m, 'key1') && !part(m, 'key2'));
m = S.migrate(a10c((p) => { part(p, 'display').type = 'display_ips279bar'; part(p, 'display').y = -13.5; }), defaults).params;
ok('a display that was changed for another stays as it was', part(m, 'display').type === 'display_ips279bar' && part(m, 'display').x === 30.0 && part(m, 'display').y === -13.5);
m = S.migrate(a10c((p) => { part(p, 'display').window = { crop: 0.3 }; p.parts.push({ id: 'sw1', type: 'tact_ts1187', x: 5, y: -6, rot: 0, mount: { on: 'L0', side: 'top' } }); }), defaults).params;
ok('a display as drawn with a window keeps its window and takes the new place; an added part is kept', part(m, 'display').x === dflt.x && !!part(m, 'display').window && !!part(m, 'sw1'));
m = S.migrate(a10c((p) => { p.meta.rev = 'A10d 2026-11-27'; }), defaults).params;
ok('an A10d design that has the keys (put back by hand) keeps them', !!part(m, 'key1') && !!part(m, 'key2') && part(m, 'display').x === 30.0);
m = S.migrate(a10c((p) => { p.meta.rev = 'A9 2026-11-25'; }), defaults).params;
ok('an untouched A9 design: the same as A10c', !part(m, 'key1') && !part(m, 'key2') && part(m, 'display').x === dflt.x);
const a6 = JSON.parse(JSON.stringify(defaults)); a6.meta.rev = 'A6 2026-11-24'; a6.parts = a6.parts.filter((q) => q.id !== 'display' && q.id !== 'side');      /* a rev A6 design has no socket in the right side (that came with rev A11c, which adds it) */ a6.parts.unshift({ id: 'display', type: 'display_amoled147', x: 19, y: -11.8, rot: 90, mount: { flush: 'top', offset: 0 } });
m = S.migrate(a6, defaults).params;
ok('an untouched A6 design (the 1.47 inch AMOLED): it becomes the built-in design, with no keys', JSON.stringify(m.parts.map((q) => q.id).sort()) === JSON.stringify(defaults.parts.map((q) => q.id).sort()) && part(m, 'display').type === dflt.type && part(m, 'display').x === dflt.x);
console.log(bad ? bad + ' wrong' : 'ALL OK'); process.exit(bad ? 1 : 0);
