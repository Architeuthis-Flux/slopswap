// STEP -> compact mesh JSON in the STEP's own frame (mm, Z-up). Groups triangles by colour.
import fs from "node:fs";
import { createRequire } from "node:module";
const occtimportjs = createRequire(process.cwd() + "/")("occt-import-js");
const [src, out, deflArg, angArg] = process.argv.slice(2);
const occt = await occtimportjs();
const params = { linearUnit: "millimeter", linearDeflectionType: "absolute_value", linearDeflection: parseFloat(deflArg || "0.05"), angularDeflection: parseFloat(angArg || "0.5") };
const r = occt.ReadStepFile(new Uint8Array(fs.readFileSync(src)), params);
if (!r.success) { console.error("STEP read failed", src); process.exit(2); }
const groups = new Map();
const lo = [1e9, 1e9, 1e9], hi = [-1e9, -1e9, -1e9];
let tris = 0;
for (const m of r.meshes) {
  const p = m.attributes.position.array, ix = m.index.array;
  const faceCols = m.brep_faces || [];
  // per-face colours when present, else mesh colour
  const triColor = new Array(ix.length / 3).fill(null);
  for (const f of faceCols) if (f.color) for (let t = f.first; t <= f.last; t++) triColor[t] = f.color;
  for (let t = 0; t < ix.length / 3; t++) {
    const c = triColor[t] || m.color || [0.62, 0.62, 0.62];
    const key = c.map(v => Math.round(v * 255)).join(",");
    let g = groups.get(key);
    if (!g) { g = { color: c.map(v => +(+v).toFixed(3)), pos: [], idx: [], map: new Map() }; groups.set(key, g); }
    for (let k = 0; k < 3; k++) {
      const vi = ix[t * 3 + k];
      const x = p[vi * 3], y = p[vi * 3 + 1], z = p[vi * 3 + 2];
      const vk = m.name + ":" + vi + ":" + (r.meshes.indexOf(m));
      let ni = g.map.get(vk);
      if (ni === undefined) { ni = g.pos.length / 3; g.pos.push(x, y, z); g.map.set(vk, ni);
        lo[0] = Math.min(lo[0], x); lo[1] = Math.min(lo[1], y); lo[2] = Math.min(lo[2], z);
        hi[0] = Math.max(hi[0], x); hi[1] = Math.max(hi[1], y); hi[2] = Math.max(hi[2], z); }
      g.idx.push(ni);
    }
    tris++;
  }
}
const b64 = (ta) => Buffer.from(ta.buffer, ta.byteOffset, ta.byteLength).toString("base64");
const outG = [...groups.values()].map(g => {
  const pos = new Float32Array(g.pos);
  const big = g.pos.length / 3 > 65535;
  const idx = big ? new Uint32Array(g.idx) : new Uint16Array(g.idx);
  return { color: g.color, nv: g.pos.length / 3, nt: g.idx.length / 3, i32: big, pos: b64(pos), idx: b64(idx) };
});
const res = { bbox: [lo.map(v => +v.toFixed(3)), hi.map(v => +v.toFixed(3))], groups: outG };
fs.writeFileSync(out, JSON.stringify(res));
console.log(src.split("/").pop(), "meshes", r.meshes.length, "groups", outG.length, "tris", tris, "bbox", JSON.stringify(res.bbox), "bytes", fs.statSync(out).size);
