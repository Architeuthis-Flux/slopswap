#!/usr/bin/env node
// Jumperless V6 outline tool - the fill beside the breadboard must not leave islands.
//   node tools/islandcheck.mjs      exits 1 if any case below is wrong
// Where the frame runs along the breadboard, the spaces the breadboard's own outline leaves (corner chamfers, the waist)
// are filled so the board's edge follows the breadboard. That fill belongs to the stretch the frame actually runs along and
// to nothing else: no board may have a piece lying wholly inside the breadboard's rectangle, and no fill may reach past the
// end of the frame.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const here = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const require = createRequire(import.meta.url);
const Geo = require(path.join(here, 'src/geometry.js'));
const base = JSON.parse(fs.readFileSync(path.join(here, 'v6_outline.json'), 'utf8'));
const ref = JSON.parse(fs.readFileSync(path.join(here, 'ref/wig_ref.json'), 'utf8'));
const W = base.wig.width, H = base.wig.height;
const v7 = (P) => P.frame.outline.find((q) => Math.abs(q.x) < 1e-6 && Math.abs(q.y - H) < 1e-3);      // the strip's end at the breadboard's bottom-left corner
const v8 = (P) => P.frame.outline.find((q) => q.x < -1 && Math.abs(q.y - H) < 1e-3);
const cases = [
  ['the default design', (P) => {}, H],
  ["Kevin's 27 Nov: strip end raised to 53.35 with a rounded chamfer", (P) => { const q = v7(P); q.y = 53.35; q.c = [2.2, 1.6]; q.r = 1; }, 53.35],
  ['strip end raised to 50, square', (P) => { v7(P).y = 50; }, 50],
  ['the strip stopping at y = 40 (both of its end corners raised)', (P) => { const a = v7(P), b = v8(P); a.y = 40; b.y = 40; delete b.c; delete b.r; }, 40],
  ['7.62 strip', (P) => { P.frame.outline.forEach((q) => { if (q.x < -0.01) q.x -= 2.54; }); P.grid.dead_rows_left = 3; }, H],
];
let bad = 0;
for (const mode of ['integrated', 'removable']) for (const [name, edit, endY] of cases) {
  const P = JSON.parse(JSON.stringify(base)); P.wig.mode = mode; edit(P);
  const R = Geo.resolve(P, ref), problems = [];
  R.layers.forEach((L, li) => {
    const whole = mode === 'integrated' && li === 0;            // the one board under frame and breadboard covers the rectangle
    L.shape.forEach((e) => {
      const xs = e.outer.map((q) => q[0]), ys = e.outer.map((q) => q[1]);
      const bb = [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
      if (!whole && bb[0] > -0.02 && bb[1] > -0.02 && bb[2] < W + 0.02 && bb[3] < H + 0.02) problems.push(L.id + ': an island inside the breadboard at x ' + bb[0].toFixed(2) + '..' + bb[2].toFixed(2) + ', y ' + bb[1].toFixed(2) + '..' + bb[3].toFixed(2));
      if (!whole) { const past = e.outer.filter((q) => q[0] > 0.06 && q[0] < 3 && q[1] > endY + 0.3 && q[1] < H + 0.02); if (past.length) problems.push(L.id + ': fill reaches y ' + Math.max(...past.map((q) => q[1])).toFixed(2) + ', past the strip\'s end at ' + endY); }
    });
  });
  if (problems.length) bad++;
  console.log((problems.length ? 'FAIL ' : 'ok   ') + (mode + ': ' + name).padEnd(84) + (problems.length ? [...new Set(problems)].join('; ') : R.layers.map((L) => L.id + ' ' + L.shape.length).join(', ') + ' pieces'));
}
console.log(bad ? bad + ' case(s) wrong' : 'ALL OK');
process.exit(bad ? 1 : 0);
