#!/usr/bin/env node
// Jumperless V6 outline tool - the fill beside the breadboard must not leave islands.
//   node tools/islandcheck.mjs      exits 1 if any case below is wrong
// Where the frame runs along the breadboard, the spaces the breadboard's own outline leaves (corner chamfers, the waist)
// are filled so the board's edge follows the breadboard. That fill belongs to the stretch the frame actually runs along and
// to nothing else: no board may have a piece lying wholly inside the breadboard's rectangle, and no fill may reach past the
// end of the frame.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const here = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const require = createRequire(import.meta.url);
const Geo = require(path.join(here, 'src/geometry.js'));
const base = JSON.parse(fs.readFileSync(path.join(here, 'v6_outline.json'), 'utf8'));
const ref = JSON.parse(fs.readFileSync(path.join(here, 'ref/wig_ref.json'), 'utf8'));
const W = base.wig.width, H = base.wig.height;
const v7 = (P) => P.frame.outline.find((q) => Math.abs(q.x) < 1e-6 && Math.abs(q.y - H) < 1e-3);      // the strip's end at the breadboard's bottom-left corner
const v8 = (P) => P.frame.outline.find((q) => q.x < -1 && Math.abs(q.y - H) < 1e-3);
const cases = [
  ['the default design', (P) => {}, H],
  ["Kevin's 27 Nov: strip end raised to 53.35 with a rounded chamfer", (P) => { const q = v7(P); q.y = 53.35; q.c = [2.2, 1.6]; q.r = 1; }, 53.35],
  ['strip end raised to 50, square', (P) => { v7(P).y = 50; }, 50],
  ['the strip stopping at y = 40 (both of its end corners raised)', (P) => { const a = v7(P), b = v8(P); a.y = 40; b.y = 40; delete b.c; delete b.r; }, 40],
  ['7.62 strip', (P) => { P.frame.outline.forEach((q) => { if (q.x < -0.01) q.x -= 2.54; }); P.grid.dead_rows_left = 3; }, H],
];
let bad = 0;
for (const mode of ['integrated', 'removable']) for (const [name, edit, endY] of cases) {
  const P = JSON.parse(JSON.stringify(base)); P.wig.mode = mode; edit(P);
  const R = Geo.resolve(P, ref), problems = [];
  R.layers.forEach((L, li) => {
    const whole = mode === 'integrated' && li === 0;            // the one board under frame and breadboard covers the rectangle
    L.shape.forEach((e) => {
      const xs = e.outer.map((q) => q[0]), ys = e.outer.map((q) => q[1]);
      const bb = [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)];
      if (!whole && bb[0] > -0.02 && bb[1] > -0.02 && bb[2] < W + 0.02 && bb[3] < H + 0.02) problems.push(L.id + ': an island inside the breadboard at x ' + bb[0].toFixed(2) + '..' + bb[2].toFixed(2) + ', y ' + bb[1].toFixed(2) + '..' + bb[3].toFixed(2));
      if (!whole) { const past = e.outer.filter((q) => q[0] > 0.06 && q[0] < 3 && q[1] > endY + 0.3 && q[1] < H + 0.02); if (past.length) problems.push(L.id + ': fill reaches y ' + Math.max(...past.map((q) => q[1])).toFixed(2) + ', past the strip\'s end at ' + endY); }
    });
  });
  if (problems.length) bad++;
  console.log((problems.length ? 'FAIL ' : 'ok   ') + (mode + ': ' + name).padEnd(84) + (problems.length ? [...new Set(problems)].join('; ') : R.layers.map((L) => L.id + ' ' + L.shape.length).join(', ') + ' pieces'));
}
// The joint at the strip's end (a vertex with c:'meet' on the breadboard's corner): the frame's edge meets the breadboard's
// chamfer square, at the middle of its flat. Four points 0.45 and 0.8 mm outside the chamfer, just either side of that line:
// the two on the strip's side are board, the two on the far side are not, on every board.
{
  const o = ref.outline, cands = [];
  for (let i = 0; i < o.length; i++) { const a = o[i], b = o[(i + 1) % o.length]; if ([a, b].every((q) => q[0] < 3.2 && q[1] > H - 3.2) && Math.abs(a[0] - b[0]) > 0.05 && Math.abs(a[1] - b[1]) > 0.05) cands.push([Math.hypot(a[0] - b[0], a[1] - b[1]), a, b]); }
  cands.sort((x, y) => y[0] - x[0]);
  const [len, A, B] = cands[0], M = [(A[0] + B[0]) / 2, (A[1] + B[1]) / 2];
  let d = [(B[0] - A[0]) / len, (B[1] - A[1]) / len]; if (d[0] < 0) d = [-d[0], -d[1]];            // along the flat, towards the bottom edge
  let n = [-d[1], d[0]]; if (n[1] < 0) n = [-n[0], -n[1]];                                             // out of the breadboard, towards the corner
  const at = (u, v) => [M[0] + u * d[0] + v * n[0], M[1] + u * d[1] + v * n[1]];
  const inPoly = (pt, poly) => { let c = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const a = poly[i], b = poly[j]; if ((a[1] > pt[1]) !== (b[1] > pt[1]) && pt[0] < (b[0] - a[0]) * (pt[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c; } return c; };
  const isBoard = (L, pt) => L.shape.some((e) => inPoly(pt, e.outer) && !e.holes.some((h) => inPoly(pt, h)));
  for (const mode of ['integrated', 'removable']) for (const [name, edit] of [['the default design (vertex 7 meets the chamfer)', (P) => {}], ['a 7.62 strip', (P) => { P.frame.outline.forEach((q) => { if (q.x < -0.01) q.x -= 2.54; }); P.grid.dead_rows_left = 3; }]]) {
    const P = JSON.parse(JSON.stringify(base)); P.wig.mode = mode; edit(P);
    const R = Geo.resolve(P, ref), problems = [];
    if (!P.frame.outline.some((q) => q.c === 'meet')) problems.push('no vertex is set to meet the chamfer');
    R.layers.forEach((L) => {
      [[-0.2, 0.45], [-0.2, 0.75]].forEach((q) => { if (!isBoard(L, at(q[0], q[1]))) problems.push(L.id + ': no board on the strip\'s side of the line, ' + q[1] + ' mm off the chamfer'); });
      [[0.2, 0.45], [0.2, 0.75]].forEach((q) => { if (isBoard(L, at(q[0], q[1]))) problems.push(L.id + ': board on the far side of the line, ' + q[1] + ' mm off the chamfer'); });
    });
    if (problems.length) bad++;
    console.log((problems.length ? 'FAIL ' : 'ok   ') + (mode + ': joint, ' + name).padEnd(84) + (problems.length ? [...new Set(problems)].join('; ') : 'flat ' + len.toFixed(2) + ' long, met at (' + M[0].toFixed(2) + ', ' + M[1].toFixed(2) + ') at ' + (Math.atan2(n[1], -n[0]) * 180 / Math.PI).toFixed(1) + ' deg below the horizontal'));
  }
}
console.log(bad ? bad + ' case(s) wrong' : 'ALL OK');
process.exit(bad ? 1 : 0);
