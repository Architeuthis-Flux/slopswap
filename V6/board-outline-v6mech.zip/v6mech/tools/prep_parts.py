#!/usr/bin/env python3
"""Build src/partlib.js: real parts for the outline tool, each with its footprint and its body sizes.

For every row of TABLE the footprint and 3D model are fetched by LCSC part number with easyeda2kicad (pip install
easyeda2kicad; it asks EasyEDA, so it needs the network once: results are kept in ref/ez/<key>/). The footprint is read
into a plain structure (pads and drawings) that src/exporters.js writes back out as KiCad 8; the model (VRML, in the
footprint's own frame) is turned into a height map and reduced to one to three simple bodies: the housing, anything that
stands taller than it (the actuator), and their real heights. A part's frame in the tool IS its footprint's frame, so the
exported footprint needs no offset.

    python3 tools/prep_parts.py            # fetch what is missing, rebuild src/partlib.js
    python3 tools/prep_parts.py --report   # also print one line per part

"have" is the quantity in Kevin's ~/Documents/Parts/INVENTORY.md on 2026-11-24 (ordered, not counted).
These footprints come from EasyEDA's library, not from the makers' drawings: check each against its datasheet before a
board is ordered.
"""
import base64, json, math, os, re, subprocess, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..'); EZ = os.path.join(ROOT, 'ref', 'ez')
# key, LCSC, group, label, have, options (on: default board; h: height to use when there is no model; access: needs a way in from above)
TABLE = [
 # ---- push buttons
 ('btn_ts1187a', 'C22459525', 'button', 'Tact TS-1187A, 5.1 x 5.1 (B25 pick)', 0, {}),
 ('btn_ts1187b', 'C692459', 'button', 'Tact TS-1187B-A, 4.8 x 4.8, flat', 20, {}),
 ('btn_tc171d', 'C963234', 'button', 'Tact GT-TC171D, 3 x 2.75, 80 gf', 50, {}),
 ('btn_ts1088', 'C720477', 'button', 'Tact TS-1088, 4 x 3', 30, {}),
 ('btn_ts1809', 'C318879', 'button', 'Tact TS-1809SM, 3.5 x 3', 5, {}),
 ('btn_tm1201', 'C908451', 'button', 'Tact TM-1201-A, 4.2 x 3.6', 15, {}),
 ('btn_yts10h', 'C7436574', 'button', 'Tact YTS10H, 5.1 x 5.1, tall stem', 50, {}),
 ('btn_ksek', 'C221772', 'button', 'C&K KSEK43G, 6.2 x 6.25, soft', 30, {}),
 ('btn_tc204a', 'C2931186', 'button', 'Tact GT-TC204A, 7.6 x 7.4, flat dome', 25, {}),
 ('btn_tl3301', 'C2886849', 'button', 'E-Switch TL3301, 6 x 6', 5, {}),
 ('btn_evpasac', 'C4365033', 'button', 'Panasonic EVP-AS, 6 x 6.1', 5, {}),
 ('btn_spej', 'C97447', 'button', 'ALPS SPEJ push switch, 7 x 7, long travel', 32, {}),
 ('btn_choc', 'C404350', 'button', 'Kailh CPG1511 low-profile key switch', 5, {}),
 ('btn_ts1134', 'C843371', 'button', 'Side tact TS-1134A, 4.5 x 2.9, pressed from the edge', 5, {'access': False}),
 ('btn_ytsa034', 'C2910683', 'button', 'Side tact YTS-A034, 4.5 x 2.2, pressed from the edge', 10, {'access': False}),
 ('btn_ts2245', 'C49274356', 'button', 'Side tact TS2245 with bracket, pressed from the edge', 5, {'access': False, 'h': 2.2}),
 # ---- directional switches
 ('nav_k1_1210un', 'C128927', 'nav', 'Hroparts K1-1210UN-01 pad, 9.9 x 9.9', 14, {}),
 ('nav_k1_1502', 'C128928', 'nav', 'Hroparts K1-1502SA-03 stick, 12.8 x 11.4', 5, {}),
 ('nav_srbd', 'C255508', 'nav', 'ALPS SRBD110401', 8, {}),
 ('nav_sksd', 'C139801', 'nav', 'ALPS SKSDPCE010, 4.1 x 3.9, very flat', 15, {}),
 ('nav_tc006d', 'C3019724', 'nav', 'G-Switch GT-TC006D five-way, 7.5 x 7.5', 3, {}),
 ('nav_rkjxm1015', 'C97432', 'nav', 'ALPS RKJXM1015004 stick (B25 pick)', 4, {'on': 'base'}),
 # ---- joysticks and wheels
 ('joy_y16', 'C37323743', 'joy', 'Thumbstick Y16-YZL7.2, 19.8 x 15.5', 20, {'on': 'base'}),
 ('joy_yf16s', 'C37323740', 'joy', 'Thumbstick YF16S-FL7.2 with push, 25.5 x 20.3', 5, {'on': 'base'}),
 ('joy_ydr', 'C48972211', 'joy', 'Joystick YDR-YG16-004', 2, {'on': 'base'}),
 ('wheel_siq02', 'C29780879', 'wheel', 'Click wheel SIQ-02FVS3 (LCSC footprint)', 0, {'on': 'base', 'access': False}),
 ('enc_pec11l', 'C143799', 'wheel', 'Bourns PEC11L encoder', 1, {'on': 'base'}),
 # ---- ports and connectors
 ('port_m2_48', 'C52766533', 'port', 'M.2 Key M socket, 4.8 high (MLD-NGFF-M-4.8H)', 3, {'on': 'base', 'access': False, 'h': 4.8}),
 ('port_minipcie_40', 'C52766473', 'port', 'mini PCIe socket, 4.0 high (MLD-PCIE-52P-4.0H)', 10, {'on': 'base', 'access': False}),
 ('port_hee70', 'C5448235', 'port', 'WingTAT HEE70LP03BK card-edge slot, 70 way', 46, {'on': 'base', 'access': False}),
 ('port_usbc_hro', 'C165948', 'port', 'USB-C HRO TYPE-C-31-M-12 (LCSC footprint)', 0, {'on': 'base', 'access': False}),
 ('port_jack35', 'C707258', 'port', '3.5 mm jack PJ-3920-3A', 30, {'on': 'base', 'access': False}),
 ('port_jst_sh4', 'C160404', 'port', 'JST SH 4 way, 1 mm (Qwiic)', 0, {'on': 'base', 'access': False}),
 ('port_pogo', 'C42419351', 'port', 'SMD pogo pin YTC1P-1807-01, 2.5 mm', 50, {'on': 'base', 'access': False}),
]

# ---------- s-expressions ----------
def sx(text):
    tok = re.findall(r'\(|\)|"(?:[^"\\]|\\.)*"|[^\s()]+', text); pos = 0
    def rd():
        nonlocal pos
        t = tok[pos]; pos += 1
        if t == '(':
            out = []
            while tok[pos] != ')': out.append(rd())
            pos += 1; return out
        return t[1:-1] if t.startswith('"') else t
    return rd()
def kids(n, name): return [c for c in n if isinstance(c, list) and c and c[0] == name]
def kid(n, name): k = kids(n, name); return k[0] if k else None
def nums(n): return [float(v) for v in n[1:] if not isinstance(v, list) and re.match(r'^-?[\d.]+(e-?\d+)?$', v)]

def read_footprint(path):
    t = sx(open(path).read()); fp = {'name': t[1].split(':')[-1], 'attr': 'smd', 'pads': [], 'gfx': []}
    a = kid(t, 'attr'); fp['attr'] = a[1] if a else 'through_hole'
    for p in kids(t, 'pad'):
        at = nums(kid(p, 'at')); sz = nums(kid(p, 'size')); d = kid(p, 'drill')
        o = {'n': p[1], 't': p[2], 's': p[3], 'x': at[0], 'y': at[1], 'a': at[2] if len(at) > 2 else 0, 'w': sz[0], 'h': sz[1], 'l': [v for v in kid(p, 'layers')[1:]]}
        if d:
            dv = nums(d); o['d'] = [dv[0], dv[1]] if 'oval' in d and len(dv) > 1 else [dv[0]] if dv else None
            off = kid(d, 'offset'); 
            if off: o['do'] = nums(off)
        rr = kid(p, 'roundrect_rratio')
        if rr: o['rr'] = float(rr[1])
        pr = kid(p, 'primitives')
        if pr:
            polys = [[[float(q[1]), float(q[2])] for q in kids(kid(g, 'pts'), 'xy')] for g in kids(pr, 'gr_poly')]
            if polys: o['poly'] = polys
        fp['pads'].append(o)
    for kind in ('fp_line', 'fp_circle', 'fp_arc', 'fp_poly', 'fp_rect'):
        for g in kids(t, kind):
            lay = kid(g, 'layer')[1]; w = kid(g, 'width'); st = kid(g, 'stroke')
            width = float(w[1]) if w else float(kid(st, 'width')[1]) if st else 0.12
            o = {'k': kind[3:], 'l': lay, 'w': width}
            if kind == 'fp_poly': o['p'] = [[float(q[1]), float(q[2])] for q in kids(kid(g, 'pts'), 'xy')]
            elif kind == 'fp_circle': o['c'] = nums(kid(g, 'center')); o['e'] = nums(kid(g, 'end'))
            elif kind == 'fp_arc':
                s, e = nums(kid(g, 'start')), nums(kid(g, 'end')); m = kid(g, 'mid'); an = kid(g, 'angle')
                if m: o['s'], o['m'], o['e'] = s, nums(m), e
                elif an:                                   # KiCad 5: start is the centre, end is where the arc begins, angle is clockwise on screen
                    A = math.radians(float(an[1])); r = lambda th: [s[0] + (e[0] - s[0]) * math.cos(th) - (e[1] - s[1]) * math.sin(th), s[1] + (e[0] - s[0]) * math.sin(th) + (e[1] - s[1]) * math.cos(th)]
                    o['s'], o['m'], o['e'] = e, r(A / 2), r(A)
                else: continue
            else: o['s'] = nums(kid(g, 'start')); o['e'] = nums(kid(g, 'end'))
            fp['gfx'].append(o)
    m = kid(t, 'model'); mt = {'off': [0, 0, 0], 'rot': [0, 0, 0]}
    if m:
        for nm, key in (('offset', 'off'), ('at', 'off'), ('rotate', 'rot')):
            k = kid(m, nm)
            if k and kid(k, 'xyz'): mt[key] = nums(kid(k, 'xyz'))
    return fp, mt

# ---------- the model, as a height map in the footprint's frame ----------
def read_wrl(path):
    s = open(path, errors='replace').read(); V = []; F = []
    for blk in re.finditer(r'point\s*\[(.*?)\].*?coordIndex\s*\[(.*?)\]', s, re.S):
        pts = np.array([float(v) for v in re.findall(r'-?\d+\.?\d*(?:[eE][-+]?\d+)?', blk.group(1))]).reshape(-1, 3) * 2.54
        idx = [int(v) for v in re.findall(r'-?\d+', blk.group(2))]; base = len(V); V.extend(pts.tolist()); cur = []
        for i in idx:
            if i < 0:
                for k in range(1, len(cur) - 1): F.append((base + cur[0], base + cur[k], base + cur[k + 1]))
                cur = []
            else: cur.append(i)
    return np.array(V), np.array(F, dtype=int)

def read_wrl_groups(path):
    """the model's shapes, one (colour, points, triangles) each, points in mm"""
    s = open(path, errors='replace').read(); out = []
    for sh in re.split(r'\bShape\s*\{', s)[1:]:
        m = re.search(r'point\s*\[(.*?)\].*?coordIndex\s*\[(.*?)\]', sh, re.S)
        if not m: continue
        c = re.search(r'diffuseColor\s+([\d.eE+-]+)\s+([\d.eE+-]+)\s+([\d.eE+-]+)', sh)
        col = tuple(round(float(v), 3) for v in c.groups()) if c else (0.5, 0.5, 0.5)
        pts = np.array([float(v) for v in re.findall(r'-?\d+\.?\d*(?:[eE][-+]?\d+)?', m.group(1))]).reshape(-1, 3) * 2.54
        idx = [int(v) for v in re.findall(r'-?\d+', m.group(2))]; F = []; cur = []
        for i in idx:
            if i < 0:
                for k in range(1, len(cur) - 1): F.append((cur[0], cur[k], cur[k + 1]))
                cur = []
            else: cur.append(i)
        if len(F): out.append((col, pts, np.array(F, dtype=int)))
    return out

def pack_model(groups, mt):
    """-> the viewer's mesh record: per colour, int16 positions (x, plan-up y, z) times a scale, and triangle indices"""
    by = {}
    for col, V, F in groups:
        W = to_footprint_frame(V, mt); W = np.column_stack([W[:, 0], -W[:, 1], W[:, 2]])
        e = by.setdefault(col, [[], [], 0]); e[0].append(W); e[1].append(F + e[2]); e[2] += len(W)
    allv = np.vstack([np.vstack(e[0]) for e in by.values()]); scale = float(np.abs(allv).max()) / 32000.0 or 1e-3
    out = []
    for col, e in by.items():
        Q = np.round(np.vstack(e[0]) / scale).astype(np.int16); F = np.vstack(e[1])
        U, inv = np.unique(Q, axis=0, return_inverse=True); F = inv.reshape(-1)[F]                    # weld
        F = F[(F[:, 0] != F[:, 1]) & (F[:, 1] != F[:, 2]) & (F[:, 0] != F[:, 2])]
        if not len(F): continue
        big = len(U) > 65535
        out.append({'color': list(col), 'q': 1, 'i32': bool(big), 'pos': base64.b64encode(U.astype('<i2').tobytes()).decode(), 'idx': base64.b64encode(F.astype('<u4' if big else '<u2').tobytes()).decode()})
    return {'s': round(scale, 8), 'groups': out, 'bbox': [[round(float(v), 3) for v in allv.min(axis=0)], [round(float(v), 3) for v in allv.max(axis=0)]]}

def to_footprint_frame(V, mt):
    rx, ry, rz = [math.radians(-a) for a in mt['rot']]                       # KiCad turns a model by the negative of each angle, X then Y then Z
    Rx = np.array([[1, 0, 0], [0, math.cos(rx), -math.sin(rx)], [0, math.sin(rx), math.cos(rx)]])
    Ry = np.array([[math.cos(ry), 0, math.sin(ry)], [0, 1, 0], [-math.sin(ry), 0, math.cos(ry)]])
    Rz = np.array([[math.cos(rz), -math.sin(rz), 0], [math.sin(rz), math.cos(rz), 0], [0, 0, 1]])
    W = V @ (Rz @ Ry @ Rx).T + np.array(mt['off'])
    return np.column_stack([W[:, 0], -W[:, 1], W[:, 2]])                      # the board's y runs down the screen

def height_map(V, F, res=0.1):
    x0, y0 = V[:, 0].min(), V[:, 1].min(); nx = int((V[:, 0].max() - x0) / res) + 2; ny = int((V[:, 1].max() - y0) / res) + 2
    H = np.full((ny, nx), -1e9)
    for a, b, c in F:
        P = V[[a, b, c]]; n = int(max(np.ptp(P[:, 0]), np.ptp(P[:, 1])) / res * 1.5) + 2      # sample the triangle finely enough to leave no gaps
        u, v = np.meshgrid(np.linspace(0, 1, n), np.linspace(0, 1, n)); m = u + v <= 1.0001
        Q = P[0] + np.outer(u[m], P[1] - P[0]) + np.outer(v[m], P[2] - P[0])
        ix = ((Q[:, 0] - x0) / res).astype(int); iy = ((Q[:, 1] - y0) / res).astype(int)
        np.maximum.at(H, (iy, ix), Q[:, 2])
    return H, x0, y0, res

def bodies_from(H, x0, y0, res):
    top = float(H.max()); occ = H > 0.08
    if not occ.any(): return [], top
    def box(mask, z0, z1, name):
        ys, xs = np.where(mask); bx = [x0 + xs.min() * res, y0 + ys.min() * res, x0 + (xs.max() + 1) * res, y0 + (ys.max() + 1) * res]
        w, h = bx[2] - bx[0], bx[3] - bx[1]; fill = mask.sum() * res * res / max(w * h, 1e-9)
        if abs(w - h) < 0.15 * max(w, h) and 0.70 < fill < 0.86:               # as full as a circle in its square
            return {'c': [round((bx[0] + bx[2]) / 2, 2), round((bx[1] + bx[3]) / 2, 2), round((w + h) / 4, 2)], 'z0': round(z0, 2), 'z1': round(z1, 2), 'name': name}
        return {'r': [round(v, 2) for v in bx], 'z0': round(z0, 2), 'z1': round(z1, 2), 'name': name}
    hs = np.sort(H[occ]); 
    # the housing's top: the height that the largest share of the plan sits at (within 0.15 mm)
    best, hb = 0, top
    for h in np.unique(np.round(hs, 1)):
        n = np.sum(np.abs(hs - h) <= 0.15)
        if n > best * 1.02 or (n >= best * 0.98 and h > hb): best, hb = max(best, n), h
    hb = float(min(top, hb + 0.05)); out = [box(occ, 0, hb if top - hb > 0.35 else top, 'body')]
    if top - hb > 0.35:
        up = H > hb + 0.2
        if up.sum() * res * res > 0.3: out.append(box(up, hb, top, 'actuator'))
    low = occ & (H < hb - 0.6) & (H > 0.08)                                      # a wide low part round a taller core (flanges, lead frames)
    if low.sum() > 0.35 * occ.sum() and len(out) and 'r' in out[0]:
        core = H >= hb - 0.6; lowtop = float(np.median(H[low]))
        out = [box(occ, 0, lowtop, 'base'), box(core, lowtop, hb if top - hb > 0.35 else top, 'body')] + out[1:]
    return out, top

def fetch(key, lcsc):
    d = os.path.join(EZ, key); os.makedirs(d, exist_ok=True)
    mods = [f for f in os.listdir(os.path.join(d, 'lib.pretty'))] if os.path.isdir(os.path.join(d, 'lib.pretty')) else []
    if not mods:
        subprocess.run(['easyeda2kicad', '--lcsc_id', lcsc, '--footprint', '--3d', '--overwrite', '--output', os.path.join(d, 'lib')], capture_output=True, text=True, timeout=120)
        mods = [f for f in os.listdir(os.path.join(d, 'lib.pretty'))] if os.path.isdir(os.path.join(d, 'lib.pretty')) else []
    if not mods: return None, None
    w = [f for f in os.listdir(os.path.join(d, 'lib.3dshapes'))] if os.path.isdir(os.path.join(d, 'lib.3dshapes')) else []
    w = [f for f in w if f.endswith('.wrl')]
    return os.path.join(d, 'lib.pretty', mods[0]), (os.path.join(d, 'lib.3dshapes', w[0]) if w else None)

def main():
    report = '--report' in sys.argv; parts = {}; fps = {}; lines = []; models = {}
    for key, lcsc, group, label, have, opt in TABLE:
        mod, wrl = fetch(key, lcsc)
        if not mod: lines.append('%-18s %-10s NOT FOUND at EasyEDA' % (key, lcsc)); continue
        fp, mt = read_footprint(mod)
        px = [p['x'] for p in fp['pads']]; py = [p['y'] for p in fp['pads']]
        pb = [min(p['x'] - max(p['w'], p['h']) / 2 for p in fp['pads']), min(p['y'] - max(p['w'], p['h']) / 2 for p in fp['pads']), max(p['x'] + max(p['w'], p['h']) / 2 for p in fp['pads']), max(p['y'] + max(p['w'], p['h']) / 2 for p in fp['pads'])] if fp['pads'] else [-1, -1, 1, 1]
        bodies, top, note = [], opt.get('h', 0), ''
        if wrl:
            gr = read_wrl_groups(wrl)
            if gr: models[key] = pack_model(gr, mt)
        if wrl and 'h' not in opt:
            V, F = read_wrl(wrl)
            if len(F):
                Vf = to_footprint_frame(V, mt); H, x0, y0, res = height_map(Vf, F); bodies, top = bodies_from(H, x0, y0, res)
                mc = [(Vf[:, 0].min() + Vf[:, 0].max()) / 2, (Vf[:, 1].min() + Vf[:, 1].max()) / 2]; pc = [(pb[0] + pb[2]) / 2, (pb[1] + pb[3]) / 2]
                note = 'model centre %.1f, %.1f from the pads centre' % (mc[0] - pc[0], mc[1] - pc[1])
        if not bodies:
            g = [q for q in fp['gfx'] if q['l'] in ('F.Fab', 'F.SilkS', 'F.CrtYd')]
            xs = [v for q in g for v in ([q['s'][0], q['e'][0]] if 's' in q else [q['c'][0] - abs(q['e'][0] - q['c'][0]), q['c'][0] + abs(q['e'][0] - q['c'][0])] if 'c' in q else [])] + [pb[0], pb[2]]
            ys = [v for q in g for v in ([q['s'][1], q['e'][1]] if 's' in q else [q['c'][1] - abs(q['e'][0] - q['c'][0]), q['c'][1] + abs(q['e'][0] - q['c'][0])] if 'c' in q else [])] + [pb[1], pb[3]]
            top = top or 1.5; bodies = [{'r': [round(min(xs), 2), round(min(ys), 2), round(max(xs), 2), round(max(ys), 2)], 'z0': 0, 'z1': top, 'name': 'body'}]
            note = 'no model: outline from the footprint drawing, height %s' % ('from the part number' if 'h' in opt else 'ASSUMED 1.5')
        b0 = bodies[0]['r'] if 'r' in bodies[0] else [bodies[0]['c'][0] - bodies[0]['c'][2], bodies[0]['c'][1] - bodies[0]['c'][2], bodies[0]['c'][0] + bodies[0]['c'][2], bodies[0]['c'][1] + bodies[0]['c'][2]]
        parts[key] = {'label': label, 'group': group, 'lcsc': lcsc, 'fp': fp['name'], 'have': have, 'on': opt.get('on', 'mid' if top <= 1.75 else 'base'), 'height': round(top, 2), 'bodies': bodies, 'access': opt.get('access', group in ('button', 'nav', 'joy', 'wheel')), 'note': note, 'model': key in models,
                      'size': [round(b0[2] - b0[0], 2), round(b0[3] - b0[1], 2)]}
        for p in fp['pads']:
            for k in ('x', 'y', 'w', 'h'): p[k] = round(p[k], 4)
        fps[fp['name']] = fp
        lines.append('%-18s %-10s %-34s %5.2f x %5.2f x %5.2f  %d bodies  %2d pads  %s' % (key, lcsc, fp['name'][:34], b0[2] - b0[0], b0[3] - b0[1], top, len(bodies), len(fp['pads']), note))
    js = '// Built by tools/prep_parts.py from EasyEDA footprints and models (by LCSC number). Do not edit: change the table there.\n(function (root) { var L = ' + json.dumps({'parts': parts, 'footprints': fps}, separators=(',', ':')) + ';\n  if (typeof module === "object" && module.exports) module.exports = L; else root.V6_PARTLIB = L; })(typeof self !== "undefined" ? self : this);\n'
    open(os.path.join(ROOT, 'src', 'partlib.js'), 'w').write(js)
    mj = '// Built by tools/prep_parts.py: the EasyEDA 3D models of the library parts, in each footprint\'s own frame (x, y up the plan, z up), int16 times s.\nwindow.V6_PARTMODELS = ' + json.dumps(models, separators=(',', ':')) + ';\n'
    open(os.path.join(ROOT, 'src', 'partmodels.js'), 'w').write(mj)
    print('wrote src/partmodels.js: %d models, %d KB' % (len(models), len(mj) // 1024))
    print('wrote src/partlib.js: %d parts, %d footprints, %d KB' % (len(parts), len(fps), len(js) // 1024))
    if report or True: print('\n'.join(lines))

if __name__ == '__main__': main()
