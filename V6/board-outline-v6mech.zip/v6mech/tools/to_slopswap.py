#!/usr/bin/env python3
"""Publish this folder on slopswap.org (the Architeuthis-Flux/slopswap repo).

    node build.mjs && python3 step_export.py          # first, so the viewer and out/ are current
    python3 tools/to_slopswap.py <slopswap checkout>  # then: writes into <checkout>/V6/
    cd <checkout> && python3 build.py                 # preview in _site/, then commit and push

Writes four things next to each other in V6/:
    board-outline.html          the viewer, run through slopswap's own converter (localize_fonts.py --theme)
                                and then given the few tokens and layout rules the converter does not know
    board-outline-readme.html   README.md as a page in the site theme
    board-outline-v6mech.zip    this folder: parameters, source, part models and out/ for both variants
    board-outline-*.png         the figures the README page shows (from docs/, when present)
V6/index.html is written by hand on slopswap: add or update the two cards there yourself.
Needs: pip install markdown
"""
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
PAGE, README_PAGE, ZIP = 'board-outline.html', 'board-outline-readme.html', 'board-outline-v6mech.zip'
TITLE = 'V6 board outline and stack, in 3D'
DESC = ('The Jumperless V6 board shape traced from the notebook sketch, as three spaced boards with the real parts '
        'between them. Drag parts and outline vertices, pick the inputs, choose which boards each part opens, and '
        'check the 0.1 inch stacking, clashes and component room.')

# What the converter's token map does not cover, and what a full-screen tool needs inside the site's body.app.
# The tokens go in <head>: the viewer's script reads --viewport for the 3D background as it starts.
TOKENS = """<style>
/* slopswap, by tools/to_slopswap.py: the tokens the converter does not know */
:root,:root:not([data-theme="light"]),:root[data-theme="dark"]{color-scheme:dark;
  --field:#3d3d44;--viewport:#27272b;
  --ok:#70f899;--warn:#e8cb40;--bad:#ff8576;--ok-bg:#2c4a38;--warn-bg:#4d4420;--bad-bg:#55292a}
</style>
"""
EXTRA = """<style>
/* slopswap, by tools/to_slopswap.py: the tool's own layout under the site's body.app (after the theme, so it wins) */
html,body{height:100%}
.stack input,.stack select,.stack td:first-child{font-size:12px}
body.app{padding:0;font-size:13px;grid-template-rows:auto auto 1fr}
body.app>.eyebrow{margin:.75rem .9rem .4rem}
body.app h1{font-size:15px;margin:0}
body.app h2{font-size:11px;margin:16px 0 6px;padding-bottom:4px}
body.app table{margin-bottom:0}
body.app .pill{font:500 11px var(--sans);padding:1px 7px;border-radius:9px;border:0}
body.app .pill.info{background:var(--jl-surface-2,#3d3d44);color:var(--jl-fg,#f3f3f5)}
@media (max-width:980px){body.app{grid-template-rows:auto auto auto}}
@media (max-width:700px){
  main{grid-template-rows:55vh auto auto;grid-template-rows:55svh auto auto}
  #view{min-height:55vh;min-height:55svh}
  aside.left{max-height:40vh;max-height:40svh;overflow-y:auto;overscroll-behavior:contain}
  .vlist,#viewbar{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:none}
  #hud{display:none}
}
</style>
"""


def viewer(site: Path) -> None:
    html = (HERE / 'V6_outline_viewer.html').read_text()
    html = re.sub(r'<link[^>]+fonts\.(googleapis|gstatic)\.com[^>]*>\s*', '', html)        # the theme brings the fonts
    html = re.sub(r'<title>.*?</title>', '<title>%s</title>\n<meta name="short-title" content="V6 outline 3D">\n<meta name="description" content="%s">' % (TITLE, DESC), html, count=1, flags=re.S)
    html = html.replace('<h1>Jumperless V6 outline</h1>', '<h1>Jumperless V6 outline</h1> <a href="%s" style="font-size:12px">readme</a>' % README_PAGE, 1)
    with tempfile.TemporaryDirectory() as tmp:
        src = Path(tmp) / 'viewer.html'
        src.write_text(html)
        subprocess.run([sys.executable, str(site / 'localize_fonts.py'), '--theme', str(src), str(site / 'V6' / PAGE)], check=True)
    out = site / 'V6' / PAGE
    html = out.read_text()
    assert '</body>' in html and 'class="app"' in html, 'the converter did not theme the page'
    out.write_text(html.replace('</head>', TOKENS + '</head>', 1).replace('</body>', EXTRA + '</body>', 1))
    ext = sorted(set(u for u in re.findall(r'(?:src|href)="(https?://[^"]+)"', html)))
    print('  %s: %d KB, loads from outside: %s' % (PAGE, out.stat().st_size // 1024, ext or 'nothing'))


def readme(site: Path) -> None:
    import markdown
    md = (HERE / 'README.md').read_text()
    md = re.sub(r'^# .*\n', '', md, count=1)
    body = markdown.markdown(md, extensions=['tables', 'fenced_code', 'sane_lists'])
    body = body.replace('<table>', '<div class="table-wrap">\n<table>').replace('</table>', '</table>\n</div>')
    figs = ''
    for name, cap in (('board-outline-on-sketch.png', 'The outline (pink) laid over the notebook page it was traced from: the viewer\'s sketch underlay, seen from above.'),
                      ('board-outline-inputs.png', 'From the top edge: the click wheel under the top board at the corner, a nav switch through it, two button holes. Left, the pickers and the per-board tick boxes of the selected part.')):
        if (site / 'V6' / name).exists():
            figs += '<figure><a href="%s"><img src="%s" alt="%s"></a><figcaption>%s</figcaption></figure>\n' % (name, name, cap.split(':')[0], cap)
    page = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>V6 board outline and stack: the readme</title>
<meta name="short-title" content="V6 outline readme">
<meta name="description" content="How the V6 board outline tool works and what it found: the outline traced from the sketch, the 0.1 inch stacking rule, spaced boards, the input parts and where each lands, the checks, and what is not verified.">
<link rel="stylesheet" href="../styles/jumperless.css">
<style>
  figure{margin:0 0 1.4em} figure img{display:block;border:1px solid var(--line);border-radius:6px}
  .get{display:flex;flex-wrap:wrap;gap:.6rem 1rem;margin:0 0 1.6em;padding:0;list-style:none}
  .get a{display:inline-block;padding:.5em .9em;border:1px solid var(--line);border-radius:6px;background:var(--surface);text-decoration:none;color:var(--fg)}
  .get a:hover{border-color:var(--c,var(--accent))} .get a b{color:var(--c,var(--accent))}
  td,th{vertical-align:top}
</style>
</head>
<body>
<main class="page wide">
<p class="eyebrow"><a href="../">slopswap</a> / <a href="./">V6</a></p>
<h1>V6 board outline and stack</h1>
<p class="muted">The readme of <code>JumperlessV6/v6mech</code>, %s. Kevin Cappuccio with Claude.</p>
<ul class="get cycle">
  <li><a href="%s"><b>Open the 3D viewer</b></a></li>
  <li><a href="%s" download><b>Download the folder</b> (.zip, %s MB): parameters, source, KiCad and DXF outlines, STEP</a></li>
</ul>
%s
%s
<hr>
<p class="muted">Jumperless V6 is a work in progress. Part models in the viewer and the zip: KiCad library (CC-BY-SA 4.0 with the library exception), SparkFun (CC-BY 4.0), Adafruit (MIT); <code>models/SOURCES.md</code> in the zip says which is which.</p>
</main>
</body>
</html>
""" % (rev(), PAGE, ZIP, '%.1f' % ((site / 'V6' / ZIP).stat().st_size / 1e6), figs, body)
    (site / 'V6' / README_PAGE).write_text(page)
    print('  %s: %d KB' % (README_PAGE, len(page) // 1024))


def rev() -> str:
    import json
    return 'rev ' + json.loads((HERE / 'v6_outline.json').read_text())['meta']['rev']


def archive(site: Path) -> None:
    keep = ['README.md', 'v6_outline.json', 'V6_outline_viewer.html', 'build.mjs', 'step_export.py']
    dirs = ['src', 'tools', 'ref', 'models', 'out/integrated', 'out/removable']
    files = [HERE / k for k in keep]
    for d in dirs:
        files += [p for p in sorted((HERE / d).rglob('*')) if p.is_file()]
    files = [p for p in files if '/src/models/' not in p.as_posix() and '__pycache__' not in p.parts and p.name != '.DS_Store']
    out = site / 'V6' / ZIP
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in files:
            z.write(p, 'v6mech/' + p.relative_to(HERE).as_posix())
    print('  %s: %d files, %.1f MB' % (ZIP, len(files), out.stat().st_size / 1e6))


if __name__ == '__main__':
    if len(sys.argv) != 2 or not (Path(sys.argv[1]) / 'localize_fonts.py').exists():
        sys.exit(__doc__)
    site = Path(sys.argv[1]).resolve()
    for name in ('board-outline-on-sketch.png', 'board-outline-inputs.png'):
        src = HERE / 'docs' / name
        if src.exists():
            (site / 'V6' / name).write_bytes(src.read_bytes())
    viewer(site)
    archive(site)
    readme(site)
    print('now add or update the cards in V6/index.html, run build.py, look at _site/V6/, commit and push')
