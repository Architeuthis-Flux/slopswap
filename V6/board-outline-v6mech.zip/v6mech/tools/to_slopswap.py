#!/usr/bin/env python3
"""Publish this folder on slopswap.org (the Architeuthis-Flux/slopswap repo).

    node build.mjs && python3 step_export.py          # first, so the viewer and out/ are current
    python3 tools/to_slopswap.py <slopswap checkout>  # then: writes into <checkout>/V6/
    cd <checkout> && python3 build.py                 # preview in _site/, then commit and push

Writes four things next to each other in V6/:
    board-outline.html          the viewer with the site's stylesheet and font files in place of its inlined ones
    board-outline-readme.html   README.md as a page in the site theme
    board-outline-v6mech.zip    this folder: parameters, source, part models and out/ for both variants
    board-outline-*.png         the figures the README page shows (from docs/, when present)
V6/index.html is written by hand on slopswap: add or update the two cards there yourself.
Needs: pip install markdown
"""
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
PAGE, README_PAGE, ZIP = 'board-outline.html', 'board-outline-readme.html', 'board-outline-v6mech.zip'
TITLE = 'V6 board outline and stack, in 3D'
DESC = ('The Jumperless V6 board shape traced from the notebook sketch, as three spaced boards with the real parts '
        'between them. Drag parts and outline vertices, pick the inputs, choose which boards each part opens, and '
        'check the 0.1 inch stacking, clashes and component room.')

# The viewer already wears the site's look (the routing lab's console) and names the theme's --jl-* values with the same
# numbers as fallbacks. On slopswap it gets the theme's stylesheet in front of its own, the site's font files in place of
# the ones inlined in the single file, and the few rules that have to outrank the theme's body.app.
EXTRA = """<style>
/* slopswap, by tools/to_slopswap.py: the tool's own sizes under the site's body.app */
body.app{font-size:13px;padding:0}
body.app h1{font-size:14px;margin:0}
body.app h2{font-size:12px;margin:14px 0 5px}
body.app .sec:first-child h2,body.app #checks>h2:first-child{margin-top:2px}
body.app th{font-family:var(--label);font-size:11px;color:var(--dim);background:none}
body.app table{margin-bottom:0}
</style>
"""


def viewer(site: Path) -> None:
    html = (HERE / 'V6_outline_viewer.html').read_text()
    faces, n = re.subn(r'url\(data:font/woff2;base64,[A-Za-z0-9+/=]+\)', 'url(FONT)', html)
    names = ['ArchivoNarrow-var', 'Michroma-400', 'IBMPlexMono-400', 'IBMPlexMono-500', 'IBMPlexMono-600']
    if n != len(names):
        sys.exit(f'expected {len(names)} inlined fonts in the viewer, found {n}')
    for name in names:
        if not (site / 'styles' / 'fonts' / f'{name}.woff2').exists():
            sys.exit(f'slopswap has no styles/fonts/{name}.woff2')
        faces = faces.replace('url(FONT)', f'url(../styles/fonts/{name}.woff2)', 1)
    html = faces
    html = re.sub(r'<title>.*?</title>', f'<title>{TITLE}</title>\n<meta name="short-title" content="Board outline 3D">\n<meta name="description" content="{DESC}">', html, count=1, flags=re.S)
    html = html.replace('<style>', '<link rel="stylesheet" href="../styles/jumperless.css">\n<style>', 1)
    html = html.replace('<body>', '<body class="app">', 1)
    crumb = '<span class="eyebrow" id="crumb"><a href="../">slopswap</a> / <a href="./">V6</a> / <a href="' + README_PAGE + '">readme</a></span>'
    html, k = re.subn(r'<span class="eyebrow" id="crumb">.*?</span>', crumb, html, count=1)
    if k != 1:
        sys.exit('the viewer has no crumb to replace')
    html = html.replace('</head>', EXTRA + '</head>', 1)
    if 'fonts.googleapis' in html or 'cdn.' in html:
        sys.exit('the page still asks another site for something')
    (site / 'V6' / PAGE).write_text(html)
    print(f'wrote V6/{PAGE} ({len(html) // 1024} KB)')


def readme(site: Path) -> None:
    import markdown
    md = (HERE / 'README.md').read_text()
    md = re.sub(r'^# .*\n', '', md, count=1)
    body = markdown.markdown(md, extensions=['tables', 'fenced_code', 'sane_lists'])
    body = body.replace('<table>', '<div class="table-wrap">\n<table>').replace('</table>', '</table>\n</div>')
    figs = ''
    for name, cap in (('board-outline-on-sketch.png', 'The outline (pink) laid over the notebook page it was traced from: the viewer\'s sketch underlay, seen from above.'),
                      ('board-outline-inputs.png', 'From the top edge: the click wheel under the top board at the corner, a nav switch through it, two button holes. Left, the pickers and the per-board tick boxes of the selected part.')):
        if (site / 'V6' / name).exists():
            figs += '<figure><a href="%s"><img src="%s" alt="%s"></a><figcaption>%s</figcaption></figure>\n' % (name, name, cap.split(':')[0], cap)
    page = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>V6 board outline and stack: the readme</title>
<meta name="short-title" content="V6 outline readme">
<meta name="description" content="How the V6 board outline tool works and what it found: the outline traced from the sketch, the 0.1 inch stacking rule, spaced boards, the input parts and where each lands, the checks, and what is not verified.">
<link rel="stylesheet" href="../styles/jumperless.css">
<style>
  figure{margin:0 0 1.4em} figure img{display:block;border:1px solid var(--line);border-radius:6px}
  .get{display:flex;flex-wrap:wrap;gap:.6rem 1rem;margin:0 0 1.6em;padding:0;list-style:none}
  .get a{display:inline-block;padding:.5em .9em;border:1px solid var(--line);border-radius:6px;background:var(--surface);text-decoration:none;color:var(--fg)}
  .get a:hover{border-color:var(--c,var(--accent))} .get a b{color:var(--c,var(--accent))}
  td,th{vertical-align:top}
</style>
</head>
<body>
<main class="page wide">
<p class="eyebrow"><a href="../">slopswap</a> / <a href="./">V6</a></p>
<h1>V6 board outline and stack</h1>
<p class="muted">The readme of <code>JumperlessV6/v6mech</code>, %s. Kevin Cappuccio with Claude.</p>
<ul class="get cycle">
  <li><a href="%s"><b>Open the 3D viewer</b></a></li>
  <li><a href="%s" download><b>Download the folder</b> (.zip, %s MB): parameters, source, KiCad and DXF outlines, STEP</a></li>
</ul>
%s
%s
<hr>
<p class="muted">Jumperless V6 is a work in progress. Part models in the viewer and the zip: KiCad library (CC-BY-SA 4.0 with the library exception), SparkFun (CC-BY 4.0), Adafruit (MIT); the parts library's footprints and models are EasyEDA's, by LCSC number, unchecked; <code>models/SOURCES.md</code> in the zip says which is which.</p>
</main>
</body>
</html>
""" % (rev(), PAGE, ZIP, '%.1f' % ((site / 'V6' / ZIP).stat().st_size / 1e6), figs, body)
    (site / 'V6' / README_PAGE).write_text(page)
    print('  %s: %d KB' % (README_PAGE, len(page) // 1024))


def rev() -> str:
    import json
    return 'rev ' + json.loads((HERE / 'v6_outline.json').read_text())['meta']['rev']


def archive(site: Path) -> None:
    keep = ['README.md', 'v6_outline.json', 'V6_outline_viewer.html', 'build.mjs', 'step_export.py']
    dirs = ['src', 'tools', 'ref', 'models', 'out/integrated', 'out/removable']
    files = [HERE / k for k in keep]
    for d in dirs:
        files += [p for p in sorted((HERE / d).rglob('*')) if p.is_file()]
    # ref/ez is prep_parts.py's cache of raw EasyEDA downloads (90 MB): the script fetches it again, so it is not shipped
    files = [p for p in files if '/src/models/' not in p.as_posix() and '/ref/ez/' not in p.as_posix() and '__pycache__' not in p.parts and p.name != '.DS_Store']
    out = site / 'V6' / ZIP
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in files:
            z.write(p, 'v6mech/' + p.relative_to(HERE).as_posix())
    print('  %s: %d files, %.1f MB' % (ZIP, len(files), out.stat().st_size / 1e6))


if __name__ == '__main__':
    if len(sys.argv) != 2 or not (Path(sys.argv[1]) / 'localize_fonts.py').exists():
        sys.exit(__doc__)
    site = Path(sys.argv[1]).resolve()
    for name in ('board-outline-on-sketch.png', 'board-outline-inputs.png'):
        src = HERE / 'docs' / name
        if src.exists():
            (site / 'V6' / name).write_bytes(src.read_bytes())
    viewer(site)
    archive(site)
    readme(site)
    print('now add or update the cards in V6/index.html, run build.py, look at _site/V6/, commit and push')
