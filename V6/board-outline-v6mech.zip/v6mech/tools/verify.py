#!/usr/bin/env python3
"""Dev check: re-read every emitted file with a different parser and compare it with resolved.json.
    pip install ezdxf cadquery shapely ;  python3 tools/verify.py
DXF through ezdxf, KiCad boards through a small s-expression reader, STEP through OpenCascade (CadQuery)."""
import json, os, re, sys, glob, math
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ok = True

def area(pts):
    return 0.5 * sum(pts[i - 1][0] * pts[i][1] - pts[i][0] * pts[i - 1][1] for i in range(len(pts)))

def sexpr(text):
    toks = re.findall(r'\(|\)|"(?:\\.|[^"\\])*"|[^\s()]+', text)
    pos = 0
    def parse():
        nonlocal pos
        t = toks[pos]; pos += 1
        if t == '(':
            lst = []
            while toks[pos] != ')':
                lst.append(parse())
            pos += 1
            return lst
        return t[1:-1] if t.startswith('"') else t
    tree = parse()
    assert pos == len(toks), 'trailing tokens'
    return tree

for mode in ('integrated', 'removable'):
    d = os.path.join(HERE, 'out', mode)
    R = json.load(open(os.path.join(d, 'resolved.json')))
    print('==', mode)
    boards = {}
    for L in R['layers']:
        loops = [e['outer'] for e in L['shape']] + [h for e in L['shape'] for h in e['holes']]
        want = sum(abs(area(e['outer'])) - sum(abs(area(h)) for h in e['holes']) for e in L['shape'])
        slug = L['id'] + '_' + re.sub(r'[^A-Za-z0-9]+', '_', L['name']).strip('_')
        # --- DXF
        import ezdxf
        doc = ezdxf.readfile(os.path.join(d, slug + '.dxf'))
        polys = [[(v.dxf.location.x, -v.dxf.location.y) for v in e.vertices] for e in doc.modelspace().query('POLYLINE') if e.dxf.layer == 'Edge.Cuts']
        closed = all(e.is_closed for e in doc.modelspace().query('POLYLINE') if e.dxf.layer == 'Edge.Cuts')
        got = sorted(abs(area(p)) for p in polys); exp = sorted(abs(area(p)) for p in loops)
        dx = len(got) == len(exp) and all(abs(a - b) < 0.01 for a, b in zip(got, exp)) and closed
        # --- KiCad
        tree = sexpr(open(os.path.join(d, slug + '.kicad_pcb')).read())
        assert tree[0] == 'kicad_pcb'
        thick = [float(x[1]) for it in tree if isinstance(it, list) and it[0] == 'general' for x in it[1:] if x[0] == 'thickness'][0]
        # the outline is lines, arcs and circles now. Three things are checked, none of them with the exporter's own code:
        # every end point is shared by exactly two primitives (so every loop is closed, with no gap and no branch); the loops
        # rebuilt from them have the areas of the resolved shape; and no point of either lies more than 0.02 mm from the other.
        prims = []
        for it in tree:
            if not (isinstance(it, list) and it[0] in ('gr_line', 'gr_arc', 'gr_circle', 'gr_poly') and ['layer', 'Edge.Cuts'] in it): continue
            g = {x[0]: [float(v) - 100 for v in x[1:3]] for x in it if isinstance(x, list) and x[0] in ('start', 'mid', 'end', 'center')}
            prims.append((it[0], g))
        native = all(k != 'gr_poly' for k, g in prims)
        def key(q): return (round(q[0], 4), round(q[1], 4))
        def arc_pts(g):
            (x1, y1), (x2, y2), (x3, y3) = g['start'], g['mid'], g['end']
            d = 2 * (x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2))
            cx = ((x1 * x1 + y1 * y1) * (y2 - y3) + (x2 * x2 + y2 * y2) * (y3 - y1) + (x3 * x3 + y3 * y3) * (y1 - y2)) / d
            cy = ((x1 * x1 + y1 * y1) * (x3 - x2) + (x2 * x2 + y2 * y2) * (x1 - x3) + (x3 * x3 + y3 * y3) * (x2 - x1)) / d
            r = math.hypot(x1 - cx, y1 - cy); a1 = math.atan2(y1 - cy, x1 - cx); a2 = math.atan2(y2 - cy, x2 - cx); a3 = math.atan2(y3 - cy, x3 - cx)
            def ccw(a, b): return (b - a) % (2 * math.pi)
            sweep = ccw(a1, a3) if ccw(a1, a2) < ccw(a1, a3) else -((a1 - a3) % (2 * math.pi))
            n = max(8, int(abs(sweep) * r / 0.05) + 2)
            return [(cx + r * math.cos(a1 + sweep * i / n), cy + r * math.sin(a1 + sweep * i / n)) for i in range(n + 1)]
        deg = {}; segs = []; kp = []
        for k, g in prims:
            if k == 'gr_circle':
                (cx, cy), (ex, ey) = g['center'], g['end']; r = math.hypot(ex - cx, ey - cy)
                kp.append([(cx + r * math.cos(2 * math.pi * i / 96), cy + r * math.sin(2 * math.pi * i / 96)) for i in range(96)]); continue
            pts = arc_pts(g) if k == 'gr_arc' else [tuple(g['start']), tuple(g['end'])]
            segs.append(pts)
            for q in (pts[0], pts[-1]): deg[key(q)] = deg.get(key(q), 0) + 1
        closed_k = all(v == 2 for v in deg.values())
        left = list(segs)
        while left and closed_k:
            loop = list(left.pop(0)); guard = 0
            while key(loop[0]) != key(loop[-1]) and guard < 5000:
                guard += 1; hit = None
                for i, sg in enumerate(left):
                    if key(sg[0]) == key(loop[-1]): hit = (i, sg[1:]); break
                    if key(sg[-1]) == key(loop[-1]): hit = (i, sg[::-1][1:]); break
                if hit is None: closed_k = False; break
                left.pop(hit[0]); loop += list(hit[1])
            kp.append(loop[:-1])
        gk = sorted(abs(area(p)) for p in kp)
        from shapely.geometry import LinearRing, Point
        dev = dev_r = 9.0
        if closed_k and len(gk) == len(exp):
            # the resolved shape is a polygon whose fillets are chords; an arc put back through its corners bulges past each chord by
            # the chord's sagitta (up to 0.05 mm here). So: every corner of the polygon must lie ON the rebuilt outline (dev), and the
            # rebuilt outline may leave the polygon by no more than that sagitta (dev_r).
            ra = [LinearRing(p) for p in kp]; rb = [LinearRing(p) for p in loops]; dev = dev_r = 0.0
            for p in loops: dev = max(dev, max(min(r.distance(Point(q)) for r in ra) for q in p))
            for p in kp: dev_r = max(dev_r, max(min(r.distance(Point(q)) for r in rb) for q in p[::2]))
        n_arc = sum(1 for k, g in prims if k == 'gr_arc'); n_line = sum(1 for k, g in prims if k == 'gr_line'); n_circ = sum(1 for k, g in prims if k == 'gr_circle')
        fps = [it for it in tree if isinstance(it, list) and it[0] == 'footprint']
        kc = native and closed_k and len(gk) == len(exp) and all(abs(a - b) < 0.05 + 0.12 * n_arc for a, b in zip(gk, exp)) and dev < 0.01 and dev_r < 0.06 and abs(thick - L['t']) < 1e-9
        print('  %-18s Edge.Cuts: %d lines, %d arcs, %d circles; every end point shared by two: %s; polygon corners off the outline by at most %.4f mm, outline off the polygon by at most %.4f (chord sagitta); footprints %d' % ('', n_line, n_arc, n_circ, 'yes' if closed_k else 'NO', dev, dev_r, len(fps)))
        boards[L['id']] = kp
        print('  %-18s loops %2d  net %8.1f mm2 (json %8.1f)  dxf %s  kicad %s' % (slug, len(exp), want, L['area'], 'ok' if dx else 'FAIL', 'ok' if kc else 'FAIL'))
        ok = ok and dx and kc and abs(want - L['area']) < 0.2
    # --- neighbours, redone with shapely from the KiCad files just read back and the WigLEDmag outline:
    #     a bare breadboard one unit pitch to either side must not overlap any board, and the engine's
    #     figure for a second whole unit (bottom board against bottom board) must be reproduced.
    try:
        from shapely.geometry import Polygon
        from shapely.ops import unary_union
        from shapely import affinity
        def shape(loops):
            loops = sorted(loops, key=lambda p: -abs(area(p)))
            out = []
            for lp in loops:
                pg = Polygon(lp).buffer(0)
                host = next((i for i, o in enumerate(out) if o.contains(pg.representative_point())), None)
                if host is None: out.append(pg)
                else: out[host] = out[host].difference(pg)
            return unary_union(out)
        ref = json.load(open(os.path.join(HERE, 'ref', 'wig_ref.json')))
        wig = Polygon(ref['outline']).buffer(0)
        pitch = R['planes']['pitch']
        every = unary_union([shape(v) for v in boards.values()] + ([wig] if mode == 'removable' else []))
        for side, dx_ in (('left', -pitch), ('right', pitch)):
            ov = every.intersection(affinity.translate(wig, dx_).buffer(-0.02)).area
            print('  bare breadboard on the %-5s overlap with the boards %.3f mm2  %s' % (side, ov, 'ok' if ov < 0.02 else 'FAIL'))
            ok = ok and ov < 0.02
        base = shape(boards[R['layers'][0]['id']]) if mode == 'integrated' else unary_union([shape(boards[R['layers'][0]['id']]), wig])
        allb = every
        mine = base.intersection(affinity.translate(allb.union(unary_union([Polygon(b['pts']).buffer(0) for p in R['parts'] for b in p['bodies'] if not b.get('slot')])), -pitch).buffer(-0.02)).area
        eng = [i['mm2'] for n in R['checks']['neighbours'] if n['id'] == 'unit_left' for i in n['items'] if i['what'].startswith(R['layers'][0]['id'] + ' ')]
        if mode == 'removable':
            mine = shape(boards[R['layers'][0]['id']]).intersection(affinity.translate(allb.union(unary_union([Polygon(b['pts']).buffer(0) for p in R['parts'] for b in p['bodies'] if not b.get('slot')])), -pitch).buffer(-0.02)).area
        same = bool(eng) and abs(mine - eng[0]) < 0.6 or (not eng and mine < 0.05)
        print('  second unit on the left: bottom board overlap %.1f mm2 by shapely, engine says %s  %s' % (mine, eng[0] if eng else 0, 'ok' if same else 'FAIL'))
        ok = ok and same
    except ImportError:
        print('  (shapely not installed: neighbour re-check skipped)')
    # --- pitch arithmetic, done here by hand rather than trusted from the engine
    P = R['planes']; n = (P['xr'] - P['xl']) / 2.54
    print('  pitch %.3f = %.4f x 2.54   columns at 2.54*k from the wig edge: first %.2f last %.2f, next unit first %.2f (gap %.2f = %d pitches)' % (
        P['xr'] - P['xl'], n, R['wig']['cols'][0], R['wig']['cols'][-1], P['pitch'] + R['wig']['cols'][0], P['pitch'] + R['wig']['cols'][0] - R['wig']['cols'][-1], round((P['pitch'] + R['wig']['cols'][0] - R['wig']['cols'][-1]) / 2.54)))
    ok = ok and abs(n - round(n)) < 1e-9
    # --- STEP
    step = os.path.join(d, 'V6_stack_%s.step' % mode)
    if os.path.exists(step):
        import cadquery as cq
        bb = cq.importers.importStep(step).val().BoundingBox()
        print('  STEP bbox x %.2f..%.2f  y %.2f..%.2f  z %.2f..%.2f' % (bb.xmin, bb.xmax, bb.ymin, bb.ymax, bb.zmin, bb.zmax))
print('ALL OK' if ok else 'FAILURES')
sys.exit(0 if ok else 1)
