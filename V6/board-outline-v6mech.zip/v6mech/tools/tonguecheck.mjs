#!/usr/bin/env node
// Jumperless V6 outline tool - where a cantilevered button's tongue is cut.
//   node tools/tonguecheck.mjs      exits 1 if any case below is wrong
// The rule: the U-shaped slot belongs to the frame's top board and to no other, whatever the stack and whichever board or
// face the switch is on. A board between the switch and the top board gets the switch's plain opening only.
// Each case is tested on the boards themselves: a point on each slot's side, 5 mm towards the root from the switch, must be
// board on every board but the top one and must be cut away on the top one.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
const here = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const require = createRequire(import.meta.url);
const Geo = require(path.join(here, 'src/geometry.js'));
const base = JSON.parse(fs.readFileSync(path.join(here, 'v6_outline.json'), 'utf8'));
const ref = JSON.parse(fs.readFileSync(path.join(here, 'ref/wig_ref.json'), 'utf8'));
// The keys are the two that stood to the right of the display until rev A10d took them out of the built-in design. The test
// puts them back, and the display back at x 30 where it then was, so the probes below fall on plain board.
const KEYS = [{ id: 'key1', type: 'btn_cantilever', x: 64.5, y: -5, rot: 90, tongue: { dir: 90 }, mount: { on: 'L1', side: 'top' } },
              { id: 'key2', type: 'btn_cantilever', x: 70.5, y: -5, rot: 90, tongue: { dir: 90 }, mount: { on: 'L1', side: 'top' } }];
const PROBES = [[64.5 - 1.9, -10], [70.5 - 1.9, -10]];          // on the left leg of each slot (tongue 3 wide, slot 0.8)

function inPoly(pt, poly) { let c = false; for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) { const a = poly[i], b = poly[j]; if ((a[1] > pt[1]) !== (b[1] > pt[1]) && pt[0] < (b[0] - a[0]) * (pt[1] - a[1]) / (b[1] - a[1]) + a[0]) c = !c; } return c; }
function isBoard(L, pt) { return L.shape.some((e) => inPoly(pt, e.outer) && !e.holes.some((h) => inPoly(pt, h))); }

const cases = [
  ['the two keys as they stood beside the display', (P) => {}, {}],
  ['a fourth board added on top', (P) => { P.stack.push({ id: 'L3', name: 'Skin', t: 0.8, gap: 0.5, kind: 'board' }); }, { far: true }],
  ['switches on the main board, top face', (P) => { P.parts.forEach((p) => { if (/^key/.test(p.id)) p.mount = { on: 'L0', side: 'top' }; }); }, { far: true }],
  ['switches hanging under the mid board', (P) => { P.parts.forEach((p) => { if (/^key/.test(p.id)) p.mount = { on: 'L1', side: 'bottom' }; }); }, { away: true }],
  ['switches under the top board (riding the tongue)', (P) => { P.parts.forEach((p) => { if (/^key/.test(p.id)) p.mount = { on: P.stack[P.stack.length - 1].id, side: 'bottom' }; }); }, { under: true }],
  ['two boards only (the top board 1.775 above the main board)', (P) => { P.stack.splice(1, 1); P.parts.forEach((p) => { if (/^key/.test(p.id)) p.mount = { on: 'L0', side: 'top' }; }); }, {}],
  ['main board ticked open for the keys by hand', (P) => { P.parts.forEach((p) => { if (/^key/.test(p.id)) p.open = { L0: true }; }); }, {}],
];
let bad = 0;
for (const mode of ['integrated', 'removable']) for (const [name, edit, want] of cases) {
  const P = JSON.parse(JSON.stringify(base)); P.wig.mode = mode;
  P.parts = P.parts.filter((p) => !/^key/.test(p.id)).concat(JSON.parse(JSON.stringify(KEYS)));
  P.parts.forEach((p) => { if (p.id === 'display') { p.type = 'display_tft220bar'; p.x = 30; p.y = -9.9; p.rot = 90; delete p.window; } });
  edit(P);
  const R = Geo.resolve(P, ref), top = R.layers[R.layers.length - 1], problems = [];
  for (const L of R.layers) PROBES.forEach((pt, i) => {
    const solid = isBoard(L, pt);
    if (L.id === top.id && solid) problems.push('no slot in ' + L.id + ' for key' + (i + 1));
    if (L.id !== top.id && !solid) problems.push('slot of key' + (i + 1) + ' cut in ' + L.id);
  });
  const ck = R.checks.cantilevers || [];
  if (ck.length !== 2) problems.push('checks list ' + ck.length + ' tongues');
  ck.forEach((k) => {
    if (k.board !== top.id) problems.push(k.id + ': the check names ' + k.board + ', not ' + top.id);
    for (const f of ['far', 'away', 'under']) if (!!k[f] !== !!want[f]) problems.push(k.id + ': ' + f + ' is ' + !!k[f] + ', should be ' + !!want[f]);
  });
  if (problems.length) bad++;
  console.log((problems.length ? 'FAIL ' : 'ok   ') + (mode + ': ' + name).padEnd(78) + (problems.length ? [...new Set(problems)].join('; ') : 'slots in ' + top.id + ' only'));
}
console.log(bad ? bad + ' case(s) wrong' : 'ALL OK');
process.exit(bad ? 1 : 0);
