#!/usr/bin/env node
// Jumperless V6 outline tool - build.
//   node build.mjs            writes out/<variant>/ (DXF, KiCad, SVG, report, resolved.json) for both variants
//                             and rebuilds V6_outline_viewer.html with v6_outline.json as its defaults
//   node build.mjs --dist     also writes dist/ (the viewer as separate files, for hosting)
//   node build.mjs --check    also fails (exit 1) if two parts clash, a bare breadboard no longer fits beside the unit, or the
//                             extender (when it is on) overlaps the unit or does not meet its socket
// No dependencies: plain Node 18+.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';

const here = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const Geo = require('./src/geometry.js');
const Exp = require('./src/exporters.js');
const Mag = require('./src/magmodel.js');
const args = process.argv.slice(2);
const read = (f) => fs.readFileSync(path.join(here, f), 'utf8');

const params = JSON.parse(read('v6_outline.json'));
const ref = JSON.parse(read('ref/wig_ref.json'));

let failed = false;
for (const mode of ['integrated', 'removable']) {
  const P = JSON.parse(JSON.stringify(params));
  P.wig.mode = mode;
  const R = Geo.resolve(P, ref);
  R.checks.mag = Mag.report(R, P);                    // the magnetometer layout's numbers, for the report and resolved.json
  const dir = path.join(here, 'out', mode);
  fs.mkdirSync(dir, { recursive: true });
  const fresh = new Set(R.layers.flatMap((L) => [Exp.slug(L) + '.dxf', Exp.slug(L) + '.kicad_pcb']));
  for (const f of fs.readdirSync(dir)) {              // drop files left from layers that were renamed or removed
    if (!/\.(dxf|kicad_pcb)$/.test(f) || fresh.has(f) || /^WT_/.test(f) || (R.extender && /^EX_/.test(f))) continue;
    try { fs.rmSync(path.join(dir, f)); } catch (e) { console.warn('could not remove stale ' + f + ' (' + e.code + ')'); }
  }
  for (const L of R.layers) {
    fs.writeFileSync(path.join(dir, Exp.slug(L) + '.dxf'), Exp.dxf(R, L));
    fs.writeFileSync(path.join(dir, Exp.slug(L) + '.kicad_pcb'), Exp.kicad(R, L));
  }
  const face = Exp.kicadFace(R);
  if (face) fs.writeFileSync(path.join(dir, 'WT_wig_top_board.kicad_pcb'), face);
  if (R.extender) { fs.writeFileSync(path.join(dir, 'EX_Extender_board.kicad_pcb'), Exp.kicadExt(R)); fs.writeFileSync(path.join(dir, 'EX_Extender_board.dxf'), Exp.dxfExt(R)); }      // the extender's bottom board, on the unit's datum
  const pretty = path.join(dir, 'v6mech.pretty');           // the library footprints used on the boards, for KiCad's footprint library table
  fs.mkdirSync(pretty, { recursive: true });
  for (const f of fs.readdirSync(pretty)) if (/\.kicad_mod$/.test(f)) { try { fs.rmSync(path.join(pretty, f)); } catch (e) { /* a folder that will not let go: the next write replaces it */ } }
  for (const [name, text] of Object.entries(Exp.kicadMods(R))) fs.writeFileSync(path.join(pretty, name + '.kicad_mod'), text);
  fs.writeFileSync(path.join(dir, 'plan.svg'), Exp.svg(R));
  fs.writeFileSync(path.join(dir, 'checks.txt'), Exp.report(R));
  fs.writeFileSync(path.join(dir, 'resolved.json'), JSON.stringify(Geo.plain(R)));
  console.log(Exp.report(R));
  if (R.checks.clashes.length || R.checks.blocked.length || R.checks.neighbours.some((n) => /^wig/.test(n.id) && n.overlap_mm2)) failed = true;
  if (R.checks.extender && (R.checks.extender.overlap.overlap_mm2 || (R.checks.extender.port && (!R.checks.extender.port.faces || R.checks.extender.port.open_seam)) || (R.checks.extender.seam_col && !R.checks.extender.seam_col.fits))) failed = true;       // an extender that is shown has to stand clear of the unit and meet its socket
}

// the single-file viewer: everything inlined so it opens from disk with no network
const esc = (s) => s.replace(/<\/script/gi, '<\\/script');
const inline = (f) => '<script>\n' + esc(read(f)) + '\n</script>';
const data = '<script>\nwindow.V6_DEFAULTS = ' + esc(JSON.stringify(params)) + ';\nwindow.V6_REF = ' + esc(JSON.stringify(ref)) + ';\n</script>';
const app = [inline('src/models.js'), inline('src/partmodels.js'), inline('src/switchmodels.js'), inline('src/sketch.js'), data, inline('src/partlib.js'), inline('src/switchlib.js'), inline('src/catalog.js'), inline('src/magmodel.js'), inline('src/geometry.js'), inline('src/exporters.js'), inline('src/state.js'), inline('src/render.js'), inline('src/magtab.js'), inline('src/viewer.js')].join('\n');
// the three typefaces of the console look (all SIL OFL), inlined so the single file needs no network; dist/ gets them as files
const FONTS = [['Archivo Narrow', 'ArchivoNarrow-var.woff2', '400 700'], ['Michroma', 'Michroma-400.woff2', '400'], ['IBM Plex Mono', 'IBMPlexMono-400.woff2', '400'], ['IBM Plex Mono', 'IBMPlexMono-500.woff2', '500'], ['IBM Plex Mono', 'IBMPlexMono-600.woff2', '600']];
const fontCss = (url) => FONTS.map(([fam, file, w]) => '@font-face{font-family:"' + fam + '";src:url(' + url(file) + ') format("woff2");font-weight:' + w + ';font-display:swap}').join('\n');
const b64font = (file) => 'data:font/woff2;base64,' + fs.readFileSync(path.join(here, 'src/fonts', file)).toString('base64');
const html = read('src/viewer.html').replace('/*__FONTS__*/', fontCss(b64font));
const htmlDist = read('src/viewer.html').replace('/*__FONTS__*/', fontCss((f) => 'fonts/' + f));
const vendorInline = ['src/vendor/three.min.js', 'src/vendor/OrbitControls.js', 'src/vendor/clipper.js'].map(inline).join('\n');
fs.writeFileSync(path.join(here, 'V6_outline_viewer.html'), html.replace('/*__SCRIPTS__*/', vendorInline + '\n' + app));
if (args.includes('--dist')) {     // the same page as separate files, for hosting
  const dist = path.join(here, 'dist');
  fs.mkdirSync(path.join(dist, 'vendor'), { recursive: true });
  const files = ['vendor/three.min.js', 'vendor/OrbitControls.js', 'vendor/clipper.js', 'models.js', 'partmodels.js', 'switchmodels.js', 'sketch.js', 'data.js', 'partlib.js', 'switchlib.js', 'catalog.js', 'magmodel.js', 'geometry.js', 'exporters.js', 'state.js', 'render.js', 'magtab.js', 'viewer.js'];
  fs.mkdirSync(path.join(dist, 'fonts'), { recursive: true });
  for (const [, f] of FONTS) fs.copyFileSync(path.join(here, 'src/fonts', f), path.join(dist, 'fonts', f));
  for (const f of files) if (f !== 'data.js') fs.copyFileSync(path.join(here, 'src', f), path.join(dist, f));
  fs.writeFileSync(path.join(dist, 'data.js'), 'window.V6_DEFAULTS = ' + JSON.stringify(params) + ';\nwindow.V6_REF = ' + JSON.stringify(ref) + ';\n');
  fs.writeFileSync(path.join(dist, 'index.html'), htmlDist.replace('/*__SCRIPTS__*/', files.map((f) => '<script src="' + f + '"></script>').join('\n')));
}
console.log('wrote V6_outline_viewer.html (' + Math.round(fs.statSync(path.join(here, 'V6_outline_viewer.html')).size / 1024) + ' KB) and out/integrated, out/removable');
if (args.includes('--check') && failed) { console.error('CHECK FAILED: see the !! lines above'); process.exit(1); }
